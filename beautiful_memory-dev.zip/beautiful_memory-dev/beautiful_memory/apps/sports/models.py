from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class SportsVideoModel(SpareFieldModel):

    original_file_name = models.CharField(max_length=128, verbose_name='原文件名')
    new_file_name = models.CharField(max_length=128, verbose_name='新文件名')
    file_url = models.CharField(max_length=128, verbose_name='文件地址')
    batch = models.CharField(max_length=64, verbose_name='批次号')
    client_count = models.SmallIntegerField(verbose_name='单批次客户端数量')
    device_id = models.CharField(max_length=128, null=True, blank=True, verbose_name='设备标识')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        verbose_name = '运动视频表'
        verbose_name_plural = verbose_name
        db_table = 't_sports_video'