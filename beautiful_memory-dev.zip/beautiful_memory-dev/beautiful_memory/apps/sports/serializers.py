#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2022/4/2下午3:38
#@Author:zwz

from rest_framework import serializers
from .models import SportsVideoModel

class SportsVideoSerializer(serializers.ModelSerializer):

    class Meta:
        model = SportsVideoModel
        fields = ('id', 'file_url', 'batch', 'device_id')