import asyncio
import json
import logging
import time
import traceback
import uuid
from datetime import datetime
from django.conf import settings
from django.shortcuts import render

# Create your views here.
from kafka import KafkaProducer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from beautiful_memory.settings import KAFKA_SERVERS
from sports import serializers
from sports.models import SportsVideoModel
from user.models import Face
from utils.common import async_upload_qiniu
from video.models import WonderfulVideoTemplateContentRet, TemplateVideo, WonderfulVideoRet

producer = KafkaProducer(bootstrap_servers=KAFKA_SERVERS, value_serializer=lambda v: json.dumps(v).encode(),
                         key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip')
logger = logging.getLogger('django')

class FileUploadView(APIView):

    def post(self, request, *args, **kwargs):
        try:
            device_id = request.data.get('device_id', None)
            batch = request.data.get('batch', None)
            client_count = request.data.get('client_count', None)
            logger.info('==============视频开始上传：'+json.dumps({
                'device_id': device_id,
                'batch': batch,
                'client_count': client_count,
            }))
            if not all([batch, client_count]):
                return Response(data={'detail': '参数不完整'}, status=status.HTTP_200_OK)
            file = request.FILES.get("file")
            if not file:
                return Response(data={'detail': '未获取到文件信息'}, status=status.HTTP_400_BAD_REQUEST)
            format = '.' + file.name.split('.')[-1]
            loop = asyncio.new_event_loop()
            ret = loop.run_until_complete(async_upload_qiniu(file.read(), format))
            loop.close()
            if not ret:
                logger.error('================上传七牛失败！')
                return Response(data={'detail': '失败'}, status=status.HTTP_400_BAD_REQUEST)
            # 入库
            file_url = settings.STORAGE_HOST_QINIU + ret[0]
            sv = SportsVideoModel.objects.create(original_file_name=file.name, new_file_name=ret[1], file_url=file_url, batch=batch, client_count=client_count, device_id=device_id)
            # 入队列
            sv_count = SportsVideoModel.objects.filter(batch=batch).count()
            # print(111, sv_count, client_count)
            if sv_count == int(client_count):

                sv_set = SportsVideoModel.objects.filter(batch=batch)
                video_id = []
                video_url = []
                device_id = []
                for sv in sv_set:
                    video_id.append(sv.id)
                    video_url.append(sv.file_url)
                    device_id.append(sv.device_id)
                value = {
                    'batch': batch,
                    'video_id': video_id,
                    'video_url': video_url,
                    'device_id': device_id
                }
                try:
                    future = producer.send(settings.SPORTS_VIDEO_TOPIC, value=value)
                    future.get(timeout=100)
                except:
                    logger.error(f'运动会视频入kafka队列失败,Video_ID:{sv.id}')
                    logger.error(traceback.format_exc(), exc_info=True)
                    return Response(data={'detail': '视频入队异常'}, status=status.HTTP_400_BAD_REQUEST)
            data = {
                'file_url': settings.STORAGE_HOST_QINIU + ret[0]
            }
        except:
            logger.error('==================上传过程出错导致上传失败！')
            logger.error(traceback.format_exc(), exc_info=True)
            return Response(data={'detail': '上传过程出错导致上传失败!'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data=data, status=status.HTTP_200_OK)


class GetLeaderVideo(APIView):

    def post(self, request, *args, **kwargs):
        leader_video = request.FILES.get('leader_video', None)
        leader_feng = request.FILES.get('leader_feng', None)

        if not all([leader_video, leader_feng]):
            return Response(data={'detail': '参数不完整'}, status=status.HTTP_200_OK)

        format_video = '.' + leader_video.name.split('.')[-1]
        format_feng = '.' + leader_feng.name.split('.')[-1]

        loop = asyncio.new_event_loop()
        ret_video = loop.run_until_complete(async_upload_qiniu(leader_video.read(), format_video))
        ret_feng = loop.run_until_complete(async_upload_qiniu(leader_feng.read(), format_feng))
        loop.close()
        if not [ret_video, ret_feng]:
            return Response(data={'detail': '失败'}, status=status.HTTP_400_BAD_REQUEST)
        leader_faces = Face.objects.filter(spare_int1=1)
        temp_obj = TemplateVideo.objects.filter(name='时尚版').first()
        wonderful_video_ret_obj = WonderfulVideoRet.objects.filter(id='00d31056b73e11ec98050242c0a80005').first()
        for i in leader_faces:
            leader_obj = WonderfulVideoTemplateContentRet(
                id=uuid.uuid1().hex,
                video_url=settings.STORAGE_HOST_QINIU + ret_video[0],
                square_image_url=settings.STORAGE_HOST_QINIU + ret_feng[0],
                template_video=temp_obj,
                create_time=datetime.now(),
                wonderful_video_ret=wonderful_video_ret_obj,
                user=i.user,
                non_square_image_url=settings.STORAGE_HOST_QINIU + ret_feng[0],
                status=1,
                is_show=1)
            leader_obj.save()
        data = {
            'file_video_url': settings.STORAGE_HOST_QINIU + ret_video[0],
            'file_feng_url': settings.STORAGE_HOST_QINIU + ret_feng[0]
        }
        return Response(data=data, status=status.HTTP_200_OK)


class MakeVideoTemplate(APIView):

    def post(self, request, *args, **kwargs):

        video_start_url = request.FILES.get('video_start_url', None)
        video_end_url = request.FILES.get('video_end_url', None)
        template_image_url = request.FILES.get('template_image_url', None)

        video_music_url = request.FILES.get('video_music_url', None)
        lut_url = request.FILES.get('lut_url', None)
        mask_url = request.FILES.get('mask_url', None)
        template_image2_url = request.FILES.get('template_image2_url', None)

        video_start_url_format = '.' + video_start_url.name.split('.')[-1]
        video_end_url_format = '.' + video_end_url.name.split('.')[-1]
        template_image_url_format = '.' + template_image_url.name.split('.')[-1]

        loop = asyncio.new_event_loop()
        ret_video_start_url = loop.run_until_complete(async_upload_qiniu(video_start_url.read(), video_start_url_format))
        ret_video_end_url = loop.run_until_complete(async_upload_qiniu(video_end_url.read(), video_end_url_format))
        ret_template_image_url = loop.run_until_complete(async_upload_qiniu(template_image_url.read(), template_image_url_format))
        loop.close()

        if not [ret_video_start_url, ret_video_end_url, ret_template_image_url]:
            return Response(data={'detail': '失败'}, status=status.HTTP_400_BAD_REQUEST)

        ret_video_start_url = settings.STORAGE_HOST_QINIU + ret_video_start_url[0]
        ret_video_end_url = settings.STORAGE_HOST_QINIU + ret_video_end_url[0]
        ret_template_image_url = settings.STORAGE_HOST_QINIU + ret_template_image_url[0]

        temp_video = TemplateVideo.objects.filter(id=6).update(video_start_url=ret_video_start_url,
                                                               video_end_url=ret_video_end_url,
                                                               template_image_url=ret_template_image_url,
                                                               template_image2_url=ret_template_image_url)

        data = {
            'ret_video_start_url': ret_video_start_url,
            'ret_video_end_url': ret_video_end_url,
            'ret_template_image_url': ret_template_image_url,
        }
        return Response(data=data, status=status.HTTP_200_OK)
