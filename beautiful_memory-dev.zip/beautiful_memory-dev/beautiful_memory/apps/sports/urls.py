#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2022/4/1下午1:34
#@Author:zwz
from django.urls import path

from sports.views import FileUploadView, GetLeaderVideo, MakeVideoTemplate

urlpatterns = [
    path('file_upload', FileUploadView.as_view()),
    path('leader_file_upload', GetLeaderVideo.as_view()),
    path('make_video_template', MakeVideoTemplate.as_view()),
]