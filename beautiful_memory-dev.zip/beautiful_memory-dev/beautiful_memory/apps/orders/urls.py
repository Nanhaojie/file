#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/17上午10:51
#@Author:zwz
from django.urls import path
from apps.orders.views import PlaceOrderView, OrderInfoView, PaymentNotice, PlotformCert
from orders.views_coupon import CouponListView, CouponAggView, CouponVideoPrice, DefaultCouponPrice, RedeemCouponView

urlpatterns = [
    path('place_order', PlaceOrderView.as_view()),      # 统一下单
    path('payment_notice', PaymentNotice.as_view()),# 支付结果通知接收
    path('platform_cert', PlotformCert.as_view()),  # 支付结果通知接收

    path('info', OrderInfoView.as_view({'get': 'list'})),          # 订单信息
    path('info/<int:pk>', OrderInfoView.as_view({'delete': 'destroy'})),          # 订单信息


    path('redeem_coupons', RedeemCouponView.as_view()),  # 兑换优惠劵列表
    path('coupon', CouponListView.as_view()),  # 优惠劵列表
    path('discount_price', CouponVideoPrice.as_view()),  # 优惠价格
    path('default_discount', DefaultCouponPrice.as_view()),  # 默认优惠劵
    path('agg_coupon', CouponAggView.as_view()),  # 优惠劵列表
]