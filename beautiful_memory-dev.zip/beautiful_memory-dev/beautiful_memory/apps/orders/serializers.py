#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/9/18上午11:20
# @Author:zwz
from django.conf import settings
from django.utils.timezone import now
from rest_framework import serializers, status
from .models import Order, Coupon, RedeemCoupon


class RedeemCouponSerializer(serializers.ModelSerializer):

    class Meta:
        model = RedeemCoupon
        fields = ('value', 'create_time', 'expiration_date', 'type', 'use_time', 'write_off_code', 'id', 'note', 'spare_str1')
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'expiration_date': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'use_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }



class CouponListSerializer(serializers.ModelSerializer):
    is_used = serializers.IntegerField()
    create_time = serializers.DateTimeField(format=settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)

    class Meta:
        model = Coupon
        fields = ('name', 'create_time', 'is_used', 'discount_type', 'value', 'id')


class OrderSerializer(serializers.ModelSerializer):
    video_make_time = serializers.DateTimeField(source='wonderful_video_ret.create_time',
                                                format=settings.SERIALIZER_DATE_FIELD_FORMAT, allow_null=True)
    template_image_url = serializers.DateTimeField(source='commodity.template_image_url', allow_null=True)
    place_order_time = serializers.DateTimeField(source='create_time', format=settings.SERIALIZER_DATE_FIELD_FORMAT,
                                                 allow_null=True)
    # tem_url = serializers.CharField(max_length=256, allow_null=True)

    class Meta:
        model = Order
        fields = ('id', 'place_order_time', 'order_type', 'video_make_time', 'original_price', 'actual_payment', 'state',
                  'pay_time', 'template_image_url')
        extra_kwargs = {
            'pay_time': {'format': '%H:%M'}
        }
