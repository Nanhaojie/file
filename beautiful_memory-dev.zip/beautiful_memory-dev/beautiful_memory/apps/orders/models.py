from django.db import models

# Create your models here.
from video.models import WonderfulVideoRet, TemplateVideo
from utils.models import SpareFieldModel


class Coupon(SpareFieldModel):
    discount_type_choices = (
        (1, "金额优惠"),
        (2, "折扣优惠"),
    )
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, related_name="coupons", db_constraint=False)
    name = models.CharField(max_length=128, verbose_name='优惠劵名字')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    is_used = models.BooleanField(verbose_name='是否被使用')
    discount_type = models.SmallIntegerField(choices=discount_type_choices, default=1, verbose_name='优惠类型')
    value = models.DecimalField(max_digits=7, decimal_places=2, verbose_name='面额/折扣')

    class Meta:
        verbose_name = '优惠劵表'
        verbose_name_plural = verbose_name
        db_table = 't_coupon'


class Order(SpareFieldModel):
    """
    精彩视频结果模板内容表
    """
    type_choices = [
        (1, '视频下载'),
    ]
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, related_name="orders", db_constraint=False)
    commodity = models.ForeignKey(TemplateVideo, on_delete=models.DO_NOTHING, null=True, blank=True, verbose_name='商品(模板视频)')
    order_number = models.CharField(max_length=128, unique=True, verbose_name='订单编号')
    wx_transaction_id = models.CharField(max_length=32, null=True, blank=True, verbose_name='微信支付订单号')
    prepay_id = models.CharField(max_length=40, verbose_name='预支付交易会话标识')
    wonderful_video_ret = models.ForeignKey(WonderfulVideoRet, null=True, blank=True, on_delete=models.DO_NOTHING, db_constraint=False)
    coupon = models.ForeignKey(Coupon, null=True, blank=True, on_delete=models.DO_NOTHING, db_constraint=False)
    original_price = models.DecimalField(max_digits=7, decimal_places=2, verbose_name='原价')
    actual_payment = models.DecimalField(max_digits=7, decimal_places=2, verbose_name='实际支付价格')
    order_type = models.SmallIntegerField(choices=type_choices, default=1, verbose_name='订单类型')
    state = models.SmallIntegerField(default=0, verbose_name='支付状态')   # 0:待支付  1:已支付
    pay_time = models.DateTimeField(null=True, blank=True, verbose_name='支付时间')
    is_delete = models.BooleanField(default=False, verbose_name='是否被删除')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    create_date = models.DateField(auto_now_add=True, verbose_name='创建日期')

    class Meta:
        verbose_name = '订单表'
        verbose_name_plural = verbose_name
        db_table = 't_order'


class WXInterfaceRecord(SpareFieldModel):

    merchant_id = models.CharField(max_length=16, null=True, blank=True, verbose_name='商户号')
    out_trade_no = models.CharField(max_length=64, null=True, blank=True, verbose_name='商户订单号')
    wx_transaction_id = models.CharField(max_length=32, null=True, blank=True, verbose_name='微信支付订单号')
    name = models.CharField(max_length=32, null=True, blank=True, verbose_name='接口名称')
    path = models.CharField(max_length=128, null=True, blank=True, verbose_name='接口path')
    type = models.CharField(max_length=8, verbose_name='类型')    # CALL:调用  RECEIVE：接收
    req_headers = models.TextField(max_length=3000, null=True, blank=True, verbose_name='请求头')
    req_body = models.TextField(max_length=3000, null=True, blank=True, verbose_name='请求体')
    resp_headers = models.TextField(max_length=3000, null=True, blank=True, verbose_name='响应头')
    resp_body = models.CharField(max_length=1024, null=True, blank=True, verbose_name='响应体')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        verbose_name = '微信接口记录表'
        verbose_name_plural = verbose_name
        db_table = 't_wx_interface_record'


class RedeemCoupon(SpareFieldModel):
    type_choices = (
        (1, "视频优惠券"),
        (2, "现金优惠券"),
        (3, "现金免单劵"),
    )
    name = models.CharField(max_length=128, verbose_name='优惠劵名字')
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, related_name="redeem_coupons", db_constraint=False)
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, related_name="redeem_coupons",
                              db_constraint=False)
    value = models.CharField(max_length=16, verbose_name='面额/内容')
    note = models.CharField(max_length=512, null=True, blank=True, verbose_name='备注')
    rule = models.CharField(max_length=1024, null=True, blank=True, verbose_name='使用规则')
    is_used = models.BooleanField(default=0, verbose_name='是否被使用')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='发放时间')
    use_time = models.DateTimeField(null=True, blank=True, verbose_name='使用时间')
    expiration_date = models.DateTimeField(db_index=True, verbose_name='过期时间')
    write_off_code = models.CharField(max_length=16, null=True, blank=True, verbose_name='核销码')
    type = models.SmallIntegerField(choices=type_choices, verbose_name='优惠劵类型')

    class Meta:
        verbose_name = '兑换/优惠劵表'
        verbose_name_plural = verbose_name
        db_table = 't_redeem_coupon'
        indexes = [
            models.Index(fields=['scene', 'write_off_code'], name='scene_write_off_code'),
        ]
        ordering = ('-use_time', '-id', )
