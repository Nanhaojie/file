# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import datetime
import logging
from decimal import Decimal

from django.db import connection
from django.utils.timezone import now
from rest_framework import status
from rest_framework.generics import ListAPIView, RetrieveAPIView, CreateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from beautiful_memory import settings
from orders import serializers
from orders.models import Coupon, RedeemCoupon
from orders.serializers import RedeemCouponSerializer

logger = logging.getLogger('django')


class RedeemCouponView(ListAPIView):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return RedeemCouponSerializer

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        queryset = RedeemCoupon.objects.filter(scene_id=scene_id, user=self.request.user)

        # 根据状态进行筛选 (0, 未使用; 1, 已使用; 2, 已过期)
        coupon_type = self.request.query_params.get('type')
        if coupon_type == '2':
            queryset = queryset.filter(is_used=False, expiration_date__lt=now())
        elif coupon_type == '1':
            queryset= queryset.filter(is_used=True)
        elif coupon_type == '0':
            queryset = queryset.filter(is_used=False).exclude(expiration_date__lt=now())
        return queryset

    def get(self, request, *args, **kwargs):
        scene_id = self.request.query_params.get('scene_id')
        if not scene_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        coupon_type = self.request.query_params.get('type')
        if coupon_type not in ('0', '1', '2', None):
            return Response({'detail': 'type字段 参数错误'}, status=status.HTTP_400_BAD_REQUEST)

        return self.list(request, *args, **kwargs)


class DefaultCouponPrice(RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = serializers.CouponListSerializer

    def get(self, request, *rags, **kwargs):
        user_id = request.user.id
        instance = Coupon.objects.filter(is_used=0, user_id=user_id).first()
        if not instance:
            return Response({'detail': '没有可以使用的优惠劵'}, status=209)
        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class CouponVideoPrice(APIView):

    def get(self, request, *rags, **kwargs):
        coupon_id = request.query_params.get('coupon_id')
        price = request.query_params.get('price')

        if not all([coupon_id, price]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            coupon = Coupon.objects.get(id=coupon_id)
            coupon_value = coupon.value
        except Exception:
            logger.error(f'优惠劵{coupon_id}面值不存在', exc_info=True)
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            actual_price = Decimal(price) - coupon_value
            return Response({
                'discount_price': coupon_value,
                'actual_price': actual_price if actual_price > 0 else 0.01,
                'detail': '成功'
            }
            )


class CouponListView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = serializers.CouponListSerializer

    def get_queryset(self):
        user = self.request.user
        list_type = self.request.query_params.get('type')
        # 获取所有优惠劵
        if list_type == '0':
            query_set = Coupon.objects.filter(user_id=user.id)
        # 获取未使用的优惠劵
        elif list_type == '1':
            query_set = Coupon.objects.filter(user_id=user.id, is_used=0)
        elif list_type == '2':
            query_set = Coupon.objects.filter(user_id=user.id, is_used=1)
        else:
            raise Exception('type error')
        return query_set.order_by('-id')

    def get(self, request, *args, **kwargs):
        if request.query_params.get('type') not in ('0', '1', '2'):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        return super(CouponListView, self).get(request, *args, **kwargs)


class CouponAggView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT COUNT(id) as num, is_used 
                FROM t_coupon
                WHERE user_id = %s
                GROUP BY is_used
                """, (request.user.id.hex,))
            rows = cursor.fetchall()
            data = {'all': 0, 'not_used': 0, 'used': 0}
            for num, is_used in rows:
                if is_used == 0:
                    data['not_used'] = num
                else:
                    data['used'] = num
                data['all'] += num
        return Response(data)
