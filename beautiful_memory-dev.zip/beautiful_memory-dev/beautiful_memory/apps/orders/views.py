import base64
import datetime
import json
import logging
import time
from decimal import Decimal

import requests
from django.conf import settings
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from itsdangerous import TimedJSONWebSignatureSerializer as TJWSSerializer, BadData

from orders import serializers
from orders.models import Order, Coupon, WXInterfaceRecord
from system.models import KeyBookModel
from utils.common import WXAuthorization, order_num, place_order_wx3, rsa_verify, decrypt
from urllib import parse
from video.models import WonderfulVideoRet

logger = logging.getLogger("django")


class PlaceOrderView(APIView):
    permission_classes = (IsAuthenticated,)

    # 统一下单
    def post(self, request, *args, **kwargs):
        user = request.user
        open_id = user.open_id
        phone = user.mobile
        req_data = request.data
        coupon_id = req_data.get('coupon_id')  # 优惠券ID
        original_price = req_data.get('original_price')  # 原价金额 单位元
        price_token = req_data.get('price_token')  # 原价金额 单位元
        actual_payment = req_data.get('actual_payment')  # 实付 单位元
        description = req_data.get('description')  # 描述
        play_record_id = req_data.get('play_record_id')  # 游玩记录id
        template_video_id = req_data.get('template_video_id')  # 模板id
        if not all([original_price, play_record_id, template_video_id, description, price_token]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
        if not actual_payment and actual_payment != 0:
            return Response(data={"detail": "待付款金额不正确"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            original_price, actual_payment = float(original_price), float(actual_payment)
        except Exception:
            logger.warning('参数类型错误', exc_info=True)
            return Response(data={"detail": "参数类型错误"}, status=status.HTTP_400_BAD_REQUEST)

        # 校验实际金额和 （原价token中的价格 - 优惠劵优惠价格） 是否一致
        serializer = TJWSSerializer(settings.SECRET_KEY, settings.PRICE_TOKEN_EXPIRES)
        try:
            real_original_price = serializer.loads(price_token)
        except Exception:
            logger.warning(f'解析real_original_price失败', exc_info=True)
            return Response(data={"detail": "price_token解析错误"}, status=status.HTTP_400_BAD_REQUEST)

        # 校验优惠劵是否使用
        if coupon_id:
            coupon_obj = Coupon.objects.filter(id=coupon_id, user_id=user.id, is_used=0).first()
            if not coupon_obj:
                return Response(data={"detail": "优惠券已使用"}, status=status.HTTP_400_BAD_REQUEST)
            actual_price = Decimal(real_original_price) - coupon_obj.value
            actual_price = actual_price if actual_price > 0 else 0.01
            real_actual_payment = float(actual_price)
        else:
            real_actual_payment = float(real_original_price)
        if real_actual_payment != actual_payment:
            logger.warning(f'actual_payment参数校验失败， actual_payment={actual_payment}， '
                           f'real_actual_payment={real_actual_payment}')
            return Response(data={"detail": "价格校验失败"}, status=status.HTTP_400_BAD_REQUEST)


        # 构建请求数据
        time_expire = datetime.datetime.strftime(datetime.datetime.now() + datetime.timedelta(hours=1),
                                                 '%Y-%m-%dT%H:%M:%S+08:00')
        notify_url = settings.NOTIFY_URL  # 通知地址
        original_price *= 100
        actual_payment *= 100
        amount = {
            'total': int(actual_payment),  # 单位：分
            'currency': 'CNY',
        }
        payer = {
            'openid': open_id
        }
        order_number = order_num(phone)
        data = {
            'appid': settings.APPID,
            'mchid': settings.MCHID,
            'description': description,
            'out_trade_no': order_number,
            'time_expire': time_expire,
            'notify_url': notify_url,
            'amount': amount,
            'payer': payer,
        }
        # 生成authorization
        method = "POST"
        nonce_str = WXAuthorization().get_nonce_str()
        timestamp = str(int(time.time()))
        url_path = parse.urlparse(settings.JSAPI).path
        json_body = json.dumps(data)
        authorization = WXAuthorization().authorization(method=method, url_path=url_path, nonce_str=nonce_str,
                                                        timestamp=timestamp, body=json_body)
        # 下单
        inter_record = WXInterfaceRecord(merchant_id=settings.MCHID, out_trade_no=order_number, name='统一下单',
                          path=parse.urlparse(settings.JSAPI).path, type='CALL',
                          req_headers=json.dumps({'Authorization': authorization}),
                          req_body=json_body)
        ret_data = place_order_wx3(json_body, authorization)
        inter_record.resp_body = ret_data
        # 防止内容过长存储失败日志存储失败
        try:
            inter_record.save()
        except Exception as e:
            logger.error(e, exc_info=True)
        if not ret_data:
            return Response(data={"detail": "下单请求失败"}, status=status.HTTP_400_BAD_REQUEST)
        ret_data = json.loads(ret_data)
        prepay_id = ret_data.get('prepay_id')
        if not prepay_id:
            return Response(data={"detail": "微信接口认证失败"}, status=status.HTTP_400_BAD_REQUEST)
        # 生成订单信息入库 变更优惠券状态 添加一个新的优惠券
        with transaction.atomic():
            sid = transaction.savepoint()
            try:
                order = Order(user_id=user.id, commodity_id=template_video_id, order_number=order_number, prepay_id=prepay_id,
                              wonderful_video_ret_id=play_record_id, coupon_id=coupon_id,
                              original_price=original_price / 100, actual_payment=actual_payment / 100)
                order.save()
            except Exception as e:
                transaction.savepoint_rollback(sid)
                logger.error(e, exc_info=True)
                return Response(data={"detail": "订单信息存储失败"}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(sid)
        # 签名
        package = "prepay_id=" + prepay_id
        xcx_sign_s = WXAuthorization().xcx_sign_str(timestamp, nonce_str, package)
        pay_sign = WXAuthorization().sign(xcx_sign_s)
        ret_data = {
            'app_id': settings.APPID,
            'timestamp': timestamp,
            'nonce_str': nonce_str,
            'package': package,
            'pay_sign': pay_sign,
            'sign_type': 'RSA',
        }
        return Response(data=ret_data, status=status.HTTP_200_OK)


class PaymentNotice(APIView):

    def post(self, request, *args, **kwargs):
        # 参数
        headers = request.headers
        body = request.body.decode()
        logger.info('body:'+body, exc_info=True)
        serial = headers.get('Wechatpay-Serial')
        timestamp = headers.get('Wechatpay-Timestamp')
        nonce = headers.get('Wechatpay-Nonce')
        signature = headers.get('Wechatpay-Signature')
        data = request.data
        event_type = data.get('event_type')
        # create_time = data.get('create_time')
        resource = data.get('resource')
        inter_record = WXInterfaceRecord(merchant_id=settings.MCHID, name='支付通知',
                                         path=parse.urlparse(settings.NOTIFY_URL).path,
                                         type='RECEIVE', req_headers=json.dumps(dict(headers)), req_body=body)
        # 支付失败
        if event_type != 'TRANSACTION.SUCCESS':
            ret_data = {'code': 'SUCCESS', 'message': '成功'}
        elif serial != settings.PLAT_SERIAL_NO:
            ret_data = {'code': 400, 'message': '序列号不正确'}
        else:
            # 验签
            # signature = base64.b64decode(signature).decode()
            ret = rsa_verify(timestamp, nonce, body, signature)
            if not ret:
                ret_data = {'code': 400, 'message': '验签失败'}
                logger.info('================================验签失败================================', exc_info=True)
            else:
                # 解密
                nonce = resource['nonce']
                associated_data = resource.get('associated_data', '')
                ciphertext = resource['ciphertext']
                decrypt_data = json.loads(decrypt(nonce, ciphertext, associated_data))
                out_trade_no = decrypt_data['out_trade_no']
                transaction_id = decrypt_data['transaction_id']
                success_time = decrypt_data['success_time'][:19]
                success_time = datetime.datetime.strptime(success_time, '%Y-%m-%dT%H:%M:%S')
                inter_record.out_trade_no = out_trade_no
                inter_record.wx_transaction_id = transaction_id
                # 修改订单及游玩记录支付状态
                with transaction.atomic():
                    sid = transaction.savepoint()
                    try:
                        order = Order.objects.filter(order_number=out_trade_no).first()
                        order.order_number = out_trade_no
                        order.wx_transaction_id = transaction_id
                        order.state = 1
                        order.pay_time = success_time
                        order.save()
                        play_record = order.wonderful_video_ret
                        play_record.is_pay = 1
                        play_record.save()
                        coupon_id = order.coupon_id
                        if coupon_id:
                            Coupon.objects.filter(id=coupon_id).update(is_used=1)
                        coupon_type = KeyBookModel.objects.filter(key=settings.DEFAULT_COUPON_TYPE_KEY).only(
                            'value').first().value
                        coupon_value = KeyBookModel.objects.filter(key=settings.DEFAULT_COUPON_VALUE_KEY).only(
                            'value').first().value
                        Coupon.objects.create(user_id=order.user_id, name=settings.DEFAULT_COUPON_NAME, is_used=0,
                                              value=coupon_value, discount_type=coupon_type)
                        transaction.savepoint_commit(sid)
                        ret_data = {'code': 'SUCCESS', 'message': '成功'}
                    except Exception as e:
                        transaction.savepoint_rollback(sid)
                        logger.error(e, exc_info=True)
                        ret_data = {'code': 400, 'message': '存储失败'}
        inter_record.resp_body = json.dumps(ret_data)
        # 防止内容过长存储失败日志存储失败
        try:
            inter_record.save()
        except Exception as e:
            logger.error(e, exc_info=True)
        return JsonResponse(ret_data)


class OrderInfoView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self, filter_data):
        user_id = self.request.user.id
        if filter_data:
            return Order.objects.filter(user_id=user_id, is_delete=False, **filter_data).order_by('-create_time')
        return Order.objects.filter(user_id=user_id, is_delete=False).order_by('-create_time')

    def get_serializer_class(self):
        return serializers.OrderSerializer

    def list(self, request, *args, **kwargs):
        # response = super(OrderInfoView, self).list(request, *args, **kwargs)

        # 1. 获取日期的分页数据
        order_date_queryset = Order.objects.filter(user_id=request.user.id, is_delete=False, state=1).\
            order_by('-create_date').values('create_date').distinct()
        order_date_page_data = self.paginate_queryset(order_date_queryset)
        # 2. 根据日期条件进行查询过滤
        filter_values = [item.get("create_date") for item in order_date_page_data]
        filter_data = {'create_date__in': filter_values, 'state': 1}
        date_list = []
        data_list = []
        # column = ['id', 'order_type', 'place_order_time', 'video_make_time', 'original_price', 'actual_payment', 'state', 'pay_time', 'template_image_url']
        queryset = self.get_queryset(filter_data)  # .values_list('id', 'order_type', 'create_time', 'wonderful_video_ret__create_time', 'original_price', 'actual_payment', 'state', 'pay_time', 'commodity__template_image_url')
        if queryset:
            # 查询订单服务电话
            try:
                order_service_tel_str = KeyBookModel.objects.filter(key=settings.ORDER_SERVICE_TEL_KEY).only(
                    'value').first().value
                order_service_tel_list = json.loads(order_service_tel_str)
            except Exception:
                logger.error('订单服务电话获取失败', exc_info=True)
                order_service_tel_list = list()
            # 3. 构造数据
            for order in queryset:
                order_date = datetime.datetime.strftime(order.create_time, settings.SERIALIZER_DATE_FIELD_FORMAT)
                if order_date not in date_list:
                    date_list.append(order_date)
                    data_list.append({
                        'place_order_time': order_date,
                        'tel': order_service_tel_list,
                        'data': []
                    })
                index = date_list.index(order_date)
                data = serializers.OrderSerializer(order).data
                data_list[index]['data'].append(data)
        return Response(data={'count': order_date_queryset.count(), 'results': data_list}, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.is_delete = True
        instance.save()
        return Response(data=[], status=status.HTTP_204_NO_CONTENT)


class PlotformCert(APIView):

    def get(self, request, *args, **kwargs):
        # 生成authorization
        method = "GET"
        nonce_str = WXAuthorization().get_nonce_str()
        timestamp = str(int(time.time()))
        url_path = '/v3/certificates'
        authorization = WXAuthorization().authorization(method=method, url_path=url_path, nonce_str=nonce_str,
                                                        timestamp=timestamp, body='')
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': authorization}
        resp = requests.get(url='https://api.mch.weixin.qq.com/v3/certificates', headers=headers)
        # print(resp.text)
        logger.info(resp.text, exc_info=True)
        return Response(data='')