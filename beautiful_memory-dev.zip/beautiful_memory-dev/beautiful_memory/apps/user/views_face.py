# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import datetime
import json
import logging

from django.conf import settings
from django.db import transaction
from django.urls import reverse
from django_redis import get_redis_connection
from kafka import KafkaProducer
from redis import StrictRedis
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView
from itsdangerous import TimedJSONWebSignatureSerializer as TJWSSerializer, BadData

from system.models import KeyBookModel
from user.models import Face
from utils.common import upload, gen_qrcode
from utils.human_face import face_data_verify

logger = logging.getLogger('django')


class HumanFaceAppend(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        human_face = request.FILES.get('file')
        is_reset = request.query_params.get('is_reset')
        # type {0：正脸， 1：侧脸1， 2:侧脸2}
        type = request.query_params.get('type')
        if type == '0':
            type = 0
        elif type == '1':
            type = 1
        elif type == '2':
            type = 2
        else:
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        if not human_face:
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        human_face_data = human_face.read()
        # 验证人脸数据是否正确
        true_type = face_data_verify(human_face_data)
        user = request.user
        if true_type is None:
            return Response(data={"detail": "请调整面部角度"}, status=status.HTTP_400_BAD_REQUEST)
        elif true_type == -1:
            return Response(data={"detail": "请确认有且仅有一张人脸"}, status=status.HTTP_400_BAD_REQUEST)
        elif type == 0 and true_type != type:
            return Response(data={"detail": "请确认为正脸"}, status=status.HTTP_400_BAD_REQUEST)
        elif type != 0 and Face.objects.filter(user_id=user.id, type=true_type).exists():
            if type == 1:
                # 查询该用户历史存储的人脸是否有该type
                return Response(data={"detail": "请确认为侧脸"}, status=status.HTTP_400_BAD_REQUEST)
            elif type == 2:
                return Response(data={"detail": "请确认为另一张侧脸"}, status=status.HTTP_400_BAD_REQUEST)

        # 上传七牛云
        try:
            url = upload(human_face_data)
        except Exception:
            return Response(data={"detail": "上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        # 保存到kafka
        kafka_producer = KafkaProducer(bootstrap_servers=settings.KAFKA_SERVERS,
                                       value_serializer=lambda v: json.dumps(v).encode(), compression_type='gzip')
        kafka_producer.send(settings.FACE_APPEND_TOPIC, value={'user_id': user.id.hex, 'face_urls': [url],
                                                               'type': true_type})

        # 批量持久化mysql
        with transaction.atomic():
            if is_reset == '1' or type == 0:
                # 将之前的人脸录入结果删除
                Face.objects.filter(user_id=user.id).delete()
            # 重新录入人脸
            Face.objects.create(user_id=user.id, face_url=url, type=true_type)
        return Response(data={"detail": "成功"})


class HumanFaceQRCodeView(APIView):

    def post(self, request, *args, **kwargs):
        human_face = request.FILES.get('file')
        # type {0：正脸， 1：侧脸1， 2:侧脸2}
        type = request.data.get('type')
        # 前两次录入人脸的ids
        face_ids = request.data.get('face_ids')
        if type in ['0', 0, '1', 1, '2', 2]:
            type = int(type)
        else:
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        if not human_face:
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        human_face_data = human_face.read()
        # 验证人脸数据是否正确
        true_type = face_data_verify(human_face_data)
        if true_type is None:
            return Response(data={"detail": "请调整面部角度"}, status=status.HTTP_400_BAD_REQUEST)
        elif true_type == -1:
            return Response(data={"detail": "请确认有且仅有一张人脸"}, status=status.HTTP_400_BAD_REQUEST)
        elif type == 0 and true_type != type:
            return Response(data={"detail": "请确认为正脸"}, status=status.HTTP_400_BAD_REQUEST)
        elif type == 1 and true_type == 0:
            # type为1，真实type必须为侧脸
            return Response(data={"detail": "请确认为侧脸"}, status=status.HTTP_400_BAD_REQUEST)
        elif type == 2:
            # type为2，必须要有 face_ids参数
            if not face_ids:
                return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
            try:
                face_ids = json.loads(face_ids)
            except Exception:
                return Response(data={"detail": "参数解析错误"}, status=status.HTTP_400_BAD_REQUEST)
            # 如果face_ids记录中 type有该侧脸，那么该侧脸存储过了
            if Face.objects.filter(id__in=face_ids, type=true_type).exists():
                return Response(data={"detail": "请确认为另一张侧脸"}, status=status.HTTP_400_BAD_REQUEST)

        # 上传七牛云
        try:
            url = upload(human_face_data)
        except Exception:
            return Response(data={"detail": "上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        obj = Face.objects.create(face_url=url, type=true_type)
        if type == 2:
            # 拼接链接返回二维码
            try:
                face_ids.append(obj.id)
                serializer = TJWSSerializer(settings.SECRET_KEY, settings.FACE_ID_TOKEN_EXPIRES)
                face_ids_token = serializer.dumps(face_ids).decode()
                # data = {"method": "post", "path": reverse('append_f_qrc'), "data": {"face_ids": face_ids}}
                # url = upload(gen_qrcode(json.dumps(data)))
                url = upload(gen_qrcode(json.dumps({"face_ids": face_ids_token, "face_url": url})))
            except Exception:
                return Response(data={"detail": "二维码上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

            # 将链接存储redis，并设置过期时间24 * 7小时
            redis_conn = get_redis_connection()  # type: StrictRedis
            redis_conn.setex(f"{settings.QR_CODE_URL_PRE}{'-'.join([str(item) for item in face_ids])}",
                             datetime.timedelta(hours=24), '1')
            return Response(data={"detail": "成功", "qr_code_url": url, "face_id": obj.id})
        else:
            return Response(data={"detail": "成功", "face_id": obj.id})


class HumanFaceQRCodeAppendView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        face_ids = request.data.get('face_ids')
        serializer = TJWSSerializer(settings.SECRET_KEY, settings.FACE_ID_TOKEN_EXPIRES)
        try:
            face_ids = serializer.loads(face_ids)
        except Exception:
            logger.warning(f'解析face_ids失败', exc_info=True)
            return Response(data={"detail": "参数解析失败"}, status=status.HTTP_400_BAD_REQUEST)

        if not isinstance(face_ids, list):
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
        if Face.objects.filter(id__in=face_ids, user_id__isnull=True).count() == 0:
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            user = request.user
            if request.data.get('spare_int1'):
                Face.objects.filter(user_id=user.id).delete()
                Face.objects.filter(id__in=face_ids).update(user_id=user.id, spare_int1=request.data.get('spare_int1'))
            else:
                Face.objects.filter(user_id=user.id).delete()
                Face.objects.filter(id__in=face_ids).update(user_id=user.id)
        kafka_producer = KafkaProducer(bootstrap_servers=settings.KAFKA_SERVERS,
                                       value_serializer=lambda v: json.dumps(v).encode(), compression_type='gzip')
        for face_obj in Face.objects.filter(id__in=face_ids):
            # 过滤侧脸数据
            if face_obj.type != 0:
                continue
            # 保存到kafka
            kafka_producer.send(settings.FACE_APPEND_TOPIC, value={'user_id': user.id.hex,
                                                                   'face_urls': [face_obj.face_url],
                                                                   'type': face_obj.type})
        redis_conn = get_redis_connection()  # type: StrictRedis
        redis_conn.delete(f"{settings.QR_CODE_URL_PRE}{'-'.join([str(item) for item in face_ids])}")
        return Response(data={"detail": "成功"})


class FaceQRCodeStatusView(APIView):
    def get(self, request, *args, **kwargs):
        face_ids = request.query_params.get('face_ids')
        try:
            face_ids = json.loads(face_ids)
        except Exception:
            logger.error('face_ids参数类型错误', exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
        if not isinstance(face_ids, list):
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
        redis_conn = get_redis_connection()  # type: StrictRedis
        if redis_conn.get(f"{settings.QR_CODE_URL_PRE}{'-'.join([str(item) for item in face_ids])}"):
            return Response(data={"detail": "正在使用", "status": 0}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(data={"detail": "已经使用", "status": 1}, status=status.HTTP_400_BAD_REQUEST)


class HumanFaceQRCodeIMG3View(APIView):

    def post(self, request, *args, **kwargs):
        human_face0_file = request.FILES.get('file0')
        # human_face1_file = request.FILES.get('file1')
        # human_face2_file = request.FILES.get('file2')
        human_face_file_list = [human_face0_file, ]
        if not all(human_face_file_list):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
        face_ids = list()
        first_face_url = None
        with transaction.atomic():
            for index, human_face_file in enumerate(human_face_file_list):
                try:
                    human_face0_bytes = human_face_file.read()
                    face_url = upload(human_face0_bytes)
                    if not first_face_url:
                        first_face_url = face_url
                except Exception:
                    return Response(data={"detail": "上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
                face_obj = Face.objects.create(face_url=face_url, type=index)
                face_ids.append(face_obj.id)
        try:
            serializer = TJWSSerializer(settings.SECRET_KEY, settings.FACE_ID_TOKEN_EXPIRES)
            face_ids_token = serializer.dumps(face_ids).decode()
            url = upload(gen_qrcode(json.dumps({"face_ids": face_ids_token, "face_url": first_face_url})))
        except Exception:
            return Response(data={"detail": "二维码上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        # 将链接存储redis，并设置过期时间24 * 7小时
        redis_conn = get_redis_connection()  # type: StrictRedis
        redis_conn.setex(f"{settings.QR_CODE_URL_PRE}{'-'.join([str(item) for item in face_ids])}",
                         datetime.timedelta(hours=24), '1')
        return Response(data={"detail": "成功", "qr_code_url": url, "face_ids": face_ids})


class HumanFaceQRCodeIMG1View(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        # 接收图片字段
        human_face_file = request.FILES.get('file0')
        # 校验参数
        if not human_face_file:
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # 仅仅录入正脸的逻辑
            human_face0_bytes = human_face_file.read()
            # 验证人脸数据是否正确
            true_type = face_data_verify(human_face0_bytes)
            if true_type is None:
                return Response(data={"detail": "请调整面部角度"}, status=status.HTTP_400_BAD_REQUEST)
            elif true_type == -1:
                return Response(data={"detail": "请确认有且仅有一张人脸"}, status=status.HTTP_400_BAD_REQUEST)
            elif true_type != 0:
                return Response(data={"detail": "请确认为正脸"}, status=status.HTTP_400_BAD_REQUEST)

            face_url = upload(human_face0_bytes)
        except Exception:
            return Response(data={"detail": "上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        face_obj = Face.objects.create(face_url=face_url, type=0)
        face_ids = [face_obj.id]
        try:
            serializer = TJWSSerializer(settings.SECRET_KEY, settings.FACE_ID_TOKEN_EXPIRES)
            face_ids_token = serializer.dumps(face_ids).decode()
            if request.data.get('spare_int1'):
                spare_int1 = request.data.get('spare_int1')
                logger.info(f'获取运动员的参数{spare_int1},类型{type(spare_int1)}')
                url = upload(gen_qrcode(json.dumps({"face_ids": face_ids_token, "face_url": face_url, "spare_int1": spare_int1})))
            else:
                url = upload(gen_qrcode(json.dumps({"face_ids": face_ids_token, "face_url": face_url})))
        except Exception:
            return Response(data={"detail": "二维码上传七牛失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        # 将链接存储redis，并设置过期时间24 * 7小时 在绑定过之后人脸照片之后，会清空这个键
        redis_conn = get_redis_connection()  # type: StrictRedis
        redis_conn.setex(f"{settings.QR_CODE_URL_PRE}{'-'.join([str(item) for item in face_ids])}",
                         datetime.timedelta(hours=24), '1')
        return Response(data={"detail": "成功", "qr_code_url": url, "face_ids": face_ids})


class QRCodeAppendPersonView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        """查询手机号是否为指定人脸录入管理员手机号"""
        try:
            qr_personnel_phone_list_obj = KeyBookModel.objects.get(key=settings.QR_PERSONNEL_PHONE_LIST)
        except Exception:
            logger.error('获取工作人员手机号列表失败', exc_info=True)
            return Response({'detail': '校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            phone_list = json.loads(qr_personnel_phone_list_obj.value)
            if request.user.mobile not in [str(phone) for phone in phone_list]:
                return Response({'detail': '校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'detail': '校验成功'})
