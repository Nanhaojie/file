import hashlib
import logging
import random
from calendar import timegm
from datetime import datetime, timedelta

from django.db import transaction
from django.shortcuts import render

# Create your views here.
from django.utils import timezone
from django_redis import get_redis_connection
from rest_framework import status, mixins
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.conf import settings
from rest_framework.viewsets import ModelViewSet, ViewSetMixin
from rest_framework_jwt.settings import api_settings

from orders.models import Coupon
from system.models import KeyBookModel
from user import serializers
from user.models import User
from utils.common import code_2_session, check_sign, WXDataCrypt

redis_conn = get_redis_connection('user')
logger = logging.getLogger('django')


class UserAuthView(APIView):

    def my_md5(self, jwt):
        md = hashlib.md5()
        md.update(jwt.encode(encoding='utf-8'))
        md5_str = md.hexdigest()
        return md5_str

    def post(self, request, *args, **kwargs):

        # 测试
        # openid = 'wx4f4bc4dec97d474c'
        # session_key = 'tiihtNczf5v6AKRyjwEUhQ=='
        # unionid = 'unionid1'
        # openid = 'o-MNU5abOYSQgEMC0HHcdcYXMX8U'
        # session_key = 'BoZ7Twgqf1E3FC8nnzFMMg=='
        # unionid = 'unionid1'
        user_id = request.query_params.get('test_user_id', '').replace('-', '')
        if user_id:
            user = User.objects.filter(id=user_id).first()
            openid = user.open_id
            session_key = 'test_session_key'
        else:
            # 获取微信code
            code = request.data.get("code")
            # 根据code获取 openid openid session_key
            errcode, openid, unionid, session_key = code_2_session(code, settings.APPID, settings.APPSECRET)
            if not openid:
                return Response({'detail': '未获取到用户微信信息'}, status=status.HTTP_400_BAD_REQUEST)
            # 判断用户表中是否有openid 如果有没则插入用户表中
            user = User.objects.filter(open_id=openid).first()
            if not user:
                with transaction.atomic():
                    user = User(open_id=openid, unionid=unionid)
                    user.save()
                    coupon_type = KeyBookModel.objects.filter(key=settings.DEFAULT_COUPON_TYPE_KEY).only(
                        'value').first().value
                    coupon_value = KeyBookModel.objects.filter(key=settings.DEFAULT_COUPON_VALUE_KEY).only(
                        'value').first().value
                    Coupon.objects.create(user_id=user.id, name=settings.DEFAULT_COUPON_NAME, is_used=0,
                                          discount_type=coupon_type, value=coupon_value)

        # 生成token
        user_info = {
            'openid': openid,
            'session_key': session_key,
            'exp': datetime.timestamp(datetime.now() + timedelta(minutes=settings.TOKEN_EXP))
        }
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = self.my_jwt_payload_handler(user_info)
        token = jwt_encode_handler(payload)
        md5_str = self.my_md5(token)
        val = {"token": token, "openid": openid, "session_key": session_key}
        # 检查 mysp_xcx_user_'openid': {token}
        old_md5_str = redis_conn.get('mysp_xcx_user_' + openid)
        if old_md5_str:
            redis_conn.delete(old_md5_str)
        redis_conn.set(md5_str, str(val), settings.APP_EXP_SECOND)
        redis_conn.set('mysp_xcx_user_' + openid, md5_str, settings.APP_EXP_SECOND)
        # 用户最后登录时间更新
        user.last_login = timezone.now()
        user.save(update_fields=['last_login'])
        # 返回定义token
        return Response({'token': 'JWT ' + md5_str, 'id': user.id})

    def my_jwt_payload_handler(self, payload):
        payload['ran'] = random.randint(1, 1000)
        if api_settings.JWT_ALLOW_REFRESH:
            payload['orig_iat'] = timegm(
                datetime.utcnow().utctimetuple()
            )

        if api_settings.JWT_AUDIENCE is not None:
            payload['aud'] = api_settings.JWT_AUDIENCE

        if api_settings.JWT_ISSUER is not None:
            payload['iss'] = api_settings.JWT_ISSUER
        return payload

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.check_throttles(request)


class UserLogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    def delete(self, request, *args, **kwargs):
        openid = request.user.open_id
        token = request.META.get('HTTP_AUTHORIZATION').replace('JWT ', '')
        redis_conn.delete(token)
        redis_conn.delete('mysp_xcx_user_' + openid)
        return Response(data={'detail': '成功'}, status=status.HTTP_200_OK)


class UserInfoView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        queryset = User.objects.all()
        return queryset

    def get_serializer_class(self):
        return serializers.UserInfoSerializers

    def update(self, request, *args, **kwargs):
        return super(UserInfoView, self).update(request, partial=True, *args, **kwargs)


class UpdatePhoneView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def update(self, request, *args, **kwargs):
        user = request.user
        session_info = eval(redis_conn.get(redis_conn.get('mysp_xcx_user_' + user.open_id)))
        session_key = session_info.get('session_key')
        encryptedData = request.data.get('encryptedData')
        iv = request.data.get('iv')
        if not all([encryptedData, iv]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
        wx = WXDataCrypt(settings.APPID, session_key)
        # wx = WXDataCrypt('wx4f4bc4dec97d474b', session_key)
        try:
            user_info = wx.decrypt(encryptedData, iv)
        except Exception as e:
            logger.error(e, exc_info=True)
            return Response(data={"detail": "解析用户信息失败！"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user.mobile = user_info['purePhoneNumber']
            user.save()
        except Exception:
            logger.warning('手机号修改失败', exc_info=True)
            return Response(data={"detail": "手机号已绑定！"}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'detail': '成功'}, status=status.HTTP_200_OK)


class TestView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        user = request.user
        print(user.id)
        print(user.unionid)
        return Response({'user': 'test'})
