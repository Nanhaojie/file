#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/8上午9:45
#@Author:zwz

from django.urls import path
from apps.user.views import UserAuthView,TestView, UserInfoView, UpdatePhoneView, UserLogoutView
from user.views_face import HumanFaceAppend, HumanFaceQRCodeView, HumanFaceQRCodeAppendView, FaceQRCodeStatusView, \
    HumanFaceQRCodeIMG3View, HumanFaceQRCodeIMG1View, QRCodeAppendPersonView

urlpatterns = [
    path('login', UserAuthView.as_view()),
    path('logout', UserLogoutView.as_view()),
    # path('send_user_info', UserInfoView.as_view({''})),
    path('user_info/<str:pk>', UserInfoView.as_view({'get': 'retrieve', 'put': 'update'})),
    path('update_phone/<uuid:pk>', UpdatePhoneView.as_view({'put': 'update'})),
    path('test', TestView.as_view()),

    # 保存人脸数据
    path('face/append', HumanFaceAppend.as_view()),
    path('face/qr_code', HumanFaceQRCodeView.as_view()),
    path('face/qr_code_img3', HumanFaceQRCodeIMG3View.as_view()),
    path('face/append_f_qrc', HumanFaceQRCodeAppendView.as_view(), name='append_f_qrc'),
    path('face/qr_code_status', FaceQRCodeStatusView.as_view()),
    # 小程序录入正脸 返回二维码
    path('face/qr_code_img1', HumanFaceQRCodeIMG1View.as_view()),
    # 判断该用户手机号是否包含在定义列表中
    path('face/is_qr_personnel', QRCodeAppendPersonView.as_view()),
]