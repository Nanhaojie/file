import uuid

from django.db import models

# Create your models here.

from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import UserManager, PermissionsMixin
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.db import models

# Create your models here.
from utils.models import SpareFieldModel
from django.utils.translation import gettext_lazy as _


class User(AbstractBaseUser, SpareFieldModel, PermissionsMixin):
    """
    用户表模型类
    """
    shot_status_choices = (
        (0, "开始"),
        (1, "暂停"),
        (2, "结束"),
    )
    username_validator = UnicodeUsernameValidator()
    id = models.UUIDField(primary_key=True, default=uuid.uuid1, editable=False)
    wechat_number = models.CharField(max_length=512, null=True, blank=True, verbose_name="微信号")
    open_id = models.CharField(max_length=512, null=True, blank=True, verbose_name="open_id")
    unionid = models.CharField(max_length=512, null=True, blank=True, verbose_name="unionid")
    nickname = models.CharField(max_length=256, null=True, blank=True, verbose_name="昵称")
    gender = models.SmallIntegerField(null=True, blank=True, verbose_name="性别")
    avatar_url = models.CharField(max_length=256, null=True, blank=True, verbose_name="微信头像")

    mobile = models.CharField(max_length=11, unique=True, null=True, blank=True, verbose_name="手机号", error_messages={
        'unique': _("该手机号已存在"),
    })
    shot_status = models.SmallIntegerField(default=0, choices=shot_status_choices)
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name="备注")
    is_staff = models.BooleanField(
        _('staff status'),
        default=False,
        help_text=_('Designates whether the user can log into this admin site.'),
    )
    is_active = models.BooleanField(
        _('active'),
        default=True,
        help_text=_(
            'Designates whether this user should be treated as active. '
            'Unselect this instead of deleting accounts.'
        ),
    )
    date_joined = models.DateTimeField(_('date joined'), auto_now_add=True)
    update_time = models.DateTimeField(_('date update'), auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'mobile'
    REQUIRED_FIELDS = ['nickname']

    class Meta:
        verbose_name = '用户表'
        verbose_name_plural = verbose_name
        db_table = 't_user'


class Face(SpareFieldModel):
    """
    用户人脸表
    """
    type_choices = (
        (0, "正脸"),
        (1, "侧脸1"),
        (2, "侧脸2")
    )
    face_url = models.CharField(max_length=256, verbose_name="脸部照片url")
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name="备注")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="faces", db_constraint=False, null=True,
                             blank=True)
    type = models.SmallIntegerField(choices=type_choices, default=0, verbose_name="身体模板类型")

    class Meta:
        verbose_name = '用户人脸表'
        verbose_name_plural = verbose_name
        db_table = 't_face'


class Body(SpareFieldModel):
    """
    用户身体表
    """
    type_choices = (
        (0, "今日身体底板"),
        (1, "临时身体底板")
    )
    body_url = models.CharField(max_length=256, verbose_name="身体图片url")
    update_time = models.DateTimeField(auto_now=True, verbose_name="创建时间")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bodies", db_constraint=False)
    type = models.SmallIntegerField(choices=type_choices, verbose_name="身体模板类型")

    class Meta:
        verbose_name = '用户人脸表'
        verbose_name_plural = verbose_name
        db_table = 't_body'
