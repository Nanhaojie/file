#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:     2021/9/10 21:58
# @Author:   zwz
from django_redis import get_redis_connection
from redis import StrictRedis
from rest_framework import serializers, status

from beautiful_memory import settings
from promotions.models import QuestionnaireRecordModel
from .models import User, Face


class UserInfoSerializers(serializers.ModelSerializer):
    nickname = serializers.CharField(max_length=256, label='昵称')
    avatar_url = serializers.CharField(max_length=256, label='头像')
    is_shared = serializers.SerializerMethodField(label='是否分享过')
    is_submitted_question = serializers.SerializerMethodField(label='是否提交过问卷')

    def get_is_shared(self, instance):
        user_id = self.context['request'].user.id.hex
        redis_conn = get_redis_connection()  # type: StrictRedis
        user_share_num = redis_conn.hget(settings.USER_SHARE_NUM_STAT_REDIS_KEY, user_id)
        if user_share_num is None:
            return False
        else:
            return True

    def get_is_submitted_question(self, instance):
        return QuestionnaireRecordModel.objects.filter(user=self.context['request'].user).exists()

    class Meta:
        model = User
        fields = ('id', 'nickname', 'avatar_url', 'mobile', 'is_shared', 'is_submitted_question')

    def to_representation(self, instance):
        data = super(UserInfoSerializers, self).to_representation(instance)
        face = Face.objects.filter(user_id=data['id']).first()
        if face:
            data['is_enter_face'] = 1
            data['face_create_time'] = face.create_time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
        else:
            data['is_enter_face'] = 0
        data['nickname'] = data.get('nickname') or '游客'
        data['avatar_url'] = data.get(
            'avatar_url') or 'http://aisource.trycan.com/mysp/img/a25cf72daa2bb098352cad5c5d7fd0ba14685aad'
        return data
