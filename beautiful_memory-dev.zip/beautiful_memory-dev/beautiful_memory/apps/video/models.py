from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class VideoEquipment(SpareFieldModel):
    """
    摄像头设备
    """
    url = models.CharField(max_length=512, verbose_name='摄像头视频流链接')
    name = models.CharField(max_length=128, verbose_name='摄像头名称')
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name="备注")
    scene = models.ForeignKey('system.SceneModel', on_delete=models.CASCADE, null=True, blank=True, db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = '摄像头设备'
        verbose_name_plural = verbose_name
        db_table = 't_video_equipment'


class WonderfulVideoRet(SpareFieldModel):
    """
    精彩视频结果记录表
    游玩信息记录表
    """
    status_choices = (
        (0, "待聚合"),
        (1, "正在制作聚合"),
        (2, "已聚合制作完成")
    )
    id = models.CharField(max_length=32, primary_key=True, verbose_name='主键，解决多个场馆本地生成id冲突问题')
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name="备注")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    first_video_finish_time = models.DateTimeField(null=True, blank=True, db_index=True,
                                                   verbose_name="第一个视频的制作完成的时间，用于审核列表的排序")
    scene = models.ForeignKey('system.SceneModel', on_delete=models.CASCADE, null=True, blank=True, db_constraint=False)
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, related_name="wonderful_video_ret_set",
                             db_constraint=False)
    is_pay = models.BooleanField(default=0, verbose_name="是否支付")
    is_agg = models.SmallIntegerField(choices=status_choices, default=0, verbose_name="聚合状态")
    is_rich = models.SmallIntegerField(default=0, verbose_name="素材是否充足")
    is_checked = models.BooleanField(default=0, verbose_name='是否审核')
    is_right = models.BooleanField(null=True, blank=True, verbose_name='视频是否正确')
    check_time = models.DateTimeField(null=True, blank=True, verbose_name='检查时间')
    checker_id = models.CharField(max_length=36, db_index=True, null=True, verbose_name='关联管理员用户的逻辑')
    new_video = models.ForeignKey('video.WonderfulVideoTemplateContentRet', on_delete=models.SET_NULL, null=True,
                                  blank=True, related_name='play_record_ret', db_constraint=False)
    new_video_is_right = models.BooleanField(null=True, blank=True, verbose_name='重新生成的视频是否正确')

    class Meta:
        verbose_name = '精彩视频结果记录表'
        verbose_name_plural = verbose_name
        db_table = 't_wonderful_video_ret'


class VideoFrame(SpareFieldModel):
    """
    精彩画面表
    """
    user = models.ForeignKey('user.User', null=True, blank=True, on_delete=models.SET_NULL, db_constraint=False)
    video_equipment_id = models.CharField(max_length=512, null=True, verbose_name='设备id/上传视频url')
    # occurrence_time = models.DateTimeField(verbose_name='精彩画面发生时间')
    beautiful_time = models.CharField(max_length=512, verbose_name='时间')
    body_coord = models.CharField(max_length=256, verbose_name='身体坐标')
    face_coord = models.CharField(max_length=256, verbose_name='人脸坐标')
    wonderful_tag = models.CharField(max_length=128, verbose_name='精彩标签')
    wonderful_weight = models.IntegerField(verbose_name='精彩权重')
    wonderful_video_ret = models.ForeignKey(WonderfulVideoRet, on_delete=models.CASCADE, related_name='video_frames',
                                            db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    scene = models.ForeignKey('system.SceneModel', on_delete=models.CASCADE, null=True, blank=True, db_constraint=False)
    video_frame_id = models.BigIntegerField(null=True, verbose_name="本地服务pk")
    is_right = models.BooleanField(null=True, verbose_name="是否正确")  # 聚合时候过滤掉 =0 的
    detection_model = models.CharField(max_length=128, null=True)
    img_url = models.CharField(max_length=512, null=True)

    class Meta:
        verbose_name = '精彩画面表'
        verbose_name_plural = verbose_name
        db_table = 't_video_frame'


class WonderfulVideoAggRet(SpareFieldModel):
    """
    精彩视频聚合结果
    """
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, db_constraint=False)
    body_coord = models.CharField(max_length=32, verbose_name='身体坐标')
    frame_start_offset = models.BigIntegerField(verbose_name='开始帧')
    frame_end_offset = models.BigIntegerField(verbose_name='结束帧')
    video_equipment_id = models.CharField(max_length=512, null=True, verbose_name='设备id/上传视频url')
    occurrence_date = models.DateField(verbose_name='精彩视频日期')
    group_id = models.CharField(max_length=32, null=True, blank=True, verbose_name='聚合组号')
    wonderful_video_ret = models.ForeignKey(WonderfulVideoRet, on_delete=models.CASCADE,
                                            related_name='wonderful_video_agg_ret_set',
                                            db_constraint=False)
    wonderful_tag = models.CharField(max_length=128, verbose_name='精彩标签')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = '精彩视频聚合结果'
        verbose_name_plural = verbose_name
        db_table = 't_wonderful_video_agg_ret'


class TemplateVideo(SpareFieldModel):
    type_choices = (
        (1, "横屏"),
        (2, "竖屏")
    )
    name = models.CharField(max_length=128, null=True, blank=True, verbose_name='模板名字')
    video_url = models.CharField(max_length=512, verbose_name='视频链接')
    video_start_url = models.CharField(max_length=512, verbose_name='模板视频开始url')
    start_video_time = models.IntegerField(verbose_name='开头模板视频时间/单位毫秒')
    video_end_url = models.CharField(max_length=512, verbose_name='模板视频结束url')
    end_video_time = models.IntegerField(verbose_name='结束模板视频时间/单位毫秒')
    video_music_url = models.CharField(max_length=512, verbose_name='模板音频url')
    lut_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='调色lut文件url')
    mask_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='蒙版资源链接')
    template_image_url = models.CharField(max_length=512, verbose_name='图片链接')
    template_image2_url = models.CharField(max_length=512, verbose_name='(高)图片链接')
    width = models.IntegerField(default=1080, verbose_name='模板宽度')
    height = models.IntegerField(default=720, verbose_name='模板高度')
    serial_no = models.IntegerField(default=0, verbose_name='序号')  # 从大到小排序
    is_use = models.BooleanField(default=True, verbose_name='是否在使用')
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    scene = models.ForeignKey('system.SceneModel', on_delete=models.CASCADE, null=True, blank=True,
                              related_name='temp_set', db_constraint=False)
    transition_set = models.ManyToManyField('TransitionEffect', through='TemplateTransitionEffect',
                                            through_fields=('template_video', 'transition_effect'))

    class Meta:
        verbose_name = '模板视频表'
        verbose_name_plural = verbose_name
        db_table = 't_template_video'


def zoom_default_value():
    return {"init_zoom": 1.3}


class TemplateUserSegment(SpareFieldModel):
    wonderful_tag = models.CharField(max_length=128, verbose_name='精彩标签')
    time = models.IntegerField(verbose_name='该段视频长度/单位毫秒')
    decoration_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='人物特效装饰资源链接')
    mask_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='该段对应蒙版资源链接')
    var_speed = models.FloatField(default=1.0, verbose_name='速度参数')
    lut_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='调色lut文件url')
    # {"zstep":0.0055,"zoom":5,"init_zoom": 1.3}  初始放大1.3倍 每帧放大zstep 最终放大5倍
    zoom = models.JSONField(null=True, blank=True, default=zoom_default_value, verbose_name='镜头推进特效参数')
    serial_no = models.IntegerField(default=0, verbose_name='序号')  # 从大到小排序
    is_used = models.BooleanField(default=True, verbose_name='是否在使用')
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    template_video = models.ForeignKey(TemplateVideo, on_delete=models.CASCADE, related_name='temp_seg_set',
                                       db_constraint=False)

    class Meta:
        verbose_name = '模板视频用户部分分段表'
        verbose_name_plural = verbose_name
        db_table = 't_template_user_segment'
        ordering = ('-serial_no', '-id')


class TransitionEffect(SpareFieldModel):
    name = models.CharField(max_length=128, verbose_name='特效名称')
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        verbose_name = '转场特效表'
        verbose_name_plural = verbose_name
        db_table = 't_transition_effect'


class TemplateTransitionEffect(SpareFieldModel):
    transition_effect = models.ForeignKey(TransitionEffect, on_delete=models.PROTECT, db_constraint=False)
    time = models.IntegerField(verbose_name='转场时间/单位毫秒')
    serial_no = models.IntegerField(default=0, verbose_name='序号')  # 从大到小排序
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    template_video = models.ForeignKey(TemplateVideo, on_delete=models.CASCADE, related_name='temp_transition_set',
                                       db_constraint=False)

    class Meta:
        verbose_name = '模板视频转场特效中间表'
        verbose_name_plural = verbose_name
        db_table = 't_template_transition_effect'
        ordering = ('-serial_no', '-id')


class WonderfulVideoTemplateContentRet(SpareFieldModel):
    """
    精彩视频结果模板内容表
    """
    status_choices = (
        (0, "制作中"),
        (1, "制作完成"),
        (2, "制作失败")
    )
    id = models.CharField(max_length=32, primary_key=True, verbose_name='主键，聚合组号对应id')
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, related_name="wonderful_video_content_ret_set",
                             db_constraint=False)
    video_url = models.CharField(null=True, blank=True, max_length=512, verbose_name='视频链接')
    square_image_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='(方型)封面链接')
    non_square_image_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='(横/竖形)封面链接')  # 横或者竖
    template_video = models.ForeignKey(TemplateVideo, on_delete=models.DO_NOTHING, db_constraint=False)
    wonderful_video_ret = models.ForeignKey(WonderfulVideoRet, on_delete=models.CASCADE, related_name='content_ret_set',
                                            db_constraint=False)
    video_size = models.CharField(max_length=11, null=True, blank=True, verbose_name='视频长度')
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name='创建时间')
    production_detail = models.CharField(max_length=1024, null=True, blank=True, verbose_name='制作详情')
    status = models.SmallIntegerField(choices=status_choices, default=0, verbose_name='制作状态')
    start_production_time = models.DateTimeField(null=True, blank=True, verbose_name='开始创建时间')
    finish_production_time = models.DateTimeField(null=True, blank=True, db_index=True, verbose_name='制作完成时间')
    is_show = models.BooleanField(default=1, verbose_name='视频是否展示')

    class Meta:
        verbose_name = '精彩视频结果模板内容表'
        verbose_name_plural = verbose_name
        db_table = 't_wonderful_video_template_content_ret'


class SampleVideo(SpareFieldModel):
    type_choices = (
        (0, "横屏"),
        (1, "竖屏")
    )
    play_type = models.SmallIntegerField(default=0, choices=type_choices, verbose_name='播放类型；横/竖屏')
    name = models.CharField(max_length=128, verbose_name='样例名称')
    video_url = models.CharField(max_length=512, verbose_name='视频链接')
    video_image = models.CharField(max_length=512, verbose_name='封面链接')
    serial_no = models.IntegerField(default=0, verbose_name='序号')  # 从大到小排序
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    scene = models.ForeignKey('system.SceneModel', on_delete=models.CASCADE, null=True, blank=True, db_constraint=False)
    note = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')

    class Meta:
        verbose_name = '样例视频表'
        verbose_name_plural = verbose_name
        db_table = 't_sample_video'


class SourceVideo(SpareFieldModel):
    file_path = models.CharField(max_length=256, verbose_name='文件存储路径')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    video_equipment = models.ForeignKey(VideoEquipment, on_delete=models.DO_NOTHING, related_name='source_video_set',
                                        db_constraint=False)

    class Meta:
        verbose_name = '原始视频表'
        verbose_name_plural = verbose_name
        db_table = 't_source_video'


class WonderfulVideoComment(SpareFieldModel):
    """
    精彩视频结果评论表
    """
    content = models.CharField(max_length=1000, null=True, blank=True, verbose_name="评论")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    scene = models.ForeignKey('system.SceneModel', on_delete=models.DO_NOTHING, null=True, blank=True,
                              db_constraint=False)
    user_video_content = models.ForeignKey(WonderfulVideoTemplateContentRet, on_delete=models.DO_NOTHING,
                                           db_constraint=False)

    class Meta:
        verbose_name = '精彩视频结果评论表'
        verbose_name_plural = verbose_name
        db_table = 't_wonderful_video_comment'


class ClickNumberModel(SpareFieldModel):
    status_choices = (
        (0, "制作失败"),
        (1, "制作成功"),
        (2, "制作中"),
    )
    user_id = models.CharField(max_length=128, verbose_name='用户id')
    scene = models.ForeignKey('system.SceneModel', on_delete=models.DO_NOTHING, null=True, blank=True,
                              db_constraint=False)
    is_success = models.SmallIntegerField(choices=status_choices, verbose_name="是否成功获取视频")
    create_time = models.DateTimeField(auto_now_add=True, null=True, blank=True, verbose_name='创建时间')

    class Meta:
        verbose_name = '用户点击表'
        verbose_name_plural = verbose_name
        db_table = 't_click_number_model'
