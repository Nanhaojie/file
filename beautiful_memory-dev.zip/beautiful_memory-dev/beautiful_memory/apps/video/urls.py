#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/13下午2:15
#@Author:zwz
from django.urls import path
from apps.video.views import SampleView, UserVideoView, GetVideo, ExistsPlayRecordView, TemplateView, RetryGetVideo, \
    VideoComment

urlpatterns = [
    path('sample', SampleView.as_view({'get': 'list'})),       # 样例视频列表  游客可看
    path('template', TemplateView.as_view()),  # 获取模板视频
    path('is_have_records', ExistsPlayRecordView.as_view()),       # 是否有游玩记录
    path('user_video', UserVideoView.as_view({'get': 'list', 'post': 'create'})),        # 用户的视频
    path('user_video/<str:pk>', UserVideoView.as_view({'get': 'retrieve', 'delete': 'destroy'})),        # 用户的单个视频
    path('get_video', GetVideo.as_view()),
    path('retry_get_video', RetryGetVideo.as_view()),
    path('video_comment', VideoComment.as_view()),
]