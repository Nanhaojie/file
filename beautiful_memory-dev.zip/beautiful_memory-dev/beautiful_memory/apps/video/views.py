import datetime
import logging

# Create your views here.
import uuid
from typing import Optional

from rest_framework import status
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework import serializers as drf_serializers

from beautiful_memory import settings
from beautiful_memory.settings import KAFKA_SERVERS, NOT_EXISTS_PLAY_RECORDS_MSG, MAKING_VIDEO_MSG, \
    VIDEO_TEMPLATE_CONFLICT_MSG
from system.models import KeyBookModel
from video.models import SampleVideo, WonderfulVideoTemplateContentRet, WonderfulVideoRet, TemplateVideo, \
    WonderfulVideoComment, ClickNumberModel
from apps.video import serializers
from kafka import KafkaProducer
import json
import time

producer = KafkaProducer(bootstrap_servers=KAFKA_SERVERS, value_serializer=lambda v: json.dumps(v).encode(),
                         key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip')
logger = logging.getLogger('django')


class SampleView(ModelViewSet):
    pagination_class = None

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            return SampleVideo.objects.filter(scene_id=scene_id).order_by('-serial_no', '-id')
        else:
            return SampleVideo.objects.all().order_by('-serial_no', '-id')

    def get_serializer_class(self):
        return serializers.SampleSerializer

    def list(self, request, *args, **kwargs):
        response = super(SampleView, self).list(request, *args, **kwargs)
        return response


class TemplateView(ListAPIView):
    pagination_class = None

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        wonderful_video_ret_id = self.request.query_params.get('wonderful_video_ret_id')
        if wonderful_video_ret_id:
            # 通过游玩记录获取 scene_id
            wonderful_video_ret_obj = WonderfulVideoRet.objects.filter(id=wonderful_video_ret_id).only(
                'scene_id').first()
            if wonderful_video_ret_obj:
                scene_id = wonderful_video_ret_obj.scene_id or scene_id
        if scene_id:
            return TemplateVideo.objects.filter(scene_id=scene_id, is_use=1).order_by('-serial_no', '-id')
        else:
            return TemplateVideo.objects.filter(is_use=1).order_by('-serial_no', '-id')

    def get_serializer_class(self):
        return serializers.TemplateSerializer


class RetryGetVideo(APIView):
    # permission_classes = (IsAuthenticated,)

    def get(self, request):
        video_id = request.query_params.get('video_id')
        if not video_id:
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        err_video_obj = WonderfulVideoTemplateContentRet.objects.filter(id=video_id, status=2).first()
        if not err_video_obj:
            return Response({'detail': '失败视频不存在'}, status=status.HTTP_400_BAD_REQUEST)
        is_show = request.query_params.get('is_show', '1')
        if is_show not in ('0', '1'):
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        # 标记是否为后台审核员重新生成的
        is_revise = request.query_params.get('is_revise', '0')
        if is_revise not in ('0', '1'):
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        # 把需要重试的视频存入kafka
        # 查询视频模板的信息
        err_video_obj.status = 0
        err_video_obj.save()
        template_video = TemplateVideo.objects.prefetch_related('temp_seg_set', 'temp_transition_set'). \
            filter(id=err_video_obj.template_video_id).first()
        # 推送游玩记录id，user_id type 及template相关内容 到kafka
        value = {'user_id': err_video_obj.user.id.hex,
                 'wonderful_video_ret_id': err_video_obj.wonderful_video_ret_id,
                 'group_id': err_video_obj.id,
                 'type': 3,  # {'1': add操作, '2': edit操作, 3: 重试操作}
                 'template_video': serializers.TemplateAllInfoSerializer(template_video).data,
                 'is_show': int(is_show),
                 'extra': {'is_revise': int(is_revise)},
                 }

        try:
            future = producer.send(settings.USER_V_AGG_MSG_TOPIC, value=value)
            future.get(timeout=100)
        except Exception:
            logger.error(f'用户修改精彩视频推送kafka-{settings.USER_V_AGG_MSG_TOPIC}失败', exc_info=True)
            return Response({'detail': '服务忙，请稍后重试'}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'detail': '成功'}, status=status.HTTP_200_OK)


class UserVideoView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_queryset(self):
        user_id = self.request.user.id
        queryset = WonderfulVideoTemplateContentRet.objects.filter(user_id=user_id, is_show=True) \
            .order_by('-create_time')
        return queryset

    def get_serializer_class(self):
        return serializers.CompositeVideoSerializer

    def list(self, request, *args, **kwargs):
        response = super(UserVideoView, self).list(request, *args, **kwargs)
        return response

    def retrieve(self, request, *args, **kwargs):
        response = super(UserVideoView, self).retrieve(request, *args, **kwargs)
        return response

    def create(self, request, *args, **kwargs):
        temp_video_id = request.data.get('temp_video_id')
        play_record_id = request.data.get('play_record_id')
        if not all([temp_video_id, play_record_id]):
            return Response({'detail': '不支持更换模板'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            # 校验play_record_id是否正确
            wonderful_video_ret = WonderfulVideoRet.objects.get(id=play_record_id, is_agg=2)
        except Exception:
            return Response({'detail': '不支持更换模板'}, status=status.HTTP_400_BAD_REQUEST)
        video = WonderfulVideoTemplateContentRet.objects.filter(template_video_id=temp_video_id,
                                                                wonderful_video_ret_id=play_record_id,
                                                                is_show=True)
        if video:
            return Response({'detail': '已有该模板的视频记录'}, status=status.HTTP_400_BAD_REQUEST)
        # 把需要编辑的视频存入kafka
        # 查询视频模板的信息
        template_video = TemplateVideo.objects.prefetch_related('temp_seg_set', 'temp_transition_set'). \
            filter(id=temp_video_id).first()

        # 计算往前推的时间
        extra_start_time = (wonderful_video_ret.create_time -
                            datetime.timedelta(minutes=settings.VIDEO_AGG_EXTRA_TIME)). \
            strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
        extra_end_time = wonderful_video_ret.create_time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)

        # 推送游玩记录id，user_id type 及template相关内容 到kafka
        value = {'user_id': request.user.id.hex,
                 'extra_start_time': extra_start_time,
                 'extra_end_time': extra_end_time,
                 'wonderful_video_ret_id': play_record_id,
                 'type': 2,  # {'1': add操作, '2': edit操作}
                 'template_video': serializers.TemplateAllInfoSerializer(template_video).data
                 }

        try:
            future = producer.send(settings.USER_V_AGG_MSG_TOPIC, value=value)
            future.get(timeout=100)
        except Exception:
            logger.error(f'用户修改精彩视频推送kafka-{settings.USER_V_AGG_MSG_TOPIC}失败', exc_info=True)
            return Response({'detail': '服务忙，请稍后重试'}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'detail': '成功'}, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        # 删除原视频
        # 删除记录
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)


class ExistsPlayRecordView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        user_id = request.user.id
        scene_id = self.request.query_params.get('scene_id')
        # 如果是运动会场景,提示暂无游玩记录
        if scene_id == 3 or scene_id == '3':
            return Response({'detail': '暂无游玩记录'}, status=status.HTTP_400_BAD_REQUEST)
        # 获取精彩视频回溯时间，从key_book表中获取指定时间，否则使用默认时间
        try:
            video_backtracking_time = int(
                KeyBookModel.objects.filter(key=settings.VIDEO_BACKTRACKING_TIME_CONF_NAME).only(
                    'value').first().value)
        except Exception:
            logger.error('获取追溯时间失败，采用默认时间', exc_info=True)
            video_backtracking_time = settings.VIDEO_BACKTRACKING_DEFAULT_TIME

        # 根据创建时间筛选游玩记录
        from_datetime = datetime.datetime.now() - datetime.timedelta(hours=video_backtracking_time)
        last_wonderful_video_record_obj = WonderfulVideoRet.objects.filter(create_time__gte=from_datetime,
                                                                           user_id=user_id,
                                                                           is_agg=0).order_by('-create_time').first()
        # 如果有新的游玩记录 返回成功
        if last_wonderful_video_record_obj:
            if last_wonderful_video_record_obj.is_rich == 1:
                click_obj = ClickNumberModel(user_id=user_id, scene_id=scene_id, is_success=1)
                click_obj.save()
                return Response({'detail': '成功', 'wonderful_video_ret_id': last_wonderful_video_record_obj.id})
            else:
                click_obj = ClickNumberModel(user_id=user_id, scene_id=scene_id, is_success=1)
                click_obj.save()
                return Response({
                    'detail': settings.VIDEO_MATERIAL_MSG,
                    'wonderful_video_ret_id': last_wonderful_video_record_obj.id
                }, status=209)
        elif WonderfulVideoTemplateContentRet.objects.filter(user_id=user_id, status__in=(0, 2)).exists():
            click_obj = ClickNumberModel(user_id=user_id, scene_id=scene_id, is_success=2)
            click_obj.save()
            return Response({'detail': MAKING_VIDEO_MSG}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # 如果没有游玩记录，返回 没有游玩记录消息
            click_obj = ClickNumberModel(user_id=user_id, scene_id=scene_id, is_success=0)
            click_obj.save()
            return Response({'detail': NOT_EXISTS_PLAY_RECORDS_MSG}, status=status.HTTP_400_BAD_REQUEST)


class GetVideo(APIView):
    # permission_classes = (IsAuthenticated,)

    def get_wonderful_video_record(self, wonderful_video_ret_id: Optional[int] = None) -> (
            WonderfulVideoRet(), uuid.uuid1()
    ):
        """
        根据参数获取 wonderful_video_ret_obj, user_id
        """
        if wonderful_video_ret_id:
            ## 如果指定wonderful_video_ret_id,那么直接查询该游玩记录的状态是否为
            last_wonderful_video_record_obj = WonderfulVideoRet.objects.filter(id=wonderful_video_ret_id).first()
            user_id = last_wonderful_video_record_obj.user_id if last_wonderful_video_record_obj else None
        else:
            ## 如果没有指定游玩记录id， 获取当前用户最近一段时间的游玩记录
            user_id = self.request.user.id
            # 获取精彩视频回溯时间，从key_book表中获取指定时间，否则使用默认时间
            try:
                video_backtracking_time = int(
                    KeyBookModel.objects.filter(key=settings.VIDEO_BACKTRACKING_TIME_CONF_NAME).only(
                        'value').first().value)
            except Exception:
                logger.error('获取追溯时间失败，采用默认时间', exc_info=True)
                video_backtracking_time = settings.VIDEO_BACKTRACKING_DEFAULT_TIME

            # 根据创建时间筛选游玩记录
            from_datetime = datetime.datetime.now() - datetime.timedelta(hours=video_backtracking_time)
            last_wonderful_video_record_obj = WonderfulVideoRet.objects.filter(
                create_time__gte=from_datetime,
                user_id=user_id,
                is_agg=0).order_by('-create_time').first()

        if not last_wonderful_video_record_obj:
            # 如果该用户
            if user_id and WonderfulVideoTemplateContentRet.objects.filter(user_id=user_id, status__in=(0, 2)).exists():
                raise drf_serializers.ValidationError(MAKING_VIDEO_MSG)
            else:
                raise drf_serializers.ValidationError(NOT_EXISTS_PLAY_RECORDS_MSG)
        return last_wonderful_video_record_obj, user_id

    def get(self, request, *args, **kwargs):
        # 获取并校验模板参数
        temp_video_id = request.query_params.get('temp_video_id')
        # 1表示展示视频，并推送消息；0表示不展示视频，不推送消息
        is_show = request.query_params.get('is_show', '1')
        if is_show not in ('0', '1'):
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)

        # 获取是否为重新生成的
        is_revise = request.query_params.get('is_revise', '0')
        if is_revise not in ('0', '1'):
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)

        if not temp_video_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        wonderful_video_ret_id = request.query_params.get('wonderful_video_ret_id')
        last_wonderful_video_record_obj, user_id = self.get_wonderful_video_record(wonderful_video_ret_id)
        # 查询视频模板的信息
        template_video = TemplateVideo.objects.prefetch_related('temp_seg_set', 'temp_transition_set'). \
            filter(id=temp_video_id).first()

        # 如果该游玩记录有scene_id 那么校验其与模板的scene_id 是否一致
        if last_wonderful_video_record_obj.scene_id and last_wonderful_video_record_obj.scene_id != template_video.scene_id:
            logger.warning(f'用户{user_id}选用的模板{temp_video_id}与游玩景区{last_wonderful_video_record_obj.scene_id}不符')
            return Response({'detail': VIDEO_TEMPLATE_CONFLICT_MSG}, status=status.HTTP_400_BAD_REQUEST)

        # 修改记录状态为已经聚合
        last_wonderful_video_record_obj.is_agg = 1
        last_wonderful_video_record_obj.save()

        extra_start_time = (last_wonderful_video_record_obj.create_time -
                            datetime.timedelta(minutes=settings.VIDEO_AGG_EXTRA_TIME)). \
            strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
        extra_end_time = last_wonderful_video_record_obj.create_time.strftime(
            settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)

        # 推送游玩记录id，user_id type 及template相关内容 到kafka
        value = {'user_id': user_id.hex if not isinstance(user_id, str) else user_id,
                 'wonderful_video_ret_id': last_wonderful_video_record_obj.id,
                 'extra_start_time': extra_start_time,
                 'extra_end_time': extra_end_time,
                 'type': 1,  # {'1': add操作, '2': edit操作}
                 'is_show': int(is_show),  # 推送用户的视频是否展示
                 'template_video': serializers.TemplateAllInfoSerializer(template_video).data,
                 'extra': {'is_revise': int(is_revise)}
                 }
        try:
            future = producer.send(settings.USER_V_AGG_MSG_TOPIC, value=value)
            future.get(timeout=100)
        except Exception:
            logger.error(f'用户获取精彩视频推送kafka-{settings.USER_V_AGG_MSG_TOPIC}失败', exc_info=True)
            return Response({'detail': '服务忙，请稍后重试'}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'detail': '成功'}, status=status.HTTP_200_OK)


class VideoComment(APIView):
    def post(self, request, *args, **kwargs):
        content = request.data.get('content')
        user_video_id = request.data.get('user_video_id')
        if not all([content, user_video_id]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        if len(content) > 1000:
            return Response({'detail': '内容需要小于1000字'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user_video_obj = WonderfulVideoTemplateContentRet.objects.get(id=user_video_id)
        except Exception:
            return Response({'detail': '视频不存在'}, status=status.HTTP_400_BAD_REQUEST)
        WonderfulVideoComment.objects.create(content=content, user_video_content_id=user_video_id,
                                             scene_id=user_video_obj.wonderful_video_ret.scene_id)
        return Response({'detail': '成功'})


class Test(APIView):
    def get(self, request, *args, **kwargs):
        return Response({'data': '测试接口'})
