#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/9/13下午2:57
# @Author:zwz
import logging

from django.conf import settings
from rest_framework import serializers
from django.db import models
from itsdangerous import TimedJSONWebSignatureSerializer as TJWSSerializer, BadData

from system.models import SceneModel, KeyBookModel
from utils.common import split_file_url
from video.models import SampleVideo, WonderfulVideoTemplateContentRet, WonderfulVideoAggRet, TemplateVideo, \
    TemplateTransitionEffect, TemplateUserSegment

logger = logging.getLogger('django')


class FilterTransitionEffectListSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        """
        List of object instances -> List of dicts of primitive datatypes.
        """
        # Dealing with nested relationships, data can be a Manager,
        # so, first get a queryset from the Manager if needed
        iterable = data.all() if isinstance(data, models.Manager) else data
        effect_obj_list = list()
        for item in iterable:
            try:
                transition_effect_name = item.transition_effect.name
            except Exception:
                pass
            else:
                item.transition_effect_name = transition_effect_name
                effect_obj_list.append(self.child.to_representation(item))
        return effect_obj_list


class TransitionEffectSerializer(serializers.ModelSerializer):
    transition_effect_name = serializers.CharField(label='转场名称')

    # transition_effect_name = serializers.CharField(source='transition_effect.name', label='转场名称')

    class Meta:
        model = TemplateTransitionEffect
        fields = ['transition_effect_name', 'time', 'serial_no']
        list_serializer_class = FilterTransitionEffectListSerializer


class FilterTemplateUserSegmentListSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        """
        List of object instances -> List of dicts of primitive datatypes.
        """
        # Dealing with nested relationships, data can be a Manager,
        # so, first get a queryset from the Manager if needed
        iterable = data.all() if isinstance(data, models.Manager) else data

        effect_obj_list = list()
        for item in iterable:
            try:
                item_is_used = item.is_used
            except Exception:
                pass
            else:
                if item_is_used == 1:
                    effect_obj_list.append(self.child.to_representation(item))
        return effect_obj_list


class TemplateUserSegmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateUserSegment
        fields = ('wonderful_tag', 'time', 'decoration_url', 'mask_url', 'serial_no', 'is_used', 'id', 'zoom',
                  'var_speed', 'lut_url')
        list_serializer_class = FilterTemplateUserSegmentListSerializer


class TemplateAllInfoSerializer(serializers.ModelSerializer):
    temp_transition_set = TransitionEffectSerializer(many=True, label='转场特效')
    temp_seg_set = TemplateUserSegmentSerializer(many=True, label='用户分段部分')

    class Meta:
        model = TemplateVideo
        fields = ['id', 'name', 'video_start_url', 'video_end_url', 'mask_url', 'video_music_url', 'width', 'height',
                  'temp_transition_set', 'temp_seg_set', 'start_video_time', 'end_video_time', 'scene_id', 'lut_url']


class TemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateVideo
        exclude = ["spare_str1", "spare_str2", "spare_str3", "spare_int1", "spare_int2", "spare_int3", "note",
                   "create_time"]


class SampleSerializer(serializers.ModelSerializer):
    class Meta:
        model = SampleVideo
        fields = ('id', 'name', 'video_url', 'video_image', 'create_time', 'note', 'play_type')
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class CompositeVideoSerializer(serializers.ModelSerializer):
    is_pay = serializers.IntegerField(source='wonderful_video_ret.is_pay')
    play_record_id = serializers.CharField(source='wonderful_video_ret_id')
    price = serializers.SerializerMethodField(label='视频原价')
    price_token = serializers.SerializerMethodField(label='视频原价token')
    play_type = serializers.SerializerMethodField(label='播放方式类型')
    square_image_url = serializers.SerializerMethodField(label='圆角封面')
    non_square_image_url = serializers.SerializerMethodField(label='非圆角封面')
    video_size = serializers.SerializerMethodField(label='视频大小')

    def get_video_size(self, instance):
        return f"{instance.video_size}MB"

    def get_square_image_url(self, instance):
        return instance.square_image_url or instance.template_video.template_image_url

    def get_non_square_image_url(self, instance):
        return instance.non_square_image_url or instance.template_video.template_image_url

    def get_price(self, instance):
        try:
            price = KeyBookModel.objects.filter(key=settings.VIDEO_ORG_PRICE_KEY).only('value').first().value
        except Exception:
            logger.error(f'获取景区视频价格失败', exc_info=True)
            raise serializers.ValidationError('获取视频价格失败')
        else:
            return price

    def get_price_token(self, instance):
        try:
            price = KeyBookModel.objects.filter(key=settings.VIDEO_ORG_PRICE_KEY).only('value').first().value
            serializer = TJWSSerializer(settings.SECRET_KEY, settings.PRICE_TOKEN_EXPIRES)
            price_token = serializer.dumps(price).decode()
        except Exception:
            logger.error(f'获取景区视频价格token失败', exc_info=True)
            raise serializers.ValidationError('获取景区视频价格token失败')
        else:
            return price_token

    def get_play_type(self, instance):
        width = instance.template_video.width
        height = instance.template_video.height
        if height >= width:
            # (1, "竖屏")
            return 1
        else:
            # (0, "横屏"),
            return 0

    class Meta:
        model = WonderfulVideoTemplateContentRet
        fields = ('id', 'video_url', 'play_record_id', 'template_video_id', 'is_pay', 'create_time',
                  'square_image_url', 'non_square_image_url', 'video_size', 'price', 'play_type', 'price_token',
                  'status', 'start_production_time', 'finish_production_time')
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'start_production_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'finish_production_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class HightLightsSerializer(serializers.ModelSerializer):
    class Meta:
        model = WonderfulVideoAggRet
        fields = ('id', 'user_id', 'body_coord', 'frame_start_offset', 'frame_end_offset')

    def to_representation(self, instance):
        data = super(HightLightsSerializer, self).to_representation(instance)
        data['beautiful_start_end'] = data['frame_start_offset'] + '-' + data['frame_end_offset']
        del data['frame_start_offset']
        del data['frame_end_offset']
        return data
