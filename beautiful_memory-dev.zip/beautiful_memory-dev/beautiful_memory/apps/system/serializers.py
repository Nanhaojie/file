#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/9/18上午11:20
# @Author:zwz
import json
import logging

from django.conf import settings
from rest_framework import serializers, status
from .models import LBImgModel, Introduction, SceneModel

logger = logging.getLogger("django")


class LBImgListSerializer(serializers.ModelSerializer):
    retention_time = serializers.SerializerMethodField(label='停留时间')

    def get_retention_time(self, instance):
        try:
            time = instance.scene.lb_time * 1000
        except Exception:
            logger.error('获取轮播图{instance.id}的停留时间失败', exc_info=True)
            return settings.DEFAULT_LB_RETENTION_TIME
        else:
            return time or settings.DEFAULT_LB_RETENTION_TIME

    class Meta:
        model = LBImgModel
        fields = ('name', 'url', 'type', 'video_url', 'retention_time')


class IntroductionListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Introduction
        fields = ('img_url', 'describe', 'id', 'type', 'video_url')


class SceneListSerializer(serializers.ModelSerializer):
    tel = serializers.SerializerMethodField(label='手机号列表')
    scene_id = serializers.IntegerField(source='id', label='场景id')

    def get_tel(self, instance):
        try:
            tel = json.loads(instance.tel)
        except Exception:
            logger.warning('tel解析错误', exc_info=True)
            return instance.tel
        else:
            return tel

    class Meta:
        model = SceneModel
        fields = ('full_name', 'shorter_describe', 'address', 'tel', 'business_hours', 'scene_url', 'scene_id')
