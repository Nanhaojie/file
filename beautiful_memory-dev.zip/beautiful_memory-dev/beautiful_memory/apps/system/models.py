from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class KeyBookModel(SpareFieldModel):
    name = models.CharField(max_length=128, verbose_name='名称')
    key = models.CharField(max_length=32, verbose_name='键')
    value = models.CharField(max_length=256, verbose_name='值')
    describe = models.CharField(max_length=215, null=True, blank=True, verbose_name='描述')
    is_use = models.BooleanField(default=True, verbose_name='是否在用')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        db_table = 't_key_book'
        verbose_name = '配置字典表'
        verbose_name_plural = verbose_name
        managed = False


class SceneModel(SpareFieldModel):
    full_name = models.CharField(max_length=128, verbose_name='景区全称')
    shorter_name = models.CharField(max_length=128, null=True, blank=True, verbose_name='景区简称')
    shorter_describe = models.CharField(max_length=256, null=True, blank=True, verbose_name='景区简述')
    is_default = models.BooleanField(default=False, verbose_name='是否是默认场馆')
    is_open_location = models.BooleanField(default=False, verbose_name='是否开启定位')
    location_update_time = models.DateTimeField(null=True, blank=True, verbose_name='位置更新时间')
    lb_time = models.SmallIntegerField(null=True, blank=True, verbose_name='轮播图时长')
    mask_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='蒙版图片链接')
    lng = models.DecimalField(max_digits=17, decimal_places=14, null=True, blank=True, verbose_name='经度')
    lat = models.DecimalField(max_digits=17, decimal_places=14, null=True, blank=True, verbose_name='纬度')
    address = models.CharField(max_length=256, null=True, blank=True, verbose_name='地址')
    tel = models.CharField(max_length=64, null=True, blank=True, verbose_name='电话')
    business_hours = models.CharField(max_length=64, null=True, blank=True, verbose_name='营业时间')
    price = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True, verbose_name='收费金额')
    describe = models.TextField(null=True, blank=True, verbose_name='详细描述')
    title = models.CharField(max_length=128, null=True, blank=True, verbose_name='详情标题')
    app_introduction = models.ForeignKey('AppIntroduction', null=True, blank=True, on_delete=models.PROTECT, db_constraint=False)
    scene_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='景区url')
    serial_no = models.IntegerField(default=0, verbose_name='序号')  # 从大到小排序
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        db_table = 't_scene'
        verbose_name = '景区表'
        verbose_name_plural = verbose_name
        ordering = ('-serial_no', '-id')


class SceneRangeCoordinateModel(SpareFieldModel):
    longitude = models.CharField(max_length=32, verbose_name="经度")
    latitude = models.CharField(max_length=32, verbose_name="纬度")
    scene = models.ForeignKey("SceneModel", on_delete=models.CASCADE, related_name="scene_coord_set", db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")

    class Meta:
        db_table = 't_scene_range_coordinate'
        verbose_name = '景区范围坐标表'
        verbose_name_plural = verbose_name

class LBImgModel(SpareFieldModel):
    type_choices = (
        (1, "图片"),
        (2, "视频")
    )
    name = models.CharField(max_length=128, null=True, blank=True, verbose_name='名称')
    url = models.CharField(max_length=256, verbose_name='轮播图url')
    video_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='视频链接')
    seq = models.IntegerField(default=0, verbose_name='排序字段')   # 从大到小排序
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    scene = models.ForeignKey(SceneModel, on_delete=models.CASCADE, null=True, blank=True, related_name='lb_img_set',
                              db_constraint=False)
    type = models.SmallIntegerField(default=1, choices=type_choices, verbose_name='资源类型')
    is_show = models.BooleanField(default=1, verbose_name='是否展示')

    class Meta:
        db_table = 't_lb_img'
        verbose_name = '轮播图'
        verbose_name_plural = verbose_name


class Introduction(SpareFieldModel):
    type_choices = (
        (1, "图片"),
        (2, "视频")
    )
    name = models.CharField(max_length=128, null=True, blank=True, verbose_name='名称')
    img_name = models.CharField(max_length=128, null=True, blank=True, verbose_name='图片名称')
    img_url = models.CharField(max_length=256, verbose_name='图片链接')
    video_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='视频链接')
    describe = models.CharField(max_length=1000, verbose_name='详细描述')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    type = models.SmallIntegerField(default=1, choices=type_choices, verbose_name='资源类型')
    scene = models.ForeignKey(SceneModel, on_delete=models.CASCADE, null=True, blank=True, db_constraint=False)
    seq = models.IntegerField(default=0, verbose_name='排序字段')   # 从大到小排序

    class Meta:
        db_table = 't_introduction'
        verbose_name = '随拍攻略'
        verbose_name_plural = verbose_name


class AppIntroduction(SpareFieldModel):
    full_name = models.CharField(max_length=128, unique=True, verbose_name='景区全称', error_messages={'unique':'产品广告名称已存'})
    shorter_name = models.CharField(max_length=128, null=True, blank=True, verbose_name='景区简称')
    shorter_describe = models.CharField(max_length=128, null=True, blank=True, verbose_name='景区简述')
    mask_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='蒙版图片链接')
    describe = models.TextField(null=True, blank=True, verbose_name='详细描述')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        db_table = 't_app_introduction'
        verbose_name = '产品介绍'
        verbose_name_plural = verbose_name
