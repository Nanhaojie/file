import json
import logging
import math
from decimal import Decimal

from django.core.serializers import serialize
from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.generics import ListAPIView, GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from beautiful_memory import settings
from system.models import LBImgModel, Introduction, SceneModel, AppIntroduction, KeyBookModel, SceneRangeCoordinateModel
from system.serializers import LBImgListSerializer, IntroductionListSerializer, SceneListSerializer
from utils.common import upload
from utils.scene_location import is_winded

logger = logging.getLogger("django")


class LBImgView(ListAPIView):
    pagination_class = None
    serializer_class = LBImgListSerializer

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            return LBImgModel.objects.filter(scene_id=scene_id, is_show=1).order_by('-seq', '-id')
        else:
            return LBImgModel.objects.filter(is_show=1).order_by('-seq', '-id')[:4]


class IntroductionView(ListAPIView):
    serializer_class = IntroductionListSerializer

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            return Introduction.objects.filter(scene_id=scene_id).order_by('-seq', '-id')
        else:
            return Introduction.objects.filter().order_by('-seq', '-id')


class TopicDescriptionView(APIView):
    def get_object(self):
        """
        Returns the object the view is displaying.
        """
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            scene_obj = SceneModel.objects.filter(id=scene_id).only('shorter_name', 'shorter_describe', 'mask_url')
        else:
            scene_obj = SceneModel.objects.only('shorter_name', 'shorter_describe', 'mask_url')[:1]
        return scene_obj

    def get(self, request):
        try:
            scene_obj = self.get_object()[0]
            data = {
                'scene_shorter_name': scene_obj.shorter_name,
                'scene_shorter_describe': scene_obj.shorter_describe,
                'scene_mask_url': scene_obj.mask_url,
                'app_shorter_name': scene_obj.app_introduction.shorter_name,
                'app_shorter_describe': scene_obj.app_introduction.shorter_describe,
                'app_mask_url': scene_obj.app_introduction.mask_url
            }
        except Exception:
            logger.error('获取景区信息失败', exc_info=True)
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data)


class SceneListView(ListAPIView):
    queryset = SceneModel.objects.filter(is_open_location=1)
    serializer_class = SceneListSerializer


class SceneDetailsView(GenericAPIView):
    field_names = ['full_name', 'lng', 'lat', 'address', 'tel', 'business_hours', 'describe', 'title']

    def get_object(self):
        """
        Returns the object the view is displaying.
        """
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            scene_obj = SceneModel.objects.filter(id=scene_id).only(*self.field_names)
        else:
            scene_obj = SceneModel.objects.only(*self.field_names)[:1]
        return scene_obj

    def get(self, request):
        try:
            instance = self.get_object()
            data = instance.values(*self.field_names)[0]
            data['tel'] = json.loads(data['tel'])
        except Exception:
            logger.error('获取景区信息失败', exc_info=True)
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data)


class AppDetailsView(GenericAPIView):
    field_names = ['full_name', 'describe']

    def get_object(self):
        """
        Returns the object the view is displaying.
        """
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            scene_obj = SceneModel.objects.filter(id=scene_id).only('app_introduction_id').first()
            app_obj = AppIntroduction.objects.filter(id=scene_obj.app_introduction_id).only(*self.field_names)
        else:
            scene_obj = SceneModel.objects.only('app_introduction_id').first()
            app_obj = AppIntroduction.objects.filter(id=scene_obj.app_introduction_id).only(*self.field_names)
        return app_obj

    def get(self, request):
        try:
            instance = self.get_object()
            data = instance.values(*self.field_names)[0]
        except Exception:
            logger.error('获取产品信息失败', exc_info=True)
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data)


class LocationStatusView(APIView):

    def get(self, request, *args, **kwargs):
        try:
            local_switch_status_obj = KeyBookModel.objects.get(key=settings.LOCATION_SWITCH_CONF_NAME)
        except Exception:
            logger.error('获取定位开关信息失败', exc_info=True)
            data = {'detail': '使用默认状态', 'status': settings.LOCATION_SWITCH_DEFAULT_VALUE}
        else:
            data = {'detail': '成功', 'status': local_switch_status_obj.value}
        try:
            face_switch_status_obj = KeyBookModel.objects.get(key=settings.FACE_SWITCH_CONF_NAME)
        except Exception:
            logger.error('获取人脸开关信息失败', exc_info=True)
            data['other_status'] = settings.FACE_SWITCH_DEFAULT_VALUE
        else:
            data['other_status'] = face_switch_status_obj.value
        return Response(data)


class LocationSceneView(APIView):

    def get(self, request, *args, **kwargs):
        try:
            lat = float(request.query_params.get('lat'))
            lng = float(request.query_params.get('lng'))
        except Exception:
            logger.error('定位参数错误', exc_info=True)
            return Response({'detail': '定位参数错误'}, status=status.HTTP_400_BAD_REQUEST)

        # 查询默认定位景区id及景区名字
        default_scene = SceneModel.objects.filter(is_default=1).only('id', 'full_name').first()
        if not default_scene:
            default_scene = SceneModel.objects.only('id', 'full_name').first()
            logger.warning('未设置默认景区，将采用第一个景区为默认景区')

        # 查询定位总开关 是否开启
        try:
            local_switch_status = KeyBookModel.objects.filter(key=settings.LOCATION_SWITCH_CONF_NAME).only(
                'value').first().value
        except Exception:
            logger.error('获取定位开关信息失败，返回默认定位景区', exc_info=True)
            return Response(data={'scene_full_name': default_scene.full_name, 'scene_id': default_scene.id})

        # 没有开启直接返回默认景区
        if local_switch_status == '0':
            return Response(data={'scene_full_name': default_scene.full_name, 'scene_id': default_scene.id})

        # 总定位开关开启，根据坐标更新时间字段倒排，遍历所有开启开关的景区的 所有点的经纬度
        scene_set = SceneModel.objects.prefetch_related('scene_coord_set'). \
            filter(is_open_location=1).order_by('-location_update_time').only('id', 'full_name')

        # 遍历景区，分别进行用户坐标点是否在景区的判断
        for scene_obj in scene_set:
            scene_coord_list = list()
            for scene_coord in scene_obj.scene_coord_set.all():
                scene_coord_list.append((float(scene_coord.longitude), float(scene_coord.latitude)))

            if scene_coord_list and is_winded([lng, lat], scene_coord_list):
                return Response(data={'scene_full_name': scene_obj.full_name, 'scene_id': scene_obj.id})

        # 遍历完都没有，返回默认景区
        return Response(data={'scene_full_name': default_scene.full_name, 'scene_id': default_scene.id})


class GetKeyBook(APIView):

    def get(self, request, *args, **kwargs):
        conf_objs = KeyBookModel.objects.all()
        conf_name = ['key', 'value']  # , 'describe', 'is_use', 'create_time', 'name'
        key_book_conf = []
        for conf_obj in conf_objs:
            data = [getattr(conf_obj, name) for name in conf_name]
            key_book_conf.append(data)
        return Response(data={'conf_key_books': key_book_conf})


class ImgUploadView(APIView):
    permission_classes = (IsAuthenticated, )

    def post(self, request):
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': '文件不能为空'}, status=status.HTTP_400_BAD_REQUEST)
        ret = upload(file.read(), file_prefix='mysp/img/')
        return Response(data={'pic_url': ret}, status=status.HTTP_200_OK)
