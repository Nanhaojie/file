#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/17上午10:51
#@Author:zwz
from django.urls import path

from system.views import LBImgView, IntroductionView, TopicDescriptionView, SceneDetailsView, AppDetailsView, \
    LocationStatusView, LocationSceneView, GetKeyBook, SceneListView, ImgUploadView

urlpatterns = [
    path('lb_img', LBImgView.as_view()),      # 首页轮播图
    path('introduction', IntroductionView.as_view()),      # 随拍攻略列表
    path('scene_desc', TopicDescriptionView.as_view()),      # 首页景区简描
    path('scene_detail', SceneDetailsView.as_view()),      # 景区详情
    path('scenes', SceneListView.as_view()),      # 景区详情
    path('app_detail', AppDetailsView.as_view()),      # 产品详情

    path('location_status', LocationStatusView.as_view()),      # 获取系统定位配置
    path('location_scene', LocationSceneView.as_view()),      # 根据用户定位信息获取所在景点
    path('key_book_conf', GetKeyBook.as_view()),      # 根据用户定位信息获取所在景点

    path('upload', ImgUploadView.as_view()),      # 上传图片
]
