#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/17上午10:51
#@Author:zwz
from django.urls import path

from promotions.views import SharePolitelyView, LotteryDrawNumView, PrizeContentView, LotteryResultView, \
    QuestionnaireView, InitStatusView

urlpatterns = [
    path('share_politely', SharePolitelyView.as_view()),      # 分享接口
    path('lottery_draw_num', LotteryDrawNumView.as_view()),      # 抽奖次数查询
    path('prize_content', PrizeContentView.as_view()),      # 转盘奖项内容查询
    path('lottery_result', LotteryResultView.as_view()),      # 抽奖接口

    path('questionnaire', QuestionnaireView.as_view()),      # 问卷题目列表接口

    path('init_status', InitStatusView.as_view()),      # 问卷题目列表接口
]
