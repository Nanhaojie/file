from django.conf import settings
from django.test import TestCase

# Create your tests here.


import os
import sys

# Create your tests here.


if not os.getenv('DJANGO_SETTINGS_MODULE'):
    os.getenv('DJANGO_SETTINGS_MODULE')
    sys.path.insert(0, '../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()

from django_redis import get_redis_connection
from redis import StrictRedis
from promotions.models import QuestionnaireRecordModel, QuestionnaireResultsDetailModel
from user.models import User


def init_user_share(user_id):
    redis_conn = get_redis_connection()  # type: StrictRedis
    redis_conn.hdel(settings.USER_SHARE_NUM_STAT_REDIS_KEY, user_id)
    print(f'{user_id} 用户分享状态重置成功')


def init_user_questionnaire(user_id):
    QuestionnaireRecordModel.objects.filter(user_id=user_id).delete()
    QuestionnaireResultsDetailModel.objects.filter(user_id=user_id).delete()
    print(f'{user_id} 用户答卷状态重置成功')


if __name__ == '__main__':
    mobile = '17788122304'
    # mobile = '19937759697'
    user_id = User.objects.get(mobile=mobile).id.hex
    init_user_share(user_id)
    init_user_questionnaire(user_id)
