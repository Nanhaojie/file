import calendar
import datetime
import logging

import numpy as np
from django.conf import settings

# Create your views here.
from django.db import transaction
from django.utils.timezone import now
from redis import StrictRedis
from rest_framework import status
from rest_framework.generics import ListAPIView, CreateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django_redis import get_redis_connection

from orders.models import RedeemCoupon
from promotions.constants import COUPON_TEMPLATE_DICT
from promotions.models import PrizeContentModel, LotteryRecordModel, QuestionnaireModel, QuestionnaireRecordModel, \
    QuestionnaireResultsDetailModel
from promotions.serializers import PrizeContentSerializer, QuestionnaireListSerializer, \
    QuestionnaireRecordSerializer
from user.models import User

logger = logging.getLogger('django')


class RedeemCouponData:
    def __init__(self, scene_id):
        self.scene_id = scene_id
        self.coupon_dict = COUPON_TEMPLATE_DICT

    def get_new_write_off_code(self, user_id: str):
        # 核销码write_off_code，包含 优惠劵发放scene_id中最后一个数字 | 优惠劵所属用户id hash得到的一位数字 | 与时间相关的6个数字
        for _ in range(10):
            write_off_code = f'{self.scene_id % 10}{int(user_id, 16) % 10}{str(now().microsecond).zfill(6)}'
            # 查询是否重复
            if not RedeemCoupon.objects.filter(write_off_code=write_off_code).exists():
                return write_off_code
        raise Exception('获取核销码失败，请稍后重试')

    def get_new_coupon_data(self, user_id, value):
        # 获取该场馆下固有信息  默认备注 优惠劵默认名称
        scene_coupon_dict = self.coupon_dict.get(self.scene_id)
        if not scene_coupon_dict:
            raise Exception(f'缺少{self.scene_id}场馆下的数据')
        # 计算过期时间
        coupon_exp_day = scene_coupon_dict.pop('coupon_exp_day', settings.DEFAULT_COUPON_EXP_DAY)
        expiration_date = (now() + datetime.timedelta(days=coupon_exp_day)) \
                              .strftime(settings.SERIALIZER_DATE_FIELD_FORMAT) + ' 23:59:59'
        scene_coupon_dict['expiration_date'] = expiration_date

        # 获取优惠码
        scene_coupon_dict['write_off_code'] = self.get_new_write_off_code(user_id)
        # 计算优惠劵类型，默认为2；如果面额为 -1时 为3
        if value == -1 or value == '-1':
            scene_coupon_dict['type'] = 3
            scene_coupon_dict['note'] = '免单时长为1小时'
            logger.info(f'-------------{scene_coupon_dict}')
        else:
            scene_coupon_dict['type'] = 2
        # 组装面额
        scene_coupon_dict['value'] = value
        # 组装数据并返回
        scene_coupon_dict['scene_id'] = self.scene_id
        scene_coupon_dict['user_id'] = user_id
        scene_coupon_dict['spare_str1'] ='有效期:' + str((datetime.datetime.now()+datetime.timedelta(days=1)).strftime("%Y.%m.%d")) + '-' + \
                                         str((now() + datetime.timedelta(days=coupon_exp_day)).strftime("%Y.%m.%d"))
        return scene_coupon_dict


class SharePolitelyView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        """用户分享接口"""
        user_id = request.user.id.hex
        redis_conn = get_redis_connection()  # type: StrictRedis
        user_share_num = redis_conn.hincrby(settings.USER_SHARE_NUM_STAT_REDIS_KEY, user_id)
        # 如果用户第一次分享
        if user_share_num == 1:
            # 用户抽奖次数 +1
            redis_conn.hincrby(settings.USER_LOTTERY_DRAW_NUM_STAT_REDIS_KEY, user_id)
        return Response({'detail': '成功'})


class LotteryDrawNumView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        """用户抽奖次数查询"""
        user_id = request.user.id.hex
        redis_conn = get_redis_connection()  # type: StrictRedis
        lottery_draw_num = redis_conn.hget(settings.USER_LOTTERY_DRAW_NUM_STAT_REDIS_KEY, user_id) or "0"
        return Response({'lottery_draw_num': lottery_draw_num})


class PrizeContentView(ListAPIView):
    pagination_class = None
    serializer_class = PrizeContentSerializer

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        if scene_id:
            return PrizeContentModel.objects.filter(scene_id=scene_id)
        else:
            return PrizeContentModel.objects.filter()


class LotteryResultView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        # 1. 参数校验
        lottery_source = request.query_params.get('lottery_source')
        scene_id = request.query_params.get('scene_id')
        if not all([scene_id, lottery_source]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            lottery_source, scene_id = map(int, [lottery_source, scene_id])
        except Exception:
            logger.warning('类型转换错误', exc_info=True)
            return Response({'detail': '参数类型错误'}, status=status.HTTP_400_BAD_REQUEST)

        # 校验用户抽奖次数
        user = request.user
        user_id = user.id.hex
        redis_conn = get_redis_connection()  # type: StrictRedis
        lottery_draw_num = redis_conn.hget(settings.USER_LOTTERY_DRAW_NUM_STAT_REDIS_KEY, user_id) or "0"
        if int(lottery_draw_num) <= 0:
            return Response({'detail': '剩余抽奖次数为0'}, status=status.HTTP_400_BAD_REQUEST)

        # 2. 统计每个奖项的概率 构造的数据结构为 {id: prob}
        prize_content_queryset = PrizeContentModel.objects.filter(scene_id=scene_id)
        # 查询场馆下 可以追加概率的奖品；初始化构造体，记录add_id
        add_probability_prize_obj = prize_content_queryset.filter(add_probability_flag=1).first()
        if not add_probability_prize_obj:
            logger.warning('未找到可追加概率的奖品', exc_info=True)
            add_probability_prize_obj = prize_content_queryset.filter(prize_limit__isnull=True).first()

        if not add_probability_prize_obj:
            return Response({'detail': '抽奖系统缺少元数据'}, status=status.HTTP_400_BAD_REQUEST)

        prize_id_2_prob_dict = {add_probability_prize_obj.id: add_probability_prize_obj.probability}
        add_prize_id = add_probability_prize_obj.id
        # 查询场馆下所有奖品
        redis_conn = get_redis_connection()  # type: StrictRedis
        for prize_obj in prize_content_queryset:
            # 如果是追加概率的奖品，continue
            if prize_obj.id == add_prize_id:
                continue
            if prize_obj.prize_limit is None:
                # 如果limit为空的奖品
                # 将概率写入构造体
                prize_id_2_prob_dict[prize_obj.id] = prize_obj.probability
            else:
                # 如果limit不为空的奖品
                # 查询该周期下是否有余量
                inventory_quantity = redis_conn.hget(f"{settings.PRIZE_INVENTORY_PREFIX}{prize_obj.refresh_cycle_type}",
                                                     prize_obj.id)
                # 如果查询结果为空，默认数量初始化到指定redis键中，并设定过期时间；将概率加入构造体
                if inventory_quantity is None:
                    prize_id_2_prob_dict[prize_obj.id] = prize_obj.probability
                    inventory_quantity_redis_key = f"{settings.PRIZE_INVENTORY_PREFIX}{prize_obj.refresh_cycle_type}"
                    redis_conn.hset(inventory_quantity_redis_key, prize_obj.id, prize_obj.prize_limit)
                    init_date = datetime.datetime.now()
                    if prize_obj.refresh_cycle_type == 1:
                        # 计算出下一个循环周期的时间
                        middle_datetime = init_date + datetime.timedelta(days=1)
                    elif prize_obj.refresh_cycle_type == 2:
                        middle_datetime = init_date + datetime.timedelta(days=(7 - init_date.weekday()))
                    elif prize_obj.refresh_cycle_type == 3:
                        days_num = calendar.monthrange(init_date.year, init_date.month)[1]
                        middle_datetime = datetime.date(year=init_date.year, month=init_date.month, day=1) \
                                          + datetime.timedelta(days=days_num)
                    else:
                        return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
                    refresh_cycle_datetime = datetime.datetime(middle_datetime.year, middle_datetime.month,
                                                               middle_datetime.day)
                    redis_conn.expireat(inventory_quantity_redis_key, refresh_cycle_datetime)
                elif int(inventory_quantity) <= 0:
                    # 如果余量为0，那么修改该奖项的概率为0，原概率追加到可追加概率的奖品上
                    prize_id_2_prob_dict[prize_obj.id] = 0
                    prize_id_2_prob_dict[add_prize_id] += prize_obj.probability
                else:
                    # 否则；将概率加入构造体
                    prize_id_2_prob_dict[prize_obj.id] = prize_obj.probability

        # 3. 开始抽奖
        np.random.seed(None)
        p = np.array(list(map(lambda x: float(x) / 100, prize_id_2_prob_dict.values())))
        prize_id = np.random.choice(list(prize_id_2_prob_dict.keys()), p=p.ravel())

        # 4. 创建抽奖记录
        # 如果奖品为门票优惠劵
        prize_obj = PrizeContentModel.objects.get(id=prize_id)
        with transaction.atomic():
            if prize_obj.prize_type == 1:
                distribution_status = None
                try:
                    coupon_data = RedeemCouponData(scene_id).get_new_coupon_data(user_id, prize_obj.prize_value)
                except Exception:
                    logger.info(f'{user.id} 获取优惠劵数据失败', exc_info=True)
                    raise Exception('优惠劵补充中，请稍后重试')
                RedeemCoupon.objects.create(**coupon_data)
            elif prize_obj.prize_type == 2:
                distribution_status = 0
            else:
                raise Exception('奖品类型错误')

            LotteryRecordModel.objects.create(
                prize_value=prize_obj.prize_value, prize_type=prize_obj.prize_type, mobile=user.mobile,
                user_id=user_id, distribution_status=distribution_status, lottery_source=lottery_source,
                scene_id=scene_id
            )

        # 将对应奖品余量 -1
        inventory_quantity_redis_key = f"{settings.PRIZE_INVENTORY_PREFIX}{prize_obj.refresh_cycle_type}"
        redis_conn.hincrby(inventory_quantity_redis_key, str(prize_id), -1)
        # 用户抽奖次数 -1
        redis_conn.hincrby(settings.USER_LOTTERY_DRAW_NUM_STAT_REDIS_KEY, user_id, -1)

        # 5. 返回抽奖结果
        return Response({'prize_id': prize_id})


class QuestionnaireView(ListAPIView, CreateAPIView):
    pagination_class = None
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        scene_id = self.request.query_params.get('scene_id')
        return QuestionnaireModel.objects.filter(scene_id=scene_id, is_delete=False)

    def get_serializer_class(self):
        if self.request.method.lower() == 'get':
            return QuestionnaireListSerializer
        elif self.request.method.lower() == 'post':
            return QuestionnaireRecordSerializer

    def list(self, request, *args, **kwargs):
        scene_id = self.request.query_params.get('scene_id')
        if not scene_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        return super(QuestionnaireView, self).list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        # 第一次答题时 抽奖次数+1
        user_id = request.user.id.hex
        if QuestionnaireRecordModel.objects.filter(user_id=user_id).count() == 1:
            redis_conn = get_redis_connection()  # type: StrictRedis
            redis_conn.hincrby(settings.USER_LOTTERY_DRAW_NUM_STAT_REDIS_KEY, user_id)
        return Response({'detail': '成功'}, status=status.HTTP_201_CREATED)


class InitStatusView(APIView):
    def get(self, request, *args, **kwargs):
        mobile = self.request.query_params.get('mobile')
        user_id = User.objects.get(mobile=mobile).id.hex
        redis_conn = get_redis_connection()  # type: StrictRedis
        redis_conn.hdel(settings.USER_SHARE_NUM_STAT_REDIS_KEY, user_id)
        QuestionnaireRecordModel.objects.filter(user_id=user_id).delete()
        QuestionnaireResultsDetailModel.objects.filter(user_id=user_id).delete()
        logger.info(f'{user_id} 用户答卷及分享状态重置成功')
        return Response({'detail': '成功'})
