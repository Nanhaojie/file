from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class QuestionnaireModel(SpareFieldModel):
    q_type_choices = (
        (1, "单选"),
        (2, "多选"),
    )
    q_type = models.SmallIntegerField(choices=q_type_choices, verbose_name="问题类型")
    q_title = models.CharField(max_length=1024, verbose_name="题目内容")
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, db_constraint=False)
    option = models.CharField(max_length=2048, verbose_name="题目选项")
    is_delete = models.BooleanField(default=0, verbose_name="软删除标识")
    seq = models.SmallIntegerField(default=0, verbose_name='排序字段')

    class Meta:
        verbose_name = '问卷题目表'
        verbose_name_plural = verbose_name
        db_table = 't_questionnaire'
        ordering = ('-seq',)


class QuestionnaireRecordModel(SpareFieldModel):
    user = models.ForeignKey('user.User', on_delete=models.DO_NOTHING, db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name='创建时间')
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, db_constraint=False)
    other_suggest = models.CharField(max_length=500, null=True, blank=True, verbose_name="其他建议")

    class Meta:
        verbose_name = '问卷答题记录表'
        verbose_name_plural = verbose_name
        db_table = 't_questionnaire_record'
        ordering = ('-create_time',)


class QuestionnaireResultsDetailModel(SpareFieldModel):
    questionnaire_record = models.ForeignKey(QuestionnaireRecordModel, on_delete=models.DO_NOTHING, db_constraint=False)
    questionnaire = models.ForeignKey(QuestionnaireModel, on_delete=models.CASCADE, db_constraint=False)
    user = models.ForeignKey('user.User', on_delete=models.DO_NOTHING, db_constraint=False)
    option_ret = models.SmallIntegerField(verbose_name="题目选项")
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, db_constraint=False)

    class Meta:
        verbose_name = '问卷答案详情表'
        verbose_name_plural = verbose_name
        db_table = 't_questionnaire_results_detail'


class PrizeContentModel(SpareFieldModel):
    prize_type_choices = (
        (1, "门票优惠券"),
        (2, "现金红包"),
    )
    refresh_cycle_type_choices = (
        (1, "day"),
        (2, "week"),
        (3, "month"),
    )
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, db_constraint=False)
    name = models.CharField(max_length=16, verbose_name="奖品名称")
    probability = models.DecimalField(max_digits=5, decimal_places=2, verbose_name="抽奖初始化概率")
    add_probability_flag = models.BooleanField(default=0, verbose_name="追加概率标识")
    refresh_cycle_type = models.SmallIntegerField(choices=refresh_cycle_type_choices, default=1,
                                                  verbose_name="奖品上限刷新周期")
    prize_limit = models.IntegerField(null=True, blank=True, verbose_name="周期内奖品上限")
    prize_value = models.CharField(max_length=11, null=True, blank=True, verbose_name="奖品面额，-1表示免单劵")
    prize_type = models.SmallIntegerField(choices=prize_type_choices, verbose_name="奖品类型")
    seq = models.SmallIntegerField(default=0, verbose_name='排序字段')

    class Meta:
        verbose_name = '抽奖奖品内容表'
        verbose_name_plural = verbose_name
        db_table = 't_prize_content'
        ordering = ('-seq',)


class LotteryRecordModel(SpareFieldModel):
    prize_type_choices = (
        (1, "门票优惠券"),
        (2, "现金红包"),
    )
    lottery_source_choices = (
        (1, "分享有礼"),
        (2, "问卷有礼"),
    )
    prize_value = models.CharField(max_length=11, null=True, blank=True, verbose_name="奖品面额，-1表示免单劵")
    prize_type = models.SmallIntegerField(choices=prize_type_choices, verbose_name="奖品类型")
    mobile = models.CharField(max_length=11, verbose_name="手机号")
    user = models.ForeignKey('user.User', on_delete=models.CASCADE, db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, db_index=True, verbose_name='更新时间')
    distribution_status = models.BooleanField(null=True, blank=True, verbose_name="奖品发放状态")
    lottery_source = models.SmallIntegerField(choices=lottery_source_choices, verbose_name="抽奖来源")
    scene = models.ForeignKey("system.SceneModel", on_delete=models.CASCADE, db_constraint=False)

    class Meta:
        verbose_name = '抽奖记录表'
        verbose_name_plural = verbose_name
        db_table = 't_lottery_record'
        ordering = ('-create_time',)
