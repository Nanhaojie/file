#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2022/2/21上午11:20
# @Author: yueyuanbo
import json
import logging

from django.db import transaction, models
from rest_framework import serializers

from promotions.models import PrizeContentModel, QuestionnaireModel, QuestionnaireResultsDetailModel, \
    QuestionnaireRecordModel
from system.models import SceneModel

logger = logging.getLogger("django")


class PrizeContentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PrizeContentModel
        fields = ('name', 'id', 'prize_value', 'prize_type')


class QuestionnaireListListSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        """
        List of object instances -> List of dicts of primitive datatypes.
        """
        # Dealing with nested relationships, data can be a Manager,
        # so, first get a queryset from the Manager if needed
        iterable = data.all() if isinstance(data, models.Manager) else data
        representation_data_list = list()
        for index, item in enumerate(iterable):
            representation_data = self.child.to_representation(item)
            representation_data['q_title'] = f"{index + 1}.{representation_data['q_title']}"
            representation_data_list.append(representation_data)
        return representation_data_list


class QuestionnaireListSerializer(serializers.ModelSerializer):
    option = serializers.SerializerMethodField(label='选项')

    def get_option(self, instance):
        try:
            option_obj = json.loads(instance.option)
        except Exception:
            logger.error('选项数据格式错误')
            raise Exception('选项数据格式错误')
        else:
            return option_obj

    class Meta:
        model = QuestionnaireModel
        fields = ('id', 'q_type', 'q_title', 'option')
        list_serializer_class = QuestionnaireListListSerializer


class QuestionnaireSerializer(serializers.ModelSerializer):
    option_ret_list = serializers.ListField(min_length=1, child=serializers.IntegerField(label='选项索引'))

    class Meta:
        model = QuestionnaireResultsDetailModel
        fields = ('questionnaire', 'option_ret_list')


class QuestionnaireRecordSerializer(serializers.Serializer):
    questionnaire_results = QuestionnaireSerializer(many=True)
    scene_id = serializers.IntegerField(label="场馆id")
    other_suggest = serializers.CharField(max_length=2048, required=False, label="其他建议")

    class Meta:
        fields = ('questionnaire_results', 'other_suggest')

    def create(self, validated_data):
        user = self.context['request'].user
        scene_id = validated_data.get('scene_id')
        other_suggest = validated_data.get('other_suggest')
        if not SceneModel.objects.filter(id=scene_id).exists():
            raise serializers.ValidationError('场馆不存在')
        questionnaire_results = validated_data.get('questionnaire_results')
        with transaction.atomic():
            # 创建答题记录
            questionnaire_record = QuestionnaireRecordModel.objects.create(user=user, scene_id=scene_id,
                                                                           other_suggest=other_suggest)
            questionnaire_results_obj_list = list()
            # 遍历questionnaire_results
            for questionnaire_result in questionnaire_results:
                option_ret_list = questionnaire_result.get('option_ret_list')
                questionnaire = questionnaire_result.get('questionnaire')
                # 遍历option_ret,创建记录
                for option_ret in option_ret_list:
                    questionnaire_results_obj_list.append(
                        QuestionnaireResultsDetailModel(
                            questionnaire=questionnaire, user=user, option_ret=option_ret, scene_id=scene_id,
                            questionnaire_record=questionnaire_record
                        )
                    )
            # 批量添加数据库
            QuestionnaireResultsDetailModel.objects.bulk_create(questionnaire_results_obj_list)
        return {'scene_id': scene_id, 'questionnaire_results': questionnaire_results}
