# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2/22/22 10:27 AM
# @author yueyuanbo
from django.conf import settings

COUPON_TEMPLATE_DICT = {
    1: {
        'coupon_exp_day': settings.DEFAULT_COUPON_EXP_DAY,
        'note': '限购买2小时以上的套餐可用',
        'name': 'DO JUMP蹦床馆现金优惠券',
    },
}