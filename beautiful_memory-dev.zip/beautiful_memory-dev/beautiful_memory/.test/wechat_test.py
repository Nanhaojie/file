#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/9/8上午11:03
# @Author:zwz
import base64
import datetime
import json

import requests
import jwt
from Crypto import Random
from Crypto.Cipher import AES
from Crypto.Signature import PKCS1_v1_5
from Crypto.PublicKey import RSA
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from Crypto.Hash import SHA256


def code_2_session(code, AppID, AppSecret):
    url = f"https://api.weixin.qq.com/sns/jscode2session?appid={AppID}&secret={AppSecret}&js_code={code}&grant_type=authorization_code"
    resp = requests.get(url).json()
    errcode = resp.get('errcode')
    openid = resp.get('openid')
    session_key = resp.get('session_key')
    return errcode, openid, session_key


def get_access_token(AppID, AppSecret):
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={AppID}&secret={AppSecret}"
    resp = requests.get(url).json()
    errcode = resp.get('errcode')
    access_token = resp.get('access_token')
    expires_in = resp.get('expires_in')
    return errcode, access_token, expires_in


def my_jwt_encode():
    headers = {
        "alg": "HS256",
        "typ": "JWT"
    }
    salt = "asgfdgerher"
    payload = {
        "name": "dawsonenjoy",
        "exp": datetime.datetime.now() + datetime.timedelta(minutes=1)
    }
    token = jwt.encode(payload=payload, key=salt, algorithm='HS256', headers=headers).decode('utf-8')
    print(token)
    return token


def my_jwt_decode(token):
    jwt.decode(token, 'asgfdgerher', True, algorithm='HS256')


class WXBizDataCrypt:
    def __init__(self, appId, sessionKey):
        self.appId = appId
        self.sessionKey = sessionKey

    def decrypt(self, encryptedData, iv):
        # base64 decode
        sessionKey = base64.b64decode(self.sessionKey)
        encryptedData = base64.b64decode(encryptedData)
        iv = base64.b64decode(iv)

        cipher = AES.new(sessionKey, AES.MODE_CBC, iv)

        decrypted = json.loads(self._unpad(cipher.decrypt(encryptedData)))

        if decrypted['watermark']['appid'] != self.appId:
            raise Exception('Invalid Buffer')

        return decrypted

    def _unpad(self, s):
        return s[:-ord(s[len(s) - 1:])]


def main():
    appId = 'wx4f4bc4dec97d474b'
    sessionKey = 'tiihtNczf5v6AKRyjwEUhQ=='
    encryptedData = 'CiyLU1Aw2KjvrjMdj8YKliAjtP4gsMZMQmRzooG2xrDcvSnxIMXFufNstNGTyaGS9uT5geRa0W4oTOb1WT7fJlAC+oNPdbB+3hVbJSRgv+4lGOETKUQz6OYStslQ142dNCuabNPGBzlooOmB231qMM85d2/fV6ChevvXvQP8Hkue1poOFtnEtpyxVLW1zAo6/1Xx1COxFvrc2d7UL/lmHInNlxuacJXwu0fjpXfz/YqYzBIBzD6WUfTIF9GRHpOn/Hz7saL8xz+W//FRAUid1OksQaQx4CMs8LOddcQhULW4ucetDf96JcR3g0gfRK4PC7E/r7Z6xNrXd2UIeorGj5Ef7b1pJAYB6Y5anaHqZ9J6nKEBvB4DnNLIVWSgARns/8wR2SiRS7MNACwTyrGvt9ts8p12PKFdlqYTopNHR1Vf7XjfhQlVsAJdNiKdYmYVoKlaRv85IfVunYzO0IKXsyl7JCUjCpoG20f0a04COwfneQAGGwd5oa+T8yO5hzuyDb/XcxxmK01EpqOyuxINew=='
    iv = 'r7BXXKkLb8qrSNn05n0qiA=='

    pc = WXBizDataCrypt(appId, sessionKey)

    print(pc.decrypt(encryptedData, iv))


def decrypt(nonce, ciphertext, associated_data):
    key = 'bf1dfacf67d811e89a23408d5c985711'
    key_bytes = str.encode(key)
    nonce_bytes = str.encode(nonce)
    ad_bytes = str.encode(associated_data)
    data = base64.b64decode(ciphertext)
    aesgcm = AESGCM(key_bytes)
    return aesgcm.decrypt(nonce_bytes, data, ad_bytes).decode('UTF-8')


def rsa_verify(timestamp, nonce, body, signature):
    sign_str = f'{timestamp}\n{nonce}\n{body}\n'
    public_key = '''MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArnJsA2aF5xZWs8V8Ec3k
                WOMvjT2Ylthc4p9ivuVsoHDtDz0Bzj+NZSDXw4VoJXFBDJJKdxqINP1anniuioYs
                SE9GmIZu08eOGnL7EDdUUSpK7tfee/iieWFYqHsxhJk3CGmAF+zn+fTMG23zJuO6
                GSbv45QsICDMNuyscRa6t0EZrv5FMUDYKou28KQOzccVH9/Hm6LBvIJAC+MI2vet
                F4ZKTZ7OXhUnI9RvSlTybrQ1dRHXWXbqgSVWbMqHdTuVScEAhdLoFXlprLrPUQ3X
                VsV+qQ9t5PIri7e/4L1JWxtfof6pDFZmSpad+NiNVNvspUoaUZc6cFppSzu+aDIN
                xQIDAQAB'''

    signature = base64.b64decode(signature)
    # try:
    #     public_key.verify(signature, message, PKCS1v15(), SHA256())
    # except InvalidSignature:
    #     return False
    # return True

    # public_keyBytes = base64.b64decode(public_key)
    # pubKey = RSA.importKey(public_keyBytes)
    verifier = PKCS1_v1_5.new(RSA.importKey(base64.b64decode(public_key)))
    # verifier = PKCS1_v1_5.new(RSA.importKey(public_key))
    h = SHA256.new(sign_str.encode('utf-8'))
    # h = SHA256.new()
    # h.update(sign_str.encode('utf-8'))
    return verifier.verify(h, signature)


def get_pub_pri():
    random_generator = Random.new().read
    rsa = RSA.generate(2048, random_generator)

    private_pem = rsa.exportKey()

    f = open('MY_KEY1_pri.pem', 'w')
    f.write(private_pem.decode())
    f.close()

    public_pem = rsa.publickey().exportKey()
    f = open('MY_KEY1_pub.pem', 'w')
    f.write(public_pem.decode())


def my_sign():
    private_key = "-----BEGIN PRIVATE KEY-----\n"\
            "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCVOq5uboTb6W0B"\
            "uGt0YwH+MTLAdBicbc5mdR5ljgfd0jcB01QqqygW8J9JKnj/1Ou85Vzbp10IQnmy"\
            "5MzFHwsto0H2kfPflw1UOva5eX9LLz3Xn33uaWTD74ZFQfeC9O5SKq/JI8ubQbMy"\
            "Otn1Ft6wEl0bPoPGVKhPQs2ewiTHzXe9Ci77ZaPtSNNIVGkSVlQ8wm8DGrrgmKz4"\
            "WXpRBRXPgU6iLGXCvbKS97HzaTzDTFIPuzEYzacSjYFPW72SLrr84lGJL4hGByog"\
            "+Bkp4r1kI0yNbPIVDyUKNpqGtQGIucyNXnKzhbX5NP9xBxo05I6O7gfcI+rWIafw"\
            "Uq1ivSq1AgMBAAECggEAHJzx0S7Tvq7VPd00jU5mlWythIU+KtBLIQ4X0/UVwQyL"\
            "i4gPvVawCyX8BLVmGfejc8autVcz2V+Voh2IvcskA44oGbUGg7qczae4ovuO0sWu"\
            "H+fu54XB0mfc4O6zHKMGBy80IWcBpTVFvL3YCMxnym7a91xXO/IDi58NegFTuBN8"\
            "ilcQ/zhomGRScPv7vNZmrR6SPiavifuqWWNsFz+PLTkX6u+/5tntqyi07CfiBlTT"\
            "UjyHdofwvaZSZ+BlOU9/I1SHX+xwod5uXFD9L0d4iLOJ5Q/d5HF5wNBN8mq0Ry6K"\
            "y6677YNuWZLK/M/sfEE83pRi4Aft1u/IDxJOr9iGgQKBgQDBD7EV82o4R1IGph9t"\
            "iayW7WTk2j4Uh7He915Onhs/Zjx6ChJi5JM9igel17OcuSgI4kNLwAS7PefAOdW4"\
            "mGDyGQDcuywnbV9Ndt2/yWoJLxoWRWGHpvmQcn0dH3BaqRMl8K3ro6NKgJ1hB4IN"\
            "ZTmROB2lMzI1LeRdtdIBHLpihQKBgQDF4OX3Xr1ziVesdZUqnkFHkS8FpIDwfUMg"\
            "NJwKw2wXGR5DN0IBbfU72QOaaZjldunIhkEkEoMZbrkQ8KIR+rnuzomDtUjrIMsP"\
            "lI/oghKZ4eo72eqD46Vn48DZY/7NDcxXHT/LYtqj7EjOijgjVufhWeKRlusm/eSR"\
            "buSgAZNWcQKBgFFR38CkQEimWfms/a3xAL6uDgKLnvycz6JgRdwNouKImM668VWw"\
            "fAi+3EvR2LkaEK/1Rm1g211XTQfeFJTlsmgnegJ/4LBW1H7Xo74GA+EMcwuQe+1c"\
            "uuBKKUMcHAJEF2mywD9yNPTLyf613+Tuj1oI7gvIzcwyoW+Lh4KqbCPVAoGBAIWZ"\
            "iqqxtIfFOwSdftD/eGOximXs44F7kU61NoWt29TciKopLM96RhDaPKyMj0aeOsnA"\
            "m0qXlRwevaTKUyKAffjWSdI7G7hks7UZQPBiodxzw4oVX1kc4hh6lUIxWV9o6YYH"\
            "oYLYg3YZmi6Y874odvaXkXlqw+nXkfL/RC0j4y6BAoGBALdc82oY6hUD4itGD5ZV"\
            "TffuPe45sWvqfaWf5VdWfJZV2+1PIzeuoqy7+2+yWCtLWODKsI2TRdynl48w0nBB"\
            "U1GB6FspDLTKNWRkjiaTkQc2JZWD5y4H8uyTmJ3j0LcfRvN9SaONFq+BPZ8YRx3I"\
            "2sRJGVERwqBSg0cIupa2fAiv\n"\
            "-----END PRIVATE KEY-----"
    # pkey = RSA.importKey(private_key)
    # h = SHA256.new('sign_str'.encode('utf-8'))
    # signature = PKCS1_v1_5.new(pkey).sign(h)
    # sign = base64.b64encode(signature).decode()
    signer_pri_obj = PKCS1_v1_5.new(RSA.importKey(private_key))
    rand_hash = SHA256.new()
    rand_hash.update('sign_str'.encode())
    signature = signer_pri_obj.sign(rand_hash)
    sign = base64.b64encode(signature).decode(encoding="utf-8")
    return sign

def my_verify():
    # public_key = "-----BEGIN PUBLIC KEY-----\n"\
    #         "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlTqubm6E2+ltAbhrdGMB"\
    #         "/jEywHQYnG3OZnUeZY4H3dI3AdNUKqsoFvCfSSp4/9TrvOVc26ddCEJ5suTMxR8L"\
    #         "LaNB9pHz35cNVDr2uXl/Sy8915997mlkw++GRUH3gvTuUiqvySPLm0GzMjrZ9Rbe"\
    #         "sBJdGz6DxlSoT0LNnsIkx813vQou+2Wj7UjTSFRpElZUPMJvAxq64Jis+Fl6UQUV"\
    #         "z4FOoixlwr2ykvex82k8w0xSD7sxGM2nEo2BT1u9ki66/OJRiS+IRgcqIPgZKeK9"\
    #         "ZCNMjWzyFQ8lCjaahrUBiLnMjV5ys4W1+TT/cQcaNOSOju4H3CPq1iGn8FKtYr0q"\
    #         "tQIDAQAB\n"\
    #         "-----END PUBLIC KEY-----"
    public_key = '''MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlTqubm6E2+ltAbhrdGMB
                /jEywHQYnG3OZnUeZY4H3dI3AdNUKqsoFvCfSSp4/9TrvOVc26ddCEJ5suTMxR8L
                LaNB9pHz35cNVDr2uXl/Sy8915997mlkw++GRUH3gvTuUiqvySPLm0GzMjrZ9Rbe
                sBJdGz6DxlSoT0LNnsIkx813vQou+2Wj7UjTSFRpElZUPMJvAxq64Jis+Fl6UQUV
                z4FOoixlwr2ykvex82k8w0xSD7sxGM2nEo2BT1u9ki66/OJRiS+IRgcqIPgZKeK9
                ZCNMjWzyFQ8lCjaahrUBiLnMjV5ys4W1+TT/cQcaNOSOju4H3CPq1iGn8FKtYr0q
                tQIDAQAB'''
    signature = base64.b64decode('HLLwFqteVGACV063edPtl/mKVomceueSMRL+iQMBnUbq62eX/+DEaY8bgxFS0Tr0p3mPbSo+kMkMDeRc8xsWn8iDtNANPFHLxwSnPjt3eHYfNhwAjB/Q27qCXWq42p0H6bU8rBP5QtxOg5NwKM4UPGs2jnRDjfgW7B/fOb3YyiZYDNXNNH4V2808yOffD3SJywMq4MR07bbQuwOq+eaLg2RzO7eIcbgMYOJJe/zCaR5mNE5JOBj+IWJPZ/EnSYqCr72Q/bC7lNk+oqCbqbhPsu7upbeE3k+Xht1+M1xwv7mLp8Y83K9jiuVlp3m/mXeIHyI0xbZSAD65QIlhpT8aag==')
    # verifier = PKCS1_v1_5.new(RSA.importKey(public_key))
    verifier = PKCS1_v1_5.new(RSA.importKey(base64.b64decode(public_key)))
    _rand_hash = SHA256.new('sign_str'.encode('utf-8'))
    verify = verifier.verify(_rand_hash, signature)
    return verify


if __name__ == '__main__':
    # AppID = 'wx56d6062ebc9ade64'
    # AppSecret = '781e40d32f7391e32cf245385d4d0bff'
    # get_access_token(AppID, AppSecret)
    # my_jwt_encode()
    # my_jwt_decode(my_jwt_encode())
    # main()
    # ret = decrypt(nonce= 'XWOMMTLU9N0t', associated_data='transaction',ciphertext='Kqwf4d2x62jSBsaHj+h1LBiSErVH1bK9ZCLWcLlO0kopxKnnSSHTcfINh70U6kXqD7VelVIjDqv0wOek4nsTlVg6lnrr7L7pIvbB6ocGVuOwnV8kQPw8jJn6MDHTtDOVf0RlxL7gkjQ6Bu6PNoMUKzybpo1yeVrqLMz1n1reDAK4Vwckv6RgMAkyeWhCwP0IAf8sqSrf5p9OrLfm9/h714WYDlLVRWGnPqwQkTdtWwIb7bnye1Y+u86OWRY5P031N7Z4CN/T2YITMgupEEibRH0U4oyt/jhU0ZRiuCHLVMmD806vDV7YIlair6AVgtwcLIgU5C5y0creHHpbhLP9OzZ8YkCY0dAyuzWqlZJKonSiuH7v5n4NzDw99603R7xMqeyxzVk+yBvmwhjQEmu2N8LCWvANwC2qyA/OI8PPUeKyonSdVFid7HcofcIxHGmGzJVuywWvxCkw+NsftkyJNxor1GEDhg/d42I9Ot19PUebNVhr9MnsQAiVx9mf4gibuJaFI47Ks+EZOxYOGRFVu7m7Xps5SM35icuAS6PCg8oYi+hvZ85Z3MHCS0+ZOF9mraH28jD+PoAy4Hid1bUhemIJ')
    # print(type(json.loads(ret)))

    # ret = decrypt(nonce='de3de6dd511d',ciphertext='HgtrBOrnomESNf/9WAV5EfbjYRZJ8b8jrOjzZ//ice73uK3UZWpMiAYT3VchWbC4dED98UW2DJu+YuyPdT3cPj/N51i1c6dLCfp0fY627XebZE8TjsU8k8kNBbV6xD+K8IigMZ/7a2SA+nme5wLUt92MjOP5VFfUjISDfFYv5EjHtFWzMYbc3SakX0yvza/yp18KSZSY4ArNlO0qFG90FGYeBY5g2zJBS1hkrEi8Z542REI8fdZituC2XIdgS1bDf2g2aaIq5ztN9K9G1QnefYbAek+i33TvJevF1NwWFglPY5CA4PSZfS6Go3lhJVndPjG9GqAzQU5JS1ep5lTshlKwSQ/QHf4qRP/8mKbpsOMAz1XWiNTnYd9me4GfB94HaDaWhDQOp7+nU5gDatO/CZ2tGA+vwd7rxum0SmJQzUCL45zsAsqlscMoRyhX1EjdmAMZuHnvi6xFZsm1fTQQO8SNTTXQq6tSrYkY3JynykRp6ta37zBcr5s1h+ImDuX8pNXOQNiUF+DLTgQVr01plv8TMliLtl0xJBcb3AtmH8d/Knt4sxjx7Os3rfF9lBbrFA2R5HbfEN1mdWqGOXA1KSvmBU2qyx5TixXjx3toqIt3SlQ6rSLZnIp1YIwSD2Pt7rJIvIOd37HqJso+2CJHqyjKMLIhwAcvOC8INlst2yerDqDDwWco3XTv9rJt56XU78bV0Crfm9Tocq8B+EoM+8WZ6S5Jx2yNJ88obxaSKz6Vu3FmNzmPgldGN09f7vrByZrbzalPk+D2VyTKjc+18PVlT61Z+uXdfnf4QJxlAWo3mm6hUr4WOkzJxQBJPCMLnP8/moMoeZoY8tWjnC1uv0gXrHJzS2WoiJ9f3HL9K8uPKm1jOCN3NhEorxRla8et4lU6KlNBj2cCkJT+VeF6kGKmKESdczvuwy+LCAkrQYrAnM+tFHINHxHWnkpzyluRgwuN9gFwmIzPbj8Ae5uy811soOPJKdoQGRrJ41S/cFn1Q89+ZY0dXaxLMY50z3JA8ecDU1oDzvPLLQ5iv6qpiaZrvNgXJzeCuNO/3m8ccwaLX9FjEq8Zi9FLTYhKJP+uJGv0qiSeLTuo2TR9IoX/RfHSFmbAFkImpiqerbfVEWTELxhOT2bmAzfIt/5gkD+RMRfO+ZwjegVAkey3HsxaDGiHi998NqDhQCGEWDWOPSnKpFJM0VIy+4GYkjmCsvbRSa0oQtT5OaHR2b4axdHyT6jG3Kzwb7I2zhcC17tRaB1V5RXlaGn4D7j3doPOPlLklM9iyC4FClp0JlbJX3FXrmzvJl/K+LVM8LA1DKelXIW8QohZnnVEm7F1wrR/AchR5aPe5xln4/IIqGJfAIn/4zdCmFN53PAQDEILXz5c6YSjeq24wqqcpIY99rT1QEQHkGuDy9anYjCGzUNUg+eEBtQHVYAUeq1cu8MPsJICe7q05TOv6zBVmFRHL371kBGlV35FDh0CkIJvLrIB3rd7/k5jJ+v25+LgjRlxEItvd9ZF50pte1qn27DZd1a1SW/SWKYVhoj6KT25Cl/jQRaJ3gQOZYPrfYaEl5xyS2wKdeJC8L4ov6Yvft07zTouMSRZLjpugTp0HArQ/lEBNxRoZVU2IlHyoFKzf9SI3I6+5sElMKxnUytF1W/YJcq3BSjlfVURU/6gpw4xLWEUY4xtFXuFOQbIfcdaVDd1OB5avC9c4kEG8aXgwFwpWYnRYX4zD9EBOmXKgd6D5+RVX4OYh7OANSac6bkcjYKtPlyjzwz3eeq2NAC0DFBJd6ujl/TXJXEzuRFi7E0+yzPwM/aMuTvRrhLbgpFmTNJbPa1KfD0ohMWjgwMGwQDx6JqfxBzYnXcU7/S5YKTaRMeyl/hUwwG9KD/F5Q==', associated_data='certificate')
    # print(ret)

    body = ({"id":"5ecd0e76-22ee-5e77-8cc9-3ef50b86c2bd","create_time":"2021-11-04T08:55:58+08:00","resource_type":"encrypt-resource","event_type":"TRANSACTION.SUCCESS","summary":"支付成功","resource":{"original_type":"transaction","algorithm":"AEAD_AES_256_GCM","ciphertext":"tHFRJlWXDh6iIWW9XGxDRR22UINwOkTDLTcMAdK+3dyDJGUOjcXcoovUbgZndo7+PtYijKb9l0c7lE7+CLM6CQtoUveFstw6ZBrw3ySSDnL4Rmm7xg1F5r/BIUI56OIcMxYBL8kr6G9xJ5OvMRlNSlz/eQ82T5+1JosrNYmIWc6aD01aZSagcip8jL6/fpGVhWqWtJZifxsV8nGNVrAJaFK6jPRNuSGkxuh4WKQ9gnu9nZ8vMjcoobzdQj6Qk4oXXZkntzjc0QXxWZ2cpjbQy7kmFFReriLjTT85sklb5l3o3ebL1wUlESTQ83Q/001Hw4Ui13eK+MX6TR0EX/JH2zpvU06yDBC1yP/gFGLaNgaEfJ9M1abgKQR3z12EI9jZ01t8Bve+C1WZCt5rsfRulmMwDPd6SW3PoU2PLHquev6qTsZUs+FuAyC7zS/qmf89WSTOTQoumzrx2OSlYW3oSmeP52FUbAfx1hZNYfRHnWHw23d5Sjz4oYsXccUPBeqQQ2FlwMo0Btvtj5vWFAGL88Ki1o7JVfbaq573bsbviUBoBELfOE//Jls7eAEhjQa5OgqxwPuiGBveviENtwpL","associated_data":"transaction","nonce":"3gxLzM6SiR5G"}})

    signature = 'IemrprIy2x/ij79C3nI3W/7E5zYjTr0SFic8Slqdy9cJmTjlgzjpKO1zqzOtmgQtDEtTZkf7DLYa6J2XXdHcBYbioynUP9gOPi6AjrT2origW3kPkpmioG3fyq+uQLMcHhanxxXg7Sya+nHAvfXGraFkpLTKtyMATnuDk+kpdXGu4kLJp31Obxpz3djyMANlXlLZOqaVMXUKJ5goOVpjIZKN4egv4LJEhFoCc+QvpEqlTcKheeuqS3TNJKi3GQZJJG455OpJJteJzHScXfhOHave4Y9AyRCw0k1kxSlFGoglTD5DGw7tGjI5ALoE6KYiNIfcYYnIjxZlNT9ceOYq1A=='
    ret = rsa_verify(nonce='rElcI1DRz70r7tI6rdGI2jHiVe2rUifY', timestamp='1635987358', body=body, signature=signature)
    print(ret)
