#!/bin/bash
cd /sports_socket/
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/
python socket_server.py > socket_log.log 2>&1

#docker run -itd --name sports_socket --restart always -p 8024:8024 -v /opt/apps/beautiful_memory/beautiful_memory/sports_socket/:/sports_socket/ sports_socket_img:v1.0 /bin/bash /sports_socket/entrypoint.sh