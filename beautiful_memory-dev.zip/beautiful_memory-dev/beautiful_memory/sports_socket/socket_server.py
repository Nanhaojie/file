#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2022/4/2上午10:21
#@Author:zwz
import datetime
import json
import logging
import threading
import time
import traceback

import eventlet
eventlet.monkey_patch()

import socketio
import eventlet.wsgi

sio = socketio.Server(async_mode='eventlet', cors_allowed_origins='*')  # 指明在evenlet模式下
app = socketio.Middleware(sio)
CLIENT_DICT = {}
CONNECT = False

logging.basicConfig(level=logging.INFO #设置日志输出格式
                    ,filename="socket_log.log" #log日志输出的文件位置和文件名
                    ,filemode="w" #文件的写入格式，w为重新写入文件，默认是追加
                    ,format="%(asctime)s - %(name)s - %(levelname)-9s - %(filename)-8s : %(lineno)s line - %(message)s" #日志输出的格式
                    # -8表示占位符，让输出左对齐，输出长度都为8位
                    ,datefmt="%Y-%m-%d %H:%M:%S" #时间输出的格式
                    )

def send_2_ios():
    try:
        while CONNECT:
            print('send_ios')
            sio.emit('ios_recv', json.dumps({
                'key': '0'
            }))
            time.sleep(5)
    except:
        traceback.format_exc()


@sio.on('connect')
def on_connect(sid, environ):
# def on_connect():
    """
    与客户端建立好连接后被执行
    :param sid: string sid是socketio为当前连接客户端生成的识别id
    :param environ: dict 在连接握手时客户端发送的握手数据(HTTP报文解析之后的字典)
    CLIENT_DICT {
        "1": {count:1,group_id:1, sid_list:['estefsfsd', 'dfsafw']},
        "2": {count:1,group_id:1, sid_list:['estefsfsd', 'dfsafw']}
    }
    """
    print(environ['QUERY_STRING'], 'sid',sid)
    query_list = environ['QUERY_STRING'].split('&')
    for query in query_list:
        query = query.split('=')
        if query[0] == 'group_id':
            group_id = query[1]
            if CLIENT_DICT.get(group_id, 0):
                count = CLIENT_DICT[group_id]['count'] + 1
                sid_list = CLIENT_DICT[group_id]['sid_list']
                sid_list.append(sid)
                CLIENT_DICT[group_id] = {
                    'count': count,
                    'group_id': group_id,
                    'sid_list': sid_list,
                }
            else:
                CLIENT_DICT[group_id] = {
                    'count': 1,
                    'group_id': group_id,
                    'sid_list': [sid],
                }
            break
    print('connect', CLIENT_DICT, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    logging.info('connect:'+json.dumps(CLIENT_DICT) + '  ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    # global CONNECT
    # CONNECT = True
    # t = threading.Thread(target=send_2_ios)
    # t.start()
    return 'ok'

@sio.on('disconnect')
def on_disconnect(sid):
    """
    与客户端断开连接后被执行
    :param sid: string sid是断开连接的客户端id
    """
    for k,v in CLIENT_DICT.items():
        if sid in v['sid_list']:
            sid_list = v['sid_list']
            sid_list.remove(sid)
            count = v['count'] - 1
            group_id = v['group_id']
            if count == 0:
                del CLIENT_DICT[k]
            else:
                CLIENT_DICT[k] = {
                    'count': count,
                    'group_id': group_id,
                    'sid_list': sid_list,
                }
            break
    # CLIENT_DICT[0] = CLIENT_DICT[0] - 1
    print('bread', CLIENT_DICT, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    logging.info('break:' + json.dumps(CLIENT_DICT) + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    # global CONNECT
    # CONNECT = False
    return 'ok'


# 以字符串的形式表示一个自定义事件，事件的定义由前后端约定
@sio.on('recv_message')
def recv_message(sid, data):
    """
    自定义事件消息的处理方法
    :param sid: string sid是发送此事件消息的客户端id
    :param data: data是客户端发送的消息数据
    """
    # 客户端数量
    for k,v in CLIENT_DICT.items():
        if sid in v['sid_list']:
            client_count = v['count']
            break

    print('client_count:',client_count,data, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    logging.info('client_count:' + json.dumps(client_count) + '  data:' + data + datetime.datetime.now().strftime('  %Y-%m-%d %H:%M:%S'))
    data = data.split(',')
    # data[0] 指令  data[1] group_id
    # 关
    if data[0] == '0':
        sio.emit('ios_recv', json.dumps({
            'key': '0',
            'client_count': str(client_count),
            'group_id': data[1]
        }))
        print('close:', {
            'key': '0',
            'client_count': str(client_count),
            'group_id': data[1]
        })
        logging.info('close:'+json.dumps({
            'key': '0',
            'client_count': str(client_count),
            'group_id': data[1]
        }))
    # 开
    if data[0] == '1':
        batch = str(int(time.time()*1000000)) + '-' + data[1]
        sio.emit('ios_recv', json.dumps({
            'key': '1',
            'client_count': str(client_count),
            'group_id': data[1],
            'batch': batch
        }))
        print('open:', {
            'key': '1',
            'client_count': str(client_count),
            'group_id': data[1],
            'batch': batch
        })
        logging.info('open:'+json.dumps({
            'key': '1',
            'client_count': str(client_count),
            'group_id': data[1],
            'batch': batch
        }))
    return 'ok'

eventlet.wsgi.server(eventlet.listen(('0.0.0.0', 8024)), app)
