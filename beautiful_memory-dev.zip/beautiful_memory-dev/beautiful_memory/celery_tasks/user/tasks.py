#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/9/9上午10:06
#@Author:zwz
import requests
from django.conf import settings
from django_redis import get_redis_connection


from celery_tasks.main import celery_app

redis_conn = get_redis_connection('user')

@celery_app.task
def set_access_token():
    AppID = 'wx56d6062ebc9ade64'
    AppSecret = '781e40d32f7391e32cf245385d4d0bff'
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={AppID}&secret={AppSecret}"
    resp = requests.get(url).json()
    access_token = resp.get('access_token')
    if access_token:
        redis_conn.set('wx_access_token', access_token, 60*60)
    # return errcode, access_token, expires_in


if __name__ == '__main__':
    set_access_token()