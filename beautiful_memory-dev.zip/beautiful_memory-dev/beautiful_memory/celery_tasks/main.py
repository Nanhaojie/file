# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/26
# @author fj
import datetime
import os, logging
from celery import Celery
from celery.schedules import crontab

logger = logging.getLogger("django")

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
# 创建celery应用
celery_app = Celery('mysp')

# 导入celery配置
celery_app.config_from_object('celery_tasks.config')


celery_app.conf.beat_schedule = {
    'set_access_token': {
        'task': 'celery_tasks.user.tasks.set_access_token',
        'schedule': datetime.timedelta(minutes=60)
    }
}

# 自动注册celery任务 在指定的包中找tasks.py文件，在这个文件中找@app.task的函数，当做任务
# 定时任务需要添加
celery_app.autodiscover_tasks(['celery_tasks.user'])

# 在出现worker接受到的message出现没有注册的错误时，使用下面一句能解决
imports = ("tasks",)
