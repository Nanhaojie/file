#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@File ：tasks.py
@Author ：nhj
@Date ：2021/9/16 上午9:44 
"""
import os
import sys

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()
from kafka import KafkaConsumer
import json
import logging

from video.models import WonderfulVideoRet
from django.conf import settings
from django.db import connection

logger = logging.getLogger("django")
yun_kafka_host_list = settings.KAFKA_SERVERS
user_play_record = settings.USER_PLAY_RECORD_TOPIC

con = KafkaConsumer(user_play_record, bootstrap_servers=yun_kafka_host_list,
                    value_deserializer=lambda v: json.loads(v.decode()),
                    auto_offset_reset='earliest', group_id='user_play_record'
                    )


# def is_connection_usable():
#     try:
#         connection.connection.ping()
#     except:
#         return False
#     else:
#         return True


def wonderful_video():
    while True:
        # if not is_connection_usable():
        connection.queries_log.clear()
        connection.close_if_unusable_or_obsolete()
        try:
            message = next(con)
        except Exception:
            logger.error(f'从kafka的video_ret取数据报错', exc_info=True)
        else:
            value_dict = message.value
            if value_dict.get("is_rich", 0):
                affected_row_num = WonderfulVideoRet.objects.filter(
                    id=value_dict.get('wonderful_video_ret_id')
                ).update(is_rich=1)
                if affected_row_num:
                    logger.info(f"用户:{value_dict.get('user_id')}游玩记录"
                                f"[{value_dict.get('wonderful_video_ret_id')}]有充足的资源")
                    continue
            try:
                WonderfulVideoRet.objects.create(user_id=value_dict.get('user_id'),
                                                 id=value_dict.get('wonderful_video_ret_id'),
                                                 scene_id=value_dict.get('scene_id'),
                                                 is_rich=value_dict.get("is_rich", 0))
            except Exception:
                logger.error(f"用户：{value_dict.get('user_id')}创建游玩记录[{value_dict.get('wonderful_video_ret_id')}]失败",
                             exc_info=True)
            else:
                logger.info(f"用户:{value_dict.get('user_id')}有一条游玩记录[{value_dict.get('wonderful_video_ret_id')}]")


if __name__ == '__main__':
    wonderful_video()
