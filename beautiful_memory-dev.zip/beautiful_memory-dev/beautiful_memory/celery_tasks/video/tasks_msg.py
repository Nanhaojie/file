#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@File ：tasks.py
@Author ：nhj
@Date ：2021/9/16 上午9:44 
"""
import os
import sys
import time
import uuid

import requests

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()
from kafka import KafkaConsumer
import json
import logging
from django.db import connection

from video.models import WonderfulVideoRet, WonderfulVideoTemplateContentRet, TemplateVideo
from user.models import User
from django.conf import settings
from utils.common import send_sms

logger = logging.getLogger("django")
add_port = settings.KAFKA_SERVERS
video_ret = settings.VIDEO_RET_TOPIC


class HandleVideoMSG:
    def __init__(self):
        self.video_ret_kafka_con = KafkaConsumer(video_ret, bootstrap_servers=add_port,
                                                 value_deserializer=lambda v: json.loads(v.decode()),
                                                 auto_offset_reset='earliest', group_id='video_ret')

    def record_revise_video(self, video_id, wonderful_video_ret_id, video_ret_msg):
        """记录重新生成的视频id"""
        is_revise = video_ret_msg.get('extra', {}).get('is_revise', 0)
        if is_revise:
            WonderfulVideoRet.objects.filter(id=wonderful_video_ret_id).update(new_video_id=video_id)

    def send_wx_msg(self, msg_data):
        resp = requests.get(settings.ACCESS_TOKEN_URL).json()
        access_token = resp.get('access_token')
        rsp = requests.post(settings.SUB_MSG_SEND_URL + access_token, json=msg_data)
        try:
            logger.warning(f'open_id[{msg_data.get("touser")}]微信订阅消息返回内容{rsp.json()}')
        except Exception:
            logger.warning('订阅消息返回rsp解析失败', exc_info=True)

    def create_user_video(self, video_ret_msg):
        """聚合完成后的消息，创建一个视频记录"""
        template_video_id = video_ret_msg.get('template_video_id')
        wonderful_video_ret_id = video_ret_msg.get('wonderful_video_ret_id')
        user_id = video_ret_msg.get('user_id')
        video_id = video_ret_msg.get('video_id')
        is_show = video_ret_msg.get('is_show', 1)
        try:
            WonderfulVideoTemplateContentRet.objects.create(
                id=video_id,
                template_video_id=template_video_id,
                wonderful_video_ret_id=wonderful_video_ret_id,
                user_id=user_id,
                is_show=is_show,
            )
        except Exception:
            logger.error('精彩视频生成记录持久化失败', exc_info=True)
        else:
            logger.warning(f'用户[{user_id}]精彩视频[{video_id}]开始制作')
            self.record_revise_video(video_id, wonderful_video_ret_id, video_ret_msg)

    def user_video_product_success(self, video_ret_msg):
        """用户视频制作成功，更新生成的结果"""
        video_url = video_ret_msg.get('video_url')
        video_id = video_ret_msg.get('video_id')
        start_production_time = time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT,
                                              time.localtime(video_ret_msg.get('task_start_time') // 1000))
        finish_production_time = time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT,
                                               time.localtime(video_ret_msg.get('task_end_time') // 1000))
        square_image_url = video_ret_msg.get('square_image_url')
        non_square_image_url = video_ret_msg.get('non_square_image_url')
        template_video_id = video_ret_msg.get('template_video_id')
        wonderful_video_ret_id = video_ret_msg.get('wonderful_video_ret_id')
        video_size = video_ret_msg.get('video_size')
        user_id = video_ret_msg.get('user_id')
        is_show = video_ret_msg.get('is_show', 1)
        try:
            wonderful_video_ret_obj = WonderfulVideoRet.objects.get(id=wonderful_video_ret_id)
            wonderful_video_ret_datetime = wonderful_video_ret_obj.create_time
        except Exception:
            logger.error('精彩视频持久化流程中，获取游玩记录失败', exc_info=True)
            return
        try:
            affected_row_num = WonderfulVideoTemplateContentRet.objects.filter(id=video_id).update(
                video_url=video_url,
                square_image_url=square_image_url,
                non_square_image_url=non_square_image_url,
                wonderful_video_ret_id=wonderful_video_ret_id,
                video_size=video_size,
                start_production_time=start_production_time,
                finish_production_time=finish_production_time,
                status=1
            )
            if not affected_row_num:
                WonderfulVideoTemplateContentRet.objects.create(
                    id=video_id,
                    video_url=video_url,
                    square_image_url=square_image_url,
                    non_square_image_url=non_square_image_url,
                    template_video_id=template_video_id,
                    wonderful_video_ret_id=wonderful_video_ret_id,
                    video_size=video_size,
                    user_id=user_id,
                    start_production_time=start_production_time,
                    finish_production_time=finish_production_time,
                    status=1,
                    is_show=is_show,
                )
        except Exception:
            logger.error('精彩视频生成记录持久化失败', exc_info=True)
            wonderful_video_ret_obj.is_agg = 0
            wonderful_video_ret_obj.save()
            return
        # 微信小程序推送
        try:
            # 查询用户是否为测试用户，如果是推送到统一测试账号
            user = User.objects.get(id=user_id)
            if user.note == 'test':
                # 将信息推送到统一测试账号上
                open_id = 'o-MNU5Tl1tUnZ8CdIRdb9llaDONA'
                mobile = '18703671501'
                user_id = 'c3e8d71c478e11ecbd9c0242c0a80102'
                WonderfulVideoTemplateContentRet.objects.create(
                    id=uuid.uuid1().hex,
                    video_url=video_url,
                    square_image_url=square_image_url,
                    non_square_image_url=non_square_image_url,
                    template_video_id=template_video_id,
                    wonderful_video_ret_id=wonderful_video_ret_id,
                    video_size=video_size,
                    user_id=user_id,
                    start_production_time=start_production_time,
                    finish_production_time=finish_production_time,
                    status=1
                )
            else:
                open_id = user.open_id
                mobile = user.mobile
            scene_name = TemplateVideo.objects.get(id=template_video_id).scene.full_name
        except Exception:
            logger.error('获取精彩视频基本信息失败', exc_info=True)
            wonderful_video_ret_obj.is_agg = 0
            wonderful_video_ret_obj.save()
        else:
            # 构造推送微信消息
            msg_data = {
                "touser": open_id,
                "template_id": settings.SUB_MSG_TEMP_ID,
                "page": settings.MINE_PAGE_PATH,
                "miniprogram_state": settings.MINIPROGRAM_STATE,
                "lang": "zh_CN",
                "data": {
                    # 标题
                    "thing1": {"value": f"{scene_name}的影像"[:20]},
                    # 游玩时间
                    "time2": {
                        "value": wonderful_video_ret_datetime.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
                    },
                    # 生成时间
                    "time4": {"value": time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)},
                    # 备注
                    "thing3": {"value": "进入小程序查询您的精彩影像"}
                }
            }
            # 如果展示该视频，才推送消息
            if int(is_show):
                self.send_wx_msg(msg_data)
                # 短信推送
                send_sms(mobile)
            if not wonderful_video_ret_obj.first_video_finish_time:
                wonderful_video_ret_obj.first_video_finish_time = finish_production_time
            wonderful_video_ret_obj.is_agg = 2
            wonderful_video_ret_obj.save()

            self.record_revise_video(video_id, wonderful_video_ret_id, video_ret_msg)

    def user_video_product_error(self, video_ret_msg):
        """用户视频制作失败"""
        template_video_id = video_ret_msg.get('template_video_id')
        wonderful_video_ret_id = video_ret_msg.get('wonderful_video_ret_id')
        user_id = video_ret_msg.get('user_id')
        video_id = video_ret_msg.get('video_id')
        start_production_time = time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT,
                                              time.localtime(video_ret_msg.get('task_start_time') // 1000))
        finish_production_time = time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT,
                                               time.localtime(video_ret_msg.get('task_end_time') // 1000))
        production_detail = video_ret_msg.get('msg')
        is_show = video_ret_msg.get('is_show', 1)
        try:
            affected_row_num = WonderfulVideoTemplateContentRet.objects.filter(id=video_id).update(
                status=2,
                start_production_time=start_production_time,
                finish_production_time=finish_production_time,
                production_detail=production_detail
            )
            if not affected_row_num:
                WonderfulVideoTemplateContentRet.objects.create(
                    id=video_id,
                    template_video_id=template_video_id,
                    wonderful_video_ret_id=wonderful_video_ret_id,
                    user_id=user_id,
                    start_production_time=start_production_time,
                    finish_production_time=finish_production_time,
                    production_detail=production_detail,
                    status=2,
                    is_show=is_show,
                )
        except Exception:
            logger.error(f'用户[{user_id}]精彩视频[{video_id}]制作失败的记录保存失败', exc_info=True)
        else:
            logger.warning(f'用户[{user_id}]精彩视频[{video_id}]制作失败的记录保存成功')
            self.record_revise_video(video_id, wonderful_video_ret_id, video_ret_msg)

    def run_handle_task(self):
        while True:
            # if not is_connection_usable():
            connection.queries_log.clear()
            connection.close_if_unusable_or_obsolete()
            try:
                message = next(self.video_ret_kafka_con)
            except Exception:
                logger.error(f'从kafka的video_ret取数据报错', exc_info=True)
            else:
                # 获取存储的消息 格式为
                # video_ret_msg = {'msg': 'success',
                #                  'non_square_image_url': 'https://aisource.trycan.com/mysp/cover/f52bbbd082724f6da8b48255cf582d07.jpg',
                #                  'video_url': 'https://aisource.trycan.com/mysp/finished/9ec5d7ea92ee4bd9aa23be38c86d1043.mp4',
                #                  'template_video_id': 3, 'video_size': '19.87',
                #                  'user_id': '86826d522b0511ecae1a0242c0a80102', 'wonderful_video_ret_id': 259,
                #                  'task_end_time': 1636515413442,
                #                  'square_image_url': 'https://aisource.trycan.com/mysp/cover/f52bbbd082724f6da8b48255cf582d07.jpg',
                #                  'video_id': '1b56221141d511ecbdb2244bfe89de66', 'task_start_time': 1636515244358,
                #                  'status': '1'}
                video_ret_msg = message.value
                status = int(video_ret_msg.get('status'))
                logger.info(f'视频结果数据{video_ret_msg}')
                # status (0, "制作中"),   (1, "制作完成"),   (2, "制作失败")
                if status == 0:
                    self.create_user_video(video_ret_msg)
                elif status == 1:
                    self.user_video_product_success(video_ret_msg)
                elif status == 2:
                    self.user_video_product_error(video_ret_msg)


if __name__ == '__main__':
    HandleVideoMSG().run_handle_task()
