# -*- coding: utf-8 -*-
"""
@Time ： 2022/4/8 下午1:50
@Auth ： nhj
@File ：sport_all_msg.py
"""

import os
import sys
import time

import requests

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()

import logging

from video.models import WonderfulVideoRet, WonderfulVideoTemplateContentRet, TemplateVideo
from user.models import User, Face
from django.conf import settings
from utils.common import send_sms
import datetime

logger = logging.getLogger("django")


class SendVideoMSG:
    def send_wx_all_msg(self, msg_data):
        resp = requests.get(settings.ACCESS_TOKEN_URL).json()
        access_token = resp.get('access_token')
        rsp = requests.post(settings.SUB_MSG_SEND_URL + access_token, json=msg_data)
        try:
            logger.warning(f'open_id[{msg_data.get("touser")}]微信订阅消息返回内容{rsp.json()}')
        except Exception:
            logger.warning('订阅消息返回rsp解析失败', exc_info=True)

    def send_all_msg(self):

        sport_users = Face.objects.filter(spare_int1__in=[0, 1])
        template_video_id = TemplateVideo.objects.filter(name='时尚版').first().id

        for sport_user in sport_users:
            user_id = sport_user.user_id.hex

            user = User.objects.get(id=user_id)
            open_id = user.open_id
            mobile = user.mobile
            scene_name = TemplateVideo.objects.get(id=template_video_id).scene.full_name

            # 判断运动会用户是否有视频通过审核
            # wonderful_video = WonderfulVideoTemplateContentRet.objects.filter(user=user_id, status=1,
            #                                                                   create_time__day=datetime.datetime.now().day).first()
            video_ret_obj = WonderfulVideoRet.objects.filter(user=user_id, is_right=1, create_time__day=datetime.datetime.now().day).all()
            if video_ret_obj.first():
                wonderful_video_ret_datetime = video_ret_obj.first().create_time
                # 构造推送微信消息
                msg_data = {
                    "touser": open_id,
                    "template_id": settings.SUB_MSG_TEMP_ID,
                    "page": settings.MINE_PAGE_PATH,
                    "miniprogram_state": settings.MINIPROGRAM_STATE,
                    "lang": "zh_CN",
                    "data": {
                        # 标题
                        "thing1": {"value": f"{scene_name}的影像"[:20]},
                        # 游玩时间
                        "time2": {
                            "value": wonderful_video_ret_datetime.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
                        },
                        # 生成时间
                        "time4": {"value": time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)},
                        # 备注
                        "thing3": {"value": "进入小程序查询您的精彩影像"}
                    }
                }
                self.send_wx_all_msg(msg_data)
                # 短信推送
                send_sms(mobile)

                # 消息推送成功,修改is_show=1
                for i in video_ret_obj:
                    is_right_user = i.user_id
                    WonderfulVideoTemplateContentRet.objects.filter(user=is_right_user).update(is_show=1)

                logger.info(f'该运动员{user_id}的精彩视频推送完成')
            else:
                logger.info(f'{user_id}没有精彩视频')


if __name__ == '__main__':
    SendVideoMSG().send_all_msg()
