#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@Author ：yueyuanbo
@Date ：2022/4/18 上午18:14
"""
import os
import sys

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()
from kafka import KafkaConsumer
import json
import logging

from video.models import VideoFrame
from django.conf import settings
from django.db import connection
from rest_framework import serializers

logger = logging.getLogger("django")
yun_kafka_host_list = settings.KAFKA_SERVERS
video_frame_topic = settings.VIDEO_FRAME_TOPIC

con = KafkaConsumer(video_frame_topic, bootstrap_servers=yun_kafka_host_list, group_id='video_frame_topic')
# con = KafkaConsumer(video_frame_topic, bootstrap_servers=yun_kafka_host_list, auto_offset_reset='earliest',
#                     group_id='video_frame_topic2')


# def is_connection_usable():
#     try:
#         connection.connection.ping()
#     except:
#         return False
#     else:
#         return True

class VideoFrameSerializers(serializers.ModelSerializer):
    user_id = serializers.CharField(max_length=32, label='用户id')
    wonderful_video_ret_id = serializers.CharField(max_length=32, label='游玩记录id')
    scene_id = serializers.CharField(max_length=32, label='场馆id')
    video_frame_id = serializers.CharField(source='id')

    class Meta:
        model = VideoFrame
        exclude = ('user', 'wonderful_video_ret', 'scene', 'id')


def wonderful_video():
    while True:
        # if not is_connection_usable():
        connection.queries_log.clear()
        connection.close_if_unusable_or_obsolete()
        message_set = con.poll(timeout_ms=5000, max_records=10000)
        batch_obj = list()
        for consumer_record in message_set.values():
            for message in consumer_record:
                try:
                    value_dict = json.loads(message.value)
                    value_dict['video_frame_id'] = value_dict.get('id')
                    serializer = VideoFrameSerializers(data=value_dict)
                    serializer.is_valid(raise_exception=True)
                    video_frame_value = serializer.data
                    batch_obj.append(VideoFrame(**video_frame_value))
                except Exception:
                    logger.error(f"解析video_frame数据失败", exc_info=True)
        try:
            VideoFrame.objects.bulk_create(batch_obj)
        except Exception:
            logger.error(f"保存video_frame数据失败", exc_info=True)


if __name__ == '__main__':
    wonderful_video()
