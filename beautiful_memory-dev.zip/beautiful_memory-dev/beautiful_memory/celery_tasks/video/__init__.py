#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@File ：__init__.py.py
@Author ：nhj
@Date ：2021/9/16 上午9:43 
"""