# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj

import os
import sys

# todo 连接的是正式线环境
if not os.getenv('DJANGO_SETTINGS_MODULE'):
    os.getenv('DJANGO_SETTINGS_MODULE')
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()

import json

from kafka import KafkaProducer

from beautiful_memory import settings
from video import serializers
from video.models import WonderfulVideoRet, TemplateVideo

producer = KafkaProducer(bootstrap_servers=settings.KAFKA_SERVERS, value_serializer=lambda v: json.dumps(v).encode(),
                         key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip')


class UserVideoTest():
    def __init__(self):
        self.temp_video_id = 2

    def get_all_test_user_video(self):
        for wonderful_video_record_obj in WonderfulVideoRet.objects.filter(user__note='test', is_agg=0):
            self.get_one_test_user_video(self.temp_video_id, wonderful_video_record_obj.user_id.hex,
                                         wonderful_video_record_obj.id)

    def get_one_test_user_video(self, temp_video_id, user_id: str, wonderful_video_record_id):
        # 查询视频模板的信息
        base_fields = ['id', 'name', 'video_start_url', 'video_end_url', 'mask_url', 'video_music_url', 'width',
                       'height', 'start_video_time', 'end_video_time']
        template_video = TemplateVideo.objects.prefetch_related('temp_seg_set', 'temp_transition_set'). \
            filter(id=temp_video_id).only(*base_fields).first()
        # 推送游玩记录id，user_id type 及template相关内容 到kafka
        value = {'user_id': user_id if not isinstance(user_id, str) else user_id,
                 'wonderful_video_ret_id': wonderful_video_record_id,
                 'type': 1,  # {'1': add操作, '2': edit操作}
                 'template_video': serializers.TemplateAllInfoSerializer(template_video).data
                 }
        try:
            future = producer.send(settings.USER_V_AGG_MSG_TOPIC, value=value)
            future.get(timeout=100)
        except Exception:
            print(f'用户获取精彩视频推送kafka失败')
        else:
            print(f'用户{user_id}发送获取视频请求，游玩记录{wonderful_video_record_id}')


if __name__ == '__main__':
    # 获取所有测试账号的精彩视频
    UserVideoTest().get_all_test_user_video()
