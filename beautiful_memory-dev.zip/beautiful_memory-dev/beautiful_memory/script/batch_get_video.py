# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2022/4/8 下午5:20
# @author yueyuanbo
import os
import sys
import time

import requests
from django.utils.timezone import now

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    os.getenv('DJANGO_SETTINGS_MODULE')
    sys.path.insert(0, '../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()

from user.models import User
from video.models import WonderfulVideoRet


class SportsMeetingGetVideo:
    def __init__(self, get_video_url, player_default_tem_video_id):
        self.get_video_url = get_video_url
        self.player_default_tem_video_id = player_default_tem_video_id

    def get_video(self, temp_video_id, wonderful_video_ret_id, is_show=0):
        """
        帮用户获取视频
        """
        try:
            params = {'temp_video_id': temp_video_id, 'wonderful_video_ret_id': wonderful_video_ret_id,
                      'is_show': is_show}
            requests.get(self.get_video_url, params=params, timeout=10)
        except Exception:
            print(f'帮助用户获取视频{wonderful_video_ret_id}失败')
        else:
            print(f'帮助用户获取视频{wonderful_video_ret_id}成功')

    def batch_get_player_video(self):
        """
        批量获取运动员今日的视频
        """
        no_player_records_user_id_list = []
        for player_user in User.objects.filter(faces__spare_int1=0):
            player_records = WonderfulVideoRet.objects.filter(
                user_id=player_user.id, is_agg=0, create_time__gte=now().date()
            ).all()
            if not player_records:
                print(f'{player_user.id} {player_user.mobile} 该运动员没有游玩记录, 无法获取视频')
                no_player_records_user_id_list.append(player_user.id)
            for player_record in player_records:
                self.get_video(self.player_default_tem_video_id, player_record.id)
                # 获取视频间隔20秒，减少视频剪辑的出错
                time.sleep(20)
        else:
            print(f'{no_player_records_user_id_list} 该运动员没有游玩记录, 无法获取视频')


if __name__ == '__main__':
    # get_video_url = 'http://abc.trycan.com/api/v1.0/video/get_video'
    get_video_url = 'https://abc.trycan.com/api/v1.0/mysp_f_dev/video/get_video'
    player_default_tem_video_id = 6
    SportsMeetingGetVideo(get_video_url, player_default_tem_video_id).batch_get_player_video()
