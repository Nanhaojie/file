# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import json
import os
import random
import sys

# todo 连接的是正式线环境
import cv2
import numpy as np

from utils.face_detection_serving.modules.utils import recover_pad_output
from utils.face_detection_serving.test import HumanFaceDetection

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    os.getenv('DJANGO_SETTINGS_MODULE')
    sys.path.insert(0, '../../')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "beautiful_memory.settings")
    # 初始化django
    import django

    django.setup()

from kafka import KafkaProducer
from redis import StrictRedis
from utils.common import upload
from beautiful_memory import settings
from user.models import User, Face


class CreateTestUser():
    def __init__(self):
        # todo 人脸资源路径
        self.base_path = '/home/fj/Downloads/D07_20211031105138'
        # base_path = '/home/fj/Downloads/人脸'
        # base_path = '/home/fj/Pictures'
        # todo 是否初始化测试用户数据
        self.init_face_data = 0
        self.redis_conn = StrictRedis('172.28.81.171', 6378, 1, password='root12300.', decode_responses=True)

    def user_face_append(self, user_id, url, face_type):
        # 保存到kafka
        kafka_producer = KafkaProducer(bootstrap_servers=settings.KAFKA_SERVERS,
                                       value_serializer=lambda v: json.dumps(v).encode(), compression_type='gzip')
        kafka_producer.send(settings.FACE_APPEND_TOPIC, value={'user_id': user_id, 'face_urls': [url],
                                                               'type': face_type})
        Face.objects.create(user_id=user_id, face_url=url, type=face_type, note='test')

    def create_test_user(self):
        # 创建测试用户
        random_mobile = '{:0>11d}'.format(random.randint(0, 99999999999))
        user = User(open_id=random_mobile, note='test', mobile=random_mobile)
        user.save()
        return user

    def create_user_and_face_from_folder(self):
        # 根据url指定用户id录入人脸数据
        # for index_type, face_url in enumerate(
        #         ['http://aisource.trycan.com/mysp/face/754c5dd7929cc3951200eb6dcbd16cbb6d1d3dd4',
        #          'http://aisource.trycan.com/mysp/face/bebbb085487f312c6b20be3df5a82a332dccfed2',
        #          'http://aisource.trycan.com/mysp/face/36d9f587e961b69e5765a99f4c95dcc5abaec61b']):
        #     user_face_append('ff3cd3ae2a7411ecb8020242c0a80102', face_url, index_type)
        if self.init_face_data:
            # 清空redis中f_n；
            self.redis_conn.delete('f_n')
            # 删除mysql测试用户记录（用户及人脸）
            Face.objects.filter(note='test').delete()
            User.objects.filter(note='test').delete()

        for base_root, base_dirs, _ in os.walk(self.base_path):
            # root 表示当前正在访问的文件夹路径
            # dirs 表示该文件夹下的子目录名list
            # files 表示该文件夹下的文件list
            for dir in base_dirs:
                user = self.create_test_user()
                for user_file_root, _, files in os.walk(f'{base_root}/{dir}'):
                    for face_index, face_file_name in enumerate(files):
                        face_file_data = open(f'{user_file_root}/{face_file_name}', 'rb').read()
                        # 上传七牛云
                        url = upload(face_file_data)
                        print(f'用户{user.id.hex}进行人脸录入{url}--{face_index}')
                        # 录入测试用户的人脸
                        self.user_face_append(user.id.hex, url, face_index)


class ClippingFaceData():
    def __init__(self, video_folder_path, timeF=5):
        # 视频文件路径
        self.video_folder_path = video_folder_path
        self.score_th = 0.96
        # 每次隔两针
        self.timeF = timeF

    def analyse_face_from_image(self, image_frame: np.array, image_name):
        """分析每帧图片中的人脸"""
        human_face_detection = HumanFaceDetection(None)
        img, pad_params = human_face_detection.prepropess(image_frame)
        outputs = human_face_detection.inference_from_local(img)
        frame_height, frame_width, _ = image_frame.shape
        outputs = recover_pad_output(outputs, pad_params, self.score_th)
        face_coor_set = np.multiply(outputs[:, :4], (frame_width, frame_height, frame_width, frame_height))
        print(f'{image_name}识别到{len(face_coor_set)}张人脸')

        for index, face_coor in enumerate(face_coor_set):
            x1, y1, x2, y2 = face_coor
            self.extend_pixel = (x2 - x1) // 3
            x1 = x1 - self.extend_pixel
            x1 = 0 if x1 < 0 else x1
            x2 = x2 + self.extend_pixel
            y1 = y1 - self.extend_pixel * 1.5
            y1 = 0 if y1 < 0 else y1
            y2 = y2 + self.extend_pixel * 1.5
            x1, y1, x2, y2 = map(int, (x1, y1, x2, y2))
            # # 文件名称按照视频名称及帧数来命名 将人脸坐标放大之后保存人脸照片
            cv2.imwrite(f'{image_name}-{index}.png', image_frame[y1:y2, x1:x2])

    def run_clipping_face(self):
        # image_bytes = open('/home/fj/Downloads/人脸/12/Feishu20211118-101133.jpg', 'rb').read()
        # image_frame = cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)
        # self.analyse_face_from_image(image_frame, 'test')
        # 遍历文件夹中所有视频
        for video_folder_path_root, _, files in os.walk(self.video_folder_path):
            for index, file_name in enumerate(files):
                capture = cv2.VideoCapture(f'{video_folder_path_root}/{file_name}')
                count = 1
                status = 1
                while status:
                    if capture.isOpened():
                        (status, frame) = capture.read()
                        if (count % self.timeF == 0):
                            # 读取视频文件中的帧
                            self.analyse_face_from_image(frame, f'{file_name}-{count}')
                    count += 1
                capture.release()


if __name__ == '__main__':
    # 根据文件数据创建测试账号同时录入人脸数据
    # CreateTestUser().create_user_and_face_from_folder()

    # 从视频文件中截图头像
    video_folder_path = '/media/fj/Elements/d7'
    ClippingFaceData(video_folder_path).run_clipping_face()
