#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:     2021/9/9 22:31
# @Author:   zwz
import base64
import datetime
import hashlib
import io
import json
import logging
import random
import time
from hashlib import sha1

import qrcode
from Crypto.Cipher import AES

import requests
from async_cow.cow import AsyncCow
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.hashes import SHA256

from qiniu import Auth, put_data
from tencentcloud.common import credential
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
# 导入对应产品模块的client models。
from tencentcloud.sms.v20210111 import sms_client, models

# 导入可选配置类
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile

from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from beautiful_memory import settings
from beautiful_memory.settings import TENCENT_SECRET_ID, TENCENT_SECRET_KEY, SMS_SDK_APPID, SMS_SIGN_NAME, \
    SMS_TEMPLATE_ID
from system.models import KeyBookModel

logger = logging.getLogger('django')


def code_2_session(code, AppID, AppSecret):
    url = f"https://api.weixin.qq.com/sns/jscode2session?appid={AppID}&secret={AppSecret}&js_code={code}&grant_type=authorization_code"
    resp = requests.get(url).json()
    logger.info("登录接口返回数据："+json.dumps(resp))
    errcode = resp.get('errcode')
    openid = resp.get('openid')
    unionid = resp.get('unionid')
    session_key = resp.get('session_key')
    return errcode, openid, unionid, session_key


def check_sign(rawData, session_key, signature):
    '''
    :param rawData:
    :param session_key:
    :param signature:
    :return:
    '''
    signature1 = sha1(rawData + session_key)
    if signature == signature1:
        return True
    else:
        return False


class WXDataCrypt:
    def __init__(self, appId, sessionKey):
        self.appId = appId
        self.sessionKey = sessionKey

    def decrypt(self, encryptedData, iv):
        # base64 decode
        sessionKey = base64.b64decode(self.sessionKey)
        encryptedData = base64.b64decode(encryptedData)
        iv = base64.b64decode(iv)

        cipher = AES.new(sessionKey, AES.MODE_CBC, iv)

        decrypted = json.loads(self._unpad(cipher.decrypt(encryptedData)))

        if decrypted['watermark']['appid'] != self.appId:
            raise Exception('Invalid Buffer')

        return decrypted

    def _unpad(self, s):
        return s[:-ord(s[len(s) - 1:])]


# 拼接外网文件url
def split_file_url(_path):
    return settings.EXTRANET_FILE_ADDR + _path


def upload(file_data, file_name=None, file_prefix='mysp/face/'):
    """图片上传七牛云"""
    access_key = settings.ACCESS_KEY_QINIU
    secret_key = settings.SECRET_KEY_QINIU
    # 要上传的空间
    bucket_name = settings.BUCKET_QINIU
    # 构建鉴权对象
    q = Auth(access_key, secret_key)
    # 生成上传 Token，可以指定过期时间等
    token = q.upload_token(bucket_name)

    sha1 = hashlib.sha1()
    sha1.update(file_data)
    key = file_name or file_prefix + sha1.hexdigest()

    ret, info = put_data(token, key, file_data)
    if info and info.status_code != 200:
        logger.error("上传文件到七牛失败, 失败状态码为{}， 原因为{}".format(info.status_code, info.text_body))
        raise Exception("上传七牛失败")
    return settings.STORAGE_HOST_QINIU + ret['key']

class WXAuthorization(object):
    def __init__(self):
        self.mchid = settings.MCHID
        self.serial_no = settings.SERIAL_NO

    # 生成欲签名字符串
    def sign_str(self, method, url_path, timestamp, nonce_str, request_body=''):
        if request_body:
            # POST
            sign_list = [
                method,
                url_path,
                timestamp,
                nonce_str,
                request_body
            ]
            return '\n'.join(sign_list) + '\n'
        else:
            # GET
            sign_list = [
                method,
                url_path,
                timestamp,
                nonce_str
            ]
            return '\n'.join(sign_list) + '\n\n'

    def xcx_sign_str(self, timestamp, nonce_str, package):
        sign_list = [
            settings.APPID,
            timestamp,
            nonce_str,
            package
        ]
        return '\n'.join(sign_list) + '\n'

    # 生成随机字符串
    def get_nonce_str(self):
        data = "123456789zxcvbnmasdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP"
        nonce_str = ''.join(random.sample(data, 30))
        return nonce_str

    # 生成签名
    def sign(self, sign_str):
        # with open('秘钥文件', 'r') as f:
        #     # 这里要注意的秘钥只能有三行
        #     # -----BEGIN PRIVATE KEY-----
        #     # ******************秘钥只能在一行，不能换行*****************
        #     # -----END PRIVATE KEY-----
        #     private_key = f.read()
        #     f.close()
        private_key = settings.PRIVATE_KEY
        pkey = RSA.importKey(private_key)
        h = SHA256.new(sign_str.encode('utf-8'))
        signature = PKCS1_v1_5.new(pkey).sign(h)
        sign = base64.b64encode(signature).decode()
        return sign

    # 生成 Authorization
    def authorization(self, method, url_path, nonce_str, timestamp, body=None):
        # 加密子串
        signstr = self.sign_str(method=method, url_path=url_path, timestamp=timestamp, nonce_str=nonce_str,
                                request_body=body)
        # 加密后子串
        s = self.sign(signstr)
        authorization = 'WECHATPAY2-SHA256-RSA2048 ' \
                        'mchid="{mchid}",' \
                        'nonce_str="{nonce_str}",' \
                        'signature="{sign}",' \
                        'timestamp="{timestamp}",' \
                        'serial_no="{serial_no}"'. \
            format(mchid=self.mchid,
                   nonce_str=nonce_str,
                   sign=s,
                   timestamp=timestamp,
                   serial_no=self.serial_no
                   )
        return authorization

def rsa_verify(timestamp, nonce, body, signature):
    sign_str = f'{timestamp}\n{nonce}\n{body}\n'
    public_key = settings.PUBLIC_KEY
    signature = base64.b64decode(signature)
    # public_keyBytes = base64.b64decode(public_key)
    # pubKey = RSA.importKey(public_keyBytes)
    verifier = PKCS1_v1_5.new(RSA.importKey(base64.b64decode(public_key)))
    h = SHA256.new(sign_str.encode('UTF-8'))
    return verifier.verify(h, signature)

def decrypt(nonce, ciphertext, associated_data):
    key = settings.APIV3_KEY
    key_bytes = str.encode(key)
    nonce_bytes = str.encode(nonce)
    ad_bytes = str.encode(associated_data)
    data = base64.b64decode(ciphertext)
    aesgcm = AESGCM(key_bytes)
    return aesgcm.decrypt(nonce_bytes, data, ad_bytes).decode('UTF-8')

# 下单
def place_order_wx3(data, authorization):
    jsapi = settings.JSAPI
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': authorization}
    resp = requests.post(jsapi, data=data, headers=headers)
    logger.info("下单接口返回数据："+str(resp.text))

    # if resp.text:
    #     ret_data = json.loads(resp.text)
    # else:
    #     ret_data = {}
    return resp.text

def order_num(phone):
    time_str = datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d%H%M%S')
    num = random.randint(100, 999)
    return 'MYSP'+time_str+str(phone)+str(num)

def send_sms(phone, *args):
    try:
        sms_switch_status = int(KeyBookModel.objects.filter(key=settings.SMS_SWITCH_CONF_NAME).only(
            'value').first().value)
    except Exception:
        logger.error('获取短信开关状态失败', exc_info=True)
        sms_switch_status = settings.SMS_SWITCH_DEFAULT_VALUE
    if sms_switch_status == 0:
        logger.info(f'短信服务关闭状态，不向[{phone}]发送短信')
        return
    try:
        cred = credential.Credential(TENCENT_SECRET_ID, TENCENT_SECRET_KEY)
        # 实例化一个http选项，可选的，没有特殊需求可以跳过。
        httpProfile = HttpProfile()
        # 如果需要指定proxy访问接口，可以按照如下方式初始化hp
        # httpProfile = HttpProfile(proxy="http://用户名:密码@代理IP:代理端口")
        # httpProfile.reqMethod = "POST"  # post请求(默认为post请求)
        # httpProfile.reqTimeout = 30  # 请求超时时间，单位为秒(默认60秒)
        # httpProfile.endpoint = "sms.tencentcloudapi.com"  # 指定接入地域域名(默认就近接入)

        # 非必要步骤:
        # 实例化一个客户端配置对象，可以指定超时时间等配置
        clientProfile = ClientProfile()
        clientProfile.signMethod = "TC3-HMAC-SHA256"  # 指定签名算法
        clientProfile.language = "en-US"
        clientProfile.httpProfile = httpProfile

        # 实例化要请求产品(以sms为例)的client对象
        # 第二个参数是地域信息，可以直接填写字符串ap-guangzhou，或者引用预设的常量
        client = sms_client.SmsClient(cred, "ap-guangzhou", clientProfile)

        # 实例化一个请求对象，根据调用的接口和实际情况，可以进一步设置请求参数
        # 你可以直接查询SDK源码确定SendSmsRequest有哪些属性可以设置
        # 属性可能是基本类型，也可能引用了另一个数据结构
        # 推荐使用IDE进行开发，可以方便的跳转查阅各个接口和数据结构的文档说明
        req = models.SendSmsRequest()

        # 基本类型的设置:
        # SDK采用的是指针风格指定参数，即使对于基本类型你也需要用指针来对参数赋值。
        # SDK提供对基本类型的指针引用封装函数
        # 帮助链接：
        # 短信控制台: https://console.cloud.tencent.com/smsv2
        # sms helper: https://cloud.tencent.com/document/product/382/3773

        # 短信应用ID: 短信SdkAppId在 [短信控制台] 添加应用后生成的实际SdkAppId，示例如1400006666
        req.SmsSdkAppId = SMS_SDK_APPID
        # 短信签名内容: 使用 UTF-8 编码，必须填写已审核通过的签名，签名信息可登录 [短信控制台] 查看
        req.SignName = SMS_SIGN_NAME
        # 短信码号扩展号: 默认未开通，如需开通请联系 [sms helper]
        req.ExtendCode = ""
        # 用户的 session 内容: 可以携带用户侧 ID 等上下文信息，server 会原样返回
        req.SessionContext = ""
        # 国际/港澳台短信 senderid: 国内短信填空，默认未开通，如需开通请联系 [sms helper]
        req.SenderId = ""
        # 下发手机号码，采用 E.164 标准，+[国家或地区码][手机号]
        # 示例如：+8613711112222， 其中前面有一个+号 ，86为国家码，13711112222为手机号，最多不要超过200个手机号
        req.PhoneNumberSet = [phone]
        # 模板 ID: 必须填写已审核通过的模板 ID。模板ID可登录 [短信控制台] 查看
        req.TemplateId = SMS_TEMPLATE_ID
        # 模板参数: 若无模板参数，则设置为空
        req.TemplateParamSet = [*args]

        # 通过client对象调用DescribeInstances方法发起请求。注意请求方法名与请求对象是对应的。
        # 返回的resp是一个DescribeInstancesResponse类的实例，与请求对象对应。
        resp = client.SendSms(req)

        # 输出json格式的字符串回包
        # print(resp.to_json_string(indent=2))

    except TencentCloudSDKException as err:
        logger.error(err, exc_info=True)


def gen_qrcode(data):
    """
    方式1： URL转换二维码
    :param data: 转换二维码的数据
    :return:  base64编码后的 二进制流 二维码数据
    """
    qr = qrcode.make(data)
    buf = io.BytesIO()
    qr.save(buf)
    img_buf = buf.getvalue()
    return img_buf

async def async_upload_qiniu(data, format):
    access_key = settings.ACCESS_KEY_QINIU
    secret_key = settings.SECRET_KEY_QINIU
    cow = AsyncCow(access_key, secret_key)
    b = cow.get_bucket(settings.BUCKET_QINIU)
    file_name = str(int(time.time()*10000000)) + format
    key = 'mysp/sports_video/' + file_name
    try:
        res = await b.put_data(data=data, key=key)
        return res[0]['key'],file_name
    except:
        return ()

if __name__ == '__main__':
    with open('/home/fj/Downloads/卡片二@2x.png', 'rb') as f:
        print(upload(f.read()))
