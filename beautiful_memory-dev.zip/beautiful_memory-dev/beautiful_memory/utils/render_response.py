# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/5/14
# @author fj
import datetime
import json
import logging

from django.conf import settings
from kafka import KafkaProducer
from redis import StrictRedis

from django_redis import get_redis_connection
from rest_framework.renderers import JSONRenderer
from rest_framework.request import Request

logger = logging.getLogger('django')


class CustomJsonRenderer(JSONRenderer):
    # 重构render方法
    def render(self, data, accepted_media_type=None, renderer_context=None):
        if renderer_context:
            # 如果返回的data为字典
            if isinstance(data, dict):
                # 响应信息中有detail和code这两个key，则获取响应信息中的detail和code，并且将原本data中的这两个key删除，放在自定义响应信息里
                # 响应信息中没有则将msg内容改为请求成功 code改为请求的状态码
                msg = data.pop('detail', '成功')

                # 判断msg如果为dict,将任意一个key,value对组装为 str
                if isinstance(msg, dict):
                    try:
                        field, errorDetail = msg.popitem()
                        errorDetail = str(errorDetail[0])
                        if errorDetail.startswith('该字段'):
                            msg = f"{field}{errorDetail.strip('该')}"
                        elif errorDetail.startswith('请确保这个字段'):
                            msg = f"{field}{errorDetail.strip('请确保这个')}"
                        else:
                            msg = errorDetail
                    except Exception:
                        logger.warning('处理msg异常', exc_info=True)
                        msg = '参数校验失败'

                code = renderer_context["response"].status_code
            # 如果不是字典则将msg内容改为请求成功 code改为请求的状态码
            else:
                msg = '成功'
                code = renderer_context["response"].status_code
            renderer_context["response"].status_code = 200

            ## 统计各个场馆的活跃用户 redis类型：set；key: active_scene_user； value: {scene_id}_{user_id}; 过期时间当天凌晨；
            # 获取用户是否有人脸录入
            try:
                # 获取 request 请求对象
                request = renderer_context["request"]  # type: Request
                scene_id = request.query_params.get('scene_id')
                user = request.user
                # 判断用户是否认证通过并且有人脸数据
                if scene_id and user.is_authenticated and user.faces.exists():
                    redis_conn = get_redis_connection()  # type: StrictRedis
                    user_id = user.id.hex
                    with redis_conn.pipeline(transaction=False) as pipe:
                        # 向redis中添加活跃用户
                        pipe.exists(settings.ACTIVE_SCENE_USER_REDIS_KEY) \
                            .sadd(settings.ACTIVE_SCENE_USER_REDIS_KEY, f"{scene_id}_{user_id}")
                        # 判断缓存键是否存在，如果不存在设置过期时间exp_set_flag为True
                        is_exist_key, is_add_success = pipe.execute()
                    # 第一次加入返回True,
                    # 如果第一次添加，向kafka中发送第一次添加的消息 active_scene_user {"scene_id": "", "user_id": ""}
                    if is_add_success:
                        try:
                            yun_producer = KafkaProducer(bootstrap_servers=settings.KAFKA_SERVERS,
                                                         value_serializer=lambda v: json.dumps(v).encode(),
                                                         key_serializer=lambda v: json.dumps(v).encode(),
                                                         request_timeout_ms=60000,
                                                         retries=3,
                                                         max_block_ms=300000,
                                                         compression_type='gzip')
                            # 如果为空，推送kafka，之后云端创建一条游玩记录，并将redis中更新这个记录
                            yun_producer.send(settings.ACTIVE_SCENE_USER_KAFKA_TOPIC, value={
                                'user_id': user_id, 'scene_id': scene_id
                            })
                            yun_producer.flush(timeout=200)
                            yun_producer.close()
                        except Exception:
                            redis_conn.srem(settings.ACTIVE_SCENE_USER_REDIS_KEY, f"{scene_id}_{user_id}")
                            logger.warning(f'活跃用户:{user_id}消息推送kafka失败', exc_info=True)
                    # 根据 is_exist_key 状态设置过期时间为第二天凌晨
                    if not is_exist_key:
                        init_date = datetime.datetime.now()
                        middle_datetime = init_date + datetime.timedelta(days=1)
                        refresh_cycle_datetime = datetime.datetime(middle_datetime.year, middle_datetime.month,
                                                                   middle_datetime.day)
                        redis_conn.expireat(settings.ACTIVE_SCENE_USER_REDIS_KEY, refresh_cycle_datetime)
            except Exception:
                logger.warning("统计活跃用户id失败", exc_info=True)

            # 自定义返回的格式
            ret = {
                'msg': msg,
                'code': code,
                'data': data,
            }
            # 返回JSON数据
            return super(CustomJsonRenderer, self).render(ret, accepted_media_type, renderer_context)
        else:
            super(CustomJsonRenderer, self).render(data, accepted_media_type, renderer_context)
