# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import json
import math


def is_winded(point, poly):
    poly.append(poly[0])
    px = point[0]
    py = point[1]
    sum = 0
    length = len(poly) - 1

    for index in range(0, length):
        sx = poly[index][0]
        sy = poly[index][1]
        tx = poly[index + 1][0]
        ty = poly[index + 1][1]

        # 点与多边形顶点重合或在多边形的边上
        if ((sx - px) * (px - tx) >= 0 and (sy - py) * (py - ty) >= 0 and (px - sx) * (ty - sy) == (py - sy) * (
                tx - sx)):
            return 1
        # 点与相邻顶点连线的夹角
        angle = math.atan2(sy - py, sx - px) - math.atan2(ty - py, tx - px)

        # 确保夹角不超出取值范围（-π 到 π）
        if (angle >= math.pi):
            angle = angle - math.pi * 2
        elif (angle <= -math.pi):
            angle = angle + math.pi * 2
        sum += angle

        # 计算回转数并判断点和多边形的几何关系
    result = 0 if int(sum / math.pi) == 0 else 1
    return result


if __name__ == '__main__':
    lnglatlist = []
    data = '[{"name":"工厂","points":[{"lng":113.642124,"lat":23.167372},{"lng":113.636176,"lat":23.175162},{"lng":113.644930,"lat":23.179870},{"lng":113.652108,"lat":23.173823}],"type":0}]'
    data = json.loads(data)
    if 'points' in data[0]:
        for point in data[0]['points']:
            lnglat = []
            lnglat.append(float(str(point['lng'])))
            lnglat.append(float(str(point['lat'])))
            lnglatlist.append(lnglat)

    point = [114.193437, 30.513068]
    print(is_winded(point, lnglatlist))
