# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import cv2
import numpy as np

from .face_detection_serving.test import HumanFaceDetection


def face_data_verify(image_bytes):
    human_face_detection = HumanFaceDetection(None)
    image_numpy = cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)
    img, pad_params = human_face_detection.prepropess(image_numpy)
    face = human_face_detection.inference_from_local(img)
    if len(face) != 1:
        # 人脸数量不对
        return  -1
    ldmk = face[0][4:-2]
    p1 = [ldmk[0],ldmk[1]]
    p2 = [ldmk[2],ldmk[3]]
    p3 = [ldmk[4],ldmk[5]]
    p4 = [ldmk[6],ldmk[7]]
    p5 = [ldmk[8],ldmk[9]]
    leftdis = 2 * p3[0] - p1[0] - p4[0]
    rightdis = p2[0] + p5[0] - 2 * p3[0]
    lean = (leftdis / rightdis) * (leftdis / rightdis)
    if 36 > lean > 5:
        return 2
    elif 0.0278 < lean < 0.2:
        # 侧脸
        return 1
    elif lean < 2 and lean > 0.5:
        # 正脸
        return 0


if __name__ == '__main__':
    print(face_data_verify(open('/home/fj/Downloads/20210929-195951.png', 'rb').read()))
