#!/bin/bash
pip install -r beautiful_memory/requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/
cd beautiful_memory && python manage.py migrate && \
    celery -A celery_tasks.main worker -l INFO >> /data/logs/celery_worker.log 2>&1 & \
    cd beautiful_memory && celery -A celery_tasks.main beat -l INFO >> /data/logs/celery_beat.log 2>&1 & \
    cd beautiful_memory/celery_tasks/video && python tasks.py >> /data/logs/video_task.log 2>&1 & \
    cd beautiful_memory/celery_tasks/video && python tasks_msg.py >> /data/logs/video_msg_task.log 2>&1 & \
    cd beautiful_memory/celery_tasks/video && python video_frame_tasks.py >> /data/logs/video_frame_tasks.log 2>&1 & \
#    cd beautiful_memory && uvicorn beautiful_memory.asgi:application --host 0.0.0.0 --port 8001 \
#    --timeout-keep-alive 60 --workers 5 --limit-max-requests 5000 2>> /data/logs/uvicorn_err.log
    cd beautiful_memory && gunicorn beautiful_memory.asgi:application -w 5 -b 0.0.0.0:8001 \
    -k uvicorn.workers.UvicornWorker --timeout 60 --max-requests 5000 --log-file - 2>> /data/logs/uvicorn_err.log