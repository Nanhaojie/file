/*!40101 SET NAMES utf8mb4 */;
create database if not exists beautiful_memory default character set = 'utf8mb4' DEFAULT COLLATE 'utf8mb4_general_ci';