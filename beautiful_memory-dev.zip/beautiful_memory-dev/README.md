中讯美忆随拍项目v1.0

```
展厅摄像头：rtsp://admin:root12300.@172.16.0.20:554/h264/ch1/main/av_stream
大门摄像头：rtsp://admin:root12300@172.17.17.57:554/cam/realmonitor?channel=1&subtype=0
Video_2('rtsp://zhanghengxing:zhanghengxing20@172.17.30.2:554/Streaming/Channels/101?transportmode=unicast')
Video_3('rtsp://zhanghengxing:zhanghengxing20@172.17.30.3:554/Streaming/Channels/101?transportmode=unicast')
Video_4('rtsp://zhanghengxing:zhanghengxing20@172.17.30.4:554/Streaming/Channels/101?transportmode=unicast')
Video_7('rtsp://zhanghengxing:zhanghengxing20@172.17.30.7:554/Streaming/Channels/101?transportmode=unicast')
Video_8('rtsp://zhanghengxing:zhanghengxing20@172.17.30.8:554/Streaming/Channels/101?transportmode=unicast')
测试大华摄像头：rtsp://admin:root12300.@172.28.81.146:554/cam/realmonitor?channel=1&subtype=1
```

```bash
# 运行api容器服务
docker run -d -v /data/logs/beautiful_memory:/data/logs -v /opt/apps/beautiful_memory:/usr/src/app --name beautiful-memory-api -p8001:8001 beautiful_memory_api:1.0
# 运行模型服务
docker run -d -p 8500:8500 -p 8501:8501 --mount type=bind,source=/home/zoneyet/project/beautiful_memory/multiModel,target=/models/multiModel/ --name tf-serving --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 -t tensorflow/serving:2.6.0-gpu --model_config_file=/models/multiModel/models.config --platform_config_file=/models/multiModel/platform.config
模型查看地址：http://172.28.81.181:8501/v1/models/beautifulMemory/versions/2/metadata
```
#### 使用docker-compose部署
```bash
# 前置条件：
#1. 有docker及docker-compse环境
#2. 部署服务器拥有域名及对应ssl证书

#部署步骤
#1. 将项目根目录下的/deploy/beautiful_memory 软链接到系统跟目录/deploy/beautiful_memory
ln -s $(project_path)/deploy/beautiful_memory /deploy/beautiful_memory

#2. 修改配置文件
#2.1 nginx相关配置；配置文件地址 /deploy/beautiful_memory/nginx.conf
#	1. $(project_path)/deploy/cert的ssl证书文件
#	2. nginx.conf（第9第10行）配置中对应证书文件路径进行修改
#	3. nginx.conf（第16行）server_name参数修改为本服务器域名
#3. 构建api项目的基础镜像
cd /deploy/beautiful_memory
docker build -t base_bm:1.0 .
#4. 启动项目
sudo docker-compose -f docker-compose.yaml build --no-cache --force-rm
docker-compose -f docker-compose.yaml up -d
```

**云服务上线步骤**
```bash
# 1. 在10服务器 将代码推送到 云服务器
root@gello:/opt/apps/beautiful_memory# bash push_code.sh
# 2. 在云服务器 重启服务
root@hecs-282952:/opt/apps# bash beautiful_memory_restart.sh


正式线迁移到腾讯云
docker run -d -v /data/logs/beautiful_memory:/data/logs -v /opt/apps/beautiful_memory:/usr/src/app --name beautiful-memory-api -p8001:8001 --restart=always beautiful_memory_api:1.0

docker run -d -e "IS_PRODUCT=1" --name mysp_bkd_1.1 -p 8002:8002 -v /opt/apps/mysp_backend:/code/mysp_backend -v /data/logs/beautiful_memory_backend:/data/logs mysp_bkd:1.1 /usr/local/bin/python /opt/apps/mysp_backend/manage.py runserver 0.0.0.0:8002

```



测试GPU环境部署方案
```
前置条件：nvidia的显卡驱动（需要根据不同的显卡型号，安装对应的显卡驱动），使用nvidia-smi查看驱动安装成功


tfserving环境：
	1. 安装docker,下载tensorflow/serving:2.6.0-gpu镜像
	2. 找到对应的模型文件路径映射，执行：docker run -d -p 8500:8500 -p 8501:8501 --mount type=bind,source=/home/zoneyet/project/beautiful_memory/multiModel,target=/models/multiModel/ --name tf-serving --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=1 -t tensorflow/serving:2.6.0-gpu --model_config_file=/models/multiModel/models.config --platform_config_file=/models/multiModel/platform.config
	3. 模型查看地址

TensorRT环境：
	Tensorrt加速的原理是利用二进制onnx模型编译得到tensorrt引擎，直接调用cudaruntime进行推理。
	环境需求cuda10.2或11.3（建议11.3可支持tensorflow2.6.0）
	opencv4.2.0+
	cmake3.11+
	cuda11.3或10.2
	cudnn与cuda对应
	protobuf3.11.4
	tensorrt与cuda和cudnn版本对应且版本大于8.x
	先编译linuxpython预测库trtpyc再编译模型
	所需onnx模型内不能有任何读取tensor shape的运算或节点。如存在需要修改模型结构。
编译过程要修改makefile中所有库的路径，gpu算力值（1080/1080ti为61），编译完成后所需库不能移动或删除，如移动位置，需要再次编译。

```

模型的部署方式
```
tensorrt加速的模型： 人脸检测、人脸识别、行人检测、手势识别
tfserving: 行人重识别、表情识别、骨骼提取、tflite
``

精彩瞬间的判断
```
1. 滑梯：检测到人脸，判断人脸坐标在滑梯的坐标内，保存精彩瞬间
2. 攀岩：检测到人脸，当人脸检测不到时，用行人重识别，根据身体底板库（不同场景，身体的底板库分开存放）比对，判断人物ID，判断人体框在攀岩墙的坐标内，判断精彩瞬间(站在红色垫子上戴帽子比ye)
3. 蹦床：检测到人脸，当人脸检测不到时，用行人重识别，根据身体底板库（不同场景，身体的底板库分开存放）比对，检测到微笑，肢体动作，判断精彩瞬间。
4. 海洋球：检测到人脸，当人脸检测不到时，用行人重识别，根据身体底板库（不同场景，身体的底板库分开存放）比对，检测手势，检测到微笑，判断精彩瞬间。
```

```
1: 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/101?starttime=20211009t153130z&endtime=20211009t153530z'
2: 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/201?starttime=20211009t153130z&endtime=20211009t153530z'
3: 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/301?starttime=20211009t154900z&endtime=20211009t155200z'
4:  'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/401?starttime=20211009t153819z&endtime=20211009t154430z'
5： 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/501?starttime=20211009t153819z&endtime=20211009t154430z'
7: 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/701?starttime=20211009t152400z&endtime=20211009t152800z'
```

测试小程序后端服务是否通： https://med.trycan.com/api/v1.0/video/sample
测试后台服务是否通：https://med.trycan.com/api/v1.0/mysp/system/conf