# 长程随访小程序api

# 设计相关
## [ER图链接地址](https://www.processon.com/view/link/61a9768ee401fd08f981390d)
## [数据库文档](https://zoneyet-ai.feishu.cn/sheets/shtcnoGKBgkjObgWBtQNqyCie2f)


## docker-compose方式部署
> 1. 将项目放在 /opt/apps/ 下，则项目跟目录为 /opt/apps/long_follow_up_applet
> 2. 在/deploy/long_follow 下软连接到 ${project_base_path}/deploy/long_follow
>    `ln -s /opt/apps/long_follow_up_applet/deploy/long_follow /deploy`
> 3. 进入/deploy/long_follow/ 文件下，执行 `bash init_pro.sh`
> 

```bash
# 部署命令
docker run -e "IS_PRODUCT=0" -d -v /data/logs/long_follow_up_applet_dev:/data/logs -v /opt/apps/long_follow_up_applet_dev/long_follow_up_applet:/usr/src/app --name long-follow-up-applet-api_dev -p8003:8001 -p8004:8002 172.16.1.10:8900/app/long_follow_up_applet:dev_202112210000

# 10.11.0.250测试线
docker run -e "IS_PRODUCT=0" -d -v /data/logs/long_follow_up_applet_dev:/data/logs -v /data/lib/jenkins/workspace/long_follow_up_applet_api:/usr/src/app --name long-follow-up-applet-api_dev -p8003:8001 -p8004:8002 172.16.1.10:8900/app/long_follow_up_applet:dev_202112210000


# 服务部署在10服务器，拉取最新服务并上线的命令
root@gello:/opt/apps/long_follow_up_applet# bash long_follow_restart.sh 
# 日志监控告警邮件
 sudo nohup /home/hello/software/logstash/bin/logstash -f /home/hello/software/logstash/from_beat.conf > /home/hello/software/logstash/logstashstart.log 2>&1 &
 
sudo nohup /home/hello/software/filebeat-7.3.1-linux-x86_64/filebeat -e -c /home/hello/software/filebeat-7.3.1-linux-x86_64/filebeat.yml -d "long_follow_up_applet" > /home/hello/software/filebeat-7.3.1-linux-x86_64/filebeatstart.log 2>&1 &
```

```
celery 定时器

celery -A celery_tasks.main beat -l info --scheduler django_celery_beat.schedulers:DatabaseScheduler

celery -A celery_tasks.main worker -l INFO

```
