#!/bin/bash
pip install -r long_follow_up_applet/requirements.txt -i https://mirrors.aliyun.com/pypi/simple
cd long_follow_up_applet && python manage.py migrate && \
    celery -A celery_tasks.main worker -l INFO >> /data/logs/celery_worker.log 2>&1 & \
    cd long_follow_up_applet && celery -A celery_tasks.main beat -l INFO --scheduler \
    django_celery_beat.schedulers:DatabaseScheduler >> /data/logs/celery_beat.log 2>&1 & cd long_follow_up_applet &&
#    uvicorn long_follow_up_applet.asgi:application --host 0.0.0.0 --port 8001 \
#    --timeout-keep-alive 60 --workers 5 --limit-max-requests 5000 2>> /data/logs/uvicorn_err.log \
    gunicorn long_follow_up_applet.asgi:application -w 5 -b 0.0.0.0:8001 \
    -k uvicorn.workers.UvicornWorker --timeout 60 --max-requests 5000 --log-file - 2>> /data/logs/uvicorn_err.log \
    & if [ "${IS_PRODUCT}" -ne "2" ]; then
          cd long_follow_up_applet && export IS_PRODUCT=_ && python manage.py runserver 0.0.0.0:8002
      else
          # 阻塞着让docker可以运行下去
          while [ 1 ]; do
            sleep 9999999999
          done
      fi
