#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/14上午11:01
#@Author:zwz
import os
from datetime import timedelta

from celery import Celery
from celery.schedules import crontab
from django.conf import settings
from django.utils import timezone

# 为celery设置环境变量
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'long_follow_up_applet.settings')
# 创建celery 应用
celery_app = Celery('long_follow_up')

# 加载[配置
celery_app.config_from_object('celery_tasks.config')

celery_app.conf.beat_schedule = {
    'set_access_token': {
        'task': 'celery_tasks.patient.tasks.set_access_token',
        # 'schedule': timedelta(hours=1)       # 每小时执行一次
        'schedule': timedelta(minutes=4)       # 每4分钟执行一次
    },
    'update_illness_status': {
        'task': 'celery_tasks.patient.tasks.update_illness_status',
        'schedule': crontab(hour=10, minute=0)   # 定时检查
    }
}

# 设置app自动加载任务
# celery_app.autodiscover_tasks(lambda : settings.INSTALLED_APPS)
celery_app.autodiscover_tasks(['celery_tasks.patient'])

# 时区问题
# celery_app.now = timezone.now()

# 在出现worker接受到的message出现没有注册的错误时，使用下面一句能解决
imports = ("tasks",)