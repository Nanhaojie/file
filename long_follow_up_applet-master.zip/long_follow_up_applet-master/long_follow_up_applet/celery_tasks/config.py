#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/14上午11:04
#@Author:zwz

from django.conf import settings

# 设置代理人
broker_url = settings.CELERY_BROKER_URL
# 指定backend
result_backend = broker_url
# 时区
timezone = 'Asia/Shanghai'
# celery 序列化与反序列化
worker_result_serializer = 'json'
# 启动动作数量
worker_concurrency = 4
# 任务预取功能 多拿减少通讯成本
worker_prefetch_multiplier = 8
# 防止死锁
worker_force_execv = True
# worker 制定多少次重启
worker_max_tasks_per_child = 20
# 结果保存时间/s
result_expires = 60*20
worker_task_result_expires = 60*60

# 任务发出后经过一段时间未收到acknowledge,就将任务交给其他worker执行
worker_disable_rate_limits = True
# 关闭限速
WORKER_DISABLE_RATE_LIMITS = True

# celery beat 配置
CELERY_ENABLE_UTC = False
# CELERY_TIMEZONE = timezone
DJANGO_CELERY_BEAT_TZ_AWARE = False
CELERY_BEAT_SCHEDULER = 'django_celery_beat.schedulers:DatabaseScheduler'


