#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/12/14下午1:51
# @Author:zwz
import datetime
import logging

import requests
from django.conf import settings
from django.db import connection
from django.db.models import Q
from django_redis import get_redis_connection

from celery_tasks.main import celery_app
from patient.models import MedicationRecordModel, MedicationRemindModel, MedicationRecordMiddleModel, PatientModel, \
    AttackLogModel

logger = logging.getLogger('django')
redis_conn = get_redis_connection('login_user')

AppID = settings.APPID
AppSecret = settings.APPSECRET
MEDICATION_REMINDER_TEM_ID = settings.MEDICATION_REMINDER_TEM_ID  # 用药提醒模板
SUBSEQUENT_VISIT_TEM_ID = settings.SUBSEQUENT_VISIT_TEM_ID     # 复诊提醒模板
BAND_DOCTOR_TEM_ID = settings.BAND_DOCTOR_TEM_ID          # 绑定医生提醒模板
SUB_MSG_SEND_URL = settings.SUB_MSG_SEND_URL
MINE_PAGE_PATH = settings.MINE_PAGE_PATH
SERIOUS_DURATION_NODE = settings.SERIOUS_DURATION_NODE  # 时长大于10分钟 严重
SERIOUS_TIMES_NODE = settings.SERIOUS_TIMES_NODE  # 每天大于1 严重
# 复诊提醒
SERIOUS_NOTICE_CONTENT = settings.SERIOUS_NOTICE_CONTENT   # 次数过多提醒内容
LONG_TIME_NOTICE_CONTENT = settings.LONG_TIME_NOTICE_CONTENT   # 时长过长用户提醒
MODERATE_NOTICE_CONTENT = settings.MODERATE_NOTICE_CONTENT    # 状态良好提醒内容
DOCTOR_ADVICE_NOTICE_CONTENT = settings.DOCTOR_ADVICE_NOTICE_CONTENT  #医生建议复诊提醒内容
NOTES = settings.NOTES

MINIPROGRAM_STATE = settings.MINIPROGRAM_STATE     # 跳转小程序类型：developer 为开发版；trial 为体验版；formal 为正式版；默认为正式版

# AppID = 'wx96e840c165843043'
# AppSecret = '631ee29a4a595aafe5f8b122e4fbc506'
# MEDICATION_REMINDER_TEM_ID = 'GarlGRMUV1xjKgdAJEJimvKiU1PfJGrhJ2owlN0RZVI'  # 用药提醒模板
# SUBSEQUENT_VISIT_TEM_ID = 'DGcK1bPT4tvf7IB_SJwR4SLqNqogvjFNT5bWnhf04XQ'     # 复诊提醒模板
# BAND_DOCTOR_TEM_ID = 'BYiWjhnARa8k5PrOLd2ED-fm91Avx_foZAME_09toAo'          # 绑定医生提醒模板
# SUB_MSG_SEND_URL = 'https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token='
# MINE_PAGE_PATH = '/pages/role/role'
# SERIOUS_DURATION_NODE = 10  # 时长大于10分钟 严重
# SERIOUS_TIMES_NODE = 1  # 每天大于1 严重
# # 复诊提醒
# SERIOUS_NOTICE_CONTENT = '您的孩子近期病情不稳定，建议及时复诊'   # 次数过多提醒内容
# LONG_TIME_NOTICE_CONTENT = '您的孩子近期病情不稳定，建议及时复诊'   # 时长过长用户提醒
# MODERATE_NOTICE_CONTENT = '您的孩子近期病情稳定，建议三个月内复诊'    # 状态良好提醒内容
# DOCTOR_ADVICE_NOTICE_CONTENT = '您孩子的复诊时间到了，请及时前往医院复诊'  #医生建议复诊提醒内容
# NOTES = '感谢您的使用,祝您早日康复'
#
# MINIPROGRAM_STATE = 'trial'     # 跳转小程序类型：developer 为开发版；trial 为体验版；formal 为正式版；默认为正式版


@celery_app.task
def medication_remind(**kwargs):
    patient_id = kwargs['patient_id']
    remind_time = kwargs['remind_time']
    remind_msg_data = kwargs['remind_msg_data']
    # 获取access_token
    access_token = redis_conn.get('long_follow_up_access_token').decode()
    # 服务通知
    rsp = requests.post(SUB_MSG_SEND_URL + access_token, json=remind_msg_data)
    try:
        logger.warning(rsp.json())
    except Exception:
        logger.warning('订阅消息返回rsp解析失败', exc_info=True)
    # 添加用药记录以及所使用药品
    medication_record = MedicationRecordModel(patient_id=patient_id)
    medication_record.save()
    medication_remind_list = MedicationRemindModel.objects.filter(patient_id=patient_id,
                                                                  remind_time=remind_time)
    for medication_remind in medication_remind_list:
        medicine = medication_remind.medicine
        MedicationRecordMiddleModel(medicine_id=medicine.id, medicine_name=medicine.name,
                                    specifications=medicine.specifications,
                                    medicine_record_id=medication_record.id, notes=medicine.notes).save()


# 设置的复诊提醒
@celery_app.task
def subsequent_visit(**kwargs):
    # 获取access_token
    access_token = redis_conn.get('long_follow_up_access_token').decode()
    # 服务通知
    rsp = requests.post(SUB_MSG_SEND_URL + access_token, json=kwargs)
    try:
        logger.warning(rsp.json())
    except Exception:
        logger.warning('订阅消息返回rsp解析失败', exc_info=True)


# 变更病情状态
@celery_app.task
def update_illness_status():
    today = datetime.date.today()
    days_ago_of_30 = today - datetime.timedelta(days=30)
    days_ago_of_30_str = days_ago_of_30.strftime('%Y-%m-%d')
    days_ago_of_90 = today - datetime.timedelta(days=90)
    patients = PatientModel.objects.filter(illness_status__in=[2, 3])

    for patient in patients:
        # 严重变适中条件: 30天内无严重情况
        if patient.illness_status == 3:
            # count = AttackLogModel.objects.filter(patient_id=patient.id, attack_time__gte=days_ago_of_30).filter(
            #     Q(same_day_attack_times__gt=SERIOUS_TIMES_NODE) | Q(duration__gt=SERIOUS_DURATION_NODE)).count()
            same_day_times_sql = '''
            select count(*) from (select count(*) as c
            from t_attack_log
            where patient_id = %s and attack_time >= %s
            group by date_format(attack_time, '%%Y-%%m-%%d')) as t1 where c>%s;
            '''
            duration_sql = '''
            select count(*)
            from t_attack_log
            where patient_id = %s and attack_time >= %s and duration > %s;
            '''
            with connection.cursor() as cursor:
                cursor.execute(same_day_times_sql, [patient.id, days_ago_of_30_str, settings.SERIOUS_TIMES_NODE])
                row_same_day = cursor.fetchone()[0]
                cursor.execute(duration_sql, [patient.id, days_ago_of_30_str, settings.SERIOUS_DURATION_NODE])
                row_duration = cursor.fetchone()[0]
            # 病情转适中
            # if not count:
            if not row_same_day and not row_duration:
                patient.illness_status = 2
                patient.save()
        # 适中变良好: 90天内无发作记录
        else:
            count = AttackLogModel.objects.filter(patient_id=patient.id, attack_time__gte=days_ago_of_90).count()
            if not count:
                patient.illness_status = 1
                patient.save()
                # 复诊时间
                subsequent_visit_date = datetime.datetime.now() + datetime.timedelta(days=1)
                subsequent_visit_date_str = datetime.datetime.strftime(subsequent_visit_date, '%Y年%m月%d日')
                # 复诊提醒
                remind_msg_data = {
                    "touser": patient.account.open_id,
                    "template_id": SUBSEQUENT_VISIT_TEM_ID,
                    "page": MINE_PAGE_PATH,
                    "miniprogram_state": MINIPROGRAM_STATE,
                    "lang": "zh_CN",
                    "data": {
                        # 温馨提醒
                        "thing1": {"value": MODERATE_NOTICE_CONTENT},
                        # 就诊人
                        "phrase2": {
                            "value": patient.name[:5]
                        },
                        # 复诊时间
                        "date5": {
                            "value": subsequent_visit_date_str
                        },
                        # 备注
                        "thing6": {"value": NOTES}
                    }
                }
                send_wx_msg.apply_async(kwargs=remind_msg_data)

@celery_app.task
def set_access_token():
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={AppID}&secret={AppSecret}"
    resp = requests.get(url).json()
    access_token = resp.get('access_token')
    if access_token:
        redis_conn.set('long_follow_up_access_token', access_token, 60 * 60 * 2)


@celery_app.task(name='send_wx_msg')
def send_wx_msg(**remind_msg_data):
    print(remind_msg_data)
    # 获取access_token
    access_token = redis_conn.get('long_follow_up_access_token').decode()
    # 服务通知
    rsp = requests.post(SUB_MSG_SEND_URL + access_token, json=remind_msg_data)
    try:
        logger.warning(rsp.json())
    except Exception:
        logger.warning('订阅消息返回rsp解析失败', exc_info=True)


@celery_app.task
def test_task(**kwargs):
    print(kwargs, type(kwargs['tewst']))
