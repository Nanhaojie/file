#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/7上午11:18
#@Author:zwz

from django.urls import path

from mytest.views import Test

urlpatterns = [
    path('', Test.as_view())
]