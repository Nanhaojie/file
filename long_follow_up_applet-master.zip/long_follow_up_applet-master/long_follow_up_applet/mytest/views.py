import json
from datetime import datetime, timedelta

import pytz
from celery.utils.time import maybe_make_aware
from django.shortcuts import render

# Create your views here.
from django_celery_beat.clockedschedule import clocked
from django_celery_beat.models import PeriodicTask, IntervalSchedule, CrontabSchedule, ClockedSchedule
from rest_framework.response import Response
from rest_framework.views import APIView

from celery_tasks.main import celery_app
# from celery_tasks.patient.tasks import test_task


class Test(APIView):

    def get(self, request, *args, **kwargs):
        data = {
            'tewst': [1,2]
        }
        # schedule, _ = CrontabSchedule.objects.update_or_create(
        #     minute = '*',
        #     hour = '*',
        #     timezone=pytz.timezone("Asia/Shanghai"),
        # )
        # schedule, _ = IntervalSchedule.objects.update_or_create(every=10, period=IntervalSchedule.SECONDS)
        now_datetime = datetime.now() + timedelta(hours=-8, seconds=10)
        clock, _ = ClockedSchedule.objects.update_or_create(clocked_time=now_datetime)

        PeriodicTask.objects.filter(name="clock-task").delete()
        PeriodicTask.objects.update_or_create(
            defaults={
                # "interval": schedule,  # 上面创建10分钟的间隔 interval 对象
                # "crontab": schedule,
                "clocked": clock,
                "one_off": True,
                "enabled": True,
                "task": "celery_tasks.patient.tasks.test_task",  # 指定需要周期性执行的任务
                "kwargs": json.dumps({'tewst': 'tewst'}, ensure_ascii=False),
            },
            # name = "interval-task",
            name = "clock-task"
        )
        # PeriodicTask.objects.filter(name='定时任务-task').delete()
        return Response(data={'test': 'test'})

    def post(self, request, *args, **kwargs):
        return Response(data={'test': 'test'})
