import uuid

from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class HospitalModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=128, verbose_name='医院姓名')
    address = models.CharField(max_length=256, verbose_name='地址')
    tel = models.CharField(max_length=64, null=True, blank=True, verbose_name='电话')
    lng = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name='经度')
    lat = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name='纬度')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    notes = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')

    class Meta:
        verbose_name = '医院表'
        verbose_name_plural = verbose_name
        db_table = 't_hospital'
        ordering = ('name', )


class DepartmentModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=128, verbose_name='科室名称')
    introduction = models.TextField(max_length=2048, verbose_name='科室介绍')
    hospital = models.ForeignKey(HospitalModel, on_delete=models.PROTECT, related_name='department_set', db_constraint=False)
    hospital_name = models.CharField(max_length=256, verbose_name='医院名称')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '科室表'
        verbose_name_plural = verbose_name
        db_table = 't_department'
        ordering = ('name', )


class HealthConsultation(SpareFieldModel):
    content_type_choices = (
        (1, '常见问题'),
        (2, '专科检查'),
        (3, '疾病介绍'),
        (4, '健康教育'),
    )

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    cover_picture_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='封面图')
    title = models.CharField(max_length=128, verbose_name='标题')
    content = models.TextField(max_length=10240, verbose_name='内容')
    hospital = models.ForeignKey(HospitalModel, on_delete=models.CASCADE, related_name='health_consultation', db_constraint=False)
    content_type = models.SmallIntegerField(choices=content_type_choices, verbose_name=f'内容类型{str(content_type_choices)}')
    serial_num = models.IntegerField(default=0, verbose_name='序号')
    release_time = models.DateTimeField(auto_now_add=True, verbose_name='发布时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '健康咨询表'
        verbose_name_plural = verbose_name
        db_table = 't_health_consultation'
        ordering = ('-serial_num', '-release_time')


class RotationPictureModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=128, null=True, blank=True, verbose_name='名称')
    picture_url = models.CharField(max_length=256, verbose_name='轮播图url')
    content = models.TextField(max_length=2048, verbose_name='内容')
    serial_num = models.IntegerField(default=0, verbose_name='序号')
    hospital = models.ForeignKey(HospitalModel, on_delete=models.CASCADE, related_name='rotation_picture', db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '轮播图表'
        verbose_name_plural = verbose_name
        db_table = 't_rotation_picture'
        ordering = ('-serial_num', '-create_time')


class HomePageIconModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=16, null=True, blank=True, verbose_name='名称')
    picture_url = models.CharField(max_length=256, verbose_name='url')
    serial_num = models.IntegerField(blank=True, auto_created=True, verbose_name='序号')
    type = models.SmallIntegerField(choices=((1, '健康咨询'), (2, '医院介绍')), verbose_name='类型')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '首页icon表'
        verbose_name_plural = verbose_name
        db_table = 't_home_page_icon'
        ordering = ('-serial_num', )