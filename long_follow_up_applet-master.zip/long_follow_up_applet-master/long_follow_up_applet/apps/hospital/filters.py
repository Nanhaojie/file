# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 12/9/21 1:52 PM
# @author yueyuanbo

import django_filters

from hospital.models import HealthConsultation, RotationPictureModel, DepartmentModel


class HealthConsultationFilter(django_filters.FilterSet):
    """健康咨询的过滤类"""
    # field_name 表示要过滤字段；lookup_expr 表示 过滤时要进行的操作，gte 表示 大于等于
    type = django_filters.NumberFilter(field_name="content_type", lookup_expr="exact",
                                       help_text=f'健康教育类型{";".join(map(str, HealthConsultation.content_type_choices))}')
    hospital_id = django_filters.CharFilter(field_name="hospital_id", lookup_expr="exact", help_text='医院id')
    release_time_from = django_filters.CharFilter(field_name='release_time', method="release_time_from_filter",
                                                  help_text="过滤开始时间 e.g. 2021-12-12")
    release_time_to = django_filters.CharFilter(field_name='release_time', method="release_time_to_filter",
                                                  help_text="过滤结束时间 e.g. 2021-12-12")
    title = django_filters.CharFilter(field_name='title', lookup_expr="contains", help_text="标题检索")

    class Meta:
        model = HealthConsultation  # 关联的表
        fields = ["type", "hospital_id"]  # 过滤的字段

    def release_time_from_filter(self, queryset, name, value):
        filter_data = {f'{name}__gte': f'{value} 00:00:00'}
        return queryset.filter(**filter_data)

    def release_time_to_filter(self, queryset, name, value):
        filter_data = {f'{name}__lte': f'{value} 23:59:59'}
        return queryset.filter(**filter_data)


class RotationPictureFilter(django_filters.FilterSet):
    """轮播图的过滤类"""
    hospital_id = django_filters.CharFilter(field_name="hospital_id", lookup_expr="exact", help_text='医院id')

    class Meta:
        model = RotationPictureModel  # 关联的表
        fields = ["hospital_id"]  # 过滤的字段


class DepartmentListFilter(django_filters.FilterSet):
    """科室列表的过滤类"""
    hospital_id = django_filters.CharFilter(field_name="hospital_id", lookup_expr="exact", help_text='医院id')
    name = django_filters.CharFilter(field_name="name", lookup_expr="contains", help_text='科室名称关键字')

    class Meta:
        model = DepartmentModel  # 关联的表
        fields = ["hospital_id"]  # 过滤的字段
