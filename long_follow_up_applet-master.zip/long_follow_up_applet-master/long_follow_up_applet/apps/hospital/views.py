# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021-12-08 16:42
# @author yueyuanbo

# Create your views here.
import logging

from django.db import connection
from django.db.models import Q, Max, ProtectedError
from django.utils.decorators import method_decorator
from django.utils.timezone import now
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.generics import ListAPIView, RetrieveAPIView, UpdateAPIView, DestroyAPIView, CreateAPIView, \
    GenericAPIView
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import filters
from rest_framework.viewsets import ModelViewSet

from doctor.models import SchedulerModel, DoctorModel
from hospital.filters import HealthConsultationFilter, RotationPictureFilter, DepartmentListFilter
from hospital.models import HealthConsultation, RotationPictureModel, DepartmentModel, HospitalModel
from hospital.serializers import HealthConsultationSerializer, HealthConsultationRetrieveSerializer, \
    RotationPictureSerializer, DepartmentListSerializer, DepartmentRetrieveSerializer, HospitalSchedulerSerializer, \
    HospitalListSerializer, CommonQuestionSerializer, CommonQuestionBaseSerializer, HospitalSerializer, \
    DepartmentSerializer, DepartmentSchedulerUpdateSerializer, RotationPictureListSerializer, DoctorSchedulerSerializer, \
    DoctorSchedulerUpdateSerializer
from long_follow_up_applet import settings
from patient.models import PatientModel
from utils.common import common_upload

logger = logging.getLogger('django')


class BKEDPictureUpload(APIView):

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""后台图片上传""",
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['file_name'],
            properties={
                'file_name': openapi.Schema(type=openapi.TYPE_FILE, description='文件'),
            }
        ),
        # 接口标题
        operation_summary='富文本图片上传',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['图片上传']
    )
    def post(self, request, *args, **kwargs):
        # {
        # // errno
        # 即错误代码，0
        # 表示没有错误。
        # // 如果有错误，errno != 0，可通过下文中的监听函数
        # "errno": 0,
        # // data
        # 是一个数组，返回图片Object，Object中包含需要包含url、alt和href三个属性, 它们分别代表图片地址、图片文字说明和跳转链接,
        # alt和href属性是可选的，可以不设置或设置为空字符串, 需要注意的是url是一定要填的。
        # "data": [
        #     {
        #         url: "图片地址",
        #         alt: "图片文字说明",
        #         href: "跳转链接"
        #     },
        #     "……"
        # ]
        # }
        data = list()
        for file in request.FILES.values():
            data.append({'url': common_upload(file.read())})
        return Response(data={'errno': 0, 'data': data}, headers={'OriginalResponse': 'true'})


@method_decorator(swagger_auto_schema(
    operation_description="""常见问题""",
    operation_summary='常见问题列表',  # 接口标题
    manual_parameters=[
        openapi.Parameter(
            # 参数名称
            name="filter_sentence",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="搜索内容",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
        openapi.Parameter(
            # 参数名称
            name="hospital_id",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="医院id",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: CommonQuestionSerializer}
    # tags=['留言'],   # 分组中
),
    name='get'
)
class CommonQuestionListView(ListAPIView):
    serializer_class = CommonQuestionBaseSerializer

    def list(self, request, *args, **kwargs):
        filter_sentence = self.request.query_params.get('filter_sentence', '')
        hospital_id = self.request.query_params.get('hospital_id', '')
        queryset = HealthConsultation.objects.filter(content_type=1)
        if hospital_id:
            queryset = queryset.filter(hospital_id=hospital_id)

        self.filter_words = list()

        if filter_sentence:
            queryset = queryset.filter(Q(title__contains=filter_sentence) | Q(content__contains=filter_sentence))
            # 默认模式
            # seg_list = pseg.cut(filter_sentence)
            # logger.info(f'对{filter_sentence}分词')
            # for word, flag in seg_list:
            #     filter_flags = ['p', 'c', 'u', 'e', 'y', 'o', 'w', 'x']
            #     logger.info(f'分词结果{word, flag}')
            #     # if not re.search('|'.join(filter_flags), flag):
            #     if flag not in filter_flags:
            #         self.filter_words.append(word)
            # filter_words_regex = '|'.join(self.filter_words)
            #
            # # 分词结果为空直接返回空结果
            # if not filter_words_regex:
            #     return Response(dict([
            #         ('count', 0),
            #         ('next', None),
            #         ('previous', None),
            #         ('key_words', []),
            #         ('results', [])
            #     ]))
            #
            # if filter_words_regex:
            #     # 根据分词结果查询
            #     queryset = queryset.filter(Q(title__regex=filter_words_regex) | Q(content__regex=filter_words_regex))

        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        return Response(dict([
            ('count', self.paginator.page.paginator.count),
            ('next', self.paginator.get_next_link()),
            ('previous', self.paginator.get_previous_link()),
            ('key_words', self.filter_words),
            ('results', serializer.data)
        ]))


class HealthConsultationListCreateView(ListAPIView, CreateAPIView):
    filter_class = HealthConsultationFilter
    queryset = HealthConsultation.objects.all()

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育列表',  # 接口标题
        tags=['健康教育'],  # 分组中
    )
    def get(self, request, *args, **kwargs):
        return super(HealthConsultationListCreateView, self).get(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育新增',  # 接口标题
        tags=['健康教育'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def post(self, request, *args, **kwargs):
        return super(HealthConsultationListCreateView, self).post(request, *args, **kwargs)

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.request.method.lower() == 'get':
            return [permission() for permission in self.permission_classes]
        else:
            return [IsAdminUser()]

    def get_serializer_class(self):
        if self.request.method.lower() == 'get':
            return HealthConsultationSerializer
        else:
            return HealthConsultationRetrieveSerializer


class HealthConsultationToppingView(UpdateAPIView):
    queryset = HealthConsultation.objects.all()
    permission_classes = (IsAdminUser,)

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育置顶',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['健康教育'],  # 分组中
    )
    def put(self, request, *rags, **kwargs):
        instance = self.get_object()
        # 查询当前分类中排序字段的最大值
        instance.serial_num = self.get_queryset().filter(hospital_id=instance.hospital_id,
                                                         content_type=instance.content_type). \
                                  aggregate(Max('serial_num')).get('serial_num__max') + 1
        instance.save()
        return Response({'detail': '成功'})


class HealthConsultationRetrieveView(RetrieveAPIView, UpdateAPIView, DestroyAPIView):
    serializer_class = HealthConsultationRetrieveSerializer
    queryset = HealthConsultation.objects.all()

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育详情',  # 接口标题
        tags=['健康教育'],  # 分组中
    )
    def get(self, request, *rags, **kwargs):
        return super(HealthConsultationRetrieveView, self).get(request, *rags, **kwargs)

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育编辑',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['健康教育'],  # 分组中
    )
    def put(self, request, *rags, **kwargs):
        return super(HealthConsultationRetrieveView, self).put(request, *rags, **kwargs)

    @swagger_auto_schema(
        operation_description="""健康教育""",
        operation_summary='健康教育删除',  # 接口标题
        tags=['健康教育'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def delete(self, request, *rags, **kwargs):
        return super(HealthConsultationRetrieveView, self).delete(request, *rags, **kwargs)

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.request.method.lower() == 'get':
            return [permission() for permission in self.permission_classes]
        else:
            return [IsAdminUser()]


class RotationPictureView(ModelViewSet):
    pagination_class = None
    serializer_class = RotationPictureSerializer
    filter_class = RotationPictureFilter
    queryset = RotationPictureModel.objects.all()

    def get_serializer_class(self):
        if self.action == 'list':
            return RotationPictureListSerializer
        else:
            return RotationPictureSerializer

    def get_permissions(self):
        if self.action in ('list', 'retrieve'):
            return [permission() for permission in self.permission_classes]
        else:
            return [IsAdminUser()]

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='轮播图列表',  # 接口标题
        tags=['轮播图'],  # 分组中
    )
    def list(self, request, *args, **kwargs):
        return super(RotationPictureView, self).list(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='轮播图详情',  # 接口标题
        tags=['轮播图'],  # 分组中
    )
    def retrieve(self, request, *args, **kwargs):
        return super(RotationPictureView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='创建轮播图',  # 接口标题
        tags=['轮播图'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def create(self, request, *args, **kwargs):
        return super(RotationPictureView, self).create(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='更新轮播图',  # 接口标题
        tags=['轮播图'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def partial_update(self, request, *args, **kwargs):
        return super(RotationPictureView, self).partial_update(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='删除轮播图',  # 接口标题
        tags=['轮播图'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def destroy(self, request, *args, **kwargs):
        return super(RotationPictureView, self).destroy(request, *args, **kwargs)


class RotationPictureToppingView(UpdateAPIView):
    queryset = RotationPictureModel.objects.all()
    permission_classes = (IsAdminUser,)

    @swagger_auto_schema(
        operation_description="""轮播图""",
        operation_summary='轮播图置顶',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['轮播图'],  # 分组中
    )
    def put(self, request, *rags, **kwargs):
        instance = self.get_object()
        # 查询当前分类中排序字段的最大值
        instance.serial_num = self.get_queryset().filter(hospital_id=instance.hospital_id). \
                                  aggregate(Max('serial_num')).get('serial_num__max') + 1
        instance.save()
        return Response({'detail': '成功'})


@method_decorator(swagger_auto_schema(
    operation_description="""科室列表""",
    operation_summary='科室列表',  # 接口标题
    # tags=['留言'],   # 分组中
),
    name='get'
)
class DepartmentListView(ListAPIView):
    serializer_class = DepartmentListSerializer
    filter_class = DepartmentListFilter
    queryset = DepartmentModel.objects.order_by('name')
    pagination_class = None


class DepartmentModelView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    filter_class = DepartmentListFilter
    queryset = DepartmentModel.objects.order_by('name')

    def get_serializer_class(self):
        if self.action == 'list':
            return DepartmentListSerializer
        else:
            return DepartmentSerializer

    @swagger_auto_schema(
        operation_description="""后台科室模块""",
        operation_summary='后台科室列表',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['后台科室']  # 分组中
    )
    def list(self, request, *args, **kwargs):
        return super(DepartmentModelView, self).list(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""后台科室模块""",
        operation_summary='后台科室详情',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['后台科室']  # 分组中
    )
    def retrieve(self, request, *args, **kwargs):
        return super(DepartmentModelView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""后台科室模块""",
        operation_summary='创建科室',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['后台科室'],  # 分组中
    )
    def create(self, request, *args, **kwargs):
        return super(DepartmentModelView, self).create(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""后台科室模块""",
        operation_summary='更新科室',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['后台科室'],  # 分组中
    )
    def partial_update(self, request, *args, **kwargs):
        return super(DepartmentModelView, self).partial_update(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""后台科室模块""",
        operation_summary='删除科室',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['后台科室'],  # 分组中
    )
    def destroy(self, request, *args, **kwargs):
        try:
            response = super(DepartmentModelView, self).destroy(request, *args, **kwargs)
        except Exception:
            logger.info('科室删除失败', exc_info=True)
            return Response({'detail': '请先删除该科室下绑定的医生'}, status=status.HTTP_400_BAD_REQUEST)
        return response


@method_decorator(swagger_auto_schema(
    operation_description="""科室详情""",
    operation_summary='科室详情',  # 接口标题
    # tags=['留言'],   # 分组中
),
    name='get'
)
class DepartmentRetrieveView(RetrieveAPIView):
    serializer_class = DepartmentRetrieveSerializer
    queryset = DepartmentModel.objects.all()


@method_decorator(swagger_auto_schema(
    operation_description="""出诊安排""",
    operation_summary='出诊安排',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        openapi.Parameter(
            # 参数名称
            name="filter_date",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="搜索日期；e.g. 2021-12-12； 默认当前时间",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
        openapi.Parameter(
            # 参数名称
            name="filter_department",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="搜索科室的id",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: HospitalSchedulerSerializer}
),
    name='get'
)
class HospitalSchedulerListView(APIView):

    def get(self, request, *args, **kwargs):
        # 获取过滤时间 默认为当前时间
        filter_date = request.query_params.get('filter_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT))
        filter_department = request.query_params.get('filter_department')
        if not filter_department:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # todo 没有过滤未审核的医生
        query_sql = """
                SELECT
                    `date`,
                    group_concat(concat_ws('-', DATE_FORMAT( start_time, '%%H:%%i') , DATE_FORMAT( end_time, '%%H:%%i'))
                     order by `start_time` separator ' ') as time,
                     `t_doctor`.`name` as doctor_name,
                     `t_doctor`.`id` as doctor_id,
                     `t_doctor`.`photo_url` as doctor_photo_url,
                     `t_doctor`.`rank` as doctor_rank,
                     `t_department`.`name` as department_name 
                FROM
                    t_scheduler, t_doctor, t_department
                WHERE
                    DATE_FORMAT( t_scheduler.date, '%%Y-%%m-%%d' ) = %s and t_scheduler.department_id=%s 
                    and t_scheduler.status=1 and t_scheduler.doctor_id=t_doctor.id 
                    and t_scheduler.department_id=t_department.id
                    and t_doctor.doctor_type=1
                GROUP BY
                    `t_scheduler`.`date`, `t_department`.`id`, `t_doctor`.`id` 
                ORDER BY time, doctor_name
                """
        with connection.cursor() as cursor:
            cursor.execute(query_sql, (filter_date, filter_department))
            data = [{'date': row[0], 'time': row[1].split(' '), 'doctor_name': row[2], 'doctor_id': row[3],
                    'doctor_photo_url': row[4], 'doctor_rank': dict(DoctorModel.rank_choices).get(row[5], '未知职级'),
                     'department_name':row[6]}
                    for row in cursor.fetchall()]
        return Response(data)


class HospitalSchedulerBKView(APIView):
    permission_classes = (IsAdminUser,)

    @swagger_auto_schema(
        operation_description="""后台排班""",
        operation_summary='后台排班管理列表',  # 接口标题
        manual_parameters=[
            openapi.Parameter(
                name="filter_date", in_=openapi.IN_QUERY, description="搜索日期；e.g. 2021-12-12； 默认当前时间",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(name="filter_department", in_=openapi.IN_QUERY, description="搜索科室的id",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="hospital_id", in_=openapi.IN_QUERY, description="医院id",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING, required=True)
        ],
        tags=['后台排班'],  # 分组
    )
    def get(self, request, *args, **kwargs):
        # 获取过滤时间 默认为当前时间
        filter_date = request.query_params.get('filter_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT))
        filter_department = request.query_params.get('filter_department', '')
        hospital_id = request.query_params.get('hospital_id')
        if not hospital_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # 从日期中筛选，按照科室和时间进行聚合， 查询结果对人名字符串进行拼接
        query_sql = [
            """
            SELECT
                concat_ws('-', DATE_FORMAT( start_time, '%%H:%%i') , DATE_FORMAT( end_time, '%%H:%%i')) as time,
                 t_department.name as department_name,
                 group_concat( concat_ws('--', t_doctor.id, t_doctor.name)  order by t_doctor.name ), 
                 `t_scheduler`.`department_id`
            FROM
                t_scheduler, t_doctor, t_department
            WHERE
                DATE_FORMAT( t_scheduler.date, '%%Y-%%m-%%d' )=%s
            """,
            f'and t_scheduler.department_id=%s' if filter_department else '%s',
            """
                and t_scheduler.status=1 and t_scheduler.department_id=t_department.id and 
                t_doctor.id=t_scheduler.doctor_id and t_department.hospital_id=%s
            GROUP BY
                `time`, `t_department`.`id`, `t_doctor`.`id`
            ORDER BY time
            """
        ]
        with connection.cursor() as cursor:
            cursor.execute(''.join(query_sql), (filter_date, filter_department, hospital_id))
            # 中间数据
            # data = {
            #   'department_namexxx': {
            #       'department_id': 'xxxid', 'department_name': 'xxx', 'scheduler': {'9:00-10:00': ['医生1', '医生2']}
            #   },
            # },
            #     ...
            # }
            middle_data = dict()
            for row in cursor.fetchall():
                # 对人名字符串进行剪切
                department_scheduler = middle_data.get(row[3])
                if not department_scheduler:
                    # 对该医院的科室item进行初始化
                    doctors = [dict(zip(('doctor_id', 'doctor_name'), doctor_item.split('--')))
                               for doctor_item in row[2].split(',')]
                    middle_data[row[3]] = {
                        'department_name': row[1], 'department_id': row[3],
                        'scheduler': {row[0]: {'time': row[0], 'doctors': doctors}}
                    }
                else:
                    # 更新科室信息
                    doctors_scheduler = department_scheduler['scheduler'].get(row[0], {'time': row[0], 'doctors': None})
                    doctors_scheduler['doctors'] = [dict(zip(('doctor_id', 'doctor_name'), doctor_item.split('--')))
                                                    for doctor_item in row[2].split(',')]
                    department_scheduler['scheduler'][row[0]] = doctors_scheduler

        ## 最终返回的
        # [
        #     {
        #         'department_name': 'xxx科室',
        #         'department_id': 'xxxid',
        #         'scheduler': [
        #             {'time': 'xxx', 'doctors': [{'doctor_id': 'xxx', 'doctor_name': ''医生1'}]}
        #         ]
        #     },
        # ]

        # 查询医院的所有科室
        department_queryset = DepartmentModel.objects.filter(hospital_id=hospital_id)
        department_queryset = department_queryset.filter(id=filter_department) \
            if filter_department else department_queryset
        department_items = {
            department_item[0]: department_item[1]
            for department_item in department_queryset.values_list('id', 'name')
        }

        data = list()
        # 填充科室的默认数据
        for department_id, department_name in department_items.items():
            default_scheduler_item = {'department_name': department_name, 'department_id': department_id,
                                      'scheduler': {}}
            scheduler_item = middle_data.get(department_id, default_scheduler_item)
            scheduler_item['scheduler'] = [item for item in scheduler_item['scheduler'].values()]
            data.append(scheduler_item)

        return Response(data)


class DepartmentSchedulerDetail(GenericAPIView):
    permission_classes = (IsAdminUser,)
    serializer_class = DepartmentSchedulerUpdateSerializer

    @swagger_auto_schema(
        operation_description="""后台排班""",
        operation_summary='后台单个科室排班详情',  # 接口标题
        manual_parameters=[
            openapi.Parameter(
                name="filter_date", in_=openapi.IN_QUERY, description="搜索日期；e.g. 2021-12-12； 默认当前时间",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(name="filter_department", in_=openapi.IN_QUERY, description="搜索科室的id",
                              type=openapi.TYPE_STRING, required=True),
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING, required=True)
        ],
        tags=['后台排班'],  # 分组
    )
    def get(self, request, *args, **kwargs):
        # 获取过滤时间 默认为当前时间
        filter_date = request.query_params.get('filter_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT))
        filter_department = request.query_params.get('filter_department', '')
        if not all([filter_date, filter_department]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # 从日期中筛选，按照科室和时间进行聚合， 查询结果对人名字符串进行拼接
        query_sql = """
                SELECT
                    concat_ws('-', DATE_FORMAT( start_time, '%%H:%%i') , DATE_FORMAT( end_time, '%%H:%%i')) as time,
                    group_concat( concat_ws('--', t_doctor.id, t_doctor.name) order by t_doctor.name )
                FROM
                    t_scheduler, t_doctor
                WHERE
                    DATE_FORMAT( t_scheduler.date, '%%Y-%%m-%%d' )=%s
                    and t_scheduler.department_id=%s
                    and t_scheduler.status=1 and 
                    t_doctor.id=t_scheduler.doctor_id
                GROUP BY
                    `time`
                ORDER BY time
                """
        with connection.cursor() as cursor:
            # 查询当前科室当前时间的所有值班医生的信息
            cursor.execute(query_sql, (filter_date, filter_department))
            # [
            #   {'time': 'xxx', 'doctors': [{'doctor_id': xxx, 'doctor_name': xxx}, ...]},
            #   {'time': 'xxx1', 'doctors': [{'doctor_id': xxx, 'doctor_name': xxx}, ...]},
            # ]
            department_scheduler = list()
            for row in cursor.fetchall():
                doctors_scheduler_item = dict()
                doctors_scheduler_item['doctors'] = [dict(zip(('doctor_id', 'doctor_name'), doctor_item.split('--')))
                                                     for doctor_item in row[1].split(',')]
                doctors_scheduler_item['time'] = row[0]
                department_scheduler.append(doctors_scheduler_item)
        return Response(department_scheduler)

    @swagger_auto_schema(
        operation_description="""后台排班""",
        operation_summary='后台单个科室排班修改',  # 接口标题
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING, required=True)
        ],
        request_body=DepartmentSchedulerUpdateSerializer,
        responses={'200': DepartmentSchedulerUpdateSerializer},
        tags=['后台排班'],  # 分组
    )
    def put(self, request, *args, **kwargs):
        # 清空所有科室记录
        # 创建科室
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class DoctorScheduler(GenericAPIView):
    permission_classes = (IsAdminUser,)
    serializer_class = DoctorSchedulerUpdateSerializer
    pagination_class = None

    @swagger_auto_schema(
        operation_description="""后台排班""",
        operation_summary='后台单个医生排班修改',  # 接口标题
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING, required=True)
        ],
        request_body=DoctorSchedulerUpdateSerializer,
        responses={'200': DoctorSchedulerUpdateSerializer},
        tags=['后台排班'],  # 分组
    )
    def put(self, request, *args, **kwargs):
        # 接受参数 {
        # 'doctor_id': 'uuid', 'date': '2022-01-01', 'department_id': 'uuid',
        # 'time': ['start_time-end_time', 'start_time-end_time']
        # }

        # 清空该医生在当前时间当前科室的记录
        # 创建排班记录
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    @swagger_auto_schema(
        operation_description="""后台排班""",
        operation_summary='后台医生排班查询',  # 接口标题
        tags=['后台排班'],  # 分组
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING, required=True),
            openapi.Parameter(
                name="filter_date", in_=openapi.IN_QUERY,description="搜索日期；e.g. 2021-12-12； 默认当前时间",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                name="filter_department", in_=openapi.IN_QUERY, description="搜索科室的id", type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        responses={200: DoctorSchedulerSerializer}
    )
    def get(self, request, *args, **kwargs):
        # 接受参数 'filter_date': '2022-01-01', 'filter_department': 'uuid'
        filter_date = request.query_params.get('filter_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT))
        filter_department = request.query_params.get('filter_department')
        if not filter_department:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        query_sql = """
                        SELECT
                            group_concat(concat_ws('-', DATE_FORMAT( start_time, '%%H:%%i') , DATE_FORMAT( end_time, '%%H:%%i'))
                             order by `start_time` separator ' ') as time,
                             `t_doctor`.`name` as doctor_name,
                             `t_doctor`.`id` as doctor_id,
                             `t_doctor`.`photo_url` as doctor_photo_url
                        FROM
                            t_doctor left join t_scheduler on t_scheduler.doctor_id=t_doctor.id 
                        WHERE
                            DATE_FORMAT( t_scheduler.date, '%%Y-%%m-%%d' ) = %s and t_scheduler.department_id=%s 
                            and t_scheduler.status=1 and t_doctor.status=1 and t_doctor.doctor_type=1
                        GROUP BY
                            `t_scheduler`.`date`, `t_doctor`.`id` 
                        """
        with connection.cursor() as cursor:
            cursor.execute(query_sql, (filter_date, filter_department))
            middle_data = {row[2]: {'time': row[0].split(' '), 'doctor_name': row[1], 'doctor_id': row[2],
                     'doctor_photo_url': row[3]} for row in cursor.fetchall()}
            data = list()
            # 查询所有的通过审核的医生
            for doctor in DoctorModel.objects.filter(status=1, doctor_type=1, department_id=filter_department)\
                    .order_by('name').all():
                doctor_item = middle_data.get(doctor.id, {'doctor_id': doctor.id, 'doctor_name': doctor.name,
                                                          'doctor_photo_url': doctor.photo_url, 'time': []})
                data.append(doctor_item)
        # 返回所有的医生
        # 返回参数 [
        # {'doctor_id': 'uuid', 'doctor_name': '医生名称',
        # 'doctor_photo_url': '医生头像',
        # 'time': ['start_time-end_time', 'start_time-end_time']}
        # ]
        return Response(data)


class HospitalListView(ModelViewSet):
    serializer_class = HospitalListSerializer
    pagination_class = None

    def get_queryset(self):
        search_name = self.request.query_params.get('search_name')
        if search_name:
            return HospitalModel.objects.all().filter(name__contains=search_name)
        else:
            return HospitalModel.objects.all()

    @method_decorator(swagger_auto_schema(
        operation_description="""医院列表""",
        operation_summary='医院列表',  # 接口标题
        manual_parameters=[
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="患者id",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=False
            ),
            openapi.Parameter(
                # 参数名称
                name="search_name",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="搜索名称",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=False
            ),
        ],
        tags=['医院'],  # 分组中
    ),
        name='get'
    )
    def list(self, request, *args, **kwargs):
        patient_id = self.request.query_params.get('patient_id')
        if not patient_id:
            return super(HospitalListView, self).list(request, *args, **kwargs)
        hospital_id = PatientModel.objects.filter(id=patient_id).first()
        if not hospital_id:
            return super(HospitalListView, self).list(request, *args, **kwargs)
        ls = []
        for queryset in list(self.get_queryset()):
            data = dict()
            if hospital_id.hospital_id == queryset.id:
                data['hospital_id'] = queryset.id
                data['name'] = queryset.name
                data['address'] = queryset.address
                data['is_current_hospital'] = 1
            else:
                data['hospital_id'] = queryset.id
                data['name'] = queryset.name
                data['address'] = queryset.address
                data['is_current_hospital'] = 0
            ls.append(data)
        return Response(data=ls, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""切换医院""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'hospital_id': openapi.Schema(type=openapi.TYPE_STRING, description='医院id'),
                'patient_id': openapi.Schema(type=openapi.TYPE_STRING, description='病人id'),
            }
        ),
        # 接口标题
        operation_summary='默认,切换医院',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医院']
    )
    def update(self, request, *args, **kwargs):
        patient_id = request.data.get('patient_id')
        hospital_id = request.data.get('hospital_id')
        data = {}
        if hospital_id:
            PatientModel.objects.filter(id=patient_id).update(hospital_id=hospital_id)
            data['hospital_id'] = hospital_id
            data['name'] = HospitalModel.objects.filter(id=hospital_id).first().name
            data['address'] = HospitalModel.objects.filter(id=hospital_id).first().address
            return Response(data=data, status=status.HTTP_200_OK)
        else:
            default_hospital_id = HospitalModel.objects.filter(spare_int1=1).first().id
            PatientModel.objects.filter(id=patient_id).update(hospital_id=default_hospital_id)
            data['hospital_id'] = default_hospital_id
            data['name'] = HospitalModel.objects.filter(id=default_hospital_id).first().name
            data['address'] = HospitalModel.objects.filter(id=default_hospital_id).first().address
            return Response(data=data, status=status.HTTP_200_OK)


# 后台
class HospitalView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return HospitalSerializer

    def get_queryset(self):
        return HospitalModel.objects.all()

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医院列表""",
        # 接口参数 GET请求参数
        manual_parameters=[openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="用户认证",
                                             type=openapi.TYPE_STRING, required=True),
                           ],
        # 接口标题
        operation_summary='医院列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医院']
    )
    def list(self, request, *args, **kwargs):
        response = super(HospitalView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医院注册""",
        manual_parameters=[openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                                             type=openapi.TYPE_STRING)
                           ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name', 'address', 'lng', 'lat'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='医院的名字'),
                'address': openapi.Schema(type=openapi.TYPE_STRING, description='医院的地址'),
                'tel': openapi.Schema(type=openapi.TYPE_STRING, description='医院的电话'),
                'lng': openapi.Schema(type=openapi.TYPE_STRING, description='医院的经度'),
                'lat': openapi.Schema(type=openapi.TYPE_STRING, description='医院的纬度'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),

            }
        ),
        # 接口标题
        operation_summary='医院注册',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医院']
    )
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医院详细信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='医院详细信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医院']
    )
    def retrieve(self, request, *args, **kwargs):
        return super(HospitalView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""修改医院信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='医院的名字'),
                'address': openapi.Schema(type=openapi.TYPE_STRING, description='医院的地址'),
                'tel': openapi.Schema(type=openapi.TYPE_STRING, description='医院的电话'),
                'lng': openapi.Schema(type=openapi.TYPE_STRING, description='医院的经度'),
                'lat': openapi.Schema(type=openapi.TYPE_STRING, description='医院的纬度'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
                'spare_int1': openapi.Schema(type=openapi.TYPE_NUMBER, description='0:不是默认医院, 1:默认医院')
            }
        ),
        # 接口标题
        operation_summary='修改医院信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医院']
    )
    def update(self, request, *args, **kwargs):
        return super(HospitalView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""删除医院""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='删除医院',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医院']
    )
    def destroy(self, request, *args, **kwargs):
        try:
            resp = super(HospitalView, self).destroy(request, *args, **kwargs)
        except ProtectedError:
            return Response({'detail': '该医院已有科室信息或有医生/患者已绑定该医院,不允许被删除'}, status=status.HTTP_400_BAD_REQUEST)
        return resp
