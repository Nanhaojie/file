# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021-12-08 16:42
# @author yueyuanbo

from django.urls import path

from apps.hospital.views import HealthConsultationListCreateView, HealthConsultationRetrieveView, RotationPictureView, \
    DepartmentListView, DepartmentRetrieveView, HospitalSchedulerListView, HospitalListView, CommonQuestionListView, \
    HealthConsultationToppingView, HospitalView, DepartmentModelView, RotationPictureToppingView, \
    HospitalSchedulerBKView, DepartmentSchedulerDetail, BKEDPictureUpload, DoctorScheduler

urlpatterns = [
    path('common_question', CommonQuestionListView.as_view()),  # 常见列表
    path('health_consultations', HealthConsultationListCreateView.as_view()),  # 健康咨询列表 及创建
    path('health_consultation/<str:pk>', HealthConsultationRetrieveView.as_view()),  # 健康咨询详情
    path('health_consultation_topping/<str:pk>', HealthConsultationToppingView.as_view()),  # 健康咨询置顶操作
    path('rotation_picture', RotationPictureView.as_view({'get': 'list', 'post': 'create'})),  # 轮播图
    path('rotation_picture/<str:pk>', RotationPictureView.as_view({'get': 'retrieve', 'put': 'partial_update', 'delete': 'destroy'})),  # 轮播图
    path('rotation_picture_topping/<str:pk>', RotationPictureToppingView.as_view()),  # 轮播图置顶操作
    path('departments', DepartmentListView.as_view()),  # 科室列表
    path('departments/<str:pk>', DepartmentRetrieveView.as_view()),  # 科室详情
    path('scheduler', HospitalSchedulerListView.as_view()),  # 出诊安排
    path('hospital_list', HospitalListView.as_view({'get': 'list', 'put': 'update'})),  # 医院列表

    # 后台
    path('hospital_info_bkd', HospitalView.as_view({'get': 'list', 'post': 'create'})),  # 医院列表, 创建医院
    path('hospital_info_bkd/<pk>', HospitalView.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'})),  # 医院详情 修改医院 删除医院
    path('bked/departments', DepartmentModelView.as_view({'get': 'list', 'post': 'create'})),  # 科室列表 创建科室
    path('bked/departments/<str:pk>', DepartmentModelView.as_view({'get': 'retrieve', 'put': 'partial_update', 'delete': 'destroy'})),  # 科室详情 修改科室 删除科室
    path('bked/scheduler', HospitalSchedulerBKView.as_view()),  # 后台的排班列表
    path('bked/scheduler_detail', DepartmentSchedulerDetail.as_view()),  # 后台的排班列表
    path('bked/scheduler_doctor', DoctorScheduler.as_view()),  # 编辑单个医生的排班
    path('bked/img_upload', BKEDPictureUpload.as_view()),  # 后台的排班列表

]
