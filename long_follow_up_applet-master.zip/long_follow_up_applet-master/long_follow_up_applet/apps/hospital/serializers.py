# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021-12-08 16:42
# @author yueyuanbo
from django.db import transaction
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer

from doctor.models import SchedulerModel
from hospital.models import HealthConsultation, RotationPictureModel, DepartmentModel, HospitalModel
from long_follow_up_applet import settings


class CommonQuestionBaseSerializer(ModelSerializer):
    class Meta:
        model = HealthConsultation
        fields = ('id', 'title', 'content')
        extra_kwargs = {
            'release_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }

class CommonQuestionSerializer(serializers.Serializer):
    count = serializers.IntegerField(label='查询总数')
    next = serializers.CharField(label='下一页的链接')
    previous = serializers.CharField(label='上一页的链接')
    key_words = serializers.ListField(min_length=0, child=serializers.CharField(label='分词结果'))
    results = CommonQuestionBaseSerializer()


class HealthConsultationSerializer(ModelSerializer):
    class Meta:
        model = HealthConsultation
        fields = ('id', 'cover_picture_url', 'title', 'release_time', 'content')
        extra_kwargs = {
            'release_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class HealthConsultationRetrieveSerializer(ModelSerializer):
    class Meta:
        model = HealthConsultation
        exclude = ('spare_str1', 'spare_str2', 'spare_str3', 'spare_int1', 'spare_int2', 'spare_int3')
        extra_kwargs = {
            'release_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'update_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class RotationPictureSerializer(ModelSerializer):
    class Meta:
        model = RotationPictureModel
        fields = ('picture_url', 'content', 'name', 'hospital', 'id')


class RotationPictureListSerializer(ModelSerializer):
    class Meta:
        model = RotationPictureModel
        fields = ('picture_url', 'name', 'hospital', 'id')


class DepartmentListSerializer(ModelSerializer):
    class Meta:
        model = DepartmentModel
        fields = ('id', 'name')


class DepartmentSerializer(ModelSerializer):
    class Meta:
        model = DepartmentModel
        fields = ('name', 'introduction', 'hospital')

    def create(self, validated_data):
        validated_data['hospital_name'] = validated_data.get('hospital').name
        return super(DepartmentSerializer, self).create(validated_data)


class DepartmentRetrieveSerializer(ModelSerializer):
    class Meta:
        model = DepartmentModel
        fields = ('name', 'introduction', 'hospital_name', 'create_time', 'update_time')


class DepartmentSchedulerSerializer(ModelSerializer):
    class Meta:
        model = SchedulerModel
        fields = ('doctor', 'department', 'date', 'start_time', 'end_time')

class DepartmentSchedulerUpdateSerializer(serializers.Serializer):
    data = DepartmentSchedulerSerializer(many=True)

    def create(self, validated_data):


        obj_list = list()

        for scheduler in validated_data['data']:
            department_obj = scheduler.get('department')
            date = scheduler.get('date')
            obj_list.append(SchedulerModel(**scheduler))

        with transaction.atomic():
            # 删除该科室所有排班
            SchedulerModel.objects.filter(department=department_obj, date=date).delete()
            objs = SchedulerModel.objects.bulk_create(obj_list)
        return {'data': objs}


class HospitalSchedulerSerializer(serializers.Serializer):
    doctor_name = serializers.CharField(label='医生名字')
    doctor_id = serializers.CharField(label='医生id')
    date = serializers.CharField(label='日期')
    time = serializers.CharField(label='排班时间')
    doctor_photo_url = serializers.CharField(label='医生头像')
    doctor_rank = serializers.CharField(label='医生职级')
    department_name = serializers.CharField(label='科室名称')


class DoctorSchedulerSerializer(serializers.Serializer):
    doctor_name = serializers.CharField(label='医生名字')
    doctor_id = serializers.CharField(label='医生id')
    time = serializers.ListField(child=serializers.CharField(label='排班时间'))
    doctor_photo_url = serializers.CharField(label='医生头像')


class DoctorSchedulerUpdateSerializer(serializers.Serializer):
    doctor_id = serializers.CharField(label='医生id')
    department_id = serializers.CharField(label='科室id')
    date = serializers.DateField(label='日期')
    time = serializers.ListField(child=serializers.CharField(label='排班时间'), write_only=True)

    def create(self, validated_data):
        time_list = validated_data.get('time')
        doctor_id = validated_data.get('doctor_id')
        department_id = validated_data.get('department_id')
        date = validated_data.get('date')

        obj_list = list()
        for item_time in time_list:
            if '-' not in item_time:
                raise serializers.ValidationError('time参数格式错误')
            start_time = item_time.split('-')[0]
            end_time = item_time.split('-')[1]
            if end_time == '24:00':
                end_time = '23:59'
            obj_list.append(SchedulerModel(doctor_id=doctor_id, department_id=department_id, date=date,
                                           start_time=start_time, end_time=end_time))
        with transaction.atomic():
            # 删除所有排班
            SchedulerModel.objects.filter(department_id=department_id, date=date, doctor_id=doctor_id).delete()
            if obj_list:
                SchedulerModel.objects.bulk_create(obj_list)
        return validated_data


class HospitalListSerializer(ModelSerializer):
    class Meta:
        model = HospitalModel
        fields = ('id', 'name', 'address')

# 后台


class HospitalSerializer(ModelSerializer):
    name = serializers.CharField(required=False)
    address = serializers.CharField(required=False)
    spare_int1 = serializers.CharField(required=False)

    class Meta:
        model = HospitalModel
        fields = ('id', 'name', 'address', 'tel', 'lng', 'lat', 'notes', 'spare_int1')
