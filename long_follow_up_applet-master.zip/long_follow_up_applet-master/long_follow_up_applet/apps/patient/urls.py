#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/9下午4:08
#@Author:zwz
from django.urls import path

from patient.views import PatientView, AttackView, AttackDetails, PatientMedicineView, MyBindDoctorView, \
    SpecificationView, TreatmentRecordView, LeaveMessageView, LeaveMessageRetrieveView, LeaveMessageSearchView, \
    LeaveMessagePatientView, LeaveMessageDoctorView, DetailView, MedicationRecordView, WeightRecordView, \
    CurrentBindDoctorView, AttackKeyTemplateView, PatientListView, SubsequentVisit, PatientMedicationRecord, \
    NoBindDoctorListView, PatientMedicationRecordMonthView, AttackTemplateView, MedicineTemView, \
    PatientMedicationRecordCommonView, AttackDateTimes, AttackInfoView, TreatmentDeleteView

urlpatterns = [
    # 患者列表、添加
    path('info', PatientView.as_view({'get': 'list', 'post': 'create'})),
    # 就诊人详情/切换就诊人
    path('info/<pk>', PatientListView.as_view({'get': 'retrieve', 'put': 'update'})),
    # 发作关键模板
    path('attack_key_tem', AttackKeyTemplateView.as_view()),
    path('attack_tem', AttackTemplateView.as_view({'get': 'list', 'post': 'create'})),
    path('attack_tem/<pk>', AttackTemplateView.as_view({'put': 'update', 'delete': 'destroy'})),
    # 发作记录
    path('attack', AttackView.as_view({'get': 'list', 'post': 'create'})),
    path('attack_details', AttackDetails.as_view()),
    path('attack_date_times', AttackDateTimes.as_view()),
    path('attack_info', AttackInfoView.as_view()),
    # 绑定医生
    path('bind_doctor', MyBindDoctorView.as_view({'get': 'list', 'post': 'create', 'put': 'update'})),
    # 当前绑定的医生
    path('bind_doctor/<str:pk>', CurrentBindDoctorView.as_view()),
    # 未绑定的医生列表
    path('no_bind_doctor', NoBindDoctorListView.as_view()),
    # 药物
    path('medicine', PatientMedicineView.as_view({'get': 'list', 'post': 'create'})),
    path('medicine/<pk>', PatientMedicineView.as_view({'put': 'update', 'delete': 'destroy'})),
    path('specification', SpecificationView.as_view({'get': 'list', 'post': 'create'})),

    # 药品-后台
    path('bkd/medicine_tem', MedicineTemView.as_view({'get': 'list', 'post': 'create'})),
    path('bkd/medicine_tem/<pk>', MedicineTemView.as_view({'put': 'update', 'delete': 'destroy'})),

    # 用药记录 列表 更改用药状态
    path('medication_record', MedicationRecordView.as_view()),
    # 患者用药记录
    path('medication_records', PatientMedicationRecord.as_view()),
    path('medication_records_month', PatientMedicationRecordMonthView.as_view()),
    path('medication_records_common', PatientMedicationRecordCommonView.as_view()),

    # path('medicine', PatientMedicineView.as_view({'get': 'list'})),
    # 诊疗记录
    path('treatmentrecord', TreatmentRecordView.as_view({'get': 'list', 'post': 'create'})),
    # 删除诊疗记录
    path('treatmentrecord_delete', TreatmentDeleteView.as_view()),
    # 添加复诊时间
    path('subsequent_time', SubsequentVisit.as_view({'get': 'list', 'post': 'create'})),

    # 患者详情
    path('detail/<str:pk>', DetailView.as_view()),
    # 患者体重记录
    path('weight_record', WeightRecordView.as_view()),

    # 留言相关
    # 当前绑定医生详情
    # 发起留言 回复留言
    path('leave_message', LeaveMessageView.as_view()),
    # 留言及回复列表患者端(留言内容及回复内容, 头像, 姓名, 回复状态, 查询3个月内)
    path('leave_message_p', LeaveMessagePatientView.as_view()),
    # 留言及回复列表医生端(留言内容及回复内容, 头像, 姓名, 回复状态, 查询3个月内)
    path('leave_message_d', LeaveMessageDoctorView.as_view()),
    # 留言及回复详情(留言内容及回复内容, 验证访问用户是谁？如果是医生，更改留言状态，id为留言或者回复的id)
    path('leave_message/<str:pk>', LeaveMessageRetrieveView.as_view()),
    # 留言搜索（优先匹配患者名称，其次匹配患者留言内容关键字，并限制输入20字以内， 搜索内容分词后搜索用户id或内容；搜索结果返回，分词结果列表）
    path('leave_message_search', LeaveMessageSearchView.as_view()),
]