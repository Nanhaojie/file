# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 12/9/21 1:52 PM
# @author yueyuanbo

import django_filters

from doctor.models import DoctorModel


class DoctorListFilter(django_filters.FilterSet):
    """未绑定医生列表的过滤类"""
    department_id = django_filters.CharFilter(field_name="department_id", lookup_expr="exact", help_text='科室id')

    class Meta:
        model = DoctorModel  # 关联的表
        fields = ["department_id"]  # 过滤的字段