#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/12/9下午4:10
# @Author:zwz
import datetime
import logging
import urllib.request

from long_follow_up_applet import settings
from django.db import transaction
from django.db import models
from django.utils.timezone import now
# from filetype import filetype
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer

from doctor.models import DoctorModel
from patient.models import PatientModel, BindDoctorModel, AttackLogModel, LeaveMessageModel, MedicationRemindModel, \
    MedicineModel, MedicationSpecificationModel, TreatmentRecord, MedicationRecordMiddleModel, WeightRecordModel, \
    MedicationRecordModel, AttackKeyTemplateModel
from patient.models import PatientModel, BindDoctorModel, AttackLogModel, MedicineModel, MedicationRemindModel, \
    LeaveMessageModel, LeaveMessageResource
from patient.models import PatientModel

logger = logging.getLogger("django")


class PatientMedicationCommonRecordSerializer(serializers.Serializer):
    medication_date = serializers.CharField(label='用药时间')
    medicated_type = serializers.IntegerField(label='用药类型 (0, 未用药), (1, 部分用药), (2, 全部用药)')


class PatientMedicationRecordMonthSerializer(serializers.ModelSerializer):
    is_all_medicated = serializers.SerializerMethodField(label='是否正常使用全部的药')

    class Meta:
        model = MedicationRecordModel
        fields = ('medication_time', 'is_all_medicated')
        extra_kwargs = {
            'medication_time': {"format": settings.SERIALIZER_DATE_FIELD_FORMAT}
        }

    def get_is_all_medicated(self, instance):
        # 没有用药
        if not instance.is_medicated:
            return 0
        # 没有用全部的药
        if MedicationRecordMiddleModel.objects.filter(medicine_record_id=instance.id, medication_status=0).exists():
            return 0
        return 1


class WeightRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = WeightRecordModel
        fields = ('weight', 'date', 'patient')

    def create(self, validated_data):
        # 查询当前日期是否存在，如果不存在就添加，否则更新
        patient = validated_data.get('patient')
        date = now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT)
        weight_record_obj = WeightRecordModel.objects.filter(patient_id=patient.id, date=date).first()
        if weight_record_obj:
            weight_record_obj.weight = validated_data.get('weight')
            weight_record_obj.save()
        else:
            weight_record_obj = super(WeightRecordSerializer, self).create(validated_data)
        return weight_record_obj


class PatientDetailSerializer(serializers.ModelSerializer):
    hospital_name = serializers.CharField(source='hospital.name', default='未知医院', label='医院名称')
    mobile = serializers.CharField(source='account.mobile', label='联系方式')
    avatar = serializers.CharField(source='avatar_url', label='病人头像')

    class Meta:
        model = PatientModel
        fields = ('id', 'name', 'disease_type', 'gender', 'id_card_number', 'age', 'address', 'hospital_name', 'hospital_name',
                  'illness_status', 'mobile', 'weight', 'avatar')


class FilterLeaveMessageListSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        """
        List of object instances -> List of dicts of primitive datatypes.
        """
        # Dealing with nested relationships, data can be a Manager,
        # so, first get a queryset from the Manager if needed
        # from_date = datetime.date.strftime(now() - datetime.timedelta(days=settings.LEAVE_MESSAGE_SAVE_TIME),
        #                                    settings.SERIALIZER_DATE_FIELD_FORMAT)
        iterable = data.all().order_by('send_time') if isinstance(data, models.Manager) else data
        # doctor_name = data.instance.doctor.name
        # doctor_avatar = data.instance.doctor.photo_url
        # patient_name = data.instance.patient.name
        # patient_avatar = data.instance.patient.account.avatar_url
        # ret_data = list()
        # for item in iterable:
        #     item_data = self.child.to_representation(item)
        #     item_data.update({'doctor_name': doctor_name, 'doctor_avatar': doctor_avatar, 'patient_name': patient_name,
        #                  'patient_avatar': patient_avatar})
        #     ret_data.append(item_data)
        # return ret_data
        return [
            self.child.to_representation(item) for item in iterable
        ]


class LeaveMessageResourceSerializer(serializers.ModelSerializer):
    leave_message_id = serializers.CharField(required=False, label='留言id')
    msg_type = serializers.CharField(max_length=36, required=True, label='留言资源类型')

    class Meta:
        model = LeaveMessageResource
        fields = ('id', 'msg_type', 'url', 'leave_message_id')


class LeaveMessageSerializer(serializers.ModelSerializer):
    send_time = serializers.DateTimeField(format=settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, read_only=True,
                                          label='消息时间')
    doctor_id = serializers.CharField(max_length=36, label='医生id')
    patient_id = serializers.CharField(max_length=36, label='病人id')
    parent_id = serializers.CharField(max_length=36, required=False, label='父级留言id')
    doctor_name = serializers.CharField(max_length=36, read_only=True, source='doctor.name', label='医生名字')
    doctor_avatar = serializers.CharField(max_length=512, read_only=True, source='doctor.photo_url', label='医生头像')
    patient_name = serializers.CharField(max_length=36, read_only=True, source='patient.name', label='病人名字')
    disease_type = serializers.CharField(max_length=64, read_only=True, source='patient.disease_type', label='患者患病类型')
    patient_avatar = serializers.CharField(max_length=512, read_only=True, source='patient.avatar_url', label='病人头像')
    leave_msg_resource = LeaveMessageResourceSerializer(many=True, required=False, label='资源列表')

    def validate(self, attrs):
        # 校验留言内容和留言资源至少一个存在
        if not attrs.get('content') and not attrs.get('leave_msg_resource'):
            raise serializers.ValidationError('留言内容和资源至少一个不为空')
        return attrs

    def create(self, validated_data):
        validated_data['account_type'] = self.context['request'].user.type or 1
        with transaction.atomic():
            # 如果回复了 将父级留言修改为已回复状态
            if validated_data.get('parent_id') is not None:
                LeaveMessageModel.objects.filter(id=validated_data.get('parent_id')).update(read_or_revert_status=3)
            if 'leave_msg_resource' in validated_data:
                # pop leave_msg_resource字段
                leave_msg_resource = validated_data.pop('leave_msg_resource')
            else:
                leave_msg_resource = list()
            instance = super(LeaveMessageSerializer, self).create(validated_data)
            # 创建LeaveMessageResource模型类
            for leave_msg_resource_item in leave_msg_resource:
                leave_msg_resource_item['leave_message_id'] = str(instance.id)

                leave_msg_resource_serializer = LeaveMessageResourceSerializer(data=leave_msg_resource_item)
                if leave_msg_resource_serializer.is_valid(raise_exception=True):
                    leave_msg_resource_serializer.save()
            # todo 发送微信服务通知 告诉对应医生
        return instance

    class Meta:
        model = LeaveMessageModel
        fields = ('id', 'doctor_id', 'patient_id', 'account_type', 'content', 'send_time', 'read_or_revert_status',
                  'parent_id', 'leave_msg_resource', 'doctor_name', 'doctor_avatar', 'patient_name', 'disease_type', 'patient_avatar')
        extra_kwargs = {
            'account_type': {"required": False}
        }
        list_serializer_class = FilterLeaveMessageListSerializer


class LeaveMessageSearchSwaggerSerializer(serializers.Serializer):
    count = serializers.IntegerField(label='查询总数')
    next = serializers.CharField(label='下一页的链接')
    previous = serializers.CharField(label='上一页的链接')
    key_words = serializers.ListField(min_length=0, child=serializers.CharField(label='分词结果'))
    results = LeaveMessageSerializer()


class LeaveMessageListSerializer(serializers.ModelSerializer):
    send_time = serializers.DateTimeField(format=settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, label='消息时间')
    doctor_id = serializers.CharField(max_length=36, label='医生id')
    doctor_name = serializers.CharField(max_length=36, source='doctor.name', label='医生名字')
    doctor_avatar = serializers.CharField(max_length=512, source='doctor.photo_url', label='医生头像')
    patient_id = serializers.CharField(max_length=36, label='病人id')
    patient_name = serializers.CharField(max_length=36, source='patient.name', label='病人名字')
    disease_type = serializers.CharField(max_length=64, read_only=True, source='patient.disease_type', label='患者患病类型')
    patient_avatar = serializers.CharField(max_length=512, source='patient.avatar_url', label='病人头像')
    child_set = LeaveMessageSerializer(many=True, label='回复列表')
    leave_msg_resource = LeaveMessageResourceSerializer(many=True, label='资源列表')

    class Meta:
        model = LeaveMessageModel
        fields = ('id', 'send_time', 'doctor_id', 'doctor_name', 'doctor_avatar', 'patient_id', 'patient_name', 'disease_type',
                  'patient_avatar', 'child_set', 'leave_msg_resource', 'account_type', 'content',
                  'read_or_revert_status')


class PatientSerializer(serializers.ModelSerializer):
    account = serializers.CharField(source='account_id', required=False)
    mobile = serializers.CharField(source='account.mobile', required=False)
    # avatar_url = serializers.CharField(source='account.avatar_url', required=False)
    hospital = serializers.CharField(source='hospital_id', required=False)
    hospital_name = serializers.CharField(source='hospital.name', required=False)
    hospital_lng = serializers.CharField(source='hospital.lng', required=False)
    hospital_lat = serializers.CharField(source='hospital.lat', required=False)
    doctor_id = serializers.CharField(max_length=36, required=False)

    class Meta:
        model = PatientModel
        fields = (
        'id', 'is_default', 'name', 'disease_type', 'age', 'gender', 'address', 'avatar_url', 'id_card_number', 'account', 'doctor_id', 'hospital',
        'hospital_name', 'hospital_lng', 'weight', 'illness_status', 'mobile', 'hospital_lat')
        extra_kwargs = {
            'name': {"required": False},
            'id_card_number': {"required": False},
            'is_default': {"required": False},
            'illness_status': {"required": False},
        }

    def validate_name(self, value):
        if len(value) > 25:
            raise serializers.ValidationError(detail='姓名不得超过25个汉字')
        return value


class MyDoctorSerializer(ModelSerializer):
    doctor_id = serializers.CharField(max_length=36, label='医生id', error_messages={'max_length': '仅支持扫描医生二维码'})
    patient_id = serializers.CharField(max_length=36, label='患者id')

    class Meta:
        model = BindDoctorModel
        fields = ('id', 'doctor_id', 'patient_id', 'bind_status')


class PatientMedicationRecordMiddleSerializer(ModelSerializer):
    class Meta:
        model = MedicationRecordMiddleModel
        fields = ('medicine', 'medicine_name', 'specifications', 'medication_status')


class PatientMedicationRecordSerializer(ModelSerializer):
    medication_record = PatientMedicationRecordMiddleSerializer(many=True)

    class Meta:
        model = MedicationRecordModel
        fields = ('medication_time', 'medication_record')
        extra_kwargs = {
            'medication_time': {"format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class CurrentBindDoctorSerializer(ModelSerializer):
    department_name = serializers.CharField(source='department.name', label='科室名称')
    rank = serializers.SerializerMethodField(label=f'职级')

    def get_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.rank == value:
                return text
        else:
            return '未知职级'

    class Meta:
        model = DoctorModel
        fields = ('id', 'name', 'age', 'gender', 'photo_url', 'introduction', 'rank', 'department_id',
                  'department_name')


class MyDoctorListUpdateSerializer(ModelSerializer):
    name = serializers.CharField(source='doctor.name', required=False)
    age = serializers.CharField(source='doctor.age', required=False)
    photo_url = serializers.CharField(source='doctor.photo_url', required=False)
    introduction = serializers.CharField(source='doctor.introduction', required=False)
    rank = serializers.SerializerMethodField(label=f'职级')

    def get_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.doctor.rank == value:
                return text
        else:
            return '未知职级'

    class Meta:
        model = BindDoctorModel
        fields = ('id', 'doctor_id', 'patient_id', 'bind_status', 'name', 'age', 'photo_url', 'rank',
                  'introduction')


class AttackSerializer(ModelSerializer):
    patient = serializers.CharField(source='patient_id')

    class Meta:
        model = AttackLogModel
        fields = ('id', 'patient', 'attack_time', 'duration', 'reason', 'form', 'medicine', 'same_day_attack_times')
        extra_kwargs = {
            'attack_time': {"format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT2}
        }

    def to_representation(self, instance):
        data = super(AttackSerializer, self).to_representation(instance)
        if data['reason']:
            data['reason'] = eval(data['reason'])
        if data['form']:
            data['form'] = eval(data['form'])
        if data['medicine']:
            data['medicine'] = eval(data['medicine'])
        return data


class AttackInfoSerializer(ModelSerializer):
    # patient_id = serializers.CharField(max_length=36)

    class Meta:
        model = AttackLogModel
        fields = ('id', 'attack_time', 'duration', 'reason', 'form', 'medicine')
        extra_kwargs = {
            'attack_time': {'format': '%m月%d日 %H:%M'}
        }

    def to_representation(self, instance):
        data = super(AttackInfoSerializer, self).to_representation(instance)
        if data['reason']:
            data['reason'] = eval(data['reason'])
        if data['form']:
            data['form'] = eval(data['form'])
        if data['medicine']:
            data['medicine'] = eval(data['medicine'])
        return data

class MedicineRemindSerializer(serializers.ModelSerializer):
    class Meta:
        model = MedicationRemindModel
        fields = ('id', 'remind_time', 'medicine')
        # extra_kwargs = {
        #     'remind_time': {'format': settings.SERIALIZER_TIME_FIELD_FORMAT}
        # }


class PatientMedicineSerializer(serializers.ModelSerializer):
    patient = serializers.CharField(source='patient_id')
    medication_remind = MedicineRemindSerializer(label='药物提醒', read_only=True, many=True)

    class Meta:
        model = MedicineModel
        fields = (
            'id', 'patient', 'name', 'medicine_url', 'specifications', 'input_time', 'is_remind', 'medication_remind', 'notes')
        extra_kwargs = {
            'input_time': {"format": settings.SERIALIZER_DATE_FIELD_FORMAT}
        }

    def to_representation(self, instance):
        data = super(PatientMedicineSerializer, self).to_representation(instance)
        data['medicine_url'] = eval(data['medicine_url']) if data['medicine_url'] else []
        data['specifications'] = eval(data['specifications']) if data['specifications'] else []
        return data


class MedicineTemSerializer(serializers.ModelSerializer):
    hospital_id = serializers.CharField(allow_null=True, allow_blank=True, required=False)

    class Meta:
        model = MedicineModel
        fields = ('id', 'name', 'is_template', 'hospital_id', 'notes')
        extra_kwargs = {
            'is_template': {'required': False}
        }


class SpecificationSerializer(serializers.ModelSerializer):
    patient = serializers.CharField(source='patient_id')

    class Meta:
        model = MedicationSpecificationModel
        fields = ('id', 'patient', 'name')


class TreatmentRecordSerializer(serializers.ModelSerializer):
    doctor_id = serializers.CharField(max_length=36, label='医生id')
    patient_id = serializers.CharField(max_length=36, label='患者id')
    department_name = serializers.CharField(max_length=128, required=False)
    doctor_name = serializers.CharField(max_length=128, required=False)
    doctor_rank = serializers.SerializerMethodField(label=f'职级')
    patient_name = serializers.CharField(source='patient.name', required=False)
    photo_url = serializers.CharField(source='doctor.photo_url', required=False)

    def get_doctor_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.doctor_rank == value:
                return text
        else:
            return '未知职级'

    class Meta:
        model = TreatmentRecord
        fields = ('id', 'treatment_time', 'doctor_id', 'patient_id', 'patient_name', 'department_name', 'doctor_name',
                  'doctor_rank', 'subsequent_visit_date', 'photo_url')
        extra_kwargs = {
            'treatment_time': {'format': settings.SERIALIZER_DATE_FIELD_FORMAT},
            'subsequent_visit_date': {'format': settings.SERIALIZER_DATE_FIELD_FORMAT}
        }


class TreatmentRecordCreatSerializer(serializers.ModelSerializer):
    doctor_id = serializers.CharField(max_length=36, label='医生id', error_messages={'max_length': '仅支持扫描医生二维码'})
    patient_id = serializers.CharField(max_length=36, label='患者id')

    class Meta:
        model = TreatmentRecord
        fields = ('id', 'treatment_time', 'doctor_id', 'patient_id', 'subsequent_visit_date')
        extra_kwargs = {
            'treatment_time': {'format': settings.SERIALIZER_DATE_FIELD_FORMAT},
            'subsequent_visit_date': {'format': settings.SERIALIZER_DATE_FIELD_FORMAT}
        }


class SubsequentVisitSerializer(serializers.ModelSerializer):
    subsequent_visit_date = serializers.CharField(required=False)
    id = serializers.CharField()

    class Meta:
        model = PatientModel
        fields = ('id', 'subsequent_visit_date')
        extra_kwargs = {
            'subsequent_visit_date': {'format': settings.SERIALIZER_TIME_FIELD_FORMAT}
        }


class MedicationRecordMiddleSerializer(serializers.ModelSerializer):
    class Meta:
        model = MedicationRecordMiddleModel
        fields = ('id', 'medicine_name', 'specifications', 'medication_status', 'notes')

    def to_representation(self, instance):
        data = super(MedicationRecordMiddleSerializer, self).to_representation(instance)
        data['specifications'] = eval(data['specifications']) if data['specifications'] else []
        return data


class AttackTemplateSerializer(serializers.ModelSerializer):

    class Meta:
        model = AttackKeyTemplateModel
        fields = ('id', 'type', 'content')
        # extra_kwargs = {
        #     'type': {'non_field_errors': {'unique': '唯一'}},
        #     'name': {'non_field_errors': {'unique': '唯一'}},
        # }