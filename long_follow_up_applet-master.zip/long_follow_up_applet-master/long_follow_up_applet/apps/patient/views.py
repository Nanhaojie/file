import copy
import datetime
import re
from collections import OrderedDict

import requests
from django.db.models import Q, Count
from django.db.models.functions import TruncMonth, ExtractYear, ExtractMonth
from django.http import Http404
from django.utils.decorators import method_decorator
from django.utils.timezone import now
import logging
import traceback

from django.db import transaction, connection
from django.shortcuts import render

# Create your views here.
from django_redis import get_redis_connection
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveAPIView, CreateAPIView, get_object_or_404, GenericAPIView

from doctor.models import DoctorModel
from doctor.serializers import NoDoctorSerializer
from hospital.models import DepartmentModel, HospitalModel
from long_follow_up_applet import settings
from patient.filters import DoctorListFilter
from patient.models import PatientModel, BindDoctorModel, AttackLogModel, MedicineModel, LeaveMessageModel, \
    TreatmentRecord, MedicationRemindTimeModel, MedicationRecordMiddleModel, MedicationRecordModel, WeightRecordModel, \
    AttackKeyTemplateModel, MedicationSpecificationModel
from rest_framework.generics import ListAPIView, RetrieveAPIView
from patient.models import PatientModel, BindDoctorModel, AttackLogModel, MedicineModel, MedicationRemindModel
from rest_framework.response import Response
from rest_framework import status
from rest_framework.viewsets import ModelViewSet
from patient import serializers
from patient.serializers import LeaveMessageSerializer, LeaveMessageListSerializer, LeaveMessageSearchSwaggerSerializer, \
    PatientDetailSerializer, WeightRecordSerializer, CurrentBindDoctorSerializer, PatientMedicationRecordSerializer, \
    PatientMedicationRecordMonthSerializer, PatientMedicationCommonRecordSerializer
from user.models import AccountModel
from utils.common import add_medication_remind_timing, remove_medication_remind_timing, add_subsequent_visit
import time
from dateutil.relativedelta import relativedelta
from celery_tasks.patient.tasks import send_wx_msg
from utils.pagination import StandardResultPagination

logger = logging.getLogger('django')
redis_conn = get_redis_connection('login_user')


@method_decorator(swagger_auto_schema(
    operation_description="""患者用药记录每日详情""",
    operation_summary='患者用药记录每日详情',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        # 声明参数
        openapi.Parameter(
            # 参数名称
            name="Authorization",
            # 参数类型为query
            in_=openapi.IN_HEADER,
            # 参数描述
            description="用户认证",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            # 参数名称
            name="patient_id",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="患者id",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
        openapi.Parameter(
            # 参数名称
            name="query_date",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="筛选日期 格式为 2021-12-15",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: PatientMedicationRecordSerializer}
),
    name='get'
)
class PatientMedicationRecord(ListAPIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = None
    serializer_class = PatientMedicationRecordSerializer

    def get_queryset(self):
        # 获取查询日期字段（指定要查询的天） 默认查询当前天
        query_date = self.request.query_params.get('query_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT))
        patient_id = self.request.query_params.get('patient_id')
        # 按照日期，及患者筛选 按照时间排序
        return MedicationRecordModel.objects.filter(
            medication_time__year=query_date.split('-')[0],
            medication_time__month=query_date.split('-')[1],
            medication_time__day=query_date.split('-')[2],
            patient_id=patient_id
        )

    def get(self, request, *args, **kwargs):
        patient_id = self.request.query_params.get('patient_id')
        if not patient_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        return super(PatientMedicationRecord, self).list(request, *args, **kwargs)


@method_decorator(swagger_auto_schema(
    operation_description="""患者用药记录列表 按照月统计""",
    operation_summary='患者用药记录列表 按照月统计',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                          type=openapi.TYPE_STRING),
        openapi.Parameter(name="patient", in_=openapi.IN_QUERY, description="患者id", type=openapi.TYPE_STRING),
        openapi.Parameter(name="year", in_=openapi.IN_QUERY, description="年", type=openapi.TYPE_STRING),
        openapi.Parameter(name="month", in_=openapi.IN_QUERY, description="月", type=openapi.TYPE_STRING),
    ],
    # tags=['留言'],   # 分组中
    responses={200: PatientMedicationRecordMonthSerializer}
),
    name='get'
)
class PatientMedicationRecordMonthView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = None
    serializer_class = PatientMedicationRecordMonthSerializer

    def get(self, request, *args, **kwargs):
        patient = self.request.query_params.get('patient')
        year = self.request.query_params.get('year')
        month = self.request.query_params.get('month')
        if not all([year, month, patient]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # 聚合查询出当前月所有用药记录的日期
        query_sql = '''
                    SELECT
                        DATE_FORMAT( medication_time, '%%Y-%%m-%%d' ) as medication_date
                    FROM
                        t_medication_record
                    WHERE
                        patient_id=%s and DATE_FORMAT( medication_time, '%%Y-%%m' )=%s
                    GROUP BY
                        medication_date
                    '''
        with connection.cursor() as cursor:
            cursor.execute(query_sql, (patient, f'{year}-{month.zfill(2)}'))
            # 渲染数据，默认为已用药
            data = {row[0]: 1 for row in cursor.fetchall()}

        # 聚合查询出当前月所有存在未用药记录的日期
        query_sql = '''
                    SELECT
                        DATE_FORMAT( medication_time, '%%Y-%%m-%%d' ) as medication_date
                    FROM
                        t_medication_record, t_medication_record_middle
                    WHERE
                        patient_id=%s and DATE_FORMAT( medication_time, '%%Y-%%m' )=%s and 
                        t_medication_record.id=t_medication_record_middle.medicine_record_id and 
                        t_medication_record_middle.medication_status=0
                    GROUP BY
                        medication_date
                    '''
        with connection.cursor() as cursor:
            cursor.execute(query_sql, (patient, f'{year}-{month.zfill(2)}'))
            # 更新未用药的数据
            for row in cursor.fetchall():
                data[row[0]] = 0

        # 返回数据
        res_data = [{'medication_time': medication_time, 'is_all_medicated': is_all_medicated }
                    for medication_time, is_all_medicated in data.items()]
        return Response(res_data)



@method_decorator(swagger_auto_schema(
    operation_description="""患者用药记录列表""",
    operation_summary='患者用药记录列表v1.1',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                          type=openapi.TYPE_STRING, required=True),
        openapi.Parameter(name="patient", in_=openapi.IN_QUERY, description="患者id", type=openapi.TYPE_STRING,
                          required=True),
        openapi.Parameter(name="year", in_=openapi.IN_QUERY, description="年,eg:2022", type=openapi.TYPE_STRING),
        openapi.Parameter(name="month", in_=openapi.IN_QUERY, description="月,eg:09", type=openapi.TYPE_STRING),
        openapi.Parameter(name="medicated_type", in_=openapi.IN_QUERY,
                          description="(0, 未用药), (1, 部分用药), (2, 全部用药)", type=openapi.TYPE_STRING),
    openapi.Parameter(name="page", in_=openapi.IN_QUERY, description="页数", type=openapi.TYPE_INTEGER),
    openapi.Parameter(name="page_size", in_=openapi.IN_QUERY, description="每页数量", type=openapi.TYPE_INTEGER),
    ],
    # tags=['留言'],   # 分组中
    responses={200: PatientMedicationCommonRecordSerializer}
),
    name='get'
)
class PatientMedicationRecordCommonView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        patient = self.request.query_params.get('patient')
        medicated_type = self.request.query_params.get('medicated_type')
        year = self.request.query_params.get('year')
        month = self.request.query_params.get('month')
        page = self.request.query_params.get('page', 0)
        page_size = self.request.query_params.get('page_size', StandardResultPagination.page_size)
        try:
            page, page_size = map(int, [page, page_size])
        except Exception:
            logger.warning('参数校验失败', exc_info=True)
            return Response({'detail': '翻页参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)

        # 聚合查询出当前月所有存在未用药记录的日期

        query_sql = '''
                    SELECT
                        DATE_FORMAT ( t_medication_record_middle.create_time, '%%Y-%%m-%%d' ) as medication_date,
                        ( case 
                        when COUNT(medication_status=1 or NULL) >= COUNT(medication_status) then 
                            2
                        when COUNT(medication_status=1 or NULL) = 0 then 
                            0
                        when COUNT(medication_status=1 or NULL) < COUNT(medication_status) then 
                            1
                        end ) as have_medication_status
                    FROM
                        t_medication_record inner join t_medication_record_middle on 
                        t_medication_record.id=t_medication_record_middle.medicine_record_id
                    WHERE
                        patient_id=%s
                    '''
        query_sql += '''and DATE_FORMAT( medication_time, '%%Y-%%m' )=%s''' if all([year, month]) else ''
        query_sql += '''
                    GROUP BY
                        medication_date
                    '''
        query_sql += '''
                    HAVING
                        have_medication_status=%s''' if medicated_type is not None else ''
        query_sql += '''
                    ORDER BY
                        medication_date DESC
                    LIMIT %s, %s
                    '''
        with connection.cursor() as cursor:
            params = [patient]
            params.append(f'{year}-{month.zfill(2)}') if all([year, month]) else None
            params.append(medicated_type) if medicated_type is not None else None
            params.extend([page * page_size, page_size])
            cursor.execute(query_sql, params)
            data = [{'medication_date': row[0], 'medicated_type': row[1]} for row in cursor.fetchall()]
        return Response({'results': data})


class WeightRecordView(CreateAPIView):
    serializer_class = WeightRecordSerializer
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    @swagger_auto_schema(
        operation_description="""患者体重记录""",
        operation_summary='患者体重记录',  # 接口标题
        # tags=['留言'],   # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="患者id",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="filter_type",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="查询类型 (day, month, quarter) 默认为 day",
                # 参数字符类型
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                # 参数名称
                name="num",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="查询数量 默认为 7",
                # 参数字符类型
                type=openapi.TYPE_STRING,
            ),
        ],
        # tags=['留言'],   # 分组中
        responses={200: WeightRecordSerializer}
    )
    def get(self, request, *args, **kwargs):
        # 聚合类型 day month quarter 默认为day
        filter_type = request.query_params.get('filter_type', 'day')
        nums = request.query_params.get('num', 7)
        try:
            nums = int(nums)
        except Exception:
            logger.warning(f'参数错误{nums}', exc_info=True)
            return Response({'detail': '参数错误'}, status=status.HTTP_400_BAD_REQUEST)
        patient_id = request.query_params.get('patient_id')
        if not patient_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # 查询最近7天的数据； day
        if filter_type == 'day':
            from_date = datetime.datetime.now() - datetime.timedelta(days=nums)
            queryset = WeightRecordModel.objects.filter(patient_id=patient_id,
                                                        date__gt=from_date.strftime(
                                                            settings.SERIALIZER_DATE_FIELD_FORMAT)
                                                        ).order_by('date')
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        # 查询最近7个月的数据； month 每个月求平均值
        elif filter_type == 'month':
            from_date = datetime.datetime.now() - datetime.timedelta(days=nums * 30)
            query_sql = """
                        SELECT
                            DATE_FORMAT (date, '%%Y-%%m') as year_month_date,
                            AVG (weight)
                        FROM
                            t_weight_record
                        WHERE
                            patient_id=%s and date>=%s
                        GROUP BY
                            year_month_date
                        ORDER BY year_month_date
                        """
            with connection.cursor() as cursor:
                cursor.execute(query_sql, (patient_id, from_date.strftime(settings.SERIALIZER_DATE_FIELD_FORMAT)))
                data = [{'date': row[0], 'weight': row[1]} for row in cursor.fetchall()]
                return Response(data)
        elif filter_type == 'quarter':
            from_date = datetime.datetime.now() - datetime.timedelta(days=nums * 30 * 3)
            query_sql = '''
                        SELECT
                            CONCAT_WS(' ', YEAR (date), QUARTER (date) ) AS year_quarter,
                            AVG (weight)
                        FROM
                            t_weight_record
                        WHERE
                            patient_id=%s and date>=%s
                        GROUP BY
                            year_quarter
                        ORDER BY year_quarter
                        '''
            with connection.cursor() as cursor:
                cursor.execute(query_sql, (patient_id, from_date.strftime(settings.SERIALIZER_DATE_FIELD_FORMAT)))
                date_func = lambda x: f"{x[1]}季度 {x[0]}"
                data = [{'date': date_func(row[0].split(" ")), 'weight': row[1]} for row in cursor.fetchall()]
                return Response(data)
        else:
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(
        operation_description="""录入患者体重""",
        operation_summary='录入患者体重',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        request_body=WeightRecordSerializer,
        # tags=['留言'],   # 分组中
        responses={200: WeightRecordSerializer}
    )
    def post(self, request, *args, **kwargs):
        return super(WeightRecordView, self).post(request, *args, **kwargs)


@method_decorator(swagger_auto_schema(
    operation_description="""患者详情""",
    operation_summary='患者详情',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        # 声明参数
        openapi.Parameter(
            # 参数名称
            name="Authorization",
            # 参数类型为query
            in_=openapi.IN_HEADER,
            # 参数描述
            description="用户认证",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    # tags=['留言'],   # 分组中
    responses={200: PatientDetailSerializer}
),
    name='get'
)
class DetailView(RetrieveAPIView):
    queryset = PatientModel.objects.filter()
    serializer_class = PatientDetailSerializer
    permission_classes = (IsAuthenticated,)


class LeaveMessageSearchView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = LeaveMessageSerializer

    @swagger_auto_schema(
        operation_description="""医生留言搜索""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="filter_sentence",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="搜索内容",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                # required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="病人id，如果是患者端调用必填",
                # 参数字符类型
                type=openapi.TYPE_STRING,
            ),
        ],
        responses={200: LeaveMessageSearchSwaggerSerializer},
        # 接口标题
        operation_summary='留言搜索',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['留言']
    )
    def get(self, request, *args, **kwargs):
        # 校验必填参数
        # request.user = AccountModel.objects.get(id="842ba9f8-b244-4ddf-b271-117d07f1e8a0")
        filter_sentence = self.request.query_params.get('filter_sentence', '')
        user = request.user
        # 如果是患者校验是否传了患者id
        if user.type == 2:
            # 如果是患者
            patient_id = self.request.query_params.get('patient_id')
            if patient_id is None:
                return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)

        # 分词
        # seg_list = pseg.cut(filter_sentence)
        # logger.info(f'对{filter_sentence}分词')
        # self.filter_words = list()
        # for word, flag in seg_list:
        #     filter_flags = ['p', 'c', 'u', 'e', 'y', 'o', 'w', 'x']
        #     logger.info(f'分词结果{word, flag}')
        #     # if not re.search('|'.join(filter_flags), flag):
        #     if flag not in filter_flags:
        #         self.filter_words.append(word)
        # filter_words_regex = '|'.join(self.filter_words)

        # 分词结果为空直接返回空结果
        # if not filter_words_regex:
        if not filter_sentence:
            return Response(dict([
                ('count', 0),
                ('next', None),
                ('previous', None),
                ('key_words', []),
                ('results', [])
            ]))

        # 根据分词结果查询
        # queryset = LeaveMessageModel.objects.filter(Q(patient__name__contains=filter_words_regex) |
        #                                              Q(content__regex=filter_words_regex))
        queryset = LeaveMessageModel.objects.filter(Q(patient__name__contains=filter_sentence) |
                                                     Q(content__contains=filter_sentence))

        # 如果是医生
        if self.request.user.type == 1:
            # 当前正式医生id
            official_doctor_id = None
            if self.request.user.doctor:
                # 如果是实习医生
                if self.request.user.doctor.doctor_type == 0:
                    official_doctor = self.request.user.doctor.p  # type: DoctorModel
                    if official_doctor:
                        official_doctor_id = official_doctor.id
                # 如果是正式医生
                elif self.request.user.doctor.doctor_type == 1:
                    official_doctor_id = self.request.user.doctor.id
                else:
                    raise serializers.serializers.ValidationError("医生类型校验失败")
            else:
                raise serializers.serializers.ValidationError("医生类型校验失败")

            queryset = queryset.filter(Q(doctor_id=official_doctor_id) | Q(parent__doctor_id=official_doctor_id))\
                .order_by('-send_time')
        # 如果是患者
        elif self.request.user.type == 2:
            patient_id = self.request.query_params.get('patient_id')
            queryset = queryset.filter(patient_id=patient_id).order_by('-send_time')

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return Response(dict([
                ('count', self.paginator.page.paginator.count),
                ('next', self.paginator.get_next_link()),
                ('previous', self.paginator.get_previous_link()),
                ('key_words', [filter_sentence]),
                ('results', serializer.data)
            ]))
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class LeaveMessageRetrieveView(RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = LeaveMessageListSerializer
    queryset = LeaveMessageModel.objects.filter()

    def get_object(self):
        # 根据留言id或者回复id查询留言id
        queryset = self.filter_queryset(self.get_queryset())

        # Perform the lookup filtering.
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        filter_kwargs = {self.lookup_field: self.kwargs[lookup_url_kwarg]}

        obj = get_object_or_404(queryset, **filter_kwargs)
        obj = obj.parent or obj
        # May raise a permission denied
        self.check_object_permissions(self.request, obj)
        return obj

    @swagger_auto_schema(
        operation_description="""医生查询留言详情""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        # 接口标题
        operation_summary='留言详情',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['留言']
    )
    def get(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        response = Response(serializer.data)
        # 如果用户为医生，就更新留言消息状态
        if request.user.type == 1:
            if instance.read_or_revert_status == 1:
                instance.read_or_revert_status = 2
            instance.save()
        return response


class LeaveMessageView(CreateAPIView):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return LeaveMessageSerializer

    @swagger_auto_schema(
        operation_description="""患者发起留言， 医生回复留言""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['doctor_id', 'patient_id'],
            properties={
                'doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='医生id'),
                'patient_id': openapi.Schema(type=openapi.TYPE_STRING, description='病人id'),
                'content': openapi.Schema(type=openapi.TYPE_STRING, description='留言或回复内容'),
                'parent_id': openapi.Schema(type=openapi.TYPE_INTEGER, description='留言id'),
                'leave_msg_resource': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_OBJECT,
                                           description='留言资源列表；e.g.[{"url": "https://aisource", "msg_type": "jpg"}},'
                                                       ' {"url": "https://aisource2", "msg_type": "png"}}]'),
            }
        ),
        # 接口标题
        operation_summary='创建留言',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['留言']
    )
    def post(self, request, *args, **kwargs):
        """患者发起留言， 医生回复留言"""
        return super(LeaveMessageView, self).post(request, *args, **kwargs)


class LeaveMessageDoctorView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = LeaveMessageSerializer

    def get_queryset(self):
        from_date = datetime.date.strftime(now() - datetime.timedelta(days=settings.LEAVE_MESSAGE_SAVE_TIME),
                                           settings.SERIALIZER_DATE_FIELD_FORMAT)
        query_set = LeaveMessageModel.objects.filter(send_time__gte=from_date, parent__isnull=True)

        # 当前正式医生和其所有实习医生账号集合
        official_doctor_id = None
        if self.request.user.doctor:
            # 如果是实习医生
            if self.request.user.doctor.doctor_type == 0:
                official_doctor = self.request.user.doctor.p  # type: DoctorModel
                if official_doctor:
                    official_doctor_id = official_doctor.id
            # 如果是正式医生
            elif self.request.user.doctor.doctor_type == 1:
                official_doctor_id = self.request.user.doctor.id
            else:
                raise serializers.serializers.ValidationError("医生类型校验失败")
        else:
            raise serializers.serializers.ValidationError("只能医生端调用")
        return query_set.filter(doctor_id=official_doctor_id).order_by('-send_time')

    @swagger_auto_schema(
        operation_description="""医生端留言列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        # 接口标题
        operation_summary='医生端留言列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['留言']
    )
    def get(self, request, *args, **kwargs):
        """医生端留言列表"""
        # request.user = AccountModel.objects.get(id="b291b4df-602a-47e3-bae9-b61c1f69e3a5")
        if request.user.type != 1:
            return Response({'detail': '只能医生端调用'}, status=status.HTTP_400_BAD_REQUEST)
        return super(LeaveMessageDoctorView, self).get(request=request, *args, **kwargs)


class LeaveMessagePatientView(ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = LeaveMessageListSerializer

    def get_queryset(self):
        from_date = datetime.date.strftime(now() - datetime.timedelta(days=settings.LEAVE_MESSAGE_SAVE_TIME),
                                           settings.SERIALIZER_DATE_FIELD_FORMAT)
        query_set = LeaveMessageModel.objects.filter(send_time__gte=from_date, parent__isnull=True)
        patient_id = self.request.query_params.get('patient_id')
        return query_set.filter(patient_id=patient_id).order_by('-send_time')

    @swagger_auto_schema(
        operation_description="""患者端留言列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="患者id",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        # 接口标题
        operation_summary='患者端留言列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['留言']
    )
    def get(self, request, *args, **kwargs):
        """患者端留言列表"""
        # 如果是患者校验是否传了患者id
        patient_id = self.request.query_params.get('patient_id')
        if patient_id is None:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        # 遍历序列化结果中的 child_set 字段，将该字段中列表放到上级列表中
        serializer_data = serializer.data  # type: OrderedDict
        response_serializer_data = copy.deepcopy(serializer_data)
        offset_count = 0
        for index, serializer_data_item in enumerate(serializer_data):
            child_set = serializer_data_item.get('child_set', [])
            if child_set:
                response_serializer_data[index + offset_count].pop('child_set')
                response_serializer_data[index + 1 + offset_count: index + 1 + offset_count] = child_set
                offset_count += len(child_set)
        return self.get_paginated_response(response_serializer_data)


@method_decorator(swagger_auto_schema(
    operation_description="""绑定的医生""",
    operation_summary='绑定的医生',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        # 声明参数
        openapi.Parameter(
            # 参数名称
            name="Authorization",
            # 参数类型为query
            in_=openapi.IN_HEADER,
            # 参数描述
            description="用户认证",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: CurrentBindDoctorSerializer}
),
    name='get'
)
class CurrentBindDoctorView(RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = PatientModel.objects.filter()
    serializer_class = CurrentBindDoctorSerializer

    def get_object(self):
        try:
            instance = super(CurrentBindDoctorView, self).get_object()
            object = instance.doctor
        except Exception:
            logger.warning('查询绑定医生失败', exc_info=True)
            raise Http404('绑定医生不存在')
        return object


class MyBindDoctorView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        if self.action in ('list', 'update', 'retrieve'):
            return serializers.MyDoctorListUpdateSerializer
        elif self.action == 'create':
            return serializers.MyDoctorSerializer

    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id')
        return BindDoctorModel.objects.filter(patient=patient_id).order_by('-bind_status')

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""绑定医生列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="绑定医生列表",
                # 参数字符类型
                type=openapi.TYPE_STRING
            ),
        ],
        # 接口标题
        operation_summary='绑定医生列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['绑定医生']
    )
    def list(self, request, *args, **kwargs):
        response = super(MyBindDoctorView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""绑定医生""",
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            # required=['attack_time', 'duration', 'patient', 'reason', 'form', 'medicine'],
            properties={
                'patient_id': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='医生id'),
            }
        ),
        # 接口标题
        operation_summary='绑定医生',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['绑定医生']
    )
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        headers = self.get_success_headers(serializer.data)
        patient_id = serializer.data['patient_id']
        doctor_id = serializer.data['doctor_id']
        if not DoctorModel.objects.filter(id=doctor_id).exists():
            return Response({'detail': '该医生不存在'}, status=status.HTTP_400_BAD_REQUEST)
        if not all([patient_id, doctor_id]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                bind_status = BindDoctorModel.objects.filter(patient_id=patient_id, bind_status=1)
                if bind_status:
                    bind_status.update(bind_status=0)
                # 如果患者曾将绑定过该医生,则修改更新绑定状态
                history_bind = BindDoctorModel.objects.filter(patient_id=patient_id, doctor_id=doctor_id, bind_status=0)
                if history_bind:
                    history_bind.update(bind_status=1)
                else:
                    bind_doctor = BindDoctorModel(patient_id=patient_id, doctor_id=doctor_id, bind_status=1)
                    bind_doctor.save()
                patient_obj = PatientModel.objects.filter(id=patient_id)
                patient_obj.update(doctor_id=doctor_id)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '添加失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
            return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者解绑医生""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'patient_id': openapi.Schema(type=openapi.TYPE_STRING, description='患者_id'),

            }
        ),
        # 接口标题
        operation_summary='患者解绑医生',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['绑定医生']
    )
    def update(self, request, *args, **kwargs):
        patient_id = request.data['patient_id']
        if not patient_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                bind_status = BindDoctorModel.objects.filter(patient_id=patient_id, bind_status=1)
                if bind_status:
                    bind_status.update(bind_status=0)
                patient_obj = PatientModel.objects.filter(id=patient_id)
                patient_obj.update(doctor_id=None)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '您暂未绑定医生,请先绑定医生!'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
            return Response(data={'data': '解绑成功'}, status=status.HTTP_200_OK)


class PatientView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return serializers.PatientSerializer

    def get_queryset(self):
        user_id = self.request.user.id
        queryset = PatientModel.objects.filter(account_id=user_id)
        return queryset

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户患者列表""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='用户患者列表(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    def list(self, request, *args, **kwargs):
        return super(PatientView, self).list(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者注册/添加""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name', 'id_card_number'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='姓名'),
                'id_card_number': openapi.Schema(type=openapi.TYPE_INTEGER, description='身份证号'),
                'disease_type': openapi.Schema(type=openapi.TYPE_STRING, description='患者患病类型'),
                'is_default': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='是否默认，首次注册为True,添加患者为false')
            }
        ),
        # 接口标题
        operation_summary='患者注册、添加(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    def create(self, request, *args, **kwargs):
        user = request.user
        # with transaction.atomic():
        #     save_id = transaction.savepoint()
        #     try:
        # 医生审核通过不能再成为患者
        try:
            doctor = user.doctor
            if doctor and doctor.status == 1:
                return Response(data={'detail': '您已注册为医生,不能再注册为患者!'}, status=status.HTTP_400_BAD_REQUEST)
            elif doctor:
                user.doctor.delete()
                user.type = None
        except:
            pass
        data = request.data
        # is_default = data.get('is_default')
        data['account'] = user.id
        data['avatar_url'] = settings.PATIENT_DEFAULT_AVATAR_URL
        data['hospital'] = HospitalModel.objects.filter(spare_int1=1).first().id
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        name = data['name']
        if re.search('[^\u4e00-\u9fa5]', name):
            return Response(data={'detail': '姓名必须是汉字'}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        user.type = 2
        user.save()
            # except:
            #     logger.error(traceback.format_exc())
            #     transaction.savepoint_rollback(save_id)
            #     return Response(data={'detail': '注册失败'}, status=status.HTTP_400_BAD_REQUEST)
            # transaction.savepoint_commit(save_id)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class PatientListView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return serializers.PatientSerializer

    def get_queryset(self):
        user = self.request.user
        queryset = PatientModel.objects.filter(account_id=user.id)
        return queryset

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者详情""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='患者详情(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    def retrieve(self, request, *args, **kwargs):
        # 测试用数据
        return super(PatientListView, self).retrieve(request, *args, **kwargs)
        # user = request.user
        # user_id = user.id
        # # user_avatar_url = user.avatar_url
        # patient = PatientModel.objects.filter(account_id=user_id, is_default=True).first()
        # data = self.get_serializer(patient).data
        # # if data:
        # #     data['avatar_url'] = user_avatar_url
        # return Response(data=data, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""切换就诊人""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='姓名'),
                'disease_type': openapi.Schema(type=openapi.TYPE_STRING, description='患病类型'),
                'age': openapi.Schema(type=openapi.TYPE_STRING, description='年龄'),
                'gender': openapi.Schema(type=openapi.TYPE_STRING, description='性别'),
                'address': openapi.Schema(type=openapi.TYPE_STRING, description='区域/地址'),
                'avatar_url': openapi.Schema(type=openapi.TYPE_STRING, description='头像url'),
                'is_default': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='切换就诊人传true, 其余情况不传')
            }
        ),
        # 接口标题
        operation_summary='编辑/切换就诊人(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    def update(self, request, *args, **kwargs):
        user_id = request.user.id
        data = request.data
        if data.get('is_default'):
            PatientModel.objects.filter(account_id=user_id, is_default=True).update(is_default=False)
        name = data.get('name')
        if name and re.search('[^\u4e00-\u9fa5]', name):
            return Response(data={'detail': '姓名必须是汉字'}, status=status.HTTP_400_BAD_REQUEST)
        return super(PatientListView, self).update(request, *args, **kwargs)
        # user_id = request.user.id
        # instance = self.get_object()
        # PatientModel.objects.filter(account_id=user_id, is_default=True).update(is_default=False)
        # instance.is_default = True
        # instance.save()
        # return Response(status=status.HTTP_200_OK)


class AttackKeyTemplateView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作关键模板""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='发作关键模板(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def get(self, request, *args, **kwargs):
        attack_resson_list = AttackKeyTemplateModel.objects.filter(type=1).values_list('content', flat=True)
        attack_form_list = AttackKeyTemplateModel.objects.filter(type=2).values_list('content', flat=True)
        data = {
            'attack_reason_list': attack_resson_list,
            'attack_form_list': attack_form_list
        }
        return Response(data=data, status=status.HTTP_200_OK)


class AttackTemplateView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        return AttackKeyTemplateModel.objects.all()

    def get_serializer_class(self):
        return serializers.AttackTemplateSerializer

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作关键模板列表""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='发作关键模板列表(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def list(self, request, *args, **kwargs):
        return super(AttackTemplateView, self).list(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作关键模板添加""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['type', 'content'],
            properties={
                'type': openapi.Schema(type=openapi.TYPE_STRING, description='类型:1_诱发因素,2_发作形式'),
                'content': openapi.Schema(type=openapi.TYPE_STRING, description='内容')
            }
        ),
        # 接口标题
        operation_summary='发作关键模板添加(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def create(self, request, *args, **kwargs):
        return super(AttackTemplateView, self).create(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作关键模板编辑""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            properties={
                'type': openapi.Schema(type=openapi.TYPE_STRING, description='类型:1_诱发因素,2_发作形式'),
                'content': openapi.Schema(type=openapi.TYPE_STRING, description='内容')
            }
        ),
        # 接口标题
        operation_summary='发作关键模板编辑(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def update(self, request, *args, **kwargs):
        return super(AttackTemplateView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作关键模板删除""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='发作关键模板删除(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def destroy(self, request, *args, **kwargs):
        return super(AttackTemplateView, self).destroy(request, *args, **kwargs)


class AttackView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_queryset(self):
        query_params = self.request.query_params
        patient_id = query_params.get('patient')
        queryset = AttackLogModel.objects.filter(patient_id=patient_id)
        year = int(query_params.get('year'))
        month = int(query_params.get('month'))
        day = int(query_params.get('day'))
        search_day = datetime.date(year, month, day)
        end_day = datetime.datetime(year, month, day, 23, 59, 59)
        queryset = queryset.filter(attack_time__range=(search_day, end_day))
        return queryset

    def get_serializer_class(self):
        return serializers.AttackSerializer

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作记录列表、详情""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="patient", in_=openapi.IN_QUERY, description="患者id", type=openapi.TYPE_STRING),
            openapi.Parameter(name="year", in_=openapi.IN_QUERY, description="年", type=openapi.TYPE_STRING),
            openapi.Parameter(name="month", in_=openapi.IN_QUERY, description="月", type=openapi.TYPE_STRING),
            openapi.Parameter(name="day", in_=openapi.IN_QUERY, description="日", type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='发作记录列表、详情(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def list(self, request, *args, **kwargs):
        resp = super(AttackView, self).list(request, *args, **kwargs)
        return resp

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""发作记录录入""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['attack_time', 'duration', 'patient', 'reason', 'form', 'medicine'],
            properties={
                'attack_time': openapi.Schema(type=openapi.TYPE_STRING, description='诱发时间:2021-10-10 10:10:10'),
                'duration': openapi.Schema(type=openapi.TYPE_INTEGER, description='发作时长/分钟'),
                'patient': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'reason': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING, description='诱发因素'),
                'form': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING, description='发作形式'),
                'medicine': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING, description='药物'),
            }
        ),
        # 接口标题
        operation_summary='发作记录录入(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-发作']
    )
    def create(self, request, *args, **kwargs):
        user = request.user
        data = request.data
        patient_id = data['patient']
        data['reason'] = str(data['reason'])
        data['form'] = str(data['form'])
        data['medicine'] = str(data['medicine'])
        # 发作时间
        attack_datetime = datetime.datetime.strptime(data['attack_time'],
                                                     settings.SERIALIZER_DATE_TIME_FIELD_FORMAT3)
        attack_year = attack_datetime.year
        attack_month = attack_datetime.month
        attack_day = attack_datetime.day
        attack_date = datetime.date(attack_year, attack_month, attack_day)
        attack_count = AttackLogModel.objects.filter(patient_id=patient_id, attack_time__year=attack_year,
                                                     attack_time__month=attack_month,
                                                     attack_time__day=attack_day).count()
        data['same_day_attack_times'] = attack_count + 1
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)

        # 状态变更
        patient = user.patient_set.filter(is_default=True).first()
        today = datetime.date.today()
        days_ago_of_30 = today - datetime.timedelta(days=30)
        days_ago_of_90 = today - datetime.timedelta(days=90)
        # 此次录入是否30天之内
        if (attack_date-days_ago_of_30).days >= 0:
            is_in_30_days = True
        else:
            is_in_30_days = False
        # 此次录入是否90天之内
        if (attack_date-days_ago_of_90).days >= 0:
            is_in_90_days = True
        else:
            is_in_90_days = False
        # 是否在90天之内
        if is_in_90_days:
            # 是否在30天之内
            if is_in_30_days:
                if int(data['duration']) > settings.SERIOUS_DURATION_NODE:
                    illness_status = 3
                    # patient.illness_status = 3
                    notice_content = settings.LONG_TIME_NOTICE_CONTENT
                elif (attack_count + 1) > settings.SERIOUS_TIMES_NODE:
                    illness_status = 3
                    # patient.illness_status = 3
                    notice_content = settings.SERIOUS_NOTICE_CONTENT
                else:
                    illness_status = 2
                    notice_content = ''
                    # 30天之内次数大于1需要提醒
                    within_30_days_count = AttackLogModel.objects.filter(patient_id=patient_id, attack_time__gte=days_ago_of_30).count()
                    if within_30_days_count > settings.MONTH_TIMES_NODE:
                        notice_content = settings.MANY_TIMES_IN_30_DAYS_NOTICE_CONTENT
            # 30天外90天内
            else:
                illness_status = 2
                notice_content = ''
        # 90天外不影响现在状态
        else:
            illness_status = 1
            notice_content = ''
        if illness_status > patient.illness_status:
            patient.illness_status = illness_status
            patient.save()
            # 暂时不用微信服务通知
            # if notice_content:
            #     access_token = redis_conn.get('long_follow_up_access_token').decode()
            #     # 构造推送微信消息
            #     remind_msg_data = {
            #         "touser": user.open_id,
            #         "template_id": settings.SUBSEQUENT_VISIT_TEM_ID,
            #         "page": settings.MINE_PAGE_PATH,
            #         "miniprogram_state": settings.MINIPROGRAM_STATE,
            #         "lang": "zh_CN",
            #         "data": {
            #             # 温馨提醒
            #             "thing1": {"value": notice_content},
            #             # 就诊人
            #             "phrase2": {
            #                 "value": patient.name
            #             },
            #             # 备注
            #             "thing6": {"value": settings.NOTES}
            #         }
            #     }
            #     rsp = requests.post(settings.SUB_MSG_SEND_URL + access_token, json=remind_msg_data)
            #     try:
            #         logger.warning(rsp.json())
            #     except Exception:
            #         logger.warning('订阅消息返回rsp解析失败', exc_info=True)
        data = serializer.data
        # if illness_status == 3:
        if notice_content:
            data['detail'] = notice_content
            data['illness_status'] = 3
        return Response(data, status=status.HTTP_201_CREATED, headers=headers)

        # # 严重: 当天发作次数大于1 或者 单次发作大于10分钟
        # if data['duration'] > settings.SERIOUS_DURATION_NODE:
        #     # illness_status = 3
        #     patient.illness_status = 3
        #     notice_content = settings.LONG_TIME_NOTICE_CONTENT.format(patient.name)
        # else:
        #     # start_time = datetime.datetime(attack_datetime.year, attack_datetime.month, attack_datetime.day, 0,0,0)
        #     # end_time = datetime.datetime(attack_datetime.year, attack_datetime.month, attack_datetime.day, 23,59,59)
        #     # attack_count = AttackLogModel.objects.filter(attack_time__range=(start_time, end_time)).count()
        #     if attack_count > settings.SERIOUS_TIMES_NODE:
        #         patient.illness_status = 3
        #         notice_content = settings.LONG_TIME_NOTICE_CONTENT
        #     # 病情适中: 排除病情严重90天之内有记录
        #     else:
        #         patient.illness_status = 2
        #         now = datetime.datetime.now()
        #         start_datetime = now - datetime.timedelta(days=30)
        #         month_count = AttackLogModel.objects.filter(attack_time__range=(start_datetime, now)).count()
        #         if month_count > settings.MONTH_TIMES_NODE:
        #             notice_content = settings.SERIOUS_NOTICE_CONTENT.format(patient.name)
        #         else:
        #             notice_content = ''
        # patient.save()
        # # 提醒患者复诊    服务通知
        # if notice_content:
        #     access_token = redis_conn.get('long_follow_up_access_token').decode()
        #     # 构造推送微信消息
        #     remind_msg_data = {
        #         "touser": user.open_id,
        #         "template_id": settings.SUBSEQUENT_VISIT_TEM_ID,
        #         # "page": settings.MINE_PAGE_PATH,
        #         "miniprogram_state": settings.MINIPROGRAM_STATE,
        #         "lang": "zh_CN",
        #         "data": {
        #             # 温馨提醒
        #             "thing1": {"value": notice_content},
        #             # 就诊人
        #             "phrase2": {
        #                 "value": patient.name
        #             },
        #             # 备注
        #             "thing6": {"value": settings.NOTES}
        #         }
        #     }
        #     rsp = requests.post(settings.SUB_MSG_SEND_URL + access_token, json=remind_msg_data)
        #     try:
        #         logger.warning(rsp.json())
        #     except Exception:
        #         logger.warning('订阅消息返回rsp解析失败', exc_info=True)
        # return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class AttackDetails(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        operation_description='发作日志细节',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name='patient', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY, description='患者id'),
            openapi.Parameter(name='year', type=openapi.TYPE_INTEGER, in_=openapi.IN_QUERY, description='年'),
            openapi.Parameter(name='month', type=openapi.TYPE_INTEGER, in_=openapi.IN_QUERY, description='月'),
        ],
        # 接口标题
        operation_summary='发作日志细节(zwz)',
        tags=['患者-发作']
    )
    def get(self, request, *args, **kwargs):
        query_params = request.query_params
        patient_id = query_params.get('patient')
        year = int(query_params.get('year'))
        month = int(query_params.get('month'))
        # day = int(query_params.get('day'))
        attack_log = AttackLogModel.objects.filter(patient_id=patient_id).first()
        # 距上次发作时长
        if attack_log:
            now = datetime.datetime.now()
            delta = now - attack_log.attack_time
            interval_day = delta.days
            interval_hours = delta.seconds // 60 // 60
            interval_minute = (delta.seconds - interval_hours * 60 * 60) // 60
        else:
            interval_day = 0
            interval_hours = 0
            interval_minute = 0
        attack_logs = AttackLogModel.objects.filter(patient_id=patient_id, attack_time__year=year,
                                                    attack_time__month=month)
        # 发作次数
        attack_times = attack_logs.count()
        # 发作日期
        attack_days = set()
        for attack_log in attack_logs:
            attack_days.add(attack_log.attack_time.day)
        data = {
            'interval_day': interval_day,
            'interval_hours': interval_hours,
            'interval_minute': interval_minute,
            'attack_times': attack_times,
            'attack_days': list(attack_days)
        }
        return Response(data=data, status=status.HTTP_200_OK)


class AttackDateTimes(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        operation_description='发作日志月份和次数',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name='patient_id', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY, required=True,
                              description='患者id'),
        ],
        # 接口标题
        operation_summary='发作日志月份和次数(zwz)',
        tags=['患者-发作']
    )
    def get(self, request, *args, **kwargs):
        query_params = request.query_params
        patient_id = query_params.get('patient_id')
        if not patient_id:
            return Response({'detail': '患者id参数必填'}, status=status.HTTP_400_BAD_REQUEST)
        patient = PatientModel.objects.filter(id=patient_id).first()
        patient_id = patient.id
        start_time = patient.create_time
        end_time = datetime.datetime.now()
        # attack_logs = AttackLogModel.objects.filter(patient_id=patient_id).extra(select={"month": "DATE_FORMAT(attack_time, '%%Y-%%m')"}).values('month').annotate(num=Count('attack_time'))
        with connection.cursor() as cursor:
            sql = '''select date_format(attack_time, '%%Y-%%m') as month, count(*) as count from t_attack_log where patient_id=%s group by date_format(attack_time, '%%Y-%%m') order by month desc'''
            cursor.execute(sql, [patient_id])
            row = cursor.fetchall()
        month_list = []
        count_list = []
        data = []
        for item in row:
            data.append({
                'month': item[0],
                'count': item[1]
            })
        # for item in row:
        #     month_list.append(item[0])
        #     count_list.append(item[1])
        # i = 0
        # data = []
        # while True:
        #     curr_time = end_time - relativedelta(months=i) if i != 0 else end_time
        #     curr_month = curr_time.strftime('%Y-%m')
        #     data.append({
        #         'month': curr_month,
        #         'count': count_list[month_list.index(curr_month)] if curr_month in month_list else 0
        #     })
        #     if curr_time.year == start_time.year and curr_time.month == start_time.month:
        #         break
        #     i += 1
        return Response(data=data, status=status.HTTP_200_OK)


class AttackInfoView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        operation_description='发作日志指定月份记录',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name='patient_id', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY, required=True, description='患者id'),
            openapi.Parameter(name='date', type=openapi.TYPE_INTEGER, in_=openapi.IN_QUERY, required=True, description='年月 例:2020-01'),
        ],
        # 接口标题
        operation_summary='发作日志指定月份记录(zwz)',
        tags=['患者-发作']
    )
    def get(self, request, *args, **kwargs):
        patient_id = request.query_params.get('patient_id')
        date = request.query_params.get('date')
        if not all([patient_id, date]):
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        attack_logs = AttackLogModel.objects.filter(patient_id=patient_id,attack_time__year=date[:4], attack_time__month=int(date[5:]))
        data = serializers.AttackInfoSerializer(attack_logs, many=True).data
        return Response(data, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        operation_description='发作日志记录删除',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['id'],
            properties={
                'id': openapi.Schema(type=openapi.TYPE_STRING, description='单条发作记录id')
            }
        ),
        # 接口标题
        operation_summary='发作日志记录删除(zwz)',
        tags=['患者-发作']
    )
    def delete(self, request, *args, **kwargs):
        attack_log_id = request.data.get('id')
        if not attack_log_id:
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        AttackLogModel.objects.filter(id=attack_log_id).delete()

        # 病情降级逻辑
        today = datetime.date.today()
        days_ago_of_30 = today - datetime.timedelta(days=30)
        days_ago_of_30_str = days_ago_of_30.strftime('%Y-%m-%d')
        days_ago_of_90 = today - datetime.timedelta(days=90)
        patient = request.user.patient_set.filter(is_default=True, illness_status__in=[2, 3]).first()
        if patient:
            # count_30 = AttackLogModel.objects.filter(patient_id=patient.id, attack_time__gte=days_ago_of_30).filter(
            #     Q(same_day_attack_times__gt=settings.SERIOUS_TIMES_NODE) | Q(duration__gt=settings.SERIOUS_DURATION_NODE)).count()
            same_day_times_sql = '''
            select count(*) from (select count(*) as c
            from t_attack_log
            where patient_id = %s and attack_time >= %s
            group by date_format(attack_time, '%%Y-%%m-%%d')) as t1 where c>%s;
            '''
            duration_sql = '''
            select count(*)
            from t_attack_log
            where patient_id = %s and attack_time >= %s and duration > %s;
            '''
            with connection.cursor() as cursor:
                cursor.execute(same_day_times_sql, [patient.id, days_ago_of_30_str, settings.SERIOUS_TIMES_NODE])
                row_same_day = cursor.fetchone()[0]
                cursor.execute(duration_sql, [patient.id, days_ago_of_30_str, settings.SERIOUS_DURATION_NODE])
                row_duration = cursor.fetchone()[0]
            # 30天内无严重情况
            if not row_same_day and not row_duration:
                count_90 = AttackLogModel.objects.filter(patient_id=patient.id,
                                                      attack_time__gte=days_ago_of_90).count()
                # 90天内无记录
                if not count_90:
                    patient.illness_status = 1
                    patient.save()
                    # 复诊时间
                    subsequent_visit_date = datetime.datetime.now() + datetime.timedelta(days=1)
                    subsequent_visit_date_str = datetime.datetime.strftime(subsequent_visit_date, '%Y年%m月%d日')
                    # 复诊提醒
                    remind_msg_data = {
                        "touser": patient.account.open_id,
                        "template_id": settings.SUBSEQUENT_VISIT_TEM_ID,
                        "page": settings.MINE_PAGE_PATH,
                        "miniprogram_state": settings.MINIPROGRAM_STATE,
                        "lang": "zh_CN",
                        "data": {
                            # 温馨提醒
                            "thing1": {"value": settings.MODERATE_NOTICE_CONTENT},
                            # 就诊人
                            "phrase2": {
                                "value": patient.name[:5]
                            },
                            # 复诊时间
                            "date5": {
                                "value": subsequent_visit_date_str
                            },
                            # 备注
                            "thing6": {"value": settings.NOTES}
                        }
                    }
                    send_wx_msg.apply_async(kwargs=remind_msg_data)
                else:
                    patient.illness_status = 2
                    patient.save()
        return Response(status=status.HTTP_204_NO_CONTENT)


class PatientMedicineView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_queryset(self):
        query_params = self.request.query_params
        is_template = query_params.get('is_template')
        patient_id = query_params.get('patient')
        name = query_params.get('name')
        if is_template == '1':
            hospital_id = PatientModel.objects.filter(id=patient_id).first().hospital_id
            queryset = MedicineModel.objects.filter(is_template=True, hospital_id=hospital_id)
        elif patient_id:
            queryset = MedicineModel.objects.filter(patient_id=patient_id)
        else:
            queryset = MedicineModel.objects.filter()
        if name:
            queryset = queryset.filter(name__contains = name)
        return queryset

    def get_serializer_class(self):
        return serializers.PatientMedicineSerializer

    @swagger_auto_schema(
        operation_description='药品列表',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name='is_template', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY, required=True,
                              description='是否模板:1_是;0_否'),
            openapi.Parameter(name='patient', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY, required=True,
                              description='患者id'),
            openapi.Parameter(name='name', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY,
                              description='药品名称(搜索)')
        ],
        # 接口标题
        operation_summary='药品列表(zwz)',
        tags=['患者-药品']
    )
    def list(self, request, *args, **kwargs):
        response = super(PatientMedicineView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        operation_description="""药品录入""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['patient', 'name'],
            properties={
                'patient': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='药品名称'),
                'medicine_url': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                               description='药品url列表'),
                'specifications': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                                 description='规格list'),
                'remind_time_list': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                                   description='提醒时间'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
            }
        ),
        # 接口标题
        operation_summary='药品录入(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品']
    )
    def create(self, request, *args, **kwargs):
        open_id = request.user.open_id
        data = request.data
        data['medicine_url'] = str(data['medicine_url']) if data.get('medicine_url') else None
        data['specifications'] = str(data['specifications']) if data.get('specifications') else None
        patient_id = data.get('patient')
        remind_time_list = data.get('remind_time_list', [])
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                summary_remind_time_list = list(MedicationRemindModel.objects.filter(patient_id=patient_id).values_list(
                    'remind_time', flat=True))
                self.perform_create(serializer)
                remind_time_list_2 = []
                for remind_time in remind_time_list:
                    remind_time = remind_time[:5]
                    remind_time_list_2.append(remind_time)
                    MedicationRemindModel(medicine_id=serializer.data['id'], patient_id=patient_id,
                                          remind_time=remind_time).save()
                remind_time_list = remind_time_list_2
                # 需要新加的定时任务
                add_remind_time_list = list(set(remind_time_list) - set(summary_remind_time_list))
                # 添加定时任务
                if add_remind_time_list:
                    patient_name = PatientModel.objects.filter(id=patient_id).first().name
                    add_medication_remind_timing(add_remind_time_list, patient_id, patient_name, open_id)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '添加失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    @swagger_auto_schema(
        operation_description="""药品编辑""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['patient', 'name'],
            properties={
                'patient': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='药品名称'),
                'medicine_url': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                               description='药品url列表'),
                'specifications': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING, description='规格list'),
                'remind_time_list': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                                   description='提醒时间'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
            }
        ),
        # 接口标题
        operation_summary='药品编辑(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品']
    )
    def update(self, request, *args, **kwargs):
        open_id = request.user.open_id
        data = request.data
        data['medicine_url'] = str(data['medicine_url']) if data.get('medicine_url') else None
        data['specifications'] = str(data['specifications']) if data.get('specifications') else None
        patient_id = data.get('patient')
        remind_time_list = data.get('remind_time_list', [])
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=data, partial=partial)
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                summary_remind_time_list = list(MedicationRemindModel.objects.filter(patient_id=patient_id).values_list(
                    'remind_time', flat=True))
                logger.warning('summary_remind_time_list'+ str(summary_remind_time_list))
                # 保存编辑的药品
                self.perform_update(serializer)
                # 删除药品提醒
                MedicationRemindModel.objects.filter(medicine_id=instance.id).delete()
                remind_time_list_2 = []
                for remind_time in remind_time_list:
                    remind_time = remind_time[:5]
                    remind_time_list_2.append(remind_time)
                    MedicationRemindModel(medicine_id=serializer.data['id'], patient_id=patient_id, remind_time=remind_time).save()
                remind_time_list = remind_time_list_2
                # 需要添加定时
                add_remind_time_list = list(set(remind_time_list) - set(summary_remind_time_list))
                logger.warning('add_remind_time_list_'+str(add_remind_time_list))
                # 添加定时任务
                if add_remind_time_list:
                    patient_name = PatientModel.objects.filter(id=patient_id).first().name
                    add_medication_remind_timing(add_remind_time_list, patient_id, patient_name, open_id)
                # 需要删除的汇总时刻
                patient_remind_time_list = list(MedicationRemindModel.objects.filter(patient_id=patient_id).values_list(
                    'remind_time', flat=True))
                remove_remind_time_list = list(set(summary_remind_time_list) - set(patient_remind_time_list))  # 需要删除的
                logger.warning('remove_remind_time_list_'+str(remove_remind_time_list))
                # 删除定时任务
                if remove_remind_time_list:
                    remove_medication_remind_timing(remove_remind_time_list, patient_id)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '编辑失败'}, status=status.HTTP_400_BAD_REQUEST)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        return Response(serializer.data)

    @swagger_auto_schema(
        operation_description="""药品删除""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='药品删除(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品']
    )
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        patient_id = instance.patient_id
        # 删除之前所有提醒时刻
        summary_remind_time_list = list(MedicationRemindModel.objects.filter(patient_id=patient_id).values_list(
            'remind_time', flat=True))
        self.perform_destroy(instance)
        # 删除之后所有提醒时刻
        summary_remind_time_list_after = list(MedicationRemindModel.objects.filter(patient_id=patient_id).values_list(
            'remind_time', flat=True))
        remove_remind_time_list = list(set(summary_remind_time_list) - set(summary_remind_time_list_after))
        # 删除定时任务
        if remove_remind_time_list:
            remove_medication_remind_timing(remove_remind_time_list, patient_id)
        return Response(status=status.HTTP_204_NO_CONTENT)


class MedicineTemView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        user = self.request.user
        query_params = self.request.query_params
        name = query_params.get('name')
        queryset = MedicineModel.objects.filter(is_template=True, hospital_id=user.hospital_id)
        if name:
            queryset = queryset.filter(name__contains = name)
        return queryset

    def get_serializer_class(self):
        return serializers.MedicineTemSerializer

    @swagger_auto_schema(
        operation_description='药品列表',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name='name', type=openapi.TYPE_STRING, in_=openapi.IN_QUERY,
                              description='药品名称(搜索)')
        ],
        # 接口标题
        operation_summary='药品列表(zwz)',
        tags=['患者-药品(后台)']
    )
    def list(self, request, *args, **kwargs):
        response = super(MedicineTemView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        operation_description="""药品录入""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='药品名称')
            }
        ),
        # 接口标题
        operation_summary='药品录入(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品(后台)']
    )
    def create(self, request, *args, **kwargs):
        user = request.user
        request.data['is_template'] = True
        request.data['hospital_id'] = user.hospital_id
        return super(MedicineTemView, self).create(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""药品编辑""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='药品名称')
            }
        ),
        # 接口标题
        operation_summary='药品编辑(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品(后台)']
    )
    def update(self, request, *args, **kwargs):
        return super(MedicineTemView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""药品删除""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='药品删除(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品(后台)']
    )
    def destroy(self, request, *args, **kwargs):
        return super(MedicineTemView, self).destroy(request, *args, **kwargs)


class SpecificationView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_queryset(self):
        patient_id = self.request.query_params.get('patient')
        queryset = MedicationSpecificationModel.objects.filter(patient_id=patient_id)
        return queryset

    def get_serializer_class(self):
        return serializers.SpecificationSerializer

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者药品规格列表""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="patient", in_=openapi.IN_QUERY, description="患者id", type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='患者药品规格列表(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品规格']
    )
    def list(self, request, *args, **kwargs):
        response = super(SpecificationView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者药品规格添加""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='规格名称'),
                'patient': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
            }
        ),
        # 接口标题
        operation_summary='患者药品规格添加(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者-药品规格']
    )
    def create(self, request, *args, **kwargs):
        return super(SpecificationView, self).create(request, *args, **kwargs)


class TreatmentRecordView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        if self.action in ('list', 'update', 'retrieve'):
            return serializers.TreatmentRecordSerializer
        elif self.action == 'create':
            return serializers.TreatmentRecordCreatSerializer

    def get_queryset(self):
        # user = self.request.user  # type: AccountModel
        # if user.type == 1:
        patient_id = self.request.query_params['patient_id']
        if patient_id:
            return TreatmentRecord.objects.filter(patient=patient_id).order_by('-treatment_time')
        else:
            return TreatmentRecord.objects.all()

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""诊疗记录列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="诊疗记录列表",
                # 参数字符类型
                type=openapi.TYPE_STRING
            ),
        ],
        # 接口标题
        operation_summary='诊疗记录列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['诊疗记录']
    )
    def list(self, request, *args, **kwargs):
        response = super(TreatmentRecordView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""诊疗记录""",

        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            # required=['attack_time', 'duration', 'patient', 'reason', 'form', 'medicine'],
            properties={
                'patient_id': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='医生id'),
            }
        ),
        # 接口标题
        operation_summary='诊疗记录',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['诊疗记录']
    )
    def create(self, request, *args, **kwargs):
        user = request.user
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid(raise_exception=True):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        headers = self.get_success_headers(serializer.data)
        patient_id = serializer.data['patient_id']
        doctor_id = serializer.data['doctor_id']
        if not DoctorModel.objects.filter(id=doctor_id).exists():
            return Response({'detail': '该医生不存在'}, status=status.HTTP_400_BAD_REQUEST)
        if not all([patient_id, doctor_id]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                object_doctor = DoctorModel.objects.filter(id=doctor_id)
                department_name = DepartmentModel.objects.filter(id=object_doctor.first().department_id).first().name
                doctor_name = object_doctor.first().name
                doctor_rank = object_doctor.first().rank
                str2date = datetime.date.today()
                visit_time = str2date + relativedelta(months=+1)
                treatment = TreatmentRecord(patient_id=patient_id, doctor_id=doctor_id, department_name=department_name,
                                            doctor_name=doctor_name, doctor_rank=doctor_rank, subsequent_visit_date=
                                            visit_time.strftime('%Y-%m-%d'))

                treatment.save()

                # 默认设置复诊时间
                object_doctor = PatientModel.objects.filter(id=patient_id)
                object_doctor.update(subsequent_visit_date=visit_time.strftime("%Y-%m-%d %H:%M"))
                # 定时提醒
                remind_datetime = datetime.datetime(visit_time.year, visit_time.month, visit_time.day,0,0,0) - datetime.timedelta(hours=settings.SUBSEQUENT_VISIT_AHEAD_OF_TIME)
                patient_name = PatientModel.objects.get(id=patient_id).name
                add_subsequent_visit(user.open_id, remind_datetime, patient_id, patient_name)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '添加失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)


class TreatmentDeleteView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        operation_description='诊疗记录删除',
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['id'],
            properties={
                'id': openapi.Schema(type=openapi.TYPE_STRING, description='诊疗记录id')
            }
        ),
        # 接口标题
        operation_summary='诊疗记录',
        tags=['诊疗记录']
    )

    def delete(self, request, *args, **kwargs):
        treatment_id = request.data.get('id')
        if not treatment_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                obj = TreatmentRecord.objects.filter(id=treatment_id).delete()
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '删除失败'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'data': '删除成功'}, status=status.HTTP_200_OK)


class SubsequentVisit(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return serializers.SubsequentVisitSerializer

    def get_queryset(self):
        patient_id = self.request.query_params['patient_id']
        if patient_id:
            return PatientModel.objects.filter(id=patient_id)
        else:
            return PatientModel.objects.all()

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""查询复诊时间""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="患者id",
                # 参数字符类型
                type=openapi.TYPE_STRING
            ),
        ],
        # 接口标题
        operation_summary='查询复诊时间',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['诊疗记录']
    )
    def list(self, request, *args, **kwargs):
        response = super(SubsequentVisit, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""自定义复诊时间""",

        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['id', 'subsequent_visit_date'],
            properties={
                'id': openapi.Schema(type=openapi.TYPE_STRING, description='患者id'),
                'subsequent_visit_date': openapi.Schema(type=openapi.TYPE_STRING, description='复诊时间'),
            }
        ),
        # 接口标题
        operation_summary='自定义复诊时间',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['诊疗记录']
    )
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid(raise_exception=True):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        headers = self.get_success_headers(serializer.data)
        id = serializer.data['id']
        subsequent_visit_date = datetime.datetime.strptime(serializer.data['subsequent_visit_date'], "%Y-%m-%d %H:%M")
        if not all([id, subsequent_visit_date]):
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                object_doctor = PatientModel.objects.filter(id=id)
                object_doctor.update(subsequent_visit_date=subsequent_visit_date)
                # 定时提醒
                user = request.user
                remind_datetime = datetime.datetime(subsequent_visit_date.year, subsequent_visit_date.month, subsequent_visit_date.day, subsequent_visit_date.hour, subsequent_visit_date.minute, 0)
                patient = object_doctor.first()
                patient_id = patient.id
                patient_name = patient.name
                add_subsequent_visit(user.open_id, remind_datetime, patient_id, patient_name)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '添加失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)


class MedicationRecordView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者最近一次提醒记录里的药品""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="patient", in_=openapi.IN_QUERY, description="患者id", type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='患者最近一次提醒记录里的药品(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    # 患者最近一次提醒记录里的药品
    def get(self, request, *args, **kwargs):
        patient_id = request.query_params.get('patient')
        medication_record = MedicationRecordModel.objects.filter(patient_id=patient_id).order_by('-create_time').first()
        data = {}
        if medication_record and medication_record.is_medicated == False:
            data['medication_record_id'] = medication_record.id
            medication_record_mid = MedicationRecordMiddleModel.objects.filter(medicine_record_id=medication_record.id)
            data.update({'data': serializers.MedicationRecordMiddleSerializer(medication_record_mid, many=True).data})
        return Response(data=data, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""患者所用药物状态更新""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['medication_record_id', 'medicine_id_list'],
            properties={
                'medication_record_id': openapi.Schema(type=openapi.TYPE_STRING, description='用药记录id'),
                'medicine_id_list': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.TYPE_STRING,
                                                   description='药品id'),
            }
        ),
        # 接口标题
        operation_summary='患者所用药物状态更新(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['患者']
    )
    # 患者所用药物状态更新
    def put(self, request, *args, **kwargs):
        data = request.data
        medication_record_id = data.get('medication_record_id')
        record_middle_id_list = data.get('medicine_id_list')
        MedicationRecordModel.objects.filter(id=medication_record_id).update(is_medicated=True)
        if record_middle_id_list:
            MedicationRecordMiddleModel.objects.filter(medicine_record_id=medication_record_id,
                                                       id__in=record_middle_id_list).update(medication_status=True)
        return Response(status=status.HTTP_200_OK)


@method_decorator(swagger_auto_schema(
    operation_description="""未绑定列表""",
    operation_summary='未绑定列表',  # 接口标题
    manual_parameters=[
            # 声明参数
            # openapi.Parameter(
            #     # 参数名称
            #     name="Authorization",
            #     # 参数类型为query
            #     in_=openapi.IN_HEADER,
            #     # 参数描述
            #     description="用户认证",
            #     # 参数字符类型
            #     type=openapi.TYPE_STRING,
            #     required=True
            # ),
            openapi.Parameter(
                # 参数名称
                name="patient_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="患者id",
                # 参数字符类型
                type=openapi.TYPE_STRING
            ),
            openapi.Parameter(
                # 参数名称
                name="hospital_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="医院id",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="search_name",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="搜索名称",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=False
            ),
        ],
    tags=['绑定医生'],   # 分组中
),
    name='get'
)
class NoBindDoctorListView(ListAPIView):
    # permission_classes = (IsAuthenticated,)

    serializer_class = NoDoctorSerializer
    filter_class = DoctorListFilter
    # queryset = DoctorModel.objects.order_by('name')
    # pagination_class = None

    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id')
        search_name = self.request.query_params.get('search_name')
        doctor_id = PatientModel.objects.filter(id=patient_id).first()
        hospital_id = self.request.query_params.get('hospital_id')
        if search_name:
            if doctor_id:
                return DoctorModel.objects.order_by('name').exclude(id=doctor_id.doctor_id).filter(hospital_id=hospital_id, name__contains=search_name, status=1, doctor_type=1)
            else:
                return DoctorModel.objects.order_by('name').filter(hospital_id=hospital_id, name__contains=search_name, status=1, doctor_type=1)
        else:
            if doctor_id:
                return DoctorModel.objects.order_by('name').exclude(id=doctor_id.doctor_id).filter(hospital_id=hospital_id, status=1, doctor_type=1)
            else:
                return DoctorModel.objects.order_by('name').filter(hospital_id=hospital_id, status=1, doctor_type=1)


