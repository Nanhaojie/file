import uuid

from utils.models import SpareFieldModel
from django.db import models


class PatientModel(SpareFieldModel):
    illness_choices = (
        (1, '良好'),
        (2, '适中'),
        (3, '严重'),
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    account = models.ForeignKey('user.AccountModel', on_delete=models.CASCADE, related_name='patient_set',
                                db_constraint=False)
    is_default = models.BooleanField(default=False, verbose_name='是否默认患者')
    name = models.CharField(max_length=128, verbose_name='患者姓名')
    disease_type = models.CharField(max_length=64, null=True, blank=True, verbose_name='患病类型')
    avatar_url = models.CharField(max_length=256, null=True, blank=True, verbose_name='患者头像')
    gender = models.SmallIntegerField(choices=((1, '男'), (0, '女')), null=True, blank=True, verbose_name='性别')
    id_card_number = models.CharField(max_length=18, unique=True, error_messages={'unique': '身份证号重复,请重新输入'}, verbose_name='身份证号码')
    weight = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, verbose_name='体重/kg')
    age = models.SmallIntegerField(null=True, blank=True, verbose_name='年龄')
    address = models.CharField(max_length=256, null=True, blank=True, verbose_name='住址')
    illness_status = models.SmallIntegerField(choices=illness_choices, default=1,
                                              verbose_name=f'病情状态{illness_choices}')
    subsequent_visit_date = models.DateTimeField(null=True, blank=True, verbose_name='复诊时间')
    hospital = models.ForeignKey('hospital.HospitalModel', on_delete=models.PROTECT, null=True, blank=True,
                                 related_name='patient_set', db_constraint=False)
    doctor = models.ForeignKey('doctor.DoctorModel', on_delete=models.SET_NULL, null=True, blank=True,
                               related_name='patient_set', db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '患者表'
        verbose_name_plural = verbose_name
        db_table = 't_patient'
        ordering = ('-create_time',)


class WeightRecordModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='weight_record',
                                db_constraint=False, verbose_name='患者')
    weight = models.DecimalField(max_digits=4, decimal_places=1, verbose_name='体重/kg')
    date = models.DateField(auto_now_add=True, verbose_name='日期')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '体重记录'
        verbose_name_plural = verbose_name
        db_table = 't_weight_record'


class TreatmentRecord(SpareFieldModel):
    rank_choices = (
        (1, '住院医师'),
        (2, '主治医师'),
        (3, '副主任医师'),
        (4, '主任医师')
    )

    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    treatment_time = models.DateField(auto_now_add=True, verbose_name='诊疗时间')
    doctor = models.ForeignKey('doctor.DoctorModel', on_delete=models.CASCADE, related_name='treatment_record',
                               db_constraint=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='treatment_record',
                                db_constraint=False, verbose_name='患者')
    department_name = models.CharField(max_length=128, verbose_name='科室名称')
    doctor_name = models.CharField(max_length=128, verbose_name='科室名称')
    doctor_rank = models.SmallIntegerField(choices=rank_choices, verbose_name=f'医生职级{rank_choices}')
    subsequent_visit_date = models.DateField(null=True, blank=True, verbose_name='建议复诊日期')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '诊疗记录'
        verbose_name_plural = verbose_name
        db_table = 't_treatment_record'


class MedicationSpecificationModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64, verbose_name='规格名称')
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='specification_set',
                                db_constraint=False, verbose_name='患者')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '药品规格'
        verbose_name_plural = verbose_name
        db_table = 't_medication_specification'
        ordering = ('-create_time',)


class MedicineModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64, verbose_name='药物名称')
    medicine_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='药物图片')  # ['url1', 'url2']
    specifications = models.CharField(max_length=512, null=True, blank=True, verbose_name='使用规格')
    is_remind = models.BooleanField(default=True, verbose_name='是否需要提醒')
    is_template = models.BooleanField(default=False, verbose_name='是否模板药物')  # 模板是后台添加的常规药物,是模板的话患者为空
    hospital = models.ForeignKey('hospital.HospitalModel', on_delete=models.CASCADE, null=True, blank=True,
                                 related_name='hospital_medicine_tem', db_constraint=False)   # 如果是后台添加的常规药物,需要存储是哪个医院
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='medicine_set', null=True,
                                blank=True, db_constraint=False, verbose_name='患者')
    input_time = models.DateTimeField(auto_now_add=True, verbose_name='录入时间')
    notes = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')

    class Meta:
        verbose_name = '药物表'
        verbose_name_plural = verbose_name
        db_table = 't_medicine'
        ordering = ('-input_time',)


class MedicationRemindModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    medicine = models.ForeignKey(MedicineModel, on_delete=models.CASCADE, related_name='medication_remind',
                                 db_constraint=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='medication_remind_patient',
                                db_constraint=False)
    remind_time = models.CharField(max_length=16, verbose_name='提醒时间')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '药物提醒表'
        verbose_name_plural = verbose_name
        db_table = 't_medication_remind'
        ordering = ('remind_time',)


class MedicationRemindTimeModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='medication_remind_time',
                                db_constraint=False)
    remind_time = models.CharField(max_length=16, verbose_name='提醒时间')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '患者用药时刻汇总表'
        verbose_name_plural = verbose_name
        db_table = 't_medication_remind_time'


class MedicationRecordModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='medication_record',
                                db_constraint=False, verbose_name='患者')
    medication_time = models.DateTimeField(null=True, blank=True, auto_now=True, verbose_name='用药时间')
    is_medicated = models.BooleanField(default=False, verbose_name='是否已用药')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '用药记录表'
        verbose_name_plural = verbose_name
        db_table = 't_medication_record'
        ordering = ('medication_time', )


class MedicationRecordMiddleModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    medicine = models.ForeignKey(MedicineModel, null=True, blank=True, on_delete=models.SET_NULL, related_name='medication_record',
                                 db_constraint=False)
    medicine_name = models.CharField(max_length=256, verbose_name='药品名称')
    specifications = models.CharField(max_length=256, null=True, blank=True, verbose_name='使用规格')
    notes = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')  # 代替规格的作用
    medicine_record = models.ForeignKey(MedicationRecordModel, on_delete=models.CASCADE,
                                        related_name='medication_record', db_constraint=False)
    medication_status = models.BooleanField(default=False, verbose_name='用药状态')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '用药记录中间表'
        verbose_name_plural = verbose_name
        db_table = 't_medication_record_middle'


class AttackLogModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    attack_time = models.DateTimeField(verbose_name='发作时间')
    duration = models.SmallIntegerField(verbose_name='发作时长/分钟')     # 1:5分钟以下、2:5-15分钟、3:15-30分钟、4:30分钟以上
    same_day_attack_times = models.SmallIntegerField(default=1, verbose_name='当天发作次数')
    reason = models.CharField(max_length=256, null=True, blank=True, verbose_name='诱发因素')
    form = models.CharField(max_length=256, null=True, blank=True, verbose_name='发作形式')
    medicine = models.CharField(max_length=256, null=True, blank=True, verbose_name='服用药物')
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='attack_log', db_constraint=False,
                                verbose_name='患者')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '发作日志表'
        verbose_name_plural = verbose_name
        db_table = 't_attack_log'
        ordering = (('-attack_time'),)


class AttackKeyTemplateModel(SpareFieldModel):
    type_choices = (
        (1, '诱发因素'),
        (2, '发作形式')
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    type = models.SmallIntegerField(choices=type_choices, verbose_name='模板类型')
    content = models.CharField(max_length=64, verbose_name='内容')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '发作关键模板表'
        verbose_name_plural = verbose_name
        db_table = 't_attack_key_template'
        unique_together = ('type', 'content')


class LeaveMessageResource(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    msg_type = models.CharField(max_length=36, null=True, blank=True,verbose_name='留言资源类型')
    leave_message = models.ForeignKey('LeaveMessageModel', on_delete=models.CASCADE, related_name='leave_msg_resource',
                                      db_constraint=False)
    url = models.CharField(max_length=512, verbose_name='资源链接')
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name='添加时间')

    class Meta:
        verbose_name = '留言资源表'
        verbose_name_plural = verbose_name
        db_table = 't_leave_message_resource'
        ordering = ('create_time', )


class LeaveMessageModel(SpareFieldModel):
    status_choices = (
        (1, '未回复'),
        (2, '已读取未回复'),
        (3, '已回复'),
    )
    account_type_choices = (
        (1, '医生'),
        (2, '患者')
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    doctor = models.ForeignKey('doctor.DoctorModel', on_delete=models.CASCADE, related_name='leave_msg',
                               db_constraint=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='leave_msg', db_constraint=False)
    account_type = models.SmallIntegerField(choices=account_type_choices,
                                            verbose_name=f'留言类型{str(account_type_choices)}')
    content = models.CharField(max_length=1024, null=True, blank=True, verbose_name='消息内容')
    send_time = models.DateTimeField(auto_now_add=True, verbose_name='发送时间')
    read_or_revert_status = models.SmallIntegerField(choices=status_choices, default=1,
                                                     verbose_name=f'读取或回复状态{str(status_choices)}')
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='child_set',
                               db_constraint=False)

    class Meta:
        verbose_name = '留言表'
        verbose_name_plural = verbose_name
        db_table = 't_leave_message'


class BindDoctorModel(SpareFieldModel):
    bind_status_choices = (
        (1, '当前绑定'),
        (0, '历史绑定'),
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    doctor = models.ForeignKey('doctor.DoctorModel', on_delete=models.CASCADE, related_name='bind_doctor_set',
                               db_constraint=False)
    patient = models.ForeignKey(PatientModel, on_delete=models.CASCADE, related_name='bind_doctor_set',
                                db_constraint=False)
    bind_status = models.SmallIntegerField(choices=bind_status_choices, default=0,
                                           verbose_name=f'绑定状态{bind_status_choices}')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '绑定医生表'
        verbose_name_plural = verbose_name
        db_table = 't_bind_doctor'
