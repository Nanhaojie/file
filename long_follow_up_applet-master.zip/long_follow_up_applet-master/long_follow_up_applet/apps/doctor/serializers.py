#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/12/9下午5:50
# @Author:zwz

from rest_framework import serializers

from doctor.models import DoctorModel, DoctorTeamModel, SchedulerModel
from hospital.models import DepartmentModel
from long_follow_up_applet import settings
from patient.models import PatientModel
from utils.common import gen_qrcode, common_upload


class BelongingPatientSerializer(serializers.ModelSerializer):
    disease_status = serializers.CharField(source='illness_status', label='健康状态')
    avatar = serializers.CharField(source='avatar_url', label='患者头像')
    class Meta:
        model = PatientModel
        fields = ('id', 'name', 'disease_type', 'disease_status', 'avatar')


class DockerSchedulerSerializer(serializers.ModelSerializer):
    time = serializers.ListField(child=serializers.CharField(label='上班时间'))
    department_name = serializers.ListField(label='科室名称')
    week = serializers.CharField(label='星期')

    class Meta:
        model = SchedulerModel
        fields = ('date', 'time', 'department_name', 'week')


class DoctorSerializer(serializers.ModelSerializer):
    account = serializers.CharField(source='account_id', required=False)
    hospital = serializers.CharField(source='hospital_id', required=False)
    department = serializers.CharField(source='department_id', required=False)
    rank = serializers.SerializerMethodField(label=f'职级')
    # name = serializers.CharField(max_length=10, required=False, error_messages={'max_length': '名字长度需要在10个字以内!'})
    photo_url = serializers.CharField(required=False)
    qualification_cert_url = serializers.CharField(required=False)
    age = serializers.CharField(max_length=2, required=False, error_messages={'max_length': '年龄在100岁以内,且不能为汉字,非法字符等!'})
    honor_experience = serializers.CharField(required=False)
    introduction = serializers.CharField(required=False)

    def get_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.rank == value:
                return text
        else:
            return '未知职级'

    def get_doctor_type(self, instance):
        for value, text in DoctorModel.type_choices:
            if instance.doctor_type == value:
                return text
        else:
            return '未知医生'

    class Meta:
        model = DoctorModel
        fields = ('id', 'name', 'age', 'gender', 'photo_url', 'qualification_cert_url', 'account', 'hospital', 'department',
                  'introduction', 'honor_experience', 'rank', 'status', 'hospital_id', 'department_id', 'qr_code_url', 'doctor_type', 'p_id')
        extra_kwargs = {
            'name': {'required': False}
        }

    def create(self, validated_data):
        instance = super(DoctorSerializer, self).create(validated_data)
        # 生成二维码上传七牛云
        qr_code_url = common_upload(gen_qrcode(instance.id))
        # # 更新医生记录
        instance.qr_code_url = qr_code_url
        instance.save()
        return instance

    def to_representation(self, instance):
        data = super(DoctorSerializer, self).to_representation(instance)
        doctor_id = data.get('id')
        data['hospital'] = DoctorModel.objects.filter(id=doctor_id).first().hospital.name
        data['department'] = DoctorModel.objects.filter(id=doctor_id).first().department.name
        return data

    def validate_name(self, value):
        if len(value) > 25:
            raise serializers.ValidationError(detail='姓名不得超过25个汉字')
        return value


class NoDoctorSerializer(serializers.ModelSerializer):
    account = serializers.CharField(source='account_id')
    hospital = serializers.CharField(source='hospital_id')
    doctor_id = serializers.CharField(source='id')
    department = serializers.CharField(source='department_id')
    rank = serializers.SerializerMethodField(label=f'职级')

    def get_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.rank == value:
                return text
        else:
            return '未知职级'

    class Meta:
        model = DoctorModel
        fields = ('doctor_id', 'name', 'age', 'gender', 'photo_url', 'qualification_cert_url', 'department',  'account', 'hospital',
                  'rank', 'introduction', 'honor_experience', 'status')


class DockerTeamSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source='department.name', label='科室名称')
    rank = serializers.SerializerMethodField(label='')

    def get_rank(self, instance):
        for value, text in DoctorModel.rank_choices:
            if instance.rank == value:
                return text
        else:
            return '未知职级'

    class Meta:
        model = DoctorTeamModel
        fields = ('id', 'name', 'hospital', 'icon_url', 'introduction', 'department_name', 'rank')


class DockerTeamRetrieveSerializer(serializers.ModelSerializer):
    class Meta:
        model = DoctorTeamModel
        fields = ('id', 'name', 'icon_url', 'introduction', 'department', 'rank')

    def create(self, validated_data):
        validated_data['hospital'] = validated_data.get('department').hospital
        return super(DockerTeamRetrieveSerializer, self).create(validated_data)

# 后台

class DoctorBKSerializer(serializers.ModelSerializer):
    mobile = serializers.CharField(source='account.mobile', max_length=11, required=False)
    name = serializers.CharField(required=False)
    department = serializers.CharField(source='department_id', required=False)
    photo_url = serializers.CharField(required=False)
    qualification_cert_url = serializers.CharField(required=False)
    status = serializers.CharField(required=False)
    notes = serializers.CharField(required=False)
    rank = serializers.CharField(required=False)

    class Meta:
        model = DoctorModel
        fields = ('id', 'name', 'department', 'photo_url', 'qualification_cert_url', 'create_time', 'status',
                  'update_time', 'mobile', 'notes', 'rank')
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'update_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }

    def to_representation(self, instance):
        data = super(DoctorBKSerializer, self).to_representation(instance)
        department_id = data.get('department')
        data['department'] = DepartmentModel.objects.filter(id=department_id).first().name
        return data
