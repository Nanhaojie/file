from datetime import datetime
import re
import time

from django.db import connection, transaction
from django.db.models import Max
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.utils.timezone import now
from filetype import filetype
from rest_framework import status
from rest_framework.generics import ListAPIView, RetrieveAPIView, CreateAPIView, UpdateAPIView, DestroyAPIView
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from drf_yasg import openapi
from doctor import serializers
from doctor.models import DoctorModel, SchedulerModel
from doctor.filters import DockerTeamFilter, DockerSchedulerFilter
from doctor.models import DoctorTeamModel
from doctor.serializers import DockerTeamSerializer, DockerTeamRetrieveSerializer, DockerSchedulerSerializer, \
    BelongingPatientSerializer, DoctorBKSerializer
from long_follow_up_applet import settings
from patient.models import PatientModel
from utils.common import qiniu_upload_base64, common_upload
from drf_yasg.utils import swagger_auto_schema
import logging
from rest_framework import filters
import traceback

logger = logging.getLogger('django')


@method_decorator(swagger_auto_schema(
    operation_description="""医生排班""",
    operation_summary='我的排班',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        # 声明参数
        openapi.Parameter(
            # 参数名称
            name="Authorization",
            # 参数类型为query
            in_=openapi.IN_HEADER,
            # 参数描述
            description="用户认证",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            # 参数名称
            name="filter_date",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="搜索日期",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: DockerSchedulerSerializer}
),
    name='get'
)
class DoctorSchedulerView(APIView):
    queryset = SchedulerModel.objects.order_by('date', 'start_time')
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        # 获取过滤时间 默认为当前时间
        filter_date = request.query_params.get('filter_date', now().strftime(settings.SERIALIZER_DATE_FIELD_FORMAT)[:7])
        query_sql = """
        SELECT
            `date`,
            group_concat(concat_ws('-', DATE_FORMAT( start_time, '%%H:%%i') , DATE_FORMAT( end_time, '%%H:%%i'))
             order by `start_time` separator ' ') as time,
             `name`
        FROM
            t_scheduler, t_department
        WHERE
            DATE_FORMAT( date, '%%Y-%%m' ) = %s and doctor_id=%s and status=1 
            and t_scheduler.department_id=t_department.id
        GROUP BY
            `t_scheduler`.`date`, `t_department`.`name`
        ORDER BY date
        """
        with connection.cursor() as cursor:
            cursor.execute(query_sql, (filter_date, request.user.doctor.id))
            def str2week(date):
                week_str = "星期一星期二星期三星期四星期五星期六星期日"
                pos = date.weekday() * 3
                return week_str[pos: pos + 3]
            data = [{'date': row[0], 'week': str2week(row[0]), 'time': row[1].split(' '), 'department_name': row[2]}
                    for row in cursor.fetchall()]
        return Response(data)


class DoctorTeamView(ListAPIView, CreateAPIView):
    filter_class = DockerTeamFilter
    queryset = DoctorTeamModel.objects.all()
    pagination_class = None

    @swagger_auto_schema(
        operation_description="""医生团队列表""",
        operation_summary='医生团队列表',  # 接口标题
        tags=['医生团队'],   # 分组中
    )
    def get(self, request, *args, **kwargs):
        return super(DoctorTeamView, self).get(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""医生团队""",
        operation_summary='医生团队新增',  # 接口标题
        tags=['医生团队'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def post(self, request, *args, **kwargs):
        return super(DoctorTeamView, self).post(request, *args, **kwargs)

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.request.method.lower() == 'get':
            return [permission() for permission in self.permission_classes]
        else:
            return [IsAdminUser()]

    def get_serializer_class(self):
        if self.request.method.lower() == 'get':
            return DockerTeamSerializer
        else:
            return DockerTeamRetrieveSerializer


class DoctorTeamRetrieve(RetrieveAPIView, UpdateAPIView, DestroyAPIView):
    serializer_class = DockerTeamRetrieveSerializer
    queryset = DoctorTeamModel.objects.all()

    @swagger_auto_schema(
        operation_description="""医生团队详情""",
        operation_summary='医生团队详情',  # 接口标题
        tags=['医生团队'],  # 分组中
    )
    def get(self, request, *args, **kwargs):
        return super(DoctorTeamRetrieve, self).get(request, *args, **kwargs)

    @swagger_auto_schema(
        operation_description="""医生团队""",
        operation_summary='医生团队编辑',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['医生团队'],  # 分组中
    )
    def put(self, request, *rags, **kwargs):
        return super(DoctorTeamRetrieve, self).put(request, *rags, **kwargs)

    @swagger_auto_schema(
        operation_description="""医生团队""",
        operation_summary='医生团队删除',  # 接口标题
        tags=['医生团队'],  # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ]
    )
    def delete(self, request, *rags, **kwargs):
        return super(DoctorTeamRetrieve, self).delete(request, *rags, **kwargs)

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.request.method.lower() == 'get':
            return [permission() for permission in self.permission_classes]
        else:
            return [IsAdminUser()]


class DoctorTeamModelToppingView(UpdateAPIView):
    queryset = DoctorTeamModel.objects.all()
    permission_classes = (IsAdminUser,)

    @swagger_auto_schema(
        operation_description="""医生团队""",
        operation_summary='医生团队置顶',  # 接口标题
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
        ],
        tags=['医生团队'],  # 分组中
    )
    def put(self, request, *rags, **kwargs):
        instance = self.get_object()
        # 查询当前分类中排序字段的最大值
        instance.serial_num = self.get_queryset().filter(hospital_id=instance.hospital_id). \
                                  aggregate(Max('serial_num')).get('serial_num__max') + 1
        instance.save()
        return Response({'detail': '成功'})


class PictureUpload(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""图片上传""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['file'],
            properties={
                'file': openapi.Schema(type=openapi.TYPE_FILE, description='文件'),
            }
        ),
        # 接口标题
        operation_summary='图片上传(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['图片上传']
    )
    def post(self, request, *args, **kwargs):
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': '文件不能为空'}, status=status.HTTP_200_OK)
        old_file_name = file.name
        new_file_name = 'kuner/long_follow_up/applet/' + str(time.time()).replace('.', '') + '.' + old_file_name.split('.')[-1]
        ret = common_upload(file.read(), file_name=new_file_name)
        # 返回资源类型
        file.seek(0)
        try:
            pic_type = (filetype.guess(file).mime or '').split('/')[1]
        except Exception:
            logger.warning('留言接口url参数校验失败', exc_info=True)
            pic_type = None
        return Response(data={'pic_url': ret, 'pic_type': pic_type}, status=status.HTTP_200_OK)


class DoctorView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return serializers.DoctorSerializer

    def get_queryset(self):
        doctor_id = self.request.query_params.get('doctor_id')
        if doctor_id:
            return DoctorModel.objects.filter(id=doctor_id)
        else:
            return DoctorModel

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医生个人信息""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(
                # 参数名称
                name="doctor_id",
                # 参数类型为query
                in_=openapi.IN_QUERY,
                # 参数描述
                description="医生个人信息",
                # 参数字符类型
                type=openapi.TYPE_STRING
            ),
        ],
        # 接口标题
        operation_summary='医生个人信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医生信息']
    )
    def list(self, request, *args, **kwargs):
        response = super(DoctorView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医生注册""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['name', 'age', 'gender', 'photo_url', 'qualification_cert_url', 'hospital', 'department'],
            properties={
                'name': openapi.Schema(type=openapi.TYPE_STRING, description='姓名'),
                'age': openapi.Schema(type=openapi.TYPE_NUMBER, description='年龄'),
                'gender': openapi.Schema(type=openapi.TYPE_NUMBER, description='性别'),
                'photo_url': openapi.Schema(type=openapi.TYPE_STRING, description='头像url'),
                'qualification_cert_url': openapi.Schema(type=openapi.TYPE_STRING, description='执照url'),
                'hospital': openapi.Schema(type=openapi.TYPE_STRING, description='医院id'),
                'department': openapi.Schema(type=openapi.TYPE_STRING, description='科室id'),
                'doctor_type': openapi.Schema(type=openapi.TYPE_NUMBER, description='(0, "实习医生"), (1, "医生")')
            }
        ),
        # 接口标题
        operation_summary='医生注册(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医生信息']
    )
    def create(self, request, *args, **kwargs):
        user = request.user
        if user.patient_set.count() != 0:
            return Response(data={'detail': '您已注册为患者,不能注册为医生!'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user.doctor.delete()
        except:
            pass
        data = request.data
        data['account'] = user.id
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        name = data['name']
        if re.search('[^\u4e00-\u9fa5]', name):
            return Response(data={'detail': '姓名必须是汉字'}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        user.type = 1
        user.save()
        headers = self.get_success_headers(serializer.data)
        data = serializer.data
        data['detail'] = '审核中,请耐心等待!'
        return Response(data,  status=status.HTTP_201_CREATED, headers=headers)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""编辑医生信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'age': openapi.Schema(type=openapi.TYPE_NUMBER, description='年龄'),
                'gender': openapi.Schema(type=openapi.TYPE_NUMBER, description='性别'),
                'photo_url': openapi.Schema(type=openapi.TYPE_STRING, description='头像url'),
                'qualification_cert_url': openapi.Schema(type=openapi.TYPE_STRING, description='执照url'),
                'introduction': openapi.Schema(type=openapi.TYPE_STRING, description='个人简介'),
                'honor_experience': openapi.Schema(type=openapi.TYPE_STRING, description='荣誉经历')
            }
        ),
        # 接口标题
        operation_summary='编辑医生信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医生信息']
    )
    def update(self, request, *args, **kwargs):
        return super(DoctorView, self).update(request, *args, **kwargs)


@method_decorator(swagger_auto_schema(
    operation_description="""我的患者""",
    operation_summary='我的患者',  # 接口标题
    # tags=['留言'],   # 分组中
    manual_parameters=[
        # 声明参数
        openapi.Parameter(
            # 参数名称
            name="Authorization",
            # 参数类型为query
            in_=openapi.IN_HEADER,
            # 参数描述
            description="用户认证",
            # 参数字符类型
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            # 参数名称
            name="filter_words",
            # 参数类型为query
            in_=openapi.IN_QUERY,
            # 参数描述
            description="搜索关键字",
            # 参数字符类型
            type=openapi.TYPE_STRING,
        ),
    ],
    # tags=['留言'],   # 分组中
    responses={200: BelongingPatientSerializer}
),
    name='get'
)
class BelongingPatientView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *rags, **kwargs):
        # 根据医生筛选患者  对患者按照患者状态排序， 按照患者名字排序
        queryset = PatientModel.objects.filter(doctor__account__id=request.user.id).order_by('-illness_status', 'name')
        # 如果有关键字 根据关键字筛选患者
        filter_words = request.query_params.get('filter_words')
        if filter_words is not None:
            queryset = queryset.filter(name__contains=filter_words)

        serializer = BelongingPatientSerializer(queryset, many=True)
        # 将患者状态一样的 分为一组
        data = {str(group_status): [] for group_status, _ in PatientModel.illness_choices}
        for patient_obj in serializer.data:
            data[patient_obj.get('disease_status')].append(patient_obj)
        # 返回数据
        return Response(data)


# 实习医生列表
class DoctorStudyView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return serializers.DoctorSerializer

    def get_queryset(self):
        name = self.request.query_params.get('name')
        if name:
            return DoctorModel.objects.filter(name=name, doctor_type=0)
        else:
            return DoctorModel.objects.filter(doctor_type=0)

    @swagger_auto_schema(
        operation_description="""实习医生列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            # 声明参数
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="用户认证", type=openapi.TYPE_STRING,
                required=True
            ),
            openapi.Parameter(name="name", in_=openapi.IN_QUERY, description="实习医生名字", type=openapi.TYPE_STRING
            ),
        ],
        # 接口标题
        operation_summary='实习医生列表',
        tags=['医生信息']
    )
    def list(self, request, *args, **kwargs):
        response = super(DoctorStudyView, self).list(request, *args, **kwargs)
        return response


# 绑定实习医生
class BindStudyDoctorView(ModelViewSet):
    # permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return serializers.DoctorSerializer


    def get_queryset(self):
        doctor_id = self.request.query_params.get('doctor_id')
        if doctor_id:
            return DoctorModel.objects.filter(p_id=doctor_id)
        else:
            return DoctorModel

    @swagger_auto_schema(
        operation_description="""绑定实习医生列表""",
        # 接口参数 GET请求参数
        manual_parameters=[openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="用户认证",
                type=openapi.TYPE_STRING, required=True),
            openapi.Parameter(name="doctor_id", in_=openapi.IN_QUERY, description="医生id", type=openapi.TYPE_STRING
            ),
        ],
        operation_summary='绑定实习医生列表',
        tags=['医生信息']
    )
    def list(self, request, *args, **kwargs):
        response = super(BindStudyDoctorView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        operation_description="""绑定实习医生""",
        # manual_parameters=[openapi.Parameter(name="Authorization",in_=openapi.IN_HEADER,description="用户认证",
        #         type=openapi.TYPE_STRING, required=True)],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='医生id'),
                'study_doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='实习医生id'),
            }
        ),
        # 接口标题
        operation_summary='绑定实习医生',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医生信息']
    )
    def create(self, request, *args, **kwargs):
        data = request.data
        study_doctor_id = data['study_doctor_id']
        doctor_id = data['doctor_id']
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                study_doctor_obj = DoctorModel.objects.filter(id=study_doctor_id)
                is_have_doctor = study_doctor_obj.first().p
                if is_have_doctor:
                    return Response({'detail': '该账号已被绑定'}, status=status.HTTP_400_BAD_REQUEST)
                study_doctor_obj.update(p_id=doctor_id)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'data': '绑定失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
            return Response(data={'data': '绑定成功'}, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        operation_description="""解除绑定实习医生""",
        manual_parameters=[openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="用户认证",
                                             type=openapi.TYPE_STRING, required=True)],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'study_doctor_id': openapi.Schema(type=openapi.TYPE_STRING, description='实习医生id'),
            }
        ),
        # 接口标题
        operation_summary='解除绑定实习医生',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['医生信息']
    )
    def update(self, request, *args, **kwargs):
        data = request.data
        study_doctor_id = data['study_doctor_id']
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                study_doctor_obj = DoctorModel.objects.filter(id=study_doctor_id)
                study_doctor_obj.update(p_id=None)
            except:
                logger.warning(traceback.format_exc())
                transaction.savepoint_rollback(save_id)
                return Response(data={'data': '解除绑定失败'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
            return Response(data={'data': '解除绑定成功'}, status=status.HTTP_200_OK)


# 后台
class DoctorBKView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return DoctorBKSerializer

    def get_queryset(self):
        hospital_id = self.request.query_params.get('hospital_id')
        is_adopt = self.request.query_params.get('is_adopt')
        if hospital_id and is_adopt:
            return DoctorModel.objects.filter(hospital_id=hospital_id, status=1)
        else:
            return DoctorModel.objects.filter(hospital_id=hospital_id)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医生列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="hospital_id", in_=openapi.IN_QUERY, description="医院id",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="is_adopt", in_=openapi.IN_QUERY, description="审核通过",
                              type=openapi.TYPE_NUMBER, required=False),
        ],
        # 接口标题
        operation_summary='医生列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医生']
    )
    def list(self, request, *args, **kwargs):
        response = super(DoctorBKView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""医生详细信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="hospital_id", in_=openapi.IN_QUERY, description="医院id",
                              type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='医生详细信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医生']
    )
    def retrieve(self, request, *args, **kwargs):
        return super(DoctorBKView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""修改医生审核状态""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="hospital_id", in_=openapi.IN_QUERY, description="医院id",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'status': openapi.Schema(type=openapi.TYPE_NUMBER, description='(0, "待审核"), (1, "审核通过"), (2, "审核未通过")'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
                'rank': openapi.Schema(type=openapi.TYPE_NUMBER, description='(1, "住院医师"), (2, "主治医师"), '
                                                                             '(3, "副主任医师"), (4, "主任医师")'),
            }
        ),
        # 接口标题
        operation_summary='修改医生审核状态',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医生']
    )
    def update(self, request, *args, **kwargs):
        return super(DoctorBKView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""删除医生""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="hospital_id", in_=openapi.IN_QUERY, description="医院id",
                              type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='删除医生',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台医生']
    )
    def destroy(self, request, *args, **kwargs):
        return super(DoctorBKView, self).destroy(request, *args, **kwargs)
