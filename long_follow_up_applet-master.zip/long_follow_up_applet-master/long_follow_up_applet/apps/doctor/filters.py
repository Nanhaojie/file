# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 12/14/21 4:10 PM
# @author yueyuanbo

import django_filters

from doctor.models import DoctorTeamModel, SchedulerModel


class DockerTeamFilter(django_filters.FilterSet):
    """健康咨询的过滤类"""
    # field_name 表示要过滤字段；lookup_expr 表示 过滤时要进行的操作，gte 表示 大于等于
    hospital_id = django_filters.CharFilter(field_name="hospital_id", lookup_expr="exact", help_text='医院id')

    class Meta:
        model = DoctorTeamModel  # 关联的表
        fields = ["hospital_id"]  # 过滤的字段

class DockerSchedulerFilter(django_filters.FilterSet):
    """医生排班的过滤类"""
    # field_name 表示要过滤字段；lookup_expr 表示 过滤时要进行的操作，gte 表示 大于等于
    filter_date = django_filters.CharFilter(field_name="date", lookup_expr="exact", help_text='筛选日期；e.g. 2021-12')

    class Meta:
        model = SchedulerModel  # 关联的表
        fields = ["filter_date"]  # 过滤的字段
