import uuid

from django.db import models

# Create your models here.
from long_follow_up_applet import settings
from utils.models import SpareFieldModel


class DoctorModel(SpareFieldModel):
    status_choices = (
        (0, '待审核'),
        (1, '审核通过'),
        (2, '审核未通过'),
    )
    rank_choices = (
        (1, '住院医师'),
        (2, '主治医师'),
        (3, '副主任医师'),
        (4, '主任医师')
    )
    type_choices = (
        (0, '实习医生'),
        (1, '医生')
    )
    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    account  = models.OneToOneField('user.AccountModel', on_delete=models.CASCADE, related_name='doctor', db_constraint=False, verbose_name='医生的账户')
    name = models.CharField(max_length=128, verbose_name='姓名')
    age = models.SmallIntegerField(null=True, blank=True, verbose_name='年龄')
    status = models.SmallIntegerField(choices=status_choices,default=0,verbose_name='审核状态') # 0:审核中  1:通过  2:未通过
    gender = models.SmallIntegerField(choices=((1, '男'),(0, '女')), null=True, blank=True,
                                      verbose_name="性别 ((1, '男'),(0, '女'))")
    id_card_number = models.CharField(max_length=18, null=True, blank=True, unique=True, error_messages={'unique': '身份证号重复,请重新输入'}, verbose_name='身份证号码')
    photo_url = models.CharField(max_length=256,verbose_name='个人照片')
    qualification_cert_url = models.CharField(max_length=256,verbose_name='医师资格证')
    introduction = models.CharField(max_length=1024, null=True, blank=True, verbose_name='个人简介')
    honor_experience = models.CharField(max_length=1024, null=True, blank=True, verbose_name='荣誉经历')
    rank = models.SmallIntegerField(choices=rank_choices, default=1, verbose_name=f'职级 {str(rank_choices)}')
    hospital = models.ForeignKey('hospital.HospitalModel', on_delete=models.PROTECT, related_name='doctor', db_constraint=False, verbose_name='医院的医生')
    department = models.ForeignKey('hospital.DepartmentModel', on_delete=models.PROTECT, related_name='doctor', db_constraint=False, verbose_name='科室的医生')
    qr_code_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='医生二维码图片')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    notes = models.CharField(max_length=512, null=True, blank=True, verbose_name='备注')
    doctor_type = models.SmallIntegerField(choices=type_choices, null=True, blank=True, default=1, verbose_name=f'{str(type_choices)}')
    p = models.ForeignKey('DoctorModel', null=True, blank=True, on_delete=models.CASCADE, related_name='p_doctor', db_constraint=False, verbose_name='父级')

    class Meta:
        verbose_name = '医生表'
        verbose_name_plural = verbose_name
        db_table = 't_doctor'


class DoctorTeamModel(SpareFieldModel):
    rank_choices = (
        (1, '住院医师'),
        (2, '主治医师'),
        (3, '副主任医师'),
        (4, '主任医师')
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=128, verbose_name='医生姓名')
    introduction = models.TextField(max_length=2048, null=True, blank=True, verbose_name='医生详情介绍')
    hospital = models.ForeignKey('hospital.HospitalModel', on_delete=models.PROTECT, related_name='doctor_team',
                                 db_constraint=False)
    department = models.ForeignKey('hospital.DepartmentModel', on_delete=models.PROTECT, db_constraint=False)
    doctor = models.ForeignKey('doctor.DoctorModel', null=True, blank=True, on_delete=models.SET_NULL,
                               db_constraint=False)
    icon_url = models.CharField(max_length=512, verbose_name='医生头像')
    rank = models.SmallIntegerField(choices=rank_choices, default=1, verbose_name=f'职级 {str(rank_choices)}')
    serial_num = models.IntegerField(default=0, verbose_name='序号')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '医生团队表'
        verbose_name_plural = verbose_name
        db_table = 't_doctor_team'
        ordering = ('-serial_num', '-create_time', )


class DoctorTeamMiddleModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    team = models.ForeignKey(DoctorTeamModel, on_delete=models.CASCADE, related_name='doctor_team_set', db_constraint=False)
    doctor = models.ForeignKey(DoctorModel, on_delete=models.CASCADE, related_name='doctor_team_set', db_constraint=False)

    class Meta:
        verbose_name = '医生团队中间表'
        verbose_name_plural = verbose_name
        db_table = 't_doctor_team_middle'


class SchedulerModel(SpareFieldModel):

    id  = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    doctor = models.ForeignKey(DoctorModel, on_delete=models.CASCADE, related_name='scheduler_set', db_constraint=False)
    department = models.ForeignKey('hospital.DepartmentModel', on_delete=models.CASCADE, related_name='scheduler_set',
                                   db_constraint=False)
    date = models.DateField(verbose_name='日期')
    start_time = models.TimeField(verbose_name='开始时间')
    end_time = models.TimeField(verbose_name='结束时间')
    status = models.SmallIntegerField(choices=((1, '正常'), (2, '休假')), default=1, verbose_name='工作状态')
    notes = models.CharField(max_length=256, null=True, blank=True, verbose_name='备注')

    class Meta:
        verbose_name = '排班表'
        verbose_name_plural = verbose_name
        db_table = 't_scheduler'