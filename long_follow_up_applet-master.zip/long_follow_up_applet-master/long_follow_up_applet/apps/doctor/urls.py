#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/12/9下午5:47
# @Author:zwz
from django.urls import path

from doctor.views import DoctorView, PictureUpload, DoctorTeamView, DoctorTeamRetrieve, DoctorSchedulerView, \
    BelongingPatientView, DoctorTeamModelToppingView, DoctorBKView, DoctorStudyView, BindStudyDoctorView

urlpatterns = [
    path('picture_upload', PictureUpload.as_view()),
    path('info', DoctorView.as_view({'post': 'create', 'get': 'list'})),  # 医生信息
    path('info/<pk>', DoctorView.as_view({'put': 'update'})),  # 医生信息
    path('study_doctor', DoctorStudyView.as_view({'get': 'list'})),
    path('bind_study_doctor', BindStudyDoctorView.as_view({'post': 'create', 'get': 'list', 'put': 'update'})),

    # 医生团队列表及详情
    path('doctor_teams', DoctorTeamView.as_view()),
    path('doctor_teams/<str:pk>', DoctorTeamRetrieve.as_view()),
    path('doctor_teams_topping/<str:pk>', DoctorTeamModelToppingView.as_view()),

    # 我的排班
    path('scheduler', DoctorSchedulerView.as_view()),
    # 我的患者
    path('belonging_patient', BelongingPatientView.as_view()),

    # 后台
    path('doctor_info_bkd', DoctorBKView.as_view({'get': 'list'})),  # 医生列表
    path('doctor_info_bkd/<pk>', DoctorBKView.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'})),  # 医生信息

]
