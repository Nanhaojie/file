#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/9下午3:35
#@Author:zwz
from django.conf import settings
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer

from hospital.models import HomePageIconModel
from patient.models import PatientModel
from user.models import AccountModel


class AccountSerializer(serializers.ModelSerializer):

    class Meta:
        model = AccountModel
        fields =('id', 'mobile')


class UserInfoSerializers(serializers.ModelSerializer):

    class Meta:
        model = AccountModel
        fields =('id', 'type')

    def to_representation(self, instance):
        data = super(UserInfoSerializers, self).to_representation(instance)
        if data['type'] == 2:
            patient = instance.patient_set.filter(is_default=True).first()
            if patient:
                data['patient'] = patient.id
                data['patient_name'] = patient.name
                data['is_bind_doctor'] = PatientModel.objects.filter(id=patient.id).first().doctor_id
        elif data['type'] == 1:
            doctor = instance.doctor
            data['status'] = doctor.status
            if doctor.status == 2:
                data['detail'] = '审核未通过,请重新提交资料!'
            if doctor.status == 0:
                data['detail'] = '审核中,请耐心等待!'
            data['doctor'] = doctor.id
        return data


class HomePageIconSerializer(ModelSerializer):
    class Meta:
        model = HomePageIconModel
        fields = ('name', 'picture_url', 'serial_num', 'type')


# 后端
class BackendUserInfoSerializers(serializers.ModelSerializer):
    hospital_id = serializers.CharField(allow_null=True, allow_blank=True, required=False)
    hospital_name = serializers.CharField(source='hospital.name', allow_null=True, allow_blank=True, required=False)

    class Meta:
        model = AccountModel
        fields =('id', 'username', 'password', 'is_superuser', 'is_staff', 'is_active', 'hospital_id', 'hospital_name', 'date_joined', 'last_login', 'mobile', 'note', 'gender')
        extra_kwargs = {
            'date_joined': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'last_login': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'password': {'write_only': True, 'required': False},
            'username': {'required': False},
            'is_superuser': {'required': False},
            'is_staff': {'required': False},
            'is_active': {'required': False},
        }