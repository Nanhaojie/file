from django.apps import AppConfig
from django.utils.module_loading import autodiscover_modules



class UserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user'

    def ready(self):
        autodiscover_modules(self.name)
        from utils.common import set_access_token
        set_access_token()
