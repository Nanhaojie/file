import hashlib
import logging
import random
import re
from calendar import timegm
from datetime import datetime, timedelta

import pytz
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.db import transaction
from django.shortcuts import render

# Create your views here.
from django.utils import timezone
from django.utils.decorators import method_decorator
from django_redis import get_redis_connection
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework_jwt.settings import api_settings

from hospital.models import HomePageIconModel
from user.models import AccountModel
from user import serializers
from user.serializers import HomePageIconSerializer
from utils.common import code_2_session, WXDataCrypt, check_sign, update_access_token, set_access_token

redis_conn = get_redis_connection('login_user')
logger = logging.getLogger('django')
# update_access_token()
# set_access_token()

class UserAuthView(APIView):

    def my_md5(self, jwt):
        md = hashlib.md5()
        md.update(jwt.encode(encoding='utf-8'))
        md5_str = md.hexdigest()
        return md5_str

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""登录""",
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['code'],
            properties={
                'code': openapi.Schema(type=openapi.TYPE_STRING, description='小程序登录code')
            }
        ),
        # 接口标题
        operation_summary='登录(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def post(self, request, *args, **kwargs):

        # 测试
        # openid = 'doctor1'
        # session_key = 'tiihtNczf5v6AKRyjwEUhQ=='
        # unionid = 'unionid1'
        # openid = 'o-MNU5abOYSQgEMC0HHcdcYXMX8U'
        # session_key = 'BoZ7Twgqf1E3FC8nnzFMMg=='
        # unionid = 'unionid1'
        # 获取微信code
        code = request.data.get("code")
        # type = request.data.get("account_type")
        # 根据code获取 openid openid session_key
        errcode, openid, unionid, session_key = code_2_session(code, settings.APPID, settings.APPSECRET)
        if not openid:
            return Response({'detail': '网络波动导致服务异常，请重试！'}, status=status.HTTP_400_BAD_REQUEST)
            # return Response({'detail': '未获取到用户微信信息'}, status=status.HTTP_400_BAD_REQUEST)
        # 判断用户表中是否有openid 如果有没则插入用户表中
        account = AccountModel.objects.filter(open_id=openid).first()
        if not account:
            with transaction.atomic():
                account = AccountModel(open_id=openid, unionid=unionid, username=openid)
                account.save()

        # 生成token
        user_info = {
            'openid': openid,
            'session_key': session_key,
            'exp': datetime.timestamp(datetime.now() + timedelta(minutes=settings.TOKEN_EXP))
        }
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = self.my_jwt_payload_handler(user_info)
        token = jwt_encode_handler(payload)
        md5_str = self.my_md5(token)
        val = {"token": token, "openid": openid, "session_key": session_key}
        # 检查 ccsf_xcx_user_'openid': {token}
        old_md5_str = redis_conn.get('ccsf_xcx_user_' + openid)
        if old_md5_str:
            redis_conn.delete(old_md5_str)
        redis_conn.set(md5_str, str(val), settings.APP_EXP_SECOND)
        redis_conn.set('ccsf_xcx_user_' + openid, md5_str, settings.APP_EXP_SECOND)
        # 用户最后登录时间更新
        account.last_login = timezone.now()
        account.save(update_fields=['last_login'])

        # 返回定义token
        return Response({'token': 'JWT ' + md5_str, 'id': account.id, 'type': account.type})

    def my_jwt_payload_handler(self, payload):
        payload['ran'] = random.randint(1, 1000)
        if api_settings.JWT_ALLOW_REFRESH:
            payload['orig_iat'] = timegm(
                datetime.utcnow().utctimetuple()
            )

        if api_settings.JWT_AUDIENCE is not None:
            payload['aud'] = api_settings.JWT_AUDIENCE

        if api_settings.JWT_ISSUER is not None:
            payload['iss'] = api_settings.JWT_ISSUER
        return payload

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.check_throttles(request)


class UserLogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""退出""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='退出(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def delete(self, request, *args, **kwargs):
        openid = request.user.open_id
        token = request.META.get('HTTP_AUTHORIZATION').replace('JWT ', '')
        redis_conn.delete(token)
        redis_conn.delete('ccsf_xcx_user_' + openid)
        return Response(data={'detail': '成功'}, status=status.HTTP_200_OK)


class UserInfoView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    # def get_queryset(self):
    #     queryset = User.objects.all()
    #     return queryset
    #
    def get_serializer_class(self):
        return serializers.UserInfoSerializers

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户微信信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['encryptedData', 'rawData', 'signature', 'iv'],
            properties={
                'encryptedData': openapi.Schema(type=openapi.TYPE_STRING, description='微信encryptedData'),
                'rawData': openapi.Schema(type=openapi.TYPE_STRING, description='微信rawData'),
                'signature': openapi.Schema(type=openapi.TYPE_STRING, description='微信signature'),
                'iv': openapi.Schema(type=openapi.TYPE_STRING, description='微信iv')
            }
        ),
        # 接口标题
        operation_summary='用户微信信息(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def update(self, request, *args, **kwargs):
        user = request.user
        session_info = eval(redis_conn.get(redis_conn.get('ccsf_xcx_user_' + user.open_id)))
        session_key = session_info.get('session_key')
        # 获取用户信息
        encryptedData = request.data.get('encryptedData')
        rawData = request.data.get('rawData')
        signature = request.data.get('signature')
        iv = request.data.get('iv')
        if not all([encryptedData, rawData, signature, iv]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
        ret = check_sign(rawData, session_key, signature)
        if not ret:
            return Response(data={"detail": "签名验证未通过"}, status=status.HTTP_400_BAD_REQUEST)
        # wx = WXDataCrypt(settings.APPID, session_key)
        # # wx = WXDataCrypt('wx4f4bc4dec97d474b', session_key)
        # try:
        #     user_info = wx.decrypt(encryptedData, iv)
        # except Exception as e:
        #     logger.error(e, exc_info=True)
        #     return Response(data={"detail": "解析用户信息失败！"}, status=status.HTTP_400_BAD_REQUEST)
        user_info = eval(rawData)
        user.nickname = user_info['nickName']
        user.gender = user_info['gender']
        user.avatar_url = user_info['avatarUrl']
        user.save()
        # data = serializers.UserInfoSerializers(user).data
        return Response(data={}, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        operation_description="""用户详情""",
        operation_summary='用户详情(zwz)',  # 接口标题
        tags=['用户'],   # 分组中
        manual_parameters=[
            # 声明参数
            openapi.Parameter(
                # 参数名称
                name="Authorization",
                # 参数类型为query
                in_=openapi.IN_HEADER,
                # 参数描述
                description="用户认证",
                # 参数字符类型
                type=openapi.TYPE_STRING,
                required=True
            )
        ]
    )
    def retrieve(self, request, *args, **kwargs):
        user = request.user
        serializer = self.get_serializer(user)
        return Response(serializer.data)

class UpdatePhoneView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户微信手机号""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['encryptedData', 'iv'],
            properties={
                'encryptedData': openapi.Schema(type=openapi.TYPE_STRING, description='微信encryptedData'),
                'iv': openapi.Schema(type=openapi.TYPE_STRING, description='微信iv')
            }
        ),
        # 接口标题
        operation_summary='用户微信手机号(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def update(self, request, *args, **kwargs):
        user = request.user
        session_info = eval(redis_conn.get(redis_conn.get('ccsf_xcx_user_' + user.open_id)))
        session_key = session_info.get('session_key')
        encryptedData = request.data.get('encryptedData')
        iv = request.data.get('iv')
        if not all([encryptedData, iv]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)
        wx = WXDataCrypt(settings.APPID, session_key)
        # wx = WXDataCrypt('wx4f4bc4dec97d474b', session_key)
        try:
            user_info = wx.decrypt(encryptedData, iv)
        except Exception as e:
            logger.warning(e, exc_info=True)
            return Response(data={"detail": "解析用户信息失败！"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user.mobile = user_info['purePhoneNumber']
            user.save()
        except Exception:
            logger.warning('手机号修改失败', exc_info=True)
            return Response(data={"detail": "手机号已绑定！"}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'detail': '成功'}, status=status.HTTP_200_OK)


class UpdatePhotoView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""更新微信头像""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['avatar_url'],
            properties={
                'avatar_url': openapi.Schema(type=openapi.TYPE_STRING, description='头像url')
            }
        ),
        # 接口标题
        operation_summary='更新用户微信头像(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def put(self, request, *args, **kwargs):
        avatar_url = request.data.get('avatar_url')
        if not avatar_url:
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        user = request.user
        user.avatar_url = avatar_url
        user.save()
        return Response(status=status.HTTP_200_OK)


# class AccountInfoView(ModelViewSet):
#
#     def get_serializer_class(self):
#         return serializers.AccountSerializer
#
#     def create(self, request, *args, **kwargs):
#         user = request.user
#         data = request.data
#         data['']
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         self.perform_create(serializer)
#         headers = self.get_success_headers(serializer.data)
#         return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class BackendUserAuthView(APIView):

    def my_md5(self, jwt):
        md = hashlib.md5()
        md.update(jwt.encode(encoding='utf-8'))
        md5_str = md.hexdigest()
        return md5_str

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""登录""",
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['username', 'password'],
            properties={
                'username': openapi.Schema(type=openapi.TYPE_STRING, description='用户名'),
                'password': openapi.Schema(type=openapi.TYPE_STRING, description='密码')
            }
        ),
        # 接口标题
        operation_summary='后台登录(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def post(self, request, *args, **kwargs):
        # 参数验证
        username = request.data.get("username")
        password = request.data.get("password")
        if not all([username, password]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        # 密码及用户校验
        try:
            user = AccountModel.objects.get(username=username)
        except Exception:
            return Response(data={"detail": "账号不存在"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if not user.check_password(password):
                return Response(data={"detail": "密码不正确"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                if user.is_active and user.is_staff:
                    request.user = user
                    # 手动生成token验证
                    jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
                    jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
                    payload = jwt_payload_handler(user)
                    token = jwt_encode_handler(payload)
                    md5_str = self.my_md5(token)
                    val = {"token": token, "username": user.username, "user_id": user.id}
                    redis_conn.set(md5_str, str(val), settings.PC_EXP_SECOND)
                    redis_conn.set('ccsf_bkd_user_' + str(user.id) + '_' + md5_str, md5_str, settings.PC_EXP_SECOND)

                    ret = {
                        'token': 'JWT ' + md5_str,
                        'username': user.username,
                        'user_id': user.id,
                        'is_active': user.is_active,
                        'is_superuser': user.is_superuser,
                        'hospital_id': user.hospital_id if user.is_superuser else None,
                    }
                    user.last_login = timezone.now()
                    user.save(update_fields=['last_login'])
                    return Response(data=ret)
                else:
                    return Response(data={"detail": "用户未激活"}, status=status.HTTP_400_BAD_REQUEST)

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.check_throttles(request)


class BackendUserLogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""退出""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='退出(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def delete(self, request, *args, **kwargs):
        user_id = request.user.id
        token = request.META.get('HTTP_AUTHORIZATION').replace('JWT ', '')
        redis_conn.delete(token)
        redis_conn.delete('ccsf_bkd_user_' + user_id + '_' + token)
        return Response(data={'detail': '成功'}, status=status.HTTP_200_OK)

@method_decorator(swagger_auto_schema(
    operation_description="""首页图标""",
    operation_summary='首页图标',  # 接口标题
    tags=['首页图标'],   # 分组中
),
    name='get'
)
class HomePageIconView(ListAPIView):
    pagination_class = None
    serializer_class = HomePageIconSerializer

    def get_queryset(self):
        return HomePageIconModel.objects.all()

    def list(self, request, *args, **kwargs):
        data1 = HomePageIconModel.objects.order_by('serial_num').filter(type=1)
        data2 = HomePageIconModel.objects.order_by('serial_num').filter(type=2)
        data = {}
        data['data1'] = HomePageIconSerializer(data1, many=True).data
        data['data2'] = HomePageIconSerializer(data2, many=True).data
        return Response(data=data, status=status.HTTP_200_OK)


class BackendUserInfoView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        queryset = AccountModel.objects.filter(is_staff=True)
        query_params = self.request.query_params
        username = query_params.get('username')
        if username:
            queryset = queryset.filter(username__contains=username)
        return queryset
    #
    def get_serializer_class(self):
        return serializers.BackendUserInfoSerializers

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""列表""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='列表(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def list(self, request, *args, **kwargs):
        return super(BackendUserInfoView, self).list(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""添加""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['username', 'is_active'],
            properties={
                'username': openapi.Schema(type=openapi.TYPE_STRING, description='用户名'),
                'hospital_id': openapi.Schema(type=openapi.TYPE_STRING, description='医院id'),
                'gender': openapi.Schema(type=openapi.TYPE_INTEGER, description='性别'),
                'is_active': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='是否激活'),
                'mobile': openapi.Schema(type=openapi.TYPE_STRING, description='手机号'),
                'note': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
            }
        ),
        # 接口标题
        operation_summary='添加(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def create(self, request, *args, **kwargs):
        request.data['password'] = make_password(request.data.get('username', 'username'))
        request.data['is_staff'] = True
        if request.data.get('mobile') == '':
            del request.data['mobile']
        if not request.data.get('hospital_id'):
            request.data['is_superuser'] = True
        return super(BackendUserInfoView, self).create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        return super(BackendUserInfoView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户详细信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='用户详细信息(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def retrieve(self, request, *args, **kwargs):
        return super(BackendUserInfoView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""删除用户""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='删除用户(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def destroy(self, request, *args, **kwargs):
        user = request.user
        instance = self.get_object()
        if user.id == instance.id:
            return Response({'detail': '当前登录账号不允许被删除'}, status=status.HTTP_400_BAD_REQUEST)
        return super(BackendUserInfoView, self).destroy(request, *args, **kwargs)


class ChangeUserPwdView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""修改密码""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['old_password', 'new_password'],
            properties={
                'old_password': openapi.Schema(type=openapi.TYPE_STRING, description='原始密码'),
                'new_password': openapi.Schema(type=openapi.TYPE_STRING, description='新密码'),
            }
        ),
        # 接口标题
        operation_summary='修改密码(zwz)',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['后台用户']
    )
    def put(self, request, *args, **kwargs):
        data = request.data
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        if not all([old_password, new_password]):
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        user = request.user
        ret = user.check_password(old_password)
        # 密码正确修改密码,清楚当前登录用户token
        if ret:
            if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', new_password):
                detail = {'detail': '新密码长度为6到18位字母加数字组合'}
                return Response(detail, status=status.HTTP_400_BAD_REQUEST)
            new_password = make_password(new_password)
            user.password = new_password
            user.save()
            bkd_login_keys = redis_conn.keys('ccsf_bkd_user_' + user.id + '_' + '*')
            if bkd_login_keys:
                for bkd_login_key in bkd_login_keys:
                    token = redis_conn.get(bkd_login_key)
                    redis_conn.delete(token)
                    redis_conn.delete(bkd_login_key)
        else:
            return Response({'detail': '原始密码不正确,请重新输入'}, status=status.HTTP_400_BAD_REQUEST)

        return Response(status=status.HTTP_200_OK)