#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/12/9上午10:52
#@Author:zwz
from django.urls import path

from user.views import UserAuthView, UserLogoutView, UpdatePhoneView, UserInfoView, HomePageIconView, \
    BackendUserAuthView, BackendUserInfoView, ChangeUserPwdView, UpdatePhotoView, BackendUserLogoutView

urlpatterns = [
    path('login', UserAuthView.as_view()),
    path('logout', UserLogoutView.as_view()),
    path('info', UserInfoView.as_view({'get': 'retrieve','put': 'update'})),
    path('update_phone/<uuid:pk>', UpdatePhoneView.as_view({'put': 'update'})),
    path('update_photo', UpdatePhotoView.as_view()),
    path('home_page_icon', HomePageIconView.as_view()),  # 首页图标

    # 后台
    path('bkd_login', BackendUserAuthView.as_view()),
    path('bkd_logout', BackendUserLogoutView.as_view()),
    path('info_bkd', BackendUserInfoView.as_view({'get': 'list', 'post': 'create'})),
    path('info_bkd/<pk>', BackendUserInfoView.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'})),
    path('change_pwd', ChangeUserPwdView.as_view()),

]