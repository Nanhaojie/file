/*!40101 SET NAMES utf8mb4 */;
create database if not exists long_follow_up default character set = 'utf8mb4' DEFAULT COLLATE 'utf8mb4_general_ci';