#!/bin/bash
docker-compose -f docker-compose.yaml build --no-cache --force-rm
docker-compose -f docker-compose.yaml up -d

# 初始化数据库
dir=`ls ./mysql/sql_init_tb/*`
sleep 20
for file in $dir
do
    docker exec -i long-follow-mysql mysql -uroot -proot12300. -Dlong_follow_up<$file
done
exit;