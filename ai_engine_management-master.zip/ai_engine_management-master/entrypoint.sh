#!/bin/bash
pip install -r app/requirements.txt -i https://pypi.douban.com/simple
aerich upgrade
gunicorn main:app -w 1 -b 0.0.0.0:8001 -k uvicorn.workers.UvicornWorker --timeout 60 --max-requests 5000 --log-file - 2>> /data/logs/uvicorn_err.log
