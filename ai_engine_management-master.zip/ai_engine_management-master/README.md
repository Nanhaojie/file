## 自学习v1.0
> 该项目现在主要功能有： 
> 为后台人脸审核提供相似人脸推荐；
> 由于模型重新部署之后，该服务的模型也可能重新部署，因此提供了方便重置人脸底板数据的接口；
> 人脸审核通过的数据存储的任务；方便后续集成模型的自动化训练；（为人脸推荐服务提供支撑）
> 用户人脸数据同步的任务；（维护其自身的人脸库）
> [待开发] 模型自动化训练
> 
> [自学习整体架构](https://zoneyet-ai.feishu.cn/mindnotes/bmncnHDRlPAsH1tavwPXA276W6g#mindmap)


```bash
# aerich初始化
aerich init -t app.db.database.TORTOISE_ORM
# 初始化数据库
aerich init-db
# 生成迁移文件
aerich migrate
# 执行迁移生成表
aerich upgrade

# 初始化容器（不适用该方式）
# docker run -e "ENVIRONMENT=testing" -d -v /data/logs/eeg_struct_report:/data/logs -v /opt/apps/ai_engine_management:/usr/src/app --name eeg-report-api -p8031:8001  tiangolo/uvicorn-gunicorn-fastapi:python3.7 /bin/sh -C ./entrypoint.sh

# 环境是基于手写AI的tensorrt环境搭建
[镜像源](https://hub.docker.com/r/hopef/tensorrt-pro)

# 项目部署启动
nohup bash -c "source /datav/software/anaconda3/bin/activate fastapi_trt_py39 && cd /datav/projects/ai_engine_management && gunicorn main:app -w 1 -b 0.0.0.0:8000 -k uvicorn.workers.UvicornWorker --timeout 60 --max-requests 5000 --log-file -" 2> /datav/projects/ai_engine_management/app/logs/self-learning-err.log &
```
