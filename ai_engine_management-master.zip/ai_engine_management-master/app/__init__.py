import asyncio
import logging
from functools import partial

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from starlette.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from app.middleware import middleware_init
from app.routers import router_init
from app.logs import log_init
from app.db.database import db_init
from app.tasks.train_data import TrainDataReceive

from app.utils.common_util import write_log

logger = logging.getLogger('fastapi')


def conf_init(app):
    from config import configs
    logger.info(msg=f'Start app with {configs.ENVIRONMENT} environment')
    if configs.ENVIRONMENT == 'production':
        app.docs_url = None
        app.redoc_url = None
        app.debug = False


async def start_event(app: FastAPI):
    from app.utils.face_detection import HumanFaceDetection
    from app.tasks.face_template import FaceTemplateTask

    # 初始化全局人脸模型类
    app.state.face_detector = await HumanFaceDetection()
    # 创建同步人脸数据的任务
    face_template_task = await FaceTemplateTask(app.state.face_detector)
    asyncio.create_task(face_template_task.run())
    # 训练数据同步任务
    train_data_receive_task = await TrainDataReceive()
    asyncio.create_task(train_data_receive_task.run())


async def shutdown_event():
    await write_log(msg='系统关闭')


async def on_api_exception(request: Request, exception: Exception) -> JSONResponse:
    logger.exception(exception)
    return JSONResponse({'msg': '请稍后重试', 'code': 500}, status_code=200)


async def http_exception_handler(request: Request, exception: StarletteHTTPException) -> JSONResponse:
    return JSONResponse({'msg': exception.detail, 'code': exception.status_code}, status_code=200)


async def validate_exception_handler(request: Request, exception: RequestValidationError) -> JSONResponse:
    return JSONResponse({'msg': str(exception), 'code': 400}, status_code=200)


def create_app():
    app = FastAPI(
        title="fastapi文档",
        description="文档描述",
        version="1.0.0",
        # on_startup=[start_event],
        # on_shutdown=[shutdown_event]
    )

    # 初始化日志
    log_init()

    # 建表
    db_init(app)

    # 加载配置
    conf_init(app)

    # 初始化中间件
    middleware_init(app)

    # 初始化路由配置
    router_init(app)

    # 启动钩子
    app.add_event_handler(event_type="startup", func=partial(start_event, app=app))

    # 异常处理
    app.add_exception_handler(Exception, on_api_exception)
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validate_exception_handler)
    # app.add_exception_handler(tortoise.exceptions, orm_exception_handler)

    return app
