import logging
import os
import time

from config import configs

# 日志配置
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,  # 是否禁用已经存在的日志器
    'formatters': {  # 日志信息显示的格式
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(lineno)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(module)s %(lineno)d %(message)s'
        },
        # 详细的日志格式
        'standard': {
            'format': '%(asctime)s - %(process)d - %(pathname)s:%(lineno)d - %(levelname)s: %(message)s'
        }
    },
    # 'filters': {  # 对日志进行过滤
    #     'require_debug_true': {
    #         '()': 'app.logs.RequireDebugTrue',
    #     },
    #     'require_debug_false': {
    #         '()': 'app.logs.RequireDebugFalse',
    #     }
    # },
    'handlers': {  # 日志处理方法
        # 默认记录所有日志
        'default': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(
                configs.LOG_FOLDER_PATH,
                'all-{}.log'.format(time.strftime(configs.SERIALIZER_DATE_FIELD_FORMAT))
            ),
            'maxBytes': 1024 * 1024 * 500,  # 文件大小  500M
            'backupCount': 5,  # 备份数
            'formatter': 'standard',  # 输出格式
            'encoding': 'utf-8',  # 设置默认编码，否则打印出来汉字乱码
        },
        'console': {  # 向终端中输出日志
            'level': 'INFO',
            # 'filters': ['require_debug_true'],
            'class': 'logging.StreamHandler',
            'formatter': 'standard'
        },
    },
    'loggers': {  # 日志器
        'fastapi': {  # 定义了一个名为fastapi的日志器
            'handlers': ['console' if configs.ENVIRONMENT == 'development' else 'default'],  # 可以同时向终端与文件中输出日志
            'propagate': True,  # 是否继续传递日志信息
            'level': 'INFO',  # 日志器接收的最低日志级别
        },
    }
}


# class RequireDebugFalse(logging.Filter):
#     def filter(self, record):
#         return not configs.DEBUG
#
#
# class RequireDebugTrue(logging.Filter):
#     def filter(self, record):
#         return configs.DEBUG


def log_init():
    logging.config.dictConfig(LOGGING)
