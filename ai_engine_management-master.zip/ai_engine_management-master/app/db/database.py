from tortoise.contrib.fastapi import register_tortoise

from config import configs

# mysql数据库url
DATABASE_URL = "mysql://{}:{}@{}:{}/{}?charset=utf8mb4".format(configs.MYSQL_USER, configs.MYSQL_PASSWORD, configs.MYSQL_SERVER,
                                                               configs.MYSQL_PORT, configs.MYSQL_DB_NAME)

# 数据库迁移配置
TORTOISE_ORM = {
    "connections": {
        "default": DATABASE_URL
    },
    "apps": {
        "models": {
            "models": ["aerich.models", "app.models.models"],
            # "models": ["aerich.models"],
            # 须添加“aerich.models” 后者“models”是上述models.py文件的路径
            "default_connection": "default",
        },
    },
    'use_tz': False,
    'timezone': 'Asia/Shanghai'
}


def db_init(app):
    register_tortoise(
        app,
        config=TORTOISE_ORM,
        # generate_schemas=True,
        add_exception_handlers=True,
    )


if __name__ == "__main__":
    token = {
        "expiredTime": "1506433269",
        "expiration": "2017-09-26T13:41:09Z",
        "credentials": {
            "sessionToken": "sdadffwe2323er4323423",
            "tmpSecretId": "VpxrX0IMC pHXWL0Wr3KQNCqJix1uhMqD",
            "tmpSecretKey": "VpxrX0IMC pHXWL0Wr3KQNCqJix1uhMqD"
        }
    }

    # import pickle

    # redis_session.setex("user", 100, pickle.dumps(token))
    # print(pickle.loads(redis_session.get("user")))
