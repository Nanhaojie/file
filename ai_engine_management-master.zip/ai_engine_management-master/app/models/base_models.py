# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 3/17/22 7:11 PM
# @author yueyuanbo
from tortoise import models
from tortoise import fields

from config import configs


class BaseDBModel(models.Model):
    id = fields.BigIntField(pk=True, index=True)
    spare_str1 = fields.CharField(max_length=512, null=True)
    spare_str2 = fields.CharField(max_length=512, null=True)
    spare_str3 = fields.CharField(max_length=512, null=True)
    spare_int1 = fields.IntField(null=True)
    spare_int2 = fields.IntField(null=True)
    spare_int3 = fields.IntField(null=True)

    async def to_dict(self):
        d = {}
        for field in self._meta.db_fields:
            d[field] = getattr(self, field)
        for field in self._meta.backward_fk_fields:
            d[field] = await getattr(self, field).all().values()
        return d

    class Meta:
        abstract = True

    class PydanticMeta:
        exclude = ["spare_str1", "spare_str2", "spare_str3", "spare_int1", "spare_int2", "spare_int3"]


class BaseUUIDDBModel(BaseDBModel):
    id = fields.UUIDField(pk=True, generated=False)

    class Meta:
        abstract = True


class BaseCreatTimeModel:
    create_time = fields.DatetimeField(auto_now_add=True)

    def create_time_str(self) -> str:
        return self.create_time.strftime(configs.SERIALIZER_DATE_TIME_FIELD_FORMAT)

    class Meta:
        abstract = True


class BaseCreatedUpdatedTimeModel:
    create_time = fields.DatetimeField(auto_now_add=True)
    update_time = fields.DatetimeField(auto_now=True)

    def create_time_str(self) -> str:
        return self.create_time.strftime(configs.SERIALIZER_DATE_TIME_FIELD_FORMAT)

    def update_time_str(self) -> str:
        return self.update_time.strftime(configs.SERIALIZER_DATE_TIME_FIELD_FORMAT)

    class Meta:
        abstract = True
