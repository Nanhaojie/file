# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 3/17/22 7:12 PM
# @author yueyuanbo
from enum import IntEnum

import pydantic
from tortoise import fields, models
from tortoise.contrib.pydantic import pydantic_model_creator
from tortoise.fields import SET_NULL, CASCADE

from config import configs
from .base_models import BaseDBModel, BaseUUIDDBModel, BaseCreatedUpdatedTimeModel, BaseCreatTimeModel


class SourceMaterial(BaseDBModel, BaseCreatTimeModel):
    """训练数据素材表"""
    user_id = fields.CharField(max_length=32, index=True, description='用户id')
    scene_id = fields.IntField(description='场景id')
    wonderful_video_ret_id = fields.CharField(max_length=32, description='游玩记录id')
    detection_model = fields.SmallIntField(description='所训练模型id ;人脸检测模型:1; 行人检测模型:2;  tf-serving 目标检测: 3')
    img_url = fields.CharField(max_length=512, null=True, description='数据链接')

    class Meta:
        table = 't_source_material'


# class User(BaseUUIDDBModel):
#     """用户信息表"""
#     username = fields.CharField(max_length=128, unique=True)
#     realname = fields.CharField(max_length=128)
#     password = fields.CharField(max_length=128, null=True)
#     mobile = fields.CharField(max_length=16, null=True)
#     is_active = fields.BooleanField(default=True)
#     is_superuser = fields.BooleanField(default=False)
#     date_joined = fields.DatetimeField(auto_now_add=True)
#     last_login = fields.DatetimeField(null=True)
#
#     class Meta:
#         table = 't_user'
#         ordering = ['-date_joined']

# class EEGBaseReport(BaseUUIDDBModel, BaseCreatedUpdatedTimeModel):
#     """eeg基础信息表"""
#     his_id = fields.CharField(max_length=20, description='HIS患者号')
#     name = fields.CharField(max_length=128, description='患者名字')
#     birthdate = fields.DateField(description='出生日期')
#     age = fields.CharField(max_length=16, null=True, description='年龄')
#     sex = fields.SmallIntField(default=1, description='性别（1，男）（2， 女）（9，未知）')
#     moblie = fields.CharField(max_length=25, null=True, description='手机号')
#     handedness = fields.SmallIntField(null=True, description='利手（1，右利手）（2，左利手）（3，两利手）')
#     nation = fields.CharField(max_length=15, null=True, description='民族')
#     native_place = fields.CharField(max_length=32, null=True, description='籍贯')
#     id_number = fields.CharField(max_length=18, null=True, description='身份证号')
#     home_address = fields.CharField(max_length=100, null=True, description='家庭住址')
#     case_number = fields.CharField(max_length=20, null=True, description='病历号')
#     inpatient_no = fields.CharField(max_length=15, null=True, description='住院号')
#     bed_number = fields.CharField(max_length=10, null=True, description='床号')
#     department_number = fields.CharField(max_length=20, null=True, description='门诊号')
#     carte_vital_number = fields.CharField(max_length=20, null=True, description='医保卡号')
#     is_insure = fields.CharField(max_length=8, null=True, description='是否医保 (0, 未投保)（1，投保）（2，未知）')
#     patient_note = fields.CharField(max_length=100, null=True, description='患者备注')
#     eeg_code = fields.CharField(max_length=15, description='脑电图号')
#     test_time = fields.DatetimeField(description='检查时间')
#     test_project = fields.CharField(max_length=25, description='检查项目')
#     conscious_state = fields.CharField(max_length=15, null=True, description='意识状态')
#     emg_position = fields.CharField(max_length=500, null=True, description='eeg位置')
#     docker_name = fields.CharField(max_length=25, null=True, description='检查医生')
#     eeg_technician = fields.CharField(max_length=25, null=True, description='脑电图技师')
#     application_department = fields.CharField(max_length=15, null=True, description='申请科室')
#     application_doctor = fields.CharField(max_length=25, null=True, description='申请医生')
#     electrode_placement = fields.CharField(max_length=15, null=True, description='电极安置')
#     special_electrode = fields.CharField(max_length=15, null=True, description='特殊电极')
#     clinical_medication = fields.CharField(max_length=500, null=True, description='临床用药')
#     clinical_diagnosis = fields.CharField(max_length=200, null=True, description='临床诊断')
#     test_note = fields.CharField(max_length=100, null=True, description='检测信息备注')
#     is_delete = fields.BooleanField(default=False)
#     user = fields.ForeignKeyField('models.User', on_delete=SET_NULL, related_name='eeg_reports', null=True,
#                                   db_constraint=False, description='创建者')
#
#     def test_time_str(self) -> str:
#         return self.test_time.strftime(configs.SERIALIZER_DATE_TIME_FIELD_FORMAT)
#
#     def create_time_str(self) -> str:
#         return self.creat_time.strftime(configs.SERIALIZER_DATE_TIME_FIELD_FORMAT)
#
#     def user_name(self) -> str:
#         """创建报告的用户"""
#         return self.user.realname
#
#     class Meta:
#         table = 't_eeg_base_report'
#         ordering = ['-creat_time']
#
#     class PydanticMeta:
#         # computed = ["test_time_str", "create_time_str", "user_name"]
#         exclude = ["update_time", "is_delete", "spare_str1", "spare_str2", "spare_str3", "spare_int1", "spare_int2",
#                    "spare_int3"]
#
#
# class EEGReportDetail(BaseUUIDDBModel, BaseCreatTimeModel):
#     """eeg报告详情"""
#     eeg_base_report = fields.ForeignKeyField('models.EEGBaseReport', on_delete=CASCADE, related_name='detail',
#                                              db_constraint=False)
#     content = fields.CharField(max_length=300, null=True)
#     report_option = fields.ForeignKeyField('models.ReportOption', on_delete=SET_NULL, related_name='detail', null=True,
#                                            db_constraint=False)
#
#     def report_option_name(self) -> str:
#         return self.report_option.name
#
#     def report_option_id(self) -> str:
#         return self.report_option.id
#
#     class Meta:
#         table = 't_eeg_report_detail'
#         ordering = ['creat_time']
#
#     class PydanticMeta:
#         exclude = ["creat_time", "spare_str1", "spare_str2", "spare_str3", "spare_int1", "spare_int2", "spare_int3"]
#
#
#
#
# EEGReportDetailOutSchemas = pydantic_model_creator(EEGReportDetail, name="EEGReportDetail",
#                                                    computed=("report_option_id", "report_option_name"))
# EEGReportDetailInSchemas = pydantic_model_creator(EEGReportDetail, name="EEGReportDetail")
#
# # 忽略多余参数
# EEGReportDetailOutSchemas.Config.extra = pydantic.main.Extra.ignore
# EEGReportDetailInSchemas.Config.extra = pydantic.main.Extra.ignore
