# !/usr/bin/env python
#  -*- coding:utf-8 -*-
# @Time      :2022/05/07 11:52:58
# @Author    :yueyuanbo
from typing import Optional
from fastapi import Body, Request, Depends, Query

from pydantic import BaseModel, Field

from app.schemas.base import Response
from app.utils.face_detection import HumanFaceDetection


class FaceRecommendData(BaseModel):
    user_id: str = Field(None, title="用户id")
    url: str = Field(None, title="用户人脸照片url")


class FaceRecommendResponse(Response):
    data: Optional[list[FaceRecommendData]]


def get_face_detector(request: Request) -> HumanFaceDetection:
    return request.app.state.face_detector


class FaceRecommendRequestData:

    def __init__(self,
                 face_url: str = Query(..., description='人脸照片链接'),
                 face_detector: HumanFaceDetection = Depends(get_face_detector)):
        self.face_url = face_url
        self.face_detector = face_detector
