# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 3/18/22 6:10 PM
# @author yueyuanbo
from pydantic import BaseModel


class Response(BaseModel):
    code: int
    msg: str
