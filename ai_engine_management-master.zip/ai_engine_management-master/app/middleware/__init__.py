import logging

from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

logger = logging.getLogger('fastapi')


async def request_log(request: Request, call_next):
    response = await call_next(request)
    try:
        logger.info(f'{request.method} {request.url.path}?{request.url.query} {response.status_code} '
                    # f'[request_body:{await request.body()}] '  # 不能打印请求体
                    f'{request.headers}'[:5000])
    except Exception:
        logger.exception('日志出错')
    return response


def middleware_init(app):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(BaseHTTPMiddleware, dispatch=request_log)
