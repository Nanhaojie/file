# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 4/28/22 3:31 PM
# @author yueyuanbo
import asyncio
import logging
import time

import aiohttp
import aiofile
import sys

import cv2
import os
import numpy as np
import aioredis
import json

logger = logging.getLogger('fastapi')


class HumanFaceDetection(object):

    def __init__(self, ):
        from config import configs
        self.model_file_root = './app/engin_file/'
        # 人脸识别模型信息
        self.face_recognition_engin_file_url = 'http://aisource.trycan.com/engin/ai_self_learning/face_recognition/trt/arcface.web.trtmodel'
        self.face_recognition_engin_file_name = 'arcface.trtmodel'
        # 人脸检测模型信息
        self.face_detection_engin_file_url = 'http://aisource.trycan.com/engin/ai_self_learning/face_detection/trt/retinaface.960x960.fp32.trtmodel'
        self.face_detection_engin_file_name = 'retinaface.trtmodel'
        self.redis_conn = aioredis.from_url(
            f"redis://:{configs.REDIS_PASSWORD}@{configs.REDIS_HOST}:{configs.REDIS_PORT}/{configs.REDIS_DB}",
            decode_responses=True)
        self.face_template_redis_key = configs.FACE_TEMPLATE_REDIS_KEY

    def __await__(self):
        """需要异步的初始化属性"""
        # 初始化模型文件
        yield from asyncio.create_task(self.init_model_file())
        self.load_model()
        return self

    async def init_model_file(self):
        for engin_file_name, engin_file_url in [(self.face_detection_engin_file_name, self.face_detection_engin_file_url),
                                                (self.face_recognition_engin_file_name, self.face_recognition_engin_file_url)]:
            if not os.path.exists(os.path.join(self.model_file_root, engin_file_name)):
                logger.info('开始从外网拉取模型文件')
                async with aiohttp.ClientSession() as session:
                    async with session.get(engin_file_url) as resp:
                        async with aiofile.async_open(os.path.join(self.model_file_root, engin_file_name), 'wb+') as f:
                            async for chunk in resp.content.iter_chunked(5120):
                                await f.write(chunk)
        logger.info('模型文件拉取成功！')
        return

    def load_model(self):
        from app.utils import trtpy as tp
        # 加载人脸识别引擎
        self.face_recognition_engin = tp.Arcface(os.path.join(self.model_file_root, self.face_recognition_engin_file_name))
        # 加载人脸检测模型
        self.face_detect_engin = tp.Retinaface(os.path.join(self.model_file_root, self.face_detection_engin_file_name),
                                               nms_threshold=0.6,
                                               confidence_threshold=0.9)

    @staticmethod
    def get_candinator(emb, user_id_list, face_url_list, characteristic_list, kth, threshold=4):
        try:
            dists = np.sum(np.square(np.array(characteristic_list) - emb), axis=2)  # type np.array
            dists = dists.reshape(dists.size)
            if dists.size - 1 < kth:
                index_array = np.array([index for index in range(dists.size)])
            else:
                index_array = np.argpartition(dists, kth)[:kth]
            index_array = index_array[dists[index_array] < threshold]
            return np.array(user_id_list)[index_array].tolist(), np.array(face_url_list)[index_array].tolist()
        except Exception:
            logger.warning('比对人脸数据失败', exc_info=True)
            return [], []

    async def infer(self, frame):
        user_id_list = list()
        user_blank_data_list = list()
        face_url_list = list()
        async with self.redis_conn as redis_conn:
            for user_face_data_str in await redis_conn.hvals(self.face_template_redis_key):
                user_face_data_dict = json.loads(user_face_data_str)
                user_id_list.append(user_face_data_dict.get('user_id'))
                user_blank_data_list.append(user_face_data_dict.get('characteristic'))
                face_url_list.append(user_face_data_dict.get('url'))

        if not user_id_list:
            return []

        faces = self.face_detect_engin.commit(frame).get()
        if len(faces) > 0:
            user_datas = []
            for face in faces:
                if (face.right - face.left) * (face.bottom - face.top) < 500000:
                    embedding = self.face_recognition_engin.commit(frame, face.landmark).get()
                    # 先使用活跃用户
                    user_id_list, url_list = self.get_candinator(embedding[0], user_id_list, face_url_list,
                                                                 user_blank_data_list, 5)
                    for index, user_id in enumerate(user_id_list):
                        user_datas.append({'user_id': user_id, 'url': url_list[index]})
            return user_datas
        return []

    async def face_embedding(self, image_array: np.array):
        faces = self.face_detect_engin.commit(image_array).get()
        if len(faces) == 1:
            face = faces[0]
        elif len(faces) > 1:
            face = sorted(faces, key=lambda face: (face.right - face.left) * (face.bottom - face.top), reverse=True)[0]
        else:
            logger.warning('未检测到人脸')
            return
        return self.face_recognition_engin.commit(image_array, face.landmark).get()

    @staticmethod
    async def cv_url_read(image_url: str) -> np.array:
        async with aiohttp.ClientSession() as session:
            async with session.get(image_url) as res:
                image_bytes = await res.content.read()
        # 图片类型转换
        return cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)


if __name__ == '__main__':
    import sys
    import os
    current_file_path = os.path.abspath(__file__)
    project_base_path = os.path.dirname(os.path.dirname(os.path.dirname(current_file_path)))
    os.chdir(project_base_path)
    sys.path.insert(0, project_base_path)

    async def face_recommand():
        face_detection = await HumanFaceDetection()
        async with aiohttp.ClientSession() as session:
            async with session.get('http://aisource.trycan.com/mysp/face/91663405f59c4dc2443867a808c4f8cef4db03d7') as res:
                img_bytes = await res.content.read()

        image = np.asarray(bytearray(img_bytes), dtype="uint8")
        image = cv2.imdecode(image, cv2.IMREAD_COLOR)
        return await face_detection.infer(image)

    print(asyncio.run(face_recommand()))
