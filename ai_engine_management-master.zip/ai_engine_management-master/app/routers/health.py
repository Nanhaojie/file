# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 4/28/22 4:18 PM
# @author yueyuanbo
from fastapi import APIRouter

from app.schemas.base import Response

router = APIRouter()


@router.get("/health", response_model=Response)
async def health_status():
    return {"code": 200, "msg": "成功"}
