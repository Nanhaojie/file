# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 4/28/22 4:57 PM
# @author yueyuanbo
import json
import logging
from multiprocessing.connection import wait
from sys import exc_info
import aiohttp
import aioredis
from fastapi import APIRouter, Depends, Request
from fastapi.params import File
import cv2
import numpy as np

from app.schemas.face_detection import FaceRecommendResponse, FaceRecommendRequestData, get_face_detector
from app.utils.face_detection import HumanFaceDetection

router = APIRouter()

logger = logging.getLogger('fastapi')


@router.get("/face/recommend", response_model=FaceRecommendResponse)
async def face_recommend(data: FaceRecommendRequestData = Depends()):
    # url = 'http://aisource.trycan.com/mysp/face/cadd87228fd4be0bcd9159649b6fc872298e7cd3'  # yue
    # url = 'http://aisource.trycan.com/mysp/face/91663405f59c4dc2443867a808c4f8cef4db03d7'  # zhy
    try:
        image_array = await data.face_detector.cv_url_read(data.face_url)
    except Exception:
        logger.warning("从链接中按照opencv方式读取数据失败", exc_info=True)
        return {"code": 400, "msg": "链接异常"}
    ret = await data.face_detector.infer(image_array)
    return {"code": 200, "msg": "成功", "data": ret}


@router.put("/face/init_face_template")
async def face_recommend(face_detector: HumanFaceDetection = Depends(get_face_detector)):
    """重置人脸底板数据"""
    # 从redis中scan数据
    async with face_detector.redis_conn as redis_conn:
        cursor = None
        while cursor != 0:
            cursor, face_template_data = await redis_conn.hscan(face_detector.face_template_redis_key, cursor or 0, count=100)
            for face_key, face_template_value in face_template_data.items():
                # 读取url中数据
                face_template_value = json.loads(face_template_value)
                face_url = face_template_value.get("url")
                try:
                    image_array = await face_detector.cv_url_read(face_url)
                except Exception:
                    logger.warning("从链接中按照opencv方式读取数据失败", exc_info=True)
                else:
                    # 根据模型重新生成数据
                    embedding = await face_detector.face_embedding(image_array)
                    if embedding is not None:
                        face_template_value["characteristic"] = embedding.tolist()
                        face_template_data[face_key] = json.dumps(face_template_value)
            # 存储新生成的数据
            await redis_conn.hset(face_detector.face_template_redis_key, mapping=face_template_data)
    return {"code": 200, "msg": "成功"}
