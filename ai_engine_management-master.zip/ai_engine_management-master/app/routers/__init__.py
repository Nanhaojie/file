# !/usr/bin/env python
#  -*- coding:utf-8 -*-
# @Time      :2022/04/29 13:52:10
# @Author    :yueyuanbo

from app.routers import health, face_detection
from config import configs


def register_router(app, router, tags):
    app.include_router(
        router,
        prefix=configs.API_V1_STR,
        tags=tags,
        responses={404: {
            "description": "Not found"
        }},
    )


def router_init(app):
    register_router(app, health.router, ["测试代码"])
    register_router(app, face_detection.router, ["测试代码"])
