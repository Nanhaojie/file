# !/usr/bin/env python
#  -*- coding:utf-8 -*-
# @Time      :2022/05/06 14:44:57
# @Author    :yueyuanbo
import logging
from aiokafka import AIOKafkaConsumer
import asyncio
import json
import aiohttp
import numpy as np
import cv2
import aioredis

logger = logging.getLogger('fastapi')


class FaceTemplateTask:

    def __init__(self, face_detector):
        self.face_detector = face_detector

    def __await__(self):
        return self.initialize().__await__()

    async def initialize(self):
        from config import configs
        # 初始化 kafka
        self.model_frame_kafka_con = AIOKafkaConsumer(configs.FACE_APPEND_TOPIC,
                                                      bootstrap_servers=configs.YUN_KAFKA_SERVERS,
                                                      value_deserializer=lambda x: json.loads(x),
                                                      group_id='ai-self-learning',
                                                      auto_offset_reset='latest')  # todo
        # auto_offset_reset='earliest')
        await self.model_frame_kafka_con.start()
        # 初始化 redis
        self.redis_conn = await aioredis.from_url(
            f"redis://:{configs.REDIS_PASSWORD}@{configs.REDIS_HOST}:{configs.REDIS_PORT}/{configs.REDIS_DB}",
            decode_responses=True)
        return self

    async def stroge_face_template(self, image_url, user_id, face_type):
        async with aiohttp.ClientSession() as session:
            async with session.get(image_url) as res:
                image_bytes = await res.content.read()
        # 图片类型转换
        img_raw = cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)
        embedding = await self.face_detector.face_embedding(img_raw)
        if embedding is None:
            return
        await self.redis_conn.hset(self.face_detector.face_template_redis_key,
                                   key=user_id + '_' + str(face_type),
                                   value=json.dumps({
                                       "user_id": user_id,
                                       "url": image_url,
                                       "characteristic": embedding.tolist(),
                                   }))

    async def run(self):
        logger.info(f"启动人脸数据同步任务")
        async for message in self.model_frame_kafka_con:
            try:
                for face_url in message.value.get('face_urls'):
                    await self.stroge_face_template(face_url, str(message.value.get('user_id')), message.value.get('type'))
            except:
                logger.error(f'人脸录入报错', exc_info=True)
            logger.info(f"{message.value.get('user_id')}人脸录入{message.value.get('face_urls')}")


if __name__ == '__main__':
    import sys
    import os
    current_file_path = os.path.abspath(__file__)
    project_base_path = os.path.dirname(os.path.dirname(os.path.dirname(current_file_path)))
    os.chdir(project_base_path)
    sys.path.insert(0, project_base_path)

    from app.utils.face_detection import HumanFaceDetection

    async def main():
        face_detector = await HumanFaceDetection()
        face_template_task = await FaceTemplateTask(face_detector)
        await face_template_task.run()

    asyncio.run(main())
