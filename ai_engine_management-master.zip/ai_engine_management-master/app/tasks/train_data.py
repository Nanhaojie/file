# !/usr/bin/env python
#  -*- coding:utf-8 -*-
# @Time      :2022/05/06 14:44:57
# @Author    :yueyuanbo
import logging
from aiokafka import AIOKafkaConsumer
import asyncio
import json
import aiohttp

logger = logging.getLogger('fastapi')


class TrainDataReceive:

    def __await__(self):
        return self.initialize().__await__()

    async def initialize(self):
        from config import configs
        # 初始化 kafka
        self.feed_data_kafka_con = AIOKafkaConsumer(
            configs.FEED_DATA_TOPIC,
            bootstrap_servers=configs.YUN_KAFKA_SERVERS,
            value_deserializer=lambda x: json.loads(x),
            group_id='ai-self-learning',
            #   auto_offset_reset='latest')  # todo
            auto_offset_reset='earliest')
        await self.feed_data_kafka_con.start()
        return self

    async def run(self):
        logger.info(f"启动训练数据同步任务")
        from app.models.models import SourceMaterial
        async for message in self.feed_data_kafka_con:
            source_material_set = list()
            # 增量添加数据，存在的不要
            for feed_data in message.value:
                if not await SourceMaterial.filter(id=feed_data.get('id')).exists():
                    source_material_set.append(SourceMaterial(**feed_data))
                else:
                    id = feed_data.pop('id')
                    await SourceMaterial.filter(id=id).update(**feed_data)
            await SourceMaterial.bulk_create(source_material_set)
        logger.info('批量创建数据')


if __name__ == '__main__':
    import sys
    import os
    from tortoise import Tortoise, run_async

    current_file_path = os.path.abspath(__file__)
    project_base_path = os.path.dirname(os.path.dirname(os.path.dirname(current_file_path)))
    os.chdir(project_base_path)
    sys.path.insert(0, project_base_path)

    from app.db.database import TORTOISE_ORM
    from config import configs

    async def main():
        await Tortoise.init(config=TORTOISE_ORM)
        train_data_receive_task = await TrainDataReceive()
        await train_data_receive_task.run()

    run_async(main())
