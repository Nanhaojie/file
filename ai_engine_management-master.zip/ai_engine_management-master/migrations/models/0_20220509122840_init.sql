-- upgrade --
CREATE TABLE IF NOT EXISTS `aerich` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `version` VARCHAR(255) NOT NULL,
    `app` VARCHAR(20) NOT NULL,
    `content` JSON NOT NULL
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `t_source_material` (
    `id` BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `spare_str1` VARCHAR(512),
    `spare_str2` VARCHAR(512),
    `spare_str3` VARCHAR(512),
    `spare_int1` INT,
    `spare_int2` INT,
    `spare_int3` INT,
    `creat_time` DATETIME(6) NOT NULL  DEFAULT CURRENT_TIMESTAMP(6),
    `user_id` VARCHAR(32) NOT NULL  COMMENT '用户id',
    `scene_id` INT NOT NULL  COMMENT '场景id',
    `wonderful_video_ret_id` VARCHAR(32) NOT NULL  COMMENT '游玩记录id',
    `detection_model` SMALLINT NOT NULL  COMMENT '所训练模型id ;人脸检测模型:1; 行人检测模型:2;  tf-serving 目标检测: 3',
    `img_url` VARCHAR(512)   COMMENT '数据链接',
    KEY `idx_t_source_ma_user_id_828d3a` (`user_id`)
) CHARACTER SET utf8mb4 COMMENT='训练数据素材表';
