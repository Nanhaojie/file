-- upgrade --
ALTER TABLE `t_source_material` CHANGE creat_time create_time DATETIME(6);
-- downgrade --
ALTER TABLE `t_source_material` CHANGE create_time creat_time DATETIME(6);
