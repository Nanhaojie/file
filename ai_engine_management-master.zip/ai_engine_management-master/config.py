import io
import logging
import os
import time
from contextlib import contextmanager
from functools import lru_cache
from io import StringIO
from typing import Optional

from dotenv.main import DotEnv
from pydantic import BaseSettings, Field

logger = logging.getLogger('fastapi')


def my_get_stream(self):
    """重写python-dotenv读取文件的方法，使用utf-8，支持读取包含中文的.env配置文件"""
    if isinstance(self.dotenv_path, StringIO):
        yield self.dotenv_path
    elif os.path.isfile(self.dotenv_path):
        with io.open(self.dotenv_path, encoding='utf-8') as stream:
            yield stream
    else:
        if self.verbose:
            logger.warning("File doesn't exist %s", self.dotenv_path)
        yield StringIO('')


DotEnv._get_stream = contextmanager(my_get_stream)


class Settings(BaseSettings):
    """System configurations."""

    # 系统环境
    ENVIRONMENT: Optional[str] = Field(None, env="ENVIRONMENT")

    # 系统安全秘钥
    SECRET_KEY = '82247e_3ba7f73fe1423_039827e69f46_f9364bc_3988bff'

    # API版本号
    API_V1_STR = "/api/v1.0/ai_self_learning"

    # token过期时间
    ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

    # 算法
    ALGORITHM = "HS256"

    # 日期格式化
    SERIALIZER_DATE_FIELD_FORMAT = "%Y-%m-%d"
    # 日期+时间格式化
    SERIALIZER_DATE_TIME_FIELD_FORMAT = "%Y-%m-%d %H:%M:%S"

    # 人脸模板rediskey
    FACE_TEMPLATE_REDIS_KEY = 'f_t'
    # 人脸数据的topic
    FACE_APPEND_TOPIC = 'face_append'
    #  训练数据topic
    FEED_DATA_TOPIC = 'feed_data'

    # 加载.env文件的配置
    class Config:
        env_file = os.path.join(os.path.dirname(__file__), '.env')
        case_sensitive = True


class DevConfig(Settings):
    """Development configurations."""

    # redis
    REDIS_HOST: Optional[str] = Field(None, env="DEV_REDIS_HOST")
    REDIS_PORT: Optional[int] = Field(None, env="DEV_REDIS_PORT")
    REDIS_USERNAME: Optional[str] = Field(None, env="DEV_REDIS_USERNAME")
    REDIS_PASSWORD: Optional[str] = Field(None, env="DEV_REDIS_PASSWORD")
    REDIS_DB: Optional[int] = Field(None, env="DEV_REDIS_DB")

    # Mysql
    MYSQL_SERVER: Optional[str] = Field(None, env="DEV_MYSQL_SERVER")
    MYSQL_USER: Optional[str] = Field(None, env="DEV_MYSQL_USER")
    MYSQL_PASSWORD: Optional[str] = Field(None, env="DEV_MYSQL_PASSWORD")
    MYSQL_DB_NAME: Optional[str] = Field(None, env="DEV_MYSQL_DB_NAME")
    MYSQL_PORT: Optional[int] = Field(None, env="DEV_MYSQL_PORT")

    # 日志位置
    LOG_FOLDER_PATH: Optional[str] = Field(None, env="DEV_LOG_FOLDER_PATH")

    # 云kafka信息
    YUN_KAFKA_SERVERS: Optional[str] = Field(None, env="DEV_YUN_KAFKA_SERVERS")


class TestConfig(Settings):
    """Production configurations."""

    REDIS_HOST: Optional[str] = Field(None, env="TEST_REDIS_HOST")
    REDIS_PORT: Optional[int] = Field(None, env="TEST_REDIS_PORT")
    REDIS_USERNAME: Optional[str] = Field(None, env="TEST_REDIS_USERNAME")
    REDIS_PASSWORD: Optional[str] = Field(None, env="TEST_REDIS_PASSWORD")
    REDIS_DB: Optional[int] = Field(None, env="TEST_REDIS_DB")

    MYSQL_SERVER: Optional[str] = Field(None, env="TEST_MYSQL_SERVER")
    MYSQL_USER: Optional[str] = Field(None, env="TEST_MYSQL_USER")
    MYSQL_PASSWORD: Optional[str] = Field(None, env="TEST_MYSQL_PASSWORD")
    MYSQL_DB_NAME: Optional[str] = Field(None, env="TEST_MYSQL_DB_NAME")
    MYSQL_PORT: Optional[int] = Field(None, env="TEST_MYSQL_PORT")

    # 日志位置
    LOG_FOLDER_PATH: Optional[str] = Field(None, env="TEST_LOG_FOLDER_PATH")

    # 云kafka信息
    YUN_KAFKA_SERVERS: Optional[str] = Field(None, env="TEST_YUN_KAFKA_SERVERS")


class ProdConfig(Settings):
    """Production configurations."""

    REDIS_HOST: Optional[str] = Field(None, env="PROD_REDIS_HOST")
    REDIS_PORT: Optional[int] = Field(None, env="PROD_REDIS_PORT")
    REDIS_USERNAME: Optional[str] = Field(None, env="PROD_REDIS_USERNAME")
    REDIS_PASSWORD: Optional[str] = Field(None, env="PROD_REDIS_PASSWORD")
    REDIS_DB: Optional[int] = Field(None, env="PROD_REDIS_DB")

    MYSQL_SERVER: Optional[str] = Field(None, env="PROD_MYSQL_SERVER")
    MYSQL_USER: Optional[str] = Field(None, env="PROD_MYSQL_USER")
    MYSQL_PASSWORD: Optional[str] = Field(None, env="PROD_MYSQL_PASSWORD")
    MYSQL_DB_NAME: Optional[str] = Field(None, env="PROD_MYSQL_DB_NAME")
    MYSQL_PORT: Optional[int] = Field(None, env="PROD_MYSQL_PORT")

    # 日志位置
    LOG_FOLDER_PATH: Optional[str] = Field(None, env="PROD_LOG_FOLDER_PATH")

    # 云kafka信息
    YUN_KAFKA_SERVERS: Optional[str] = Field(None, env="PROD_YUN_KAFKA_SERVERS")


class FactoryConfig:
    """Returns a config instance dependending on the ENV_STATE variable."""

    def __init__(self, env_state: Optional[str]):
        self.env_state = env_state

    def __call__(self):

        if self.env_state == "development":
            return DevConfig()

        elif self.env_state == "production":
            return ProdConfig()

        elif self.env_state == "testing":
            return TestConfig()


@lru_cache()
def get_configs():
    """加载一下环境文件"""
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), '.env'), encoding='utf-8')
    return FactoryConfig(Settings().ENVIRONMENT)()


configs = get_configs()
