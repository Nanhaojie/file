-- upgrade --
ALTER TABLE `t_video_frame` ADD `detection_model` VARCHAR(128);
ALTER TABLE `t_video_frame` ADD `img_url` VARCHAR(512);
ALTER TABLE `t_video_frame` ADD `is_right` BOOL   COMMENT '是否正确';
-- downgrade --
ALTER TABLE `t_video_frame` DROP COLUMN `detection_model`;
ALTER TABLE `t_video_frame` DROP COLUMN `img_url`;
ALTER TABLE `t_video_frame` DROP COLUMN `is_right`;
