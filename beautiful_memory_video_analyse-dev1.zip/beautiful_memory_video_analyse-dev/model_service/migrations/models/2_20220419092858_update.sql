-- upgrade --
ALTER TABLE `t_wonderful_video_agg_ret` DROP INDEX `idx_t_wonderful_video_e_590ff7`;
ALTER TABLE `t_video_frame` DROP INDEX `idx_t_video_fra_video_e_d7fc5e`;
ALTER TABLE `t_video_frame` MODIFY COLUMN `video_equipment_id` VARCHAR(512);
ALTER TABLE `t_wonderful_video_agg_ret` MODIFY COLUMN `video_equipment_id` VARCHAR(512);
-- downgrade --
ALTER TABLE `t_video_frame` MODIFY COLUMN `video_equipment_id` INT NOT NULL;
ALTER TABLE `t_wonderful_video_agg_ret` MODIFY COLUMN `video_equipment_id` INT NOT NULL;
ALTER TABLE `t_video_frame` ADD INDEX `idx_t_video_fra_video_e_d7fc5e` (`video_equipment_id`);
ALTER TABLE `t_wonderful_video_agg_ret` ADD INDEX `idx_t_wonderful_video_e_590ff7` (`video_equipment_id`);
