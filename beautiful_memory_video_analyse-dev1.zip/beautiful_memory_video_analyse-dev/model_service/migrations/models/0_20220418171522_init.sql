-- upgrade --
CREATE TABLE IF NOT EXISTS `aerich` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `version` VARCHAR(255) NOT NULL,
    `app` VARCHAR(20) NOT NULL,
    `content` JSON NOT NULL
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `t_video_frame` (
    `id` BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `spare_str1` VARCHAR(512)   COMMENT '备用字符串字段1',
    `spare_str2` VARCHAR(512)   COMMENT '备用字符串字段2',
    `spare_str3` VARCHAR(512)   COMMENT '备用字符串字段3',
    `spare_int1` INT   COMMENT '备用int字段1',
    `spare_int2` INT   COMMENT '备用int字段2',
    `spare_int3` INT   COMMENT '备用int字段3',
    `user_id` VARCHAR(32) NOT NULL,
    `video_equipment_id` INT NOT NULL,
    `beautiful_time` VARCHAR(512) NOT NULL  COMMENT '时间',
    `body_coord` VARCHAR(256) NOT NULL  COMMENT '身体坐标',
    `face_coord` VARCHAR(256) NOT NULL  COMMENT '人脸坐标',
    `wonderful_tag` VARCHAR(128) NOT NULL  COMMENT '精彩标签',
    `wonderful_weight` INT NOT NULL  COMMENT '精彩权重',
    `wonderful_video_ret_id` VARCHAR(32) NOT NULL,
    `create_time` DATETIME(6) NOT NULL  COMMENT '创建时间' DEFAULT CURRENT_TIMESTAMP(6),
    KEY `idx_t_video_fra_user_id_5c4cc7` (`user_id`),
    KEY `idx_t_video_fra_video_e_d7fc5e` (`video_equipment_id`),
    KEY `idx_t_video_fra_wonderf_f03acb` (`wonderful_video_ret_id`)
) CHARACTER SET utf8mb4 COMMENT='精彩画面表';
CREATE TABLE IF NOT EXISTS `t_wonderful_video_agg_ret` (
    `id` BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `spare_str1` VARCHAR(512)   COMMENT '备用字符串字段1',
    `spare_str2` VARCHAR(512)   COMMENT '备用字符串字段2',
    `spare_str3` VARCHAR(512)   COMMENT '备用字符串字段3',
    `spare_int1` INT   COMMENT '备用int字段1',
    `spare_int2` INT   COMMENT '备用int字段2',
    `spare_int3` INT   COMMENT '备用int字段3',
    `user_id` VARCHAR(32) NOT NULL,
    `body_coord` VARCHAR(32) NOT NULL  COMMENT '身体坐标',
    `frame_start_offset` BIGINT NOT NULL  COMMENT '开始帧',
    `frame_end_offset` BIGINT NOT NULL  COMMENT '结束帧',
    `video_equipment_id` INT NOT NULL,
    `occurrence_date` DATE NOT NULL  COMMENT '精彩视频日期',
    `group_id` VARCHAR(32)   COMMENT '聚合组号',
    `wonderful_video_ret_id` VARCHAR(32) NOT NULL,
    `wonderful_tag` VARCHAR(128) NOT NULL  COMMENT '精彩标签',
    `create_time` DATETIME(6) NOT NULL  COMMENT '创建时间' DEFAULT CURRENT_TIMESTAMP(6),
    KEY `idx_t_wonderful_user_id_eabd80` (`user_id`),
    KEY `idx_t_wonderful_video_e_590ff7` (`video_equipment_id`),
    KEY `idx_t_wonderful_wonderf_76ddb8` (`wonderful_video_ret_id`)
) CHARACTER SET utf8mb4 COMMENT='精彩视频聚合结果';
