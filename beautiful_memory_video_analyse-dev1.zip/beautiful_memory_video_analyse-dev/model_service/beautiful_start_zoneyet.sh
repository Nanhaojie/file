#!/bin/bash
source /etc/bash.bashrc
# /root/miniconda3/envs/py38/bin/python  get_conf.py &
# /root/miniconda3/envs/py38/bin/python face_template.py &
/root/miniconda3/envs/py38/bin/python  persist_records.py &
/root/miniconda3/envs/py38/bin/python  sport_beautiful.py &>sport.log &

