# from kafka import KafkaConsumer
# video_url_topic = KafkaConsumer('beautiful_result', bootstrap_servers=['172.28.81.171:9092'], auto_offset_reset='earliest'
#                                 )
#
#
# def consumer_video_url_topic():
#     while True:
#         try:
#             message = next(video_url_topic)
#         except Exception as e:
#             print(f'从kafka的hum_no_face_topic取数据报错,{e}')
#         else:
#             print(message.key)
#             print(message.value)
#
#
# consumer_video_url_topic()


# import configparser
# from redis import StrictRedis
# import os
#
# IS_PRODUCT = os.environ.get('IS_PRODUCT')
# config = configparser.ConfigParser()
# if IS_PRODUCT == '1':
#     config.read('conf/pro.conf')
# else:
#     config.read('conf/dev.conf')
# # redis
# while True:
#     REDIS_HOST = config.get('redis', 'host')
#     REDIS_PORT = config.get('redis', 'port')
#     REDIS_PASSWORD = config.get('redis', 'password')
#     BODY_TEMPLATE_REDIS_KEY = config.get('redis', 'body_template_key')
#     BODY_TEMPLATE_REDIS_NAME = config.get('redis', 'body_template_name')
#     redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD)
#     sd = redis_conn.hget(BODY_TEMPLATE_REDIS_NAME, BODY_TEMPLATE_REDIS_KEY)
#     print(sd)


# import cv2
# import pickle
# # cap = cv2.VideoCapture('rtsp://admin:886699hh@172.28.81.145:554/Streaming/Channels/801?transportmode=unicast')
# cap = cv2.VideoCapture('rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/401?starttime=20211019t113500z&endtime=20211019t113600z')
#
# while cap.isOpened():
#     sta, frame = cap.read()
#     f = open('pick_test', 'wb')
#     pickle.dump(frame, f)
#     f.close()
#     # d = pickle.loads(o)
#     # print(type(d))
#     # print(d)
#     exit()

# import os
# import configparser
# from kafka import KafkaConsumer
# from kafka import KafkaProducer
# import json
# IS_PRODUCT = os.environ.get('IS_PRODUCT')
# config = configparser.ConfigParser()
# if IS_PRODUCT == '1':
#     config.read('conf/pro.conf')
# else:
#     config.read('conf/dev.conf')
# add_port = config.get('local_kafka', 'servers').split(',')
# video_img_topic = config.get('local_kafka', 'video_img_topic')
# producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
#                          compression_type='gzip')
# def product_video_img(ip):
#     cap = cv2.VideoCapture(ip)
#     # cap = cv2.VideoCapture(0)
#     rate = 3
#     num = 0
#     if cap.isOpened():
#         print('海康')
#     while True:
#         if num % rate == 0:
#             start = time.time()
#             frame = cap.read()[1]
#             cv2.imwrite('ss.jpg', frame)
#             frame_bytes = cv2.imencode('.jpg', frame)[1].tobytes()
#             future = producer.send(video_img_topic, key=ip.split('/')[-1].split('.')[0].split('_')[0], value=frame_bytes)
#             print(future)
#             # log.logger.info(f'读摄像头{str(ip)}视频流放入kafka的video_img的fps: {1 / (time.time() - start)}')
#         num += 1
#
# product_video_img('/home/zoneyet/视频/slide/D02_20211009145534.mp4')

# sr = 'c7da3110-2a77-11ec-9193-0242c0a801022'
# print(len(sr))


# import cv2
# from face_detection.test_retinaface import HumanFaceDetection
# import time
# # cap = cv2.VideoCapture('rtsp://admin:root12300.@172.28.81.145:554/Streaming/Channels/801?transportmode=unicast')
# cap = cv2.VideoCapture('rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/501?starttime=20211019t113700z&endtime=20211019t113800z')
# face_detectorss = HumanFaceDetection()
#
# while True:
#     sta, frame = cap.read()
#     # 调用人脸检测,识别的模型
#     start_face_time = time.time()
#     face_result = face_detectorss.infer(frame)
#     face_fps = 1 / (time.time() - start_face_time)
# if face_result:
#     _, coordinate, user_ids = face_result[0], face_result[1], face_result[2]
#     print('11111111111', user_ids)
#     # 遍历一张图中多个人脸
#     for i, coord in enumerate(coordinate):
#         face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(
#             coord[3])
#             # 人脸比对成功
#         if user_ids[i]:
#             print('------------------', str(user_ids[i].split('_')[0]))
#             cv2.putText(frame, str(user_ids[i].split('_')[0]), (200, 225), cv2.FONT_HERSHEY_DUPLEX,
#                         0.75, (0, 255, 255), 2)
#
#         # 人脸检测可视化
#         cv2.rectangle(frame, (face_x1, face_y1), (face_x2, face_y2), (0, 255, 255), 2)
#
# # 可视化
# cv2.putText(frame, str('face FPS: %.2f' % face_fps), (300, 85), cv2.FONT_HERSHEY_DUPLEX, 0.75,
#             (0, 255, 255), 2)
# 可视化展示
# cv2.imshow('hum_face_model', cv2.resize(frame, (1000, 800)))
# if cv2.waitKey(1) == ord('q'):
#     exit()

# import cv2
# import time
# import multiprocessing as mp
# import random
#
#
# def queue_img_put(q_put, rtsp):
#     # 读摄像头的流
#     cap = cv2.VideoCapture(rtsp)
#     s1 = time.time()
#     while True:
#         is_opened, frame = cap.read()
#         if not is_opened:
#             print('1111', time.time()-s1)
#         q_put.put(frame) if is_opened else None
#         # 如果队列里大于一帧，说明存的速度大于取的速度，就从队列取出来，保证队列中只存最新的一帧
#         q_put.get() if q_put.qsize() > 1 else None
#
#
# def main(origin_img):
#     while True:
#         # 从队列里面取出图片
#         frame = origin_img.get()
#         cv2.imshow('frame', frame)
#         cv2.waitKey(1)
#
#
# if __name__ == '__main__':
#     mp.set_start_method(method='spawn')
#
#     origin_img_q = mp.Queue()
#     result_img_q = mp.Queue()
#
#     processes = [
#         mp.Process(target=queue_img_put, args=(origin_img_q, 'rtsp://admin:root12300.@172.28.81.145:554/Streaming/tracks/701?starttime=20211019t120700z&endtime=20211019t121200z')),
#         mp.Process(target=main, args=(origin_img_q,)),
#     ]
#
#     # [setattr(process, "daemon", True) for process in processes]
#     [process.start() for process in processes]
#     [process.join() for process in processes]

# from threading import Thread
#
# import cv2
#
#
# class ThreadedCamera(object):
#     def __init__(self, source=0):
#         self.capture = cv2.VideoCapture(source)
#         self.thread = Thread(target=self.update, args=())
#         self.thread.daemon = True
#         self.thread.start()
#
#     def update(self):
#         while True:
#             if self.capture.isOpened():
#                 self.capture.grab()
#
#     def grab_frame(self):
#         status, frame = self.capture.retrieve()
#         video_pos_time = int(self.capture.get(cv2.CAP_PROP_POS_MSEC))
#         if status:
#             return frame, video_pos_time
#         return None, None
#
#
# streamer0 = ThreadedCamera('rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/101?transportmode=unicast')
#
# while True:
#     slide_image, slide_video_pos_time = streamer0.grab_frame()
#     if slide_image is not None and slide_video_pos_time is not None:
#         print(streamer0.video_pos_time)

# import cv2
# cap = cv2.VideoCapture('rtsp://admin:root12300.@192.168.11.11:554/Streaming/Channels/501?transportmode=unicast')
# while True:
#     is_opened, frame = cap.read()
#     cv2.imwrite('fg.jpg', frame)
#     print('sucedd')
#
# int(time.mktime(time.strptime(climb_rtsp.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000


# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2/25/22 9:22 AM
# @author yueyuanbo
import time

# import cv2
#
# cam = cv2.VideoCapture(
#     'rtsp://admin:root12300.@172.17.24.58:554/Streaming/tracks/3201?starttime=20220323t150000z')
#
# first_time = None
# while True:
#     _, frame = cam.read()
#     print(frame)
#     cv2.waitKey(3)
