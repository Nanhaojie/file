# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in
# @author fj

"""
身体底板的录入逻辑

1. 从内网kafka中读取人脸识别和行人检测的框，
    key的数据结构
    [
        {
        'body_coor': '', # 身体底板坐标
        'user_id': 0, # 用户id
        'video_equipment_id': 0, # 摄像头设备id
        },
        ...
    ]
    value存储原始图片

2. 如果设备为门口摄像头，保存为今日身体库；如果为其他摄像头，保存为今日瞬间身体底板；
3. 将身体数据推送到云端kafka
"""
import json
import os
import configparser
import time
import cv2
from redis import StrictRedis
from body_recognition.body_recognition_model import body_rec
from tools.log import Logger

IS_PRODUCT = os.environ.get('IS_PRODUCT')

config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
BODY_TEMPLATE_REDIS_KEY = config.get('redis', 'body_template_key')
BODY_TEMPLATE_REDIS_NAME = config.get('redis', 'body_template_name')
redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD)
body_template_logger = Logger('logs/body_template.log', level='info').logger

# 场景坐标
climb_ce_coord = eval(redis_conn.get('climb_ce_coord').decode())

climb_ce_x1, climb_ce_y1, climb_ce_x2, climb_ce_y2 = climb_ce_coord[0], climb_ce_coord[1], climb_ce_coord[2], \
                                                     climb_ce_coord[3]


def append_body(image, model_output_f_image):
    for single_data in model_output_f_image:
        # {
        #     'body_coor': 'human_y1:human_y2, human_x1:human_x2',  # 身体底板坐标
        #     'user_id': 0,  # 用户id
        #     'video_equipment_id': 0,  # 摄像头设备id
        # }
        key_type = 1
        human_x1, human_y1, human_x2, human_y2 = single_data['body_coord']
        center_x, center_y = (human_x1 + human_x2)/2, (human_y1 + human_y2)/2,

        if climb_ce_x1 < center_x < climb_ce_x2 and climb_ce_y1 < center_y < climb_ce_y2:
            #cv2.imwrite('body/' + 'ss.jpg', image[climb_ce_y1:climb_ce_y2, climb_ce_x1:climb_ce_x2])
            if 1 < (human_y2-human_y1) / (human_x2-human_x1) < 5:
                body_image = image[human_y1:human_y2, human_x1:human_x2]
                #cv2.imwrite('body/'+str(time.time()) + '.jpg', body_image)
                redis_conn.hset(
                    BODY_TEMPLATE_REDIS_NAME, key=f'{single_data["user_id"]}',
                    value=json.dumps({"user_id": single_data["user_id"], "characteristic": body_rec(body_image).tolist(),
                                      "body_time_stamp": int(time.time())})
                )
                body_template_logger.info(f'人体模板录入成功{single_data["user_id"]}')

'''
def append_body(image, model_output_f_image):
    for single_data in model_output_f_image:
        # {
        #     'body_coor': 'human_y1:human_y2, human_x1:human_x2',  # 身体底板坐标
        #     'user_id': 0,  # 用户id
        #     'video_equipment_id': 0,  # 摄像头设备id
        # }
        key_type = 1
        human_x1, human_y1, human_x2, human_y2 = single_data['body_coord']

        if climb_ce_x1 < human_x1 and human_x2 < climb_ce_x2 and climb_ce_y1 < human_y1 and human_y2 < climb_ce_y2:
            if 1.5 < (human_y2-human_y1) / (human_x2-human_x1) < 5:
                body_image = image[human_y1:human_y2, human_x1:human_x2]
                cv2.imwrite(str(time.time()) + '.jpg', body_image)

                chars = []
                for item in redis_conn.hgetall(BODY_TEMPLATE_REDIS_NAME).values():
                    item = json.loads(item)
                    if item['user_id'] == single_data["user_id"]:
                        chars.append(item['characteristic'])

                redis_conn.hset(
                    BODY_TEMPLATE_REDIS_NAME, key=f'{single_data["user_id"]}',
                    value=json.dumps({"user_id": single_data["user_id"], "characteristic": chars.append(body_rec(body_image).tolist()),
                                      "body_time_stamp": int(time.time())})
                )
                body_template_logger.info('人体模板录入成功')
'''