# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in
# @author fj

"""
人脸数据的录入


1. 从云上kafka中获取需要录入的人脸数据
    数据结构
    {
    'face_urls': ['', ''], # 人脸照片
    'user_id': 0, # 用户id
    }
2. 将人脸录入到模型
"""
import datetime
import json
import numpy as np

import configparser

# 项目初始化 加载配置文件
import time
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED

from kafka import KafkaConsumer

from face_detection.test_retinaface import HumanFaceDetection
from tools.log import Logger
import os
from tools.redis_utils import redis_conn

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

YUN_KAFKA_SERVERS = config.get('yun_kafka', 'servers').split(',')
FACE_APPEND_TOPIC = config.get('yun_kafka', 'face_append_topic')
ACTIVE_SCENE_USER_TOPIC = config.get('yun_kafka', 'active_scene_user')
ACTIVE_SCENE_USER_REDIS_KEY = config.get('redis', 'active_scene_user')
FACE_DATA_LAST_MODIFY_REDIS_KEY = config.get('redis', 'face_data_last_modify')
GROUP_ID = config.get('yun_kafka', 'face_group_id')
SCENE_ID = config.get('base_info', 'scene_id')
face_template_logger = Logger('logs/face_template.log', level='info').logger

def update_face_data(face_detector: HumanFaceDetection):
    # 从redis中scan数据
    face_template_logger.info("更新所有人脸数据")
    redis_conn = face_detector.redis_conn
    cursor = None
    while cursor != 0:
        cursor, face_template_data = redis_conn.hscan(face_detector.face_template_redis_key, cursor or 0, count=100)
        for face_key, face_template_value in face_template_data.items():
            # 读取url中数据
            face_template_value = json.loads(face_template_value)
            face_url = face_template_value.get("url")
            try:
                image_array = face_detector.cv_url_read(face_url)
            except Exception:
                face_template_logger.warning("从链接中按照opencv方式读取数据失败", exc_info=True)
            else:
                # 根据模型重新生成数据
                embedding = face_detector.embedding_f_face(image_array)
                if embedding is not None:
                    face_template_value["characteristic"] = embedding.tolist()
                    face_template_data[face_key] = json.dumps(face_template_value)
        # 存储新生成的数据
        redis_conn.hset(face_detector.face_template_redis_key, mapping=face_template_data)

def check_face_data(face_detector: HumanFaceDetection):
    # 每次重启服务先检查人脸数据和模型是否匹配
    redis_conn = face_detector.redis_conn
    cursor = None
    is_right = None
    while cursor != 0:
        cursor, face_template_data = redis_conn.hscan(face_detector.face_template_redis_key,  cursor or 0, count=1)
        for face_template_value in face_template_data.values():
            face_template_value = json.loads(face_template_value)
            face_url = face_template_value.get("url")
            try:
                image_array = face_detector.cv_url_read(face_url)
            except Exception:
                face_template_logger.warning("从链接中按照opencv方式读取数据失败", exc_info=True)
            else:
                # 根据模型重新生成数据
                embedding = face_detector.embedding_f_face(image_array)
                if embedding is None:
                    continue
                dists = np.sum(np.square(np.array(face_template_value.get("characteristic")) - embedding))
                if dists < 1.1:
                    is_right = True
                else:
                    is_right = False

    if is_right == False:
        # 如果不正确 将所有数据重新更新
        update_face_data(face_detector)

def append_face(rec_conn):
    face_append_consumer = KafkaConsumer(FACE_APPEND_TOPIC, bootstrap_servers=YUN_KAFKA_SERVERS,
                                         value_deserializer=lambda v: json.loads(v.decode()),
                                         auto_offset_reset='earliest', group_id=GROUP_ID)
    face_detectors = HumanFaceDetection()
    check_face_data(face_detectors)
    while True:
        if rec_conn.poll():
            face_template_logger.info("录入人脸进程被终止")
            return
        message_set = face_append_consumer.poll(timeout_ms=1000)
        for consumer_record in message_set.values():
                for message in consumer_record:
                    try:
                        face_detectors.face_embedding(str(message.value.get('user_id')), message.value.get('face_urls'),
                                                    message.value.get('type'))
                        redis_conn.set(FACE_DATA_LAST_MODIFY_REDIS_KEY, int(time.time()))
                    except:
                        face_template_logger.error(f'人脸录入报错', exc_info=True)
                    face_template_logger.info(f"{message.value.get('user_id')}人脸录入{message.value.get('face_urls')}")


def append_active_user(rec_conn):
    activate_user_consumer = KafkaConsumer(ACTIVE_SCENE_USER_TOPIC, bootstrap_servers=YUN_KAFKA_SERVERS,
                                         value_deserializer=lambda v: json.loads(v.decode()),
                                         auto_offset_reset='earliest', group_id=f"{ACTIVE_SCENE_USER_TOPIC}1")
    while True:
        if rec_conn.poll():
            face_template_logger.info("活跃用户统计进程被终止")
            return
        message_set = activate_user_consumer.poll(timeout_ms=1000)
        for consumer_record in message_set.values():
            for message in consumer_record:
                if message.value.get('scene_id') != SCENE_ID:
                    face_template_logger.info(f"舍弃掉场馆{message.value.get('scene_id')}的活跃用户数据")
                    continue
                user_id = message.value.get('user_id')
                try:
                    with redis_conn.pipeline(transaction=False) as pipe:
                        # 向redis中添加活跃用户
                        pipe.exists(ACTIVE_SCENE_USER_REDIS_KEY) \
                            .sadd(ACTIVE_SCENE_USER_REDIS_KEY, f"{user_id}_0") \
                            .set(FACE_DATA_LAST_MODIFY_REDIS_KEY, int(time.time()))
                        # 判断缓存键是否存在，如果不存在设置过期时间exp_set_flag为True
                        is_exist_key, _, _ = pipe.execute()
                    # 根据 is_exist_key 状态设置过期时间为第二天凌晨
                    if not is_exist_key:
                        init_date = datetime.datetime.now()
                        middle_datetime = init_date + datetime.timedelta(days=1)
                        refresh_cycle_datetime = datetime.datetime(middle_datetime.year, middle_datetime.month,
                                                                middle_datetime.day)
                        redis_conn.expireat(ACTIVE_SCENE_USER_REDIS_KEY, refresh_cycle_datetime)
                except Exception:
                    face_template_logger.warning(f"统计活跃用户{user_id}失败", exc_info=True)
                else:
                    face_template_logger.info(f"统计到活跃用户{user_id}...")

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:
        all_task = [pool.submit(append_face), pool.submit(append_active_user)]
