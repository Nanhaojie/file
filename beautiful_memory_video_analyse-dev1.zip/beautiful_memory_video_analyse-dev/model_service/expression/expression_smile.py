#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@File ：expression_smile.py
@Author ：nhj
@Date ：2021/9/11 上午10:54 
"""
import time

from PIL import Image

import expression.transforms.transforms as transforms
from skimage import io
from skimage.transform import resize
import cv2
import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import torch
# import torch.nn.functional as F
import configparser
import os

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

server = config.get('tf-serving', 'server')
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]

gender_offsets = (10, 10)
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'beautifulMemory'
request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 11

cut_size = 44

transform_test = transforms.Compose([
    transforms.TenCrop(cut_size),
    transforms.Lambda(lambda crops: torch.stack([transforms.ToTensor()(crop) for crop in crops])),
])


def rgb2gray(rgb):
    return np.dot(rgb[..., :3], [0.299, 0.587, 0.114])


def smile(raw_img):
    gray = rgb2gray(raw_img)
    gray = resize(gray, (48, 48), mode='symmetric').astype(np.uint8)
    img = gray[:, :, np.newaxis]
    img = np.concatenate((img, img, img), axis=2)
    img = Image.fromarray(img)
    inputs = transform_test(img)
    ncrops, c, h, w = np.shape(inputs)
    inputs = inputs.view(-1, c, h, w)

    # inputs = Variable(inputs, volatile=True)
    class_names = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

    inputs = inputs.tolist()
    inputs = np.array(inputs).astype('float32')

    request.inputs['input'].CopyFrom(tf.compat.v1.make_tensor_proto(inputs.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 20)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    pred = data['output']
    pred = torch.tensor(pred)
    outputs_avg = pred.view(ncrops, -1).mean(0)  # avg over crops
    # score = F.softmax(outputs_avg)
    _, predicted = torch.max(outputs_avg.data, 0)
    # score_max = score[predicted]
    # flag = 'no_smile'
    # if predicted == 3:
    #     flag = 'smile'
    return int(predicted)


# raw_img = cv2.imread('/home/zhb/PycharmProjects/docr/img/smil.png')
# ss = smile(raw_img)
# print(ss)
