# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in
# @author fj
import asyncio
import copy
import datetime
import functools
import json
import os
import uuid
import configparser
import random
import time

import aioredis
import numpy as np
import pandas as pd
import requests
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from kafka import KafkaConsumer, KafkaProducer
from redis import StrictRedis
from tortoise import Tortoise, run_async

import get_conf
from orm_model.models import VideoFrame
from tools.video_upload import async_upload_qiniu
from tools.log import Logger
from tools.mysql_utils import MysqlPool

IS_PRODUCT = os.environ.get('IS_PRODUCT')

config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

# 本地kafka
LOCAL_KAFKA_SERVERS = config.get('local_kafka', 'servers').split(',')
BEAUTIFUL_MODEL_TOPIC = config.get('local_kafka', 'beautiful_model_topic')
BEAUTIFUL_RESULT_TOPIC = config.get('local_kafka', 'beautiful_result_topic')
GROUP_ID = config.get('yun_kafka', 'persist_group_id')
VIDEO_FRAME_TOPIC = config.get('yun_kafka', 'video_frame_topic')
SCENE_ID = config.get('base_info', 'scene_id')
DEFAULT_TEMPLATE_ID = config.get('base_info', 'default_template_id')
GET_VIDEO_URL = config.get('base_info', 'get_video_url')


# , auto_offset_reset='earliest'
local_producer = KafkaProducer(bootstrap_servers=LOCAL_KAFKA_SERVERS,
                               value_serializer=lambda v: json.dumps(v).encode(),
                               key_serializer=lambda v: json.dumps(v).encode(),
                               batch_size=131072,
                               request_timeout_ms=60000,
                               retries=4,
                               max_block_ms=240000,
                               compression_type='gzip')

# 云kafka
USER_PLAY_RECORD_TOPIC = config.get('yun_kafka', 'user_play_record_topic')
USER_VIDEO_AGG_MSG_TOPIC = config.get('yun_kafka', 'user_v_agg_msg_topic')
VIDEO_RET_MSG = config.get('yun_kafka', 'video_ret_msg_topic')
VIDEO_FRAME_UPDATE_TOPIC = config.get('yun_kafka', 'video_frame_update_topic')
user_video_agg_msg_kafka_con = KafkaConsumer(USER_VIDEO_AGG_MSG_TOPIC, bootstrap_servers=get_conf.YUN_KAFKA_SERVERS,
                                             key_deserializer=lambda v: json.loads(v.decode()),
                                             value_deserializer=lambda v: json.loads(v.decode()),
                                             group_id=GROUP_ID)

# redis
REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
DB = config.get('redis', 'db')
redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD, decode_responses=True, db=DB)
PLAY_RECORD_PER_REDIS_KEY = config.get('redis', 'play_record_per_redis_key')
BEAUTIFUL_TIME_SCORE_STAT = config.get('redis', 'beautiful_time_score_stat')
BEAUTIFUL_TIME_RICH_PUSH = config.get('redis', 'beautiful_time_rich_push')
ACTIVE_SCENE_USER_REDIS_KEY = config.get('redis', 'active_scene_user')
ASSIST_USER_GET_VIDEO_REDIS_KEY = config.get('redis', 'assist_user_get_video')

# mysql
VIDEO_FRAME_TABLE_NAME = config.get('mysql', 'video_frame_table_name')
AGG_RET_TABLE_NAME = config.get('mysql', 'agg_ret_table_name')
SERIALIZER_DATE_FIELD_FORMAT = '%Y-%m-%d'
SQL_DATE_FIELD_FORMAT = '%%Y-%%m-%%d'
SERIALIZER_DATETIME_FIELD_FORMAT = "%Y-%m-%d %H:%M:%S"
MYSQL_HOST = config.get('mysql', 'host')
MYSQL_PORT = config.get('mysql', 'port')
MYSQL_USER = config.get('mysql', 'user')
MYSQL_PASSWORD = config.get('mysql', 'password')
MYSQL_DATABASE = config.get('mysql', 'database')
# mysql数据库url
DATABASE_URL = "mysql://{}:{}@{}:{}/{}?charset=utf8mb4".format(
    MYSQL_USER,
    MYSQL_PASSWORD,
    MYSQL_HOST,
    MYSQL_PORT,
    MYSQL_DATABASE
)
# 数据库配置
TORTOISE_ORM = {
    "connections": {"default": DATABASE_URL},
    "apps": {
        "models": {
            "models": ["aerich.models", "orm_model.models"],
            # 须添加“aerich.models” 后者“models”是上述models.py文件的路径
            "default_connection": "default",
        },
    },
    'use_tz': False,
    'timezone': 'Asia/Shanghai'
}

# 聚合视频分割阈值 单位毫秒 3s todo
# SPLIT_THRESHOLD = 1000
# VIDEO_BACKTRACKING_TIME = 120
SPLIT_THRESHOLD = int(redis_conn.get('split_threshold'))
VIDEO_BACKTRACKING_TIME = int(redis_conn.get('VIDEO_BACKTRACKING_TIME'))

persist_logger = Logger('logs/persist.log', level='info').logger

# 分数阈值
BEAUTIFUL_VIDEO_SCORE_THRESHOLD = int(config.get('base_info', 'video_score_threshold'))


class Dict(dict):
    def __getattr__(self, key):
        return self.get(key)

    def __setattr__(self, key, value):
        self[key] = value


def decode_json(value):
    try:
        return json.loads(value)
    except Exception:
        persist_logger.warning('解析json数据失败', exc_info=True)
        return {}


class RemindUserGenVideo:
    def __init__(self, user_leave_time: datetime.timedelta):
        self.user_leave_time = user_leave_time

    def task(self):
        # 查询今天分析到的用户，但是没有在聚合记录查询到的，仅提醒活跃用户
        activate_user_ids = tuple(user_id.split('_')[0] for user_id in redis_conn.smembers(ACTIVE_SCENE_USER_REDIS_KEY))
        now_time = datetime.datetime.now()
        # now_time = datetime.datetime(year=2021, month=11, day=19, hour=19, second=8)
        today_date = datetime.datetime(year=now_time.year, month=now_time.month, day=now_time.day)
        forward_time = now_time - self.user_leave_time
        with MysqlPool() as pool:
            sql_str = """
                    select
                        t_video_frame.wonderful_video_ret_id, t_video_frame.user_id
                    from
                        t_video_frame left join t_wonderful_video_agg_ret on
                        t_video_frame.wonderful_video_ret_id = t_wonderful_video_agg_ret.wonderful_video_ret_id
                    where
                        t_video_frame.create_time > %s and t_wonderful_video_agg_ret.id is null 
                    """
            sql_str += "and t_video_frame.user_id in %s" if activate_user_ids else ""
            sql_str += """
                    group by
                        t_video_frame.wonderful_video_ret_id, t_video_frame.user_id
                    having
                        max(t_video_frame.create_time) < %s;
                    """
            if activate_user_ids:
                user_play_records_data = pool.execute_select_sql(sql_str, (today_date, activate_user_ids, forward_time))
            else:
                # user_play_records_data = pool.execute_select_sql(sql_str, (today_date, forward_time))
                user_play_records_data = ()
        if not user_play_records_data:
            persist_logger.warning("未检测到符合用户")
            return
        with redis_conn.pipeline(transaction=False) as pipe:
            # 每个游玩记录仅提醒一次，提醒记录在redis中
            play_records_set = list()
            pipe.exists(ASSIST_USER_GET_VIDEO_REDIS_KEY)
            for user_play_record in user_play_records_data:
                play_record_id = user_play_record.get("wonderful_video_ret_id")
                # 向redis中添加活跃用户
                pipe.sadd(ASSIST_USER_GET_VIDEO_REDIS_KEY, play_record_id)
                play_records_set.append(play_record_id)
            # 判断缓存键是否存在，如果不存在设置过期时间 is_exist_key为True
            is_exist_key, *is_add_success_set = pipe.execute()
        # 第一次加入返回True
        for index, is_add_success in enumerate(is_add_success_set):
            if not is_add_success:
                continue
            try:
                params = {'temp_video_id': DEFAULT_TEMPLATE_ID, 'wonderful_video_ret_id': play_records_set[index]}
                requests.get(GET_VIDEO_URL, params=params, timeout=10)
            except Exception:
                pipe.srem(ASSIST_USER_GET_VIDEO_REDIS_KEY, play_records_set[index])
                persist_logger.warning(f'帮助用户获取视频{play_records_set[index]}失败', exc_info=True)
            else:
                persist_logger.warning(f'帮助用户获取视频{play_records_set[index]}')
        # 根据 is_exist_key 状态设置过期时间为第二天凌晨
        if not is_exist_key:
            init_date = datetime.datetime.now()
            middle_datetime = init_date + datetime.timedelta(days=1)
            refresh_cycle_datetime = datetime.datetime(middle_datetime.year, middle_datetime.month,
                                                       middle_datetime.day)
            redis_conn.expireat(ASSIST_USER_GET_VIDEO_REDIS_KEY, refresh_cycle_datetime)

    def run_task(self, task_interval: datetime.timedelta):
        persist_logger.info('启动辅助用户获取视频任务')
        while True:
            self.task()
            time.sleep(task_interval.seconds)


class UpdateFrame:
    def __init__(self, video_frame_update_topic, yun_kafka_servers):
        self.video_frame_update_topic = video_frame_update_topic
        self.yun_kafka_servers = yun_kafka_servers

    async def per_run(self):
        """运行任务的前置工作"""
        self.update_frame_kafka_con = AIOKafkaConsumer(self.video_frame_update_topic,
                                                       bootstrap_servers=self.yun_kafka_servers,
                                                       value_deserializer=decode_json,
                                                       group_id=SCENE_ID,
                                                       auto_offset_reset='latest')  # todo
                                                       # auto_offset_reset='earliest')
        await self.update_frame_kafka_con.start()

    async def run_task(self):
        persist_logger.info('启动精彩瞬间审核状态同步任务')
        await self.per_run()
        while True:
            result = await self.update_frame_kafka_con.getmany(timeout_ms=10 * 1000, max_records=10000)

            ## 构造数据
            right_id_list = list()
            wrong_id_list = list()
            for tp, messages in result.items():
                for message in messages:
                    update_video_frame_data = message.value
                    if update_video_frame_data.get('scene_id') != int(SCENE_ID):
                        continue
                    if update_video_frame_data.get('is_right') == True:
                        right_id_list.append(update_video_frame_data.get('video_frame_id'))
                    elif update_video_frame_data.get('is_right') == False:
                        wrong_id_list.append(update_video_frame_data.get('video_frame_id'))

            ## 保存数据
            try:
                if right_id_list:
                    await VideoFrame.filter(id__in=copy.deepcopy(right_id_list)).update(is_right=1)
                if wrong_id_list:
                    await VideoFrame.filter(id__in=copy.deepcopy(wrong_id_list)).update(is_right=0)
            except Exception:
                persist_logger.error(f'存储精彩瞬间失败', exc_info=True)


class PersistFrame:
    def __init__(self, beautiful_model_topic, local_kafka_servers, redis_password, redis_host, redis_port, redis_db):
        self.beautiful_model_topic = beautiful_model_topic
        self.local_kafka_servers = local_kafka_servers
        self.yun_kafka_servers = get_conf.YUN_KAFKA_SERVERS
        self.redis_password = redis_password
        self.redis_host = redis_host
        self.redis_port = redis_port
        self.redis_db = redis_db

    async def per_run(self):
        """运行任务的前置工作"""
        self.model_frame_kafka_con = AIOKafkaConsumer(self.beautiful_model_topic,
                                                      bootstrap_servers=self.local_kafka_servers,
                                                      key_deserializer=decode_json,
                                                      group_id='2',  # TODO
                                                      auto_offset_reset='latest')  # todo
                                                      # auto_offset_reset='earliest')
        await self.model_frame_kafka_con.start()
        # 云端 aiokafka
        self.yun_producer = AIOKafkaProducer(bootstrap_servers=self.yun_kafka_servers,
                                             value_serializer=lambda v: json.dumps(v).encode(),
                                             key_serializer=lambda v: json.dumps(v).encode(),
                                             # enable_idempotence=True,
                                             connections_max_idle_ms=20000,
                                             compression_type='gzip')
        await self.yun_producer.start()

        self.redis_conn_future = aioredis.from_url(
            f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/{self.redis_db}",
            decode_responses=True)
        self.redis_conn = await self.redis_conn_future

    async def get_wonderful_video_ret_id(self, message_key):
        """获取游玩记录id；信息同步到云端"""
        # 获取用户id
        user_id = message_key['user_id']
        play_record_redis_key = f'{PLAY_RECORD_PER_REDIS_KEY}{user_id}'
        wonderful_video_ret_id = await self.redis_conn.get(play_record_redis_key)
        if not wonderful_video_ret_id:
            wonderful_video_ret_id = uuid.uuid1().hex
            try:
                # 如果为空，推送kafka，之后云端创建一条游玩记录，并将redis中更新这个记录
                future = await self.yun_producer.send(USER_PLAY_RECORD_TOPIC, value={
                    'user_id': user_id, 'wonderful_video_ret_id': wonderful_video_ret_id, 'scene_id': SCENE_ID
                })
                await future
            except Exception:
                persist_logger.warning(f'用户:{user_id}有一条游玩记录推送kafka失败', exc_info=True)
                message_key['spare_int1'] = 0
            else:
                # 保存游玩id，过期时间12小时
                await self.redis_conn.setex(play_record_redis_key, datetime.timedelta(hours=VIDEO_BACKTRACKING_TIME),
                                            wonderful_video_ret_id)
                # await self.redis_conn.set(play_record_redis_key, wonderful_video_ret_id)
                persist_logger.info(f'用户:{user_id}有一条游玩记录{wonderful_video_ret_id}')
                await self.redis_conn.hset(f'{BEAUTIFUL_TIME_SCORE_STAT}{wonderful_video_ret_id}',
                                           message_key['wonderful_tag'], 1)
                await self.redis_conn.expire(f'{BEAUTIFUL_TIME_SCORE_STAT}{wonderful_video_ret_id}',
                                             datetime.timedelta(hours=VIDEO_BACKTRACKING_TIME))
        return message_key, wonderful_video_ret_id

    async def push_rich_msg(self, wonderful_video_ret_id, message_key):
        """该游玩记录是否有充足素材的处理"""
        # 查询是否有该游玩记录的 is_rich 推送记录
        if not await self.redis_conn.get(f"{BEAUTIFUL_TIME_RICH_PUSH}{wonderful_video_ret_id}"):
            # 类型为hash 过期时间为24小时 {'sea': 0, 'slide': 0, 'jump': 1, 'clib': 0}
            beautiful_time_score_dict = await self.redis_conn.hgetall(f'{BEAUTIFUL_TIME_SCORE_STAT}'
                                                                      f'{wonderful_video_ret_id}')
            wonderful_tag = message_key['wonderful_tag']
            user_id = message_key['user_id']
            beautiful_time_score_dict[wonderful_tag] = int(beautiful_time_score_dict.get(wonderful_tag, 0)) + 1
            # 计算分数
            beautiful_time_score = 0
            for num in beautiful_time_score_dict.values():
                beautiful_time_score += (int(num) + 10)
            # 更新精彩瞬间的状态为有比较多的精彩瞬间了
            if beautiful_time_score >= BEAUTIFUL_VIDEO_SCORE_THRESHOLD:
                try:
                    future = self.yun_producer.send(USER_PLAY_RECORD_TOPIC, value={
                        'user_id': user_id, 'wonderful_video_ret_id': wonderful_video_ret_id,
                        'scene_id': SCENE_ID,
                        'is_rich': 1
                    })
                    await future
                except Exception:
                    persist_logger.warning(f'游玩记录{wonderful_video_ret_id}有充足素材消息推送kafka失败',
                                           exc_info=True)
                else:
                    # 推送kafka成功添加推送记录 防止重复推送 影响性能
                    await self.redis_conn.set(f"{BEAUTIFUL_TIME_RICH_PUSH}{wonderful_video_ret_id}", 1,
                                              datetime.timedelta(hours=VIDEO_BACKTRACKING_TIME))
            else:
                await self.redis_conn.hset(f'{BEAUTIFUL_TIME_SCORE_STAT}{wonderful_video_ret_id}',
                                           mapping=beautiful_time_score_dict)
                await self.redis_conn.expire(f'{BEAUTIFUL_TIME_SCORE_STAT}{wonderful_video_ret_id}',
                                             datetime.timedelta(hours=VIDEO_BACKTRACKING_TIME))

    async def push_img(self, video_frame_obj: VideoFrame(), img_content: bytes, message_key: dict):
        """将图片资源持久化后，推送到云端"""
        user_id = message_key.get('user_id')
        beautiful_time = message_key.get('beautiful_time')
        wonderful_video_ret_id = message_key.get('wonderful_video_ret_id')
        if not img_content:
            persist_logger.warning(f'从{video_frame_obj.id}帧中未获取到图片内容')
        else:
            try:
                img_url = await async_upload_qiniu(img_content,
                                                   f'split_face/{user_id}/{wonderful_video_ret_id}/{beautiful_time}')
            except Exception:
                persist_logger.warning(f'上传{video_frame_obj.id}帧中图片内容到七牛云失败', exc_info=True)
            else:
                video_frame_obj = video_frame_obj.update_from_dict({'img_url': img_url})
                await video_frame_obj.save()
            # 消息推送到云端
            video_frame_data = dict(video_frame_obj)
            video_frame_data['scene_id'] = SCENE_ID
            video_frame_data.pop('create_time')
            try:
                await self.yun_producer.send_and_wait(VIDEO_FRAME_TOPIC, value=video_frame_data)
            except Exception:
                persist_logger.warning(f'精彩帧推送云端失败[{video_frame_data}]', exc_info=True)


    async def run_task(self):
        persist_logger.info('启动精彩瞬间持久化及推送任务')
        await self.per_run()
        async for message in self.model_frame_kafka_con:
            hum_face_key = message.key
            # hum_face_key = [{'body_coord': [1465, 688, 1891, 1709], 'face_coord': [1662, 775, 1775, 904],
            # 'video_equipment_id': '5', 'beautiful_time': '1637673024621',
            # 'user_id': 'da52880636fc11ecb73f0242c0a80102', 'wonderful_tag': 'climb', 'wonderful_weight': 70}]
            for message_key in hum_face_key:
                message_key, wonderful_video_ret_id = await self.get_wonderful_video_ret_id(message_key)
                await self.push_rich_msg(wonderful_video_ret_id, message_key)
                message_key['wonderful_video_ret_id'] = wonderful_video_ret_id
                message_key['create_time'] = time.strftime(SERIALIZER_DATETIME_FIELD_FORMAT)
                message_key['video_equipment_id'] = message_key.get('video_equipment_id')
                video_frame_obj = VideoFrame(**message_key)
                try:
                    await video_frame_obj.save()
                except Exception:
                    persist_logger.error(f'存储精彩瞬间失败', exc_info=True)
                else:
                    asyncio.get_event_loop().create_task(
                        self.push_img(
                            copy.deepcopy(video_frame_obj),
                            copy.deepcopy(message.value),
                            copy.deepcopy(message_key),
                        )
                    )
            # 批量存储没有返回 pk
            # video_frame_bulk_query = await VideoFrame.bulk_create(video_frame_obj_list)


class HandleAggMSG:
    def retry_handle_add_msg(self, template_video, wonderful_video_ret_id, user_id, group_id, is_show, extra):
        """处理用户重新获取视频的消息"""
        # 查询历史聚合数据
        try:
            with MysqlPool() as pool:
                fields = ['user_id', 'body_coord', 'video_equipment_id', 'frame_start_offset as beautiful_start_time',
                          'frame_end_offset as beautiful_end_time', 'wonderful_tag',
                          f'DATE_FORMAT(occurrence_date, "{SQL_DATE_FIELD_FORMAT}") as occurrence_date',
                          'wonderful_video_ret_id']
                wonderful_video_agg_ret_list = pool.execute_select(AGG_RET_TABLE_NAME,
                                                                   {'group_id': group_id},
                                                                   fields=fields)
        except Exception:
            persist_logger.error(f'查询历史聚合视频数据{wonderful_video_ret_id}失败', exc_info=True)
            return

        # 组装数据
        wonderful_video_img_time = None
        video_segment_data_list = list()
        for temp_seg_script_index, temp_seg_script in enumerate(template_video.temp_seg_set):
            for video_segment_data_index, video_segment_data in enumerate(wonderful_video_agg_ret_list):
                if temp_seg_script_index == video_segment_data_index:
                    if not wonderful_video_img_time:
                        wonderful_video_img_time = video_segment_data.get('beautiful_start_time')
                    beautiful_start_end = f"{video_segment_data['beautiful_start_time']}-" \
                                          f"{video_segment_data['beautiful_end_time']}"
                    video_segment_data['beautiful_start_end'] = beautiful_start_end
                    video_segment_data['serial_no'] = temp_seg_script['serial_no']
                    video_segment_data['zoom'] = temp_seg_script['zoom']
                    video_segment_data['lut_url'] = temp_seg_script['lut_url']
                    video_segment_data['var_speed'] = temp_seg_script['var_speed']
                    video_segment_data['id'] = temp_seg_script['id']
                    video_segment_data['mask_url'] = temp_seg_script['mask_url']
                    video_segment_data['decoration_url'] = temp_seg_script['decoration_url']
                    video_segment_data_list.append(video_segment_data)
                    break

        # 推送到kafka
        try:
            future = local_producer.send(BEAUTIFUL_RESULT_TOPIC,
                                         key={
                                             'video_start_url': template_video.video_start_url,
                                             'start_video_time': template_video.start_video_time,
                                             'video_end_url': template_video.video_end_url,
                                             'end_video_time': template_video.end_video_time,
                                             'video_music_url': template_video.video_music_url,
                                             'mask_url': template_video.mask_url,
                                             'lut_url': template_video.lut_url,
                                             'modelid': template_video.id,
                                             'temp_transition_set': template_video. \
                                         temp_transition_set[:len(video_segment_data_list) + 1],
                                             'width': template_video.width,
                                             'height': template_video.height,
                                             'wonderful_video_ret_id': wonderful_video_ret_id,
                                             # 精彩视频图片时间
                                             'wonderful_video_img_time': wonderful_video_img_time,
                                             'user_id': user_id,
                                             'video_id': group_id,
                                             'is_show': is_show,
                                             'extra': extra,
                                         },
                                         value=video_segment_data_list
                                         )
            # future.get(timeout=200)
        except Exception:
            persist_logger.error(f'精彩片段推送kafka-{BEAUTIFUL_RESULT_TOPIC}失败, value为{wonderful_video_agg_ret_list}',
                                 exc_info=True)
        else:
            persist_logger.info(f'[{user_id}]重试获取视频, group_id[{group_id}]；数据内容为{video_segment_data_list}')

    def handle_add_msg(self, template_video, wonderful_video_ret_id, user_id, group_id, extra_start_time,
                       extra_end_time, is_show, extra):
        """处理用户获取视频的消息"""
        create_msg_data = {'template_video_id': template_video.id, 'wonderful_video_ret_id': wonderful_video_ret_id,
                           'user_id': user_id, 'video_id': group_id, 'status': 0, 'is_show': is_show, 'extra': extra}
        # 推送创建视频消息到kafka
        try:
            yun_producer = KafkaProducer(bootstrap_servers=get_conf.YUN_KAFKA_SERVERS,
                                         value_serializer=lambda v: json.dumps(v).encode(),
                                         key_serializer=lambda v: json.dumps(v).encode(),
                                         request_timeout_ms=60000,
                                         retries=4,
                                         max_block_ms=300000,
                                         compression_type='gzip')
            future = yun_producer.send(VIDEO_RET_MSG, value=create_msg_data)
            yun_producer.flush(timeout=200)
            yun_producer.close()
            # future.get(timeout=200)
        except Exception:
            persist_logger.error(f'用户[{user_id}]聚合精彩视频记录[{group_id}]推送kafka-{BEAUTIFUL_RESULT_TOPIC}失败',
                                 exc_info=True)
            return

        field_names = ['video_equipment_id', 'beautiful_time', 'body_coord', 'face_coord', 'wonderful_weight',
                       'wonderful_tag']
        try:
            with MysqlPool() as pool:
                # ({'video_equipment_id': 1, 'beautiful_time': '1000000035390', 'body_coord': '[658, 115, 793, 299]',
                #   'face_coord': '[718, 129, 750, 171]', 'wonderful_weight': 60},)
                # if user_id == '85a380e633c611eca7080242c0a80102':
                #     video_frames_data = pool.execute_select(VIDEO_FRAME_TABLE_NAME,
                #                                             {'wonderful_video_ret_id': wonderful_video_ret_id},
                #                                             field_names)
                # else:
                #     sql_str = f"""
                #     SELECT {','.join(field_names) if field_names else '*'}
                #     FROM {VIDEO_FRAME_TABLE_NAME}
                #     WHERE wonderful_video_ret_id=%s or (create_time > %s and create_time < %s and user_id=%s)
                #     """
                #     video_frames_data = pool.execute_select_sql(sql_str, (wonderful_video_ret_id, extra_start_time,
                #                                                           extra_end_time, user_id))
                sql_str = f"""
                            SELECT {','.join(field_names) if field_names else '*'}
                            FROM {VIDEO_FRAME_TABLE_NAME}
                            WHERE (wonderful_video_ret_id=%s or (create_time > %s and create_time < %s and user_id=%s))
                                and (is_right is null or is_right=1);
                            """
                video_frames_data = pool.execute_select_sql(sql_str, (wonderful_video_ret_id, extra_start_time,
                                                                      extra_end_time, user_id))
                # 按照摄像头进行分组聚合
                video_frames_data = pd.DataFrame(video_frames_data, columns=field_names)
        except Exception:
            persist_logger.error(f'查询video_frame出错;wonderful_video_ret_id:{wonderful_video_ret_id}',
                                 exc_info=True)
            return

        # 最终的精彩视频保留结果
        wonderful_video_agg_ret_list = list()
        # 精彩视频候选字典
        wonderful_video_agg_candidate_dict = dict()

        # 按照tag进行分组
        for wonderful_tag, index_list in video_frames_data.groupby('wonderful_tag').groups.items():
            # 对当前分组结果 按照摄像头进行分组
            current_tag_group_data = video_frames_data[video_frames_data.index.isin(index_list)]
            single_tag_candidate_list = list()
            # 对分组结果进行聚合，构建对应tag的候选视频列表
            for video_equipment_id, index_list in current_tag_group_data.groupby('video_equipment_id').groups.items():
                current_group_data = video_frames_data[video_frames_data.index.isin(index_list)].sort_values('beautiful_time')
                # 每个分组中进行聚类，距离不超过指定阈值（阈值抽取到settings文件中）
                beautiful_time_np = current_group_data.beautiful_time.to_numpy(dtype=np.int64)
                # 另外一种聚类思路： 最近邻,把类与类间距离最近的作为类间距
                # agg_ret = sch.fcluster(sch.linkage(beautiful_time_np, method='single', metric=self.time_distinct),
                #                        t=3000, criterion="distance")

                dt = np.diff(beautiful_time_np)
                pos = np.where(dt > SPLIT_THRESHOLD)[0] + 1
                video_segment_list = np.split(current_group_data, pos)
                for index, video_segment in enumerate(video_segment_list):
                    # beautiful_start_time = int(video_segment.iloc[0].beautiful_time)
                    # beautiful_end_time = int(video_segment.iloc[-1].beautiful_time)
                    beautiful_start_time = int(video_segment.iloc[0].beautiful_time) - 100
                    beautiful_end_time = int(video_segment.iloc[-1].beautiful_time) + 100
                    beautiful_start_end = f'{beautiful_start_time}-{beautiful_end_time}'
                    total_time = beautiful_end_time - beautiful_start_time
                    # 取第一帧的人物的位置
                    body_coord = video_segment.iloc[0].body_coord
                    video_segment_data = {
                        'user_id': user_id, 'video_equipment_id': video_equipment_id, 'body_coord': body_coord,
                        'beautiful_start_time': beautiful_start_time, 'beautiful_end_time': beautiful_end_time,
                        'beautiful_start_end': beautiful_start_end, 'total_time': total_time,
                        'wonderful_tag': wonderful_tag,
                        'group_wonderful_weight': video_segment.wonderful_weight.max().item()
                    }
                    single_tag_candidate_list.append(video_segment_data)
            # 将候选视频按照视频长度排序（优选策略为视频长度）
            single_tag_candidate_list = sorted(single_tag_candidate_list,
                                               key=lambda x: (x.get('group_wonderful_weight'),
                                                              int(x.get('beautiful_end_time')))
                                               )
            wonderful_video_agg_candidate_dict[wonderful_tag] = single_tag_candidate_list

        search_no_script = list()
        # 脚本字典
        temp_seg_script_dict = dict()
        # 遍历模板脚本的用户部分，从对应tag的候选视频中筛选出指定视频
        for temp_seg_script in template_video.temp_seg_set:
            # {"wonderful_tag": "jump", "time": 3, "decoration_url": None, "mask_url": "test.mask.com", "serial_no": 3}
            current_script_wonderful_tag = temp_seg_script.get('wonderful_tag')
            temp_seg_script_dict[current_script_wonderful_tag] = temp_seg_script
            try:
                video_segment_data = wonderful_video_agg_candidate_dict[current_script_wonderful_tag].pop()
            except Exception:
                # 如果没有指定tag的视频，记录该脚本段
                persist_logger.warning('获取视频段失败', exc_info=True)
                search_no_script.append(temp_seg_script)
                continue

            current_script_time = temp_seg_script.get('time')
            video_segment_time = video_segment_data.get('total_time')
            # 如果视频长度不够
            if current_script_time > video_segment_time:
                lack_time = current_script_time - video_segment_time
                half_lack_time, remainder = divmod(lack_time, 2)
                video_segment_data['beautiful_start_time'] -= half_lack_time
                video_segment_data['beautiful_end_time'] += half_lack_time + remainder
                # 将剩余长度拼接到捕获视频前后
                video_segment_data['beautiful_start_end'] = \
                    f"{video_segment_data['beautiful_start_time']}-{video_segment_data['beautiful_end_time']}"
                video_segment_data['total_time'] = current_script_time
            # 如果长度过长
            elif current_script_time < video_segment_time:
                # 将视频剪到指定长度
                surplus_total_time = video_segment_data['total_time'] - current_script_time
                ret_end_time = video_segment_data['beautiful_start_time'] + current_script_time

                # 如果剩余长度大于当前要求段长度，将剩余部分放到候选list头部
                if surplus_total_time > current_script_time:
                    surplus_video_segment_data = copy.deepcopy(video_segment_data)
                    surplus_video_segment_data['total_time'] = surplus_total_time
                    surplus_video_segment_data['beautiful_start_time'] = ret_end_time
                    surplus_video_segment_data['wonderful_tag'] = current_script_wonderful_tag
                    wonderful_video_agg_candidate_dict[current_script_wonderful_tag].insert(0,
                                                                                            surplus_video_segment_data)
                video_segment_data['total_time'] = current_script_time
                video_segment_data['beautiful_end_time'] = ret_end_time
                video_segment_data[
                    'beautiful_start_end'] = f"{video_segment_data['beautiful_start_time']}-{ret_end_time}"
            video_segment_data['serial_no'] = temp_seg_script['serial_no']
            video_segment_data['zoom'] = temp_seg_script['zoom']
            video_segment_data['lut_url'] = temp_seg_script['lut_url']
            video_segment_data['var_speed'] = temp_seg_script['var_speed']
            video_segment_data['id'] = temp_seg_script['id']
            video_segment_data['mask_url'] = temp_seg_script['mask_url']
            video_segment_data['decoration_url'] = temp_seg_script['decoration_url']
            wonderful_video_agg_ret_list.append(video_segment_data)
        wonderful_video_agg_candidate_list = list()
        for wonderful_video_item in wonderful_video_agg_candidate_dict.values():
            wonderful_video_agg_candidate_list += wonderful_video_item
        wonderful_video_agg_candidate_list = sorted(wonderful_video_agg_candidate_list,
                                                    key=lambda x: x.get('group_wonderful_weight'))
        for temp_seg_script in search_no_script:
            # 遍历没有结果的脚本段，从候选视频中选出最优视频
            try:
                video_segment_data = wonderful_video_agg_candidate_list.pop()
            except Exception:
                persist_logger.warning('候选视频段为空', exc_info=True)
                # 如果候选视频为空，从结果视频中随机选取
                if wonderful_video_agg_ret_list:
                    video_segment_data = copy.deepcopy(random.choice(wonderful_video_agg_ret_list))
                    centre_time = (video_segment_data['beautiful_start_time'] +
                                   video_segment_data['beautiful_end_time']) // 2
                    video_segment_data['beautiful_start_time'] = centre_time
                    video_segment_data['beautiful_end_time'] = centre_time
                    video_segment_data['total_time'] = 0
                else:
                    persist_logger.warning('候选视频段为空的同时聚合结果视频也为空')
                    return

            current_script_time = temp_seg_script.get('time')
            video_segment_time = video_segment_data.get('total_time')
            # 如果视频长度不够
            if current_script_time > video_segment_time:
                lack_time = current_script_time - video_segment_time
                half_lack_time, remainder = divmod(lack_time, 2)
                video_segment_data['beautiful_start_time'] -= half_lack_time
                video_segment_data['beautiful_end_time'] += half_lack_time + remainder
                # 将剩余长度拼接到捕获视频前后
                video_segment_data['beautiful_start_end'] = \
                    f"{video_segment_data['beautiful_start_time']}-{video_segment_data['beautiful_end_time']}"
                video_segment_data['total_time'] = current_script_time
            # 如果长度过长
            elif current_script_time < video_segment_time:
                # 将视频剪到指定长度
                ret_end_time = video_segment_data['beautiful_start_time'] + current_script_time
                video_segment_data['total_time'] = current_script_time
                video_segment_data['beautiful_end_time'] = ret_end_time
                video_segment_data['beautiful_start_end'] = \
                    f"{video_segment_data['beautiful_start_time']}-{ret_end_time}"
            video_segment_data['serial_no'] = temp_seg_script['serial_no']
            # 根据标签添加视频特效
            seg_script = temp_seg_script_dict.get(video_segment_data.get('wonderful_tag')) or temp_seg_script
            video_segment_data['zoom'] = seg_script['zoom']
            video_segment_data['lut_url'] = seg_script['lut_url']
            video_segment_data['var_speed'] = seg_script['var_speed']
            video_segment_data['id'] = temp_seg_script['id']
            video_segment_data['mask_url'] = seg_script['mask_url']
            video_segment_data['decoration_url'] = seg_script['decoration_url']
            wonderful_video_agg_ret_list.append(video_segment_data)
        if not wonderful_video_agg_ret_list:
            # 排除如果数据为空的情况
            persist_logger.warning('遍历二遍后没有找模板对应的精彩视频')
            return
        # 对结果视频按照排序字段进行倒排
        wonderful_video_agg_ret_list = sorted(wonderful_video_agg_ret_list,
                                              key=lambda x: (x.get('serial_no'), x.get('id'),),
                                              reverse=True)
        wonderful_video_img_time = wonderful_video_agg_ret_list[0].get('beautiful_start_time')
        # 推送到kafka
        try:
            future = local_producer.send(BEAUTIFUL_RESULT_TOPIC,
                                         key={
                                             'video_start_url': template_video.video_start_url,
                                             'start_video_time': template_video.start_video_time,
                                             'video_end_url': template_video.video_end_url,
                                             'end_video_time': template_video.end_video_time,
                                             'video_music_url': template_video.video_music_url,
                                             'mask_url': template_video.mask_url,
                                             'lut_url': template_video.lut_url,
                                             'modelid': template_video.id,
                                             'temp_transition_set': template_video. \
                                         temp_transition_set[:len(wonderful_video_agg_ret_list) + 1],
                                             'width': template_video.width,
                                             'height': template_video.height,
                                             'wonderful_video_ret_id': wonderful_video_ret_id,
                                             # 精彩视频图片时间
                                             'wonderful_video_img_time': wonderful_video_img_time,
                                             'user_id': user_id,
                                             'video_id': group_id,
                                             'is_show': is_show,
                                             'extra': extra,
                                         },
                                         value=wonderful_video_agg_ret_list
                                         )
            # future.get(timeout=200)
        except Exception:
            persist_logger.error(f'精彩片段推送kafka-{BEAUTIFUL_RESULT_TOPIC}失败, value为{wonderful_video_agg_ret_list}',
                                 exc_info=True)
        else:
            # 持久化精彩视频
            wonderful_video_agg_ret_set = list()
            with MysqlPool() as pool:
                for wonderful_video_agg_ret in wonderful_video_agg_ret_list:
                    wonderful_video_agg_ret_set.append(
                        dict(user_id=user_id,
                             body_coord=wonderful_video_agg_ret.get('body_coord'),
                             video_equipment_id=wonderful_video_agg_ret.get('video_equipment_id'),
                             frame_start_offset=wonderful_video_agg_ret.get('beautiful_start_time'),
                             frame_end_offset=wonderful_video_agg_ret.get('beautiful_end_time'),
                             wonderful_tag=wonderful_video_agg_ret.get('wonderful_tag'),
                             occurrence_date=time.strftime(SERIALIZER_DATE_FIELD_FORMAT),
                             wonderful_video_ret_id=wonderful_video_ret_id,
                             create_time=time.strftime(SERIALIZER_DATETIME_FIELD_FORMAT),
                             group_id=group_id
                             )
                    )
                pool.execute_insert_many(AGG_RET_TABLE_NAME, wonderful_video_agg_ret_set)
        persist_logger.info(
            f'user[{user_id}] group_id[{group_id}] wonderful_video_ret_id[{wonderful_video_ret_id}] video send success')

    def handle_agg_msg(self):
        """
        处理来自yun_kafka的用户获取的精彩视频的消息
        :return:
        """
        persist_logger.info('启动聚合任务')
        while True:
            try:
                message = next(user_video_agg_msg_kafka_con)
                # pass
            except Exception:
                persist_logger.error(f'从kafka的用户视频聚合消息中取数据报错', exc_info=True)
            else:
                # msg 数据结构
                # value = {"user_id": "c7da31102a7711ec91930242c0a80102",
                #          "wonderful_video_ret_id": '32f3710a4d0f11ec85f04ccc6a437ac8', "type": 1,
                #          "extra_start_time": "2021-11-23 11:00:00", "extra_end_time": "2021-11-23 13:00:00",
                #          "template_video": {"id": 1, "name": "test", "video_start_url": "test", "video_end_url": "test",
                #                             "mask_url": None, "video_music_url": "test", "width": 1080, "height": 720,
                #                             'start_video_time': 9000, 'end_video_time': 5000, "scene_id": 0,
                #                             "lut_url": "test.lut_url.com",
                #                             "temp_transition_set": [
                #                                 {"transition_effect_name": "Doors2", "time": 500, "serial_no": 5},
                #                                 {"transition_effect_name": "Doors1", "time": 500, "serial_no": 5},
                #                                 {"transition_effect_name": "Doors1", "time": 300, "serial_no": 4},
                #                                 {"transition_effect_name": "flipOver", "time": 400, "serial_no": 3},
                #                                 {"transition_effect_name": "flipOver", "time": 400, "serial_no": 3}
                #                             ],
                #                                 "temp_seg_set": [
                #                                 {"wonderful_tag": "sea", "time": 2400, "decoration_url": None,
                #                                  'zoom': {"init_zoom": 1.3}, 'var_speed': 1.0,
                #                                  "mask_url": "test.mask.com", "serial_no": 4, "is_used": 1, "id": 1},
                #                                 {"wonderful_tag": "sea", "time": 2670, "decoration_url": None,
                #                                  'zoom': {"init_zoom": 1.3}, 'var_speed': 1.0,
                #                                  "mask_url": "test.mask.com", "serial_no": 3, "is_used": 1, "id": 2},
                #                                 {"wonderful_tag": "sea", "time": 2200, "decoration_url": None,
                #                                  'zoom': {"init_zoom": 1.3}, 'var_speed': 1.0,
                #                                  "mask_url": "test.mask2.com", "serial_no": 2, "is_used": 1, "id": 4},
                #                                 {"wonderful_tag": "jump", "time": 2500, "decoration_url": None,
                #                                  'zoom': {"init_zoom": 1.3}, 'var_speed': 1.0,
                #                                  "mask_url": "test.mask.com", "serial_no": 1, "is_used": 1, "id": 3}]}}
                value = message.value
                template_video = Dict(value.get('template_video'))
                wonderful_video_ret_id = value.get('wonderful_video_ret_id')
                extra_start_time = value.get('extra_start_time')
                extra_end_time = value.get('extra_end_time')
                user_id = value.get('user_id')
                msg_type = value.get('type')
                is_show = value.get('is_show', 1)
                extra = value.get('extra', {})
                if SCENE_ID != str(template_video.scene_id):
                    continue
                persist_logger.info(f'接收到一条获取视频消息, user_id:{user_id}, '
                                    f'wonderful_video_ret_id:{wonderful_video_ret_id}, type:{msg_type}')

                # {'1': add操作, '2': edit操作, '3': 用户重新获取}
                if msg_type == 1:
                    # 清空用户在reids中的游玩记录
                    redis_conn.delete(f'{PLAY_RECORD_PER_REDIS_KEY}{user_id}')
                    redis_conn.delete(f'{BEAUTIFUL_TIME_SCORE_STAT}{wonderful_video_ret_id}')
                    redis_conn.delete(f"{BEAUTIFUL_TIME_RICH_PUSH}{wonderful_video_ret_id}")
                # elif msg_type == 2:
                #     self.handle_edit_msg(template_video, wonderful_video_ret_id, user_id)

                # 每次聚合结果分为一组，一个游玩记录，可以聚合多次结果；一次结果会存储多个聚合记录，多个聚合记录通过group_id来划分
                if msg_type in (1, 2):
                    # 编辑视频或更换模板
                    group_id = uuid.uuid1()
                    self.handle_add_msg(template_video, wonderful_video_ret_id, user_id, group_id.hex, extra_start_time,
                                        extra_end_time, is_show, extra)
                elif msg_type == 3:
                    group_id = value.get('group_id')
                    # 重试制作
                    self.retry_handle_add_msg(template_video, wonderful_video_ret_id, user_id, group_id, is_show, extra)


def executor_callback(worker):
    worker_exception = worker.exception()
    if worker_exception:
        try:
            raise worker_exception
        except Exception:
            persist_logger.error('task run error', exc_info=True)


async def main():
    await Tortoise.init(config=TORTOISE_ORM)

    ## 提交到线程中运行
    loop = asyncio.get_event_loop()
    # 聚合用户视频任务
    loop.run_in_executor(None, HandleAggMSG().handle_agg_msg),
    # 辅助用户获取视频
    loop.run_in_executor(None, RemindUserGenVideo(datetime.timedelta(hours=2)).run_task, datetime.timedelta(minutes=5))

    coros_task = [
        # 持久化精彩瞬间的任务
        PersistFrame(
            beautiful_model_topic=BEAUTIFUL_MODEL_TOPIC, local_kafka_servers=LOCAL_KAFKA_SERVERS,
            redis_password=REDIS_PASSWORD, redis_host=REDIS_HOST, redis_port=REDIS_PORT, redis_db=DB
        ).run_task(),
        # 更新审核状态
        UpdateFrame(VIDEO_FRAME_UPDATE_TOPIC, get_conf.YUN_KAFKA_SERVERS).run_task(),
    ]
    ## 协程中并行运行
    await asyncio.gather(*coros_task)


if __name__ == '__main__':
    run_async(main())
