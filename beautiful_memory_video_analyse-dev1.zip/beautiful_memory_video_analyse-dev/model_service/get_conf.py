import configparser
from redis import StrictRedis
import os
import requests
from tools.log import Logger

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

log = Logger('logs/get_key_book_conf.log', level='info')

## 基本信息
SCENE_ID = config.get('base_info', 'scene_id')

## redis
REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
DB = config.get('redis', 'db')
redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD, decode_responses=True, db=DB)

key_book_url = config.get('key_book', 'key_book_url')


# 请求接口，读取Keybook表，把配置信息存到redis
try:
    key_book_conf = eval(requests.get(key_book_url, timeout=5).content.decode())['data']['conf_key_books']
except Exception:
    print(f"获取远程数据失败[{key_book_url}]")
else:
    for key_book in key_book_conf:
        redis_conn.set(key_book[0], key_book[1])
    log.logger.info(f'请求接口，读取Keybook表，把配置信息存到redis成功')


## KAFKA topic
LOCAL_KAFKA_SERVERS = config.get('local_kafka', 'servers')
# 识别到的精彩瞬间
BEAUTIFUL_MODEL_TOPIC = config.get('local_kafka', 'beautiful_model_topic')

# yunkafka地址
YUN_KAFKA_SERVERS = config.get('yun_kafka', 'servers').split(',')
# 云端kafka发送模型文件
ENGINE_FILE_TOPIC = config.get('yun_kafka', 'engine_file_topic')


## 识别引擎相关
# 人脸识别引擎默认文件名称
DEFAULT_ARCFACE_ENGINE_FILE_NAME = 'arcface.trtmodel.sl'
# 引擎保存路径
ENGINE_FILE_SAVE_PATH = 'face_detection/models/'
# 本地引擎文件url
ENGINE_FILE_LOCAL_URL = 'http://192.168.11.37:8080/engin/ai_self_learning/'
