# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2022/4/19 上午9:41
# @author yueyuanbo

class DetectModel:
    # 人脸检测模型
    FACE_DETECTOR = 1
    # 行人检测模型
    PERSON_DETECTOR = 2
    # tf-serving 目标检测
    BH_DETECTOR = 3
