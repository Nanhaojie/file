import tools.trtpy as tp
import cv2
import time
import os
from pathlib import Path
import numpy as np


BASE_DIR = Path(__file__).resolve().parent
conf_tch = 0.45
conf_tch_slide = 0.05
conf_climb = 0.8


class PersonDetection(object):
    def __init__(self):
        self.persondetector = tp.Yolo(os.path.join(BASE_DIR, 'yolohuman.trtmodel'), type=tp.YoloType.V5, device_id=0)

    def infer(self, frame, video_equipment_id):
        bboxes = self.persondetector.commit(frame).get()
        if video_equipment_id == '2':
            result = [[int(box.left), int(box.top), int(box.right), int(box.bottom), box.confidence]
                      for box in bboxes if box.class_label == 0 and box.confidence > conf_tch_slide]
        elif video_equipment_id == '4':
            result = [[int(box.left), int(box.top), int(box.right), int(box.bottom), box.confidence]
                      for box in bboxes if box.class_label == 0 and box.confidence > conf_climb]
        else:
            result = [[int(box.left), int(box.top), int(box.right), int(box.bottom), box.confidence]
                      for box in bboxes if box.class_label == 0 and box.confidence > conf_tch]
        return result


class SlidePersonDetect(object):
    def __init__(self):
        self.preframe = None

    def slideinfer(self, frame):
        frame = cv2.resize(frame, (int(frame.shape[0] / 5), int(frame.shape[1] / 5)))
        if self.preframe is not None:
            d = frame / 255 - self.preframe
            diff = np.sum(d > 0.5)
            self.preframe = frame / 255
            if diff > 200:
                return 1
            else:
                return 0
        else:
            self.preframe = frame / 255


if __name__ == '__main__':
    person_detect = PersonDetection()
    cam = cv2.VideoCapture(0)
    while True:
        _, frame = cam.read()
        # frame = cv2.imread('./bus.jpg')
        # for _ in range(500):
        #     result = person_detect(frame)
        start = time.time()
        result = person_detect.infer(frame)

        print('fps', 1 / (time.time() - start))


