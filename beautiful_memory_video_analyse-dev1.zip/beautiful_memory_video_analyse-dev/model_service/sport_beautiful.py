# -*- coding: utf-8 -*-
"""
@Time ： 2022/3/24 下午5:23
@Auth ： nhj
@File ：sport_beautiful.py
"""
import json
import cv2
import time

from curl_detect.curl import curl_main
from face_detection.test_retinaface import HumanFaceDetection
from constants import DetectModel
from tools.log import Logger
from kafka import KafkaProducer
import configparser
from tools.redis_utils import redis_conn
import multiprocessing as mp
from kafka import KafkaConsumer

from tools.img_cut import pipeline

config = configparser.ConfigParser()
config.read('conf/zoneyet.conf')

# kafka的参数
add_port = config.get('local_kafka', 'servers')
log = Logger('logs/sport.log', level='info').logger

beautiful_model_topic = config.get('local_kafka', 'beautiful_model_topic')
producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip', max_request_size=10 * 1024 * 1024)

# 云kafka
yun_kafka_server = config.get('yun_kafka', 'servers')
sports_video = config.get('yun_kafka', 'sports_video')

# 初始化模型类
face_detectors = HumanFaceDetection()


def begin_kafka(frame, curl_results, head_video_url, pos_time):
    ih, iw, ic = frame.shape
    for curl_result in curl_results:
        if curl_result['label'] == 'dun':
            human_face = dict()
            curl_x1, curl_y1, curl_x2, curl_y2 = max(0, curl_result['coord'][0]), \
                                                 max(0, curl_result['coord'][1]), \
                                                 min(iw, curl_result['coord'][2]), \
                                                 min(ih, curl_result['coord'][3])

            # 调用人脸检测,识别的模型
            curl_img = frame[curl_y1:curl_y2, curl_x1:curl_x2].copy()
            face_result = face_detectors.infer(curl_img)

            if face_result:
                coordinate, user_ids = face_result[0], face_result[1]
                # 遍历一张图中多个人脸
                for i, coord in enumerate(coordinate):
                    human_face['body_coord'] = [curl_x1, curl_y1, curl_x2, curl_y2]
                    human_face['face_coord'] = list(map(int, coord))
                    human_face['video_equipment_id'] = head_video_url
                    human_face['beautiful_time'] = pos_time
                    human_face['wonderful_tag'] = 'head'
                    human_face['wonderful_weight'] = 90

                    # 人脸比对成功
                    if user_ids[i]:
                        human_face['user_id'] = user_ids[i].split('_')[0]
                        # cv2.imwrite('sea/' + str(time.time()) + '.jpg', curl_img)
                        # producer.send(beautiful_model_topic, key=[human_face])
                        human_face['detection_model'] = DetectModel.FACE_DETECTOR
                        pipeline(curl_img, human_face, producer, beautiful_model_topic)
                        # 识别到人脸的时间发送到redis
                        redis_conn.set('dun_human_face', json.dumps(human_face), 30)
                        log.info(f'运动会冰壶场景识别到蹲{human_face}')


def middle_kafka(middle_video_url, end_video_url, all_video_url, middle_pos_time, curl_result):
    middle_human_face = json.loads(redis_conn.get('dun_human_face').decode())
    middle_human_face['body_coord'] = [curl_result['coord'][0], curl_result['coord'][1],
                                       curl_result['coord'][2], curl_result['coord'][3]]
    middle_human_face['face_coord'] = [curl_result['coord'][0], curl_result['coord'][1],
                                       curl_result['coord'][2], curl_result['coord'][3]]
    middle_human_face['video_equipment_id'] = middle_video_url
    middle_human_face['beautiful_time'] = middle_pos_time + 500
    middle_human_face['wonderful_tag'] = 'middle'
    middle_human_face['wonderful_weight'] = 90
    producer.send(beautiful_model_topic, key=[middle_human_face])
    log.info(f'中间识别到冰壶{middle_human_face}')

    # 最后的精彩时间与中间一样
    end_human_face = middle_human_face
    end_human_face['video_equipment_id'] = end_video_url
    end_human_face['wonderful_tag'] = 'end'
    producer.send(beautiful_model_topic, key=[end_human_face])
    log.info(f'最后场景识别到冰壶{end_human_face}')

    # 全景的精彩时间与中间一样
    all_human_face = middle_human_face
    all_human_face['video_equipment_id'] = all_video_url
    all_human_face['wonderful_tag'] = 'all'
    producer.send(beautiful_model_topic, key=[all_human_face])
    log.info(f'全景的精彩瞬间{all_human_face}')


def main(head_video_url, middle_video_url, end_video_url, all_video_url):
    # 开始镜头
    cam = cv2.VideoCapture(head_video_url)
    # 隔帧分析
    num = 0
    jump = 8

    # 中间镜头
    middle_cam = cv2.VideoCapture(middle_video_url)
    # 第一次判断有冰壶的情况
    first_bh_num = 1
    # 上一帧冰壶的总数
    last_bh_nums = 0

    # 统计当前一直没有冰壶的帧数
    zero_no_bh = 0

    start_time = time.time()

    while True:
        try:
            # 开始镜头
            _, frame = cam.read()
            pos_time = int(cam.get(cv2.CAP_PROP_POS_MSEC))
            # 中间镜头
            _, middle_frame = middle_cam.read()
            middle_pos_time = int(middle_cam.get(cv2.CAP_PROP_POS_MSEC))
            if num % jump == 0:
                # 调用肢体识别的模型
                curl_results = curl_main(frame)
                if curl_results:
                    begin_kafka(frame, curl_results, head_video_url, pos_time)
                # 调用冰壶识别的模型
                curl_results = curl_main(middle_frame)
                if curl_results:
                    # 当前帧画面冰壶的总数
                    now_bh_nums = 0

                    for curl_result in curl_results:
                        if curl_result['label'] == 'BH':
                            now_bh_nums += 1

                    # 如果当前有人站着或蹲着,但没有冰壶, 记录没有冰壶的帧数
                    if now_bh_nums == 0:
                        zero_no_bh += 1

                    # 如果连续五帧没有冰壶的时候,检测到冰壶就算精彩瞬间
                    if zero_no_bh > 5 and now_bh_nums > 0:
                        log.info(f'如果连续五帧没有冰壶的时候,检测到冰壶就算精彩瞬间,现在冰壶数:{now_bh_nums}')
                        try:
                            middle_kafka(middle_video_url, end_video_url, all_video_url, middle_pos_time, curl_results[0])
                            # 将记录没有冰壶的帧数清零, 重新记录没有冰壶的情况
                            zero_no_bh = 0
                        except:
                            log.info(f'前面没有识别到人：:{redis_conn.get("face_detect_time")}')

                    # 如果当前冰壶数量大于上一帧冰壶数
                    if last_bh_nums < now_bh_nums:
                        if first_bh_num:
                            first_bh_num = 0
                            last_bh_nums = now_bh_nums
                            log.info(f'如果画面中刚开始就有冰壶,当第一次当前冰壶的数量大于上一帧冰壶的数量不处理')
                        else:
                            try:
                                log.info(f'上一帧冰壶数量{last_bh_nums}, 当前帧冰壶数量{now_bh_nums}')
                                middle_kafka(middle_video_url, end_video_url, all_video_url, middle_pos_time, curl_results[0])
                                last_bh_nums = now_bh_nums
                            except:
                                log.info(f'前面没有识别到人：:{redis_conn.get("face_detect_time")}')
                # 如果当前没有冰壶
                else:
                    zero_no_bh += 1

                num += 1
            else:
                num += 1
        except:
            log.info(f'视频分析完成退出,视频分析耗时{time.time()-start_time}', exc_info=True)
            break


if __name__ == '__main__':
    mp.set_start_method(method='spawn')
    video_img_queue = mp.Queue()

    face_append_consumer = KafkaConsumer(sports_video, bootstrap_servers=yun_kafka_server,
                                         value_deserializer=lambda v: json.loads(v.decode()),
                                         auto_offset_reset='earliest', group_id='sport')

    for message in face_append_consumer:
        batch = message.value.get('batch')
        video_id = message.value.get('video_id')
        video_url = message.value.get('video_url')
        device_id = message.value.get('device_id')
        video_url0 = 0
        video_url1 = 0
        video_url2 = 0
        video_url3 = 0
        if '3D4E5960-ABD6-4198-BD23-C4C8120E3CE2' in device_id:
            for j, i in enumerate(device_id):
                if i == '2DFF6BE6-2715-4603-840E-B83A6D419905':
                    video_url0 = video_url[j]
                elif i == '3D4E5960-ABD6-4198-BD23-C4C8120E3CE2':
                    video_url1 = video_url[j]
                elif i == '7AFB4809-2941-4B8D-94BB-BE7A548DA7A5':
                    video_url2 = video_url[j]
                elif i == '8EFAC346-CA7A-4A4E-A33E-12DA7C4EC503':
                    video_url3 = video_url[j]
            log.info(f'第一组信息:{[video_url0, video_url1, video_url2, video_url3]}')

        elif 'D920E6F7-6AA5-4370-8258-DCE68A047084' in device_id:
            for j, i in enumerate(device_id):
                if i == 'D920E6F7-6AA5-4370-8258-DCE68A047084':
                    video_url0 = video_url[j]
                elif i == 'E5C9B9E4-42A8-4502-948E-53825B6BACB5':
                    video_url1 = video_url[j]
                elif i == 'CB1A7038-ECEE-400C-9D1A-FF5839B55206':
                    video_url2 = video_url[j]
                elif i == 'AC2A0546-7AE1-4B85-BA43-F28940E27D65':
                    video_url3 = video_url[j]
            log.info(f'第二组信息:{[video_url0, video_url1, video_url2, video_url3]}')

        elif '2DFF6BE6-2715-4603-840E-B83A6D419905' in device_id:
            for j, i in enumerate(device_id):
                if i == '2DFF6BE6-2715-4603-840E-B83A6D419905':
                    video_url0 = video_url[j]
                elif i == '278A0FD4-A5A4-4010-9BCB-F103ADDB09F5':
                    video_url1 = video_url[j]
                elif i == '09C2963D-DB14-4E3D-B047-FF0B9A27268B':
                    video_url2 = video_url[j]
                elif i == 'CB1A7038-ECEE-400C-9D1A-FF5839B55206':
                    video_url3 = video_url[j]
            log.info(f'第二组信息:{[video_url0, video_url1, video_url2, video_url3]}')

        elif len(device_id) == 0 and '2DFF6BE6-2715-4603-840E-B83A6D419905' in device_id:
            for j, i in enumerate(device_id):
                if i == '2DFF6BE6-2715-4603-840E-B83A6D419905':
                    video_url0 = video_url[j]
                    video_url1 = video_url[j]
                    video_url2 = video_url[j]
                    video_url3 = video_url[j]
                # elif i == 'E5C9B9E4-42A8-4502-948E-53825B6BACB5':
                #     video_url1 = video_url[j]
                # elif i == '9001F29D-6341-4454-8F2F-7734CF2F1AE2':
                #     video_url2 = video_url[j]
                # elif i == '193AEB99-F5A0-4C05-9D67-936A1B22BDB0':
                #     video_url3 = video_url[j]
            log.info(f'第二组信息:{[video_url0, video_url1, video_url2, video_url3]}')

        # processes = [
        #     mp.Process(target=main, args=(video_url0,)),
        #     mp.Process(target=middle, args=(video_url1, video_url2, video_url3)),
        # ]
        # [process.start() for process in processes]
        # [process.join() for process in processes]
        main(video_url0, video_url1, video_url2, video_url3)
