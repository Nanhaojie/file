from tools.redis_utils import redis_conn
from pedestrian_detection.human_model import PersonDetection
import time
import cv2

slide_track_ip = redis_conn.get('slide_track_ip').decode()
person_detect = PersonDetection()


def slide_human(start_time):
    # 调用行人检测的模型
    start_time_data = time.localtime((start_time - 5000)/1000)
    end_time_data = time.localtime(start_time/1000)
    start_time_rtsp = time.strftime("%Y%m%dt%H%M%Sz", start_time_data)
    end_time_rtsp = time.strftime("%Y%m%dt%H%M%Sz", end_time_data)
    rtsp = f'{slide_track_ip}starttime={start_time_rtsp}&endtime={end_time_rtsp}'
    cap = cv2.VideoCapture(rtsp)

    while cap.isOpened():
        is_opened, image = cap.read()
        video_pos_time = int(cap.get(cv2.CAP_PROP_POS_MSEC))
        time_stamp = start_time + video_pos_time
        human_result = person_detect.infer(image)
        if len(human_result) > 0:
            return time_stamp

