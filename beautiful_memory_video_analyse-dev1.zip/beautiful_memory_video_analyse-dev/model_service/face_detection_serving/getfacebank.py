import pickle

from absl import app, flags, logging
from absl.flags import FLAGS
import cv2
import os
import numpy as np
import tensorflow as tf
import time
from modules.utils import (set_memory_growth, load_yaml,
                           pad_input_image, recover_pad_output)
from utils.align import get_aligned_faces
from arcface.get_embbding import FACENET_TFLITE
from utils.getcandinator import get_candinator
flags.DEFINE_string('cfg_path', './configs/retinaface_mbv2.yaml',
                    'config file path')
flags.DEFINE_string('gpu', '0', 'which gpu to use')
flags.DEFINE_string('img_path', './bank/user1', 'path to input image')
flags.DEFINE_string('userid', 'user1', 'path to input image')
flags.DEFINE_boolean('webcam', False, 'get image source from webcam or not')
flags.DEFINE_float('iou_th', 0.4, 'iou threshold for nms')
flags.DEFINE_float('score_th', 0.85, 'score threshold for nms')
flags.DEFINE_float('down_scale_factor', 1, 'down-scale factor for inputs')
def main(_argv):
    # init
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
    os.environ['CUDA_VISIBLE_DEVICES'] = FLAGS.gpu

    logger = tf.get_logger()
    logger.disabled = True
    logger.setLevel(logging.FATAL)
    set_memory_growth()

    cfg = load_yaml(FLAGS.cfg_path)
    model = tf.saved_model.load('retinaface')
    recognizor = FACENET_TFLITE('mobilenet_arcface_optimized.tflite')
    if not FLAGS.webcam:
        if not os.path.exists(FLAGS.img_path):
            print(f"cannot find image path from {FLAGS.img_path}")
            exit()

        print("[*] Processing on single image {}".format(FLAGS.img_path))
        image_list = os.listdir(FLAGS.img_path)
        user_id = 'user1'
        embeddings = []
        for image in image_list:
            img_raw = cv2.imread(os.path.join(FLAGS.img_path,image))
            img_height_raw, img_width_raw, _ = img_raw.shape
            img = np.float32(img_raw.copy())

            if FLAGS.down_scale_factor < 1.0:
                img = cv2.resize(img, (0, 0), fx=FLAGS.down_scale_factor,
                                 fy=FLAGS.down_scale_factor,
                                 interpolation=cv2.INTER_LINEAR)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            # pad input image to avoid unmatched shape problem
            img, pad_params = pad_input_image(img, max_steps=max(cfg['steps']))

            # run model


            t1 = time.time()
            outputs = model(img[np.newaxis, ...]).numpy()
            print(time.time() - t1)

            # recover padding effect
            outputs = recover_pad_output(outputs, pad_params, FLAGS.score_th)
            faces = get_aligned_faces(img_raw, outputs , img_width_raw, img_height_raw)

            if len(faces) ==1:
                face = faces[0]
                face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
                face = face - 127.5
                face = face * 0.0078125

                embedding = recognizor.get_embedding(np.expand_dims(face,axis = 0).astype('float32'))
                embeddings.append(embedding)
            else:
                print("more than one users in camera")
                exit()
        with open(os.path.join(cfg['face_bank_pth'],user_id + '.pkl'), 'wb') as f:
            pickle.dump((user_id, embeddings), f)
            f.close()
if __name__ == '__main__':
    try:
        app.run(main)
    except SystemExit:
        pass

