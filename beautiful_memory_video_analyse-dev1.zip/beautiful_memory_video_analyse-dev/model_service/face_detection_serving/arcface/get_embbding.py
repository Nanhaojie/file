import tensorflow as tf
class FACENET_TFLITE:
    def __init__(self, model_path):
        interpreter = tf.lite.Interpreter(model_path=model_path)
        interpreter.allocate_tensors()

        # Get input and output tensors.
        input_details = interpreter.get_input_details()
        print(str(input_details))
        output_details = interpreter.get_output_details()
        print(str(output_details))
        self.inputs = input_details
        self.outputs = output_details
        self.interpreter = interpreter

    def get_embedding(self, images):
        self.interpreter.set_tensor(self.inputs[0]['index'], images)
        self.interpreter.invoke()
        embedding = self.interpreter.get_tensor(self.outputs[0]['index'])

        return embedding