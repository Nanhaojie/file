"""
@Time     : 2021/9/2 16:47
@Author   : nhj
@Project  : beautiful_memory
@File     : load_save_model.py
"""
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import configparser
import os

IS_PRODUCT = os.environ.get('IS_PRODUCT')
BASE_DIR = Path(__file__).resolve().parent.parent
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read(os.path.join(BASE_DIR, 'conf/pro.conf'))
else:
    config.read(os.path.join(BASE_DIR, 'conf/dev.conf'))

server = config.get('tf-serving', 'server')

gender_offsets = (10, 10)
channel = grpc.insecure_channel(server)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'beautifulMemory'
request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 2


def face_detect_serving(img):
    request.inputs['input_image'].CopyFrom(tf.make_tensor_proto(img.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    return data
