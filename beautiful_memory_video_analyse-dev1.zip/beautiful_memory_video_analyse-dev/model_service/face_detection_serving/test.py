import sys
from pathlib import Path

import cv2
import os

import numpy
import numpy as np
import time

from face_detection_serving.load_save_model import face_detect_serving
from face_detection_serving.modules.anchor import prior_box_tf, decode_tf
from face_detection_serving.modules.utils import (set_memory_growth, load_yaml, draw_bbox_landm,
                                          pad_input_image, recover_pad_output)
from face_detection_serving.utils.align import get_aligned_faces
from face_detection_serving.arcface.get_embbding import FACENET_TFLITE
from face_detection_serving.utils.getcandinator import get_candinator
import multiprocessing as mp
import tensorflow as tf
import os

# model = tf.saved_model.load('model_service/face_detection_serving/FaceDetector')
BASE_DIR = Path(__file__).resolve().parent.parent
cfg_path = os.path.join(BASE_DIR, 'face_detection_serving/configs/retinaface_mbv2.yaml')
score_th = 0.85
down_scale_factor = 0.2
# init
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
cfg = load_yaml(cfg_path)
face_detection_local_model_path = os.path.join(BASE_DIR, 'face_detection_serving/FaceDetector')


def normalize_labels(labels):
    labels_np = np.array(labels)
    return labels_np / labels_np.sum()


def calc_mean_score(score_dist):
    score_dist = normalize_labels(score_dist)
    return (score_dist * np.arange(1, 11)).sum()


def get_quality(fqmodel, face):
    # a = tf.convert_to_tensor(np.expand_dims(cv2.resize(face,(224, 224)), 0), dtype=tf.float32)
    a = tf.convert_to_tensor(np.expand_dims(face, 0), dtype=tf.float32)
    quality = fqmodel.signatures['image_quality'](a)
    quality = quality['quality_prediction'].numpy()
    return round(calc_mean_score(quality), 2)


def run_optimal(img, model, cfg, score_th):
    img -= (104, 117, 123)
    img = img.transpose(2, 0, 1)
    pred = model(input0=img[np.newaxis, ...])
    loc, conf, landms = pred['output0'], pred['590'], pred['589']
    preds = tf.concat(  # [bboxes, landms, landms_valid, conf]
        [loc[0], landms[0],
         tf.ones_like(conf[0, :, 0][..., tf.newaxis]),
         conf[0, :, 1][..., tf.newaxis]], 1)
    priors = prior_box_tf((img.shape[1], img.shape[2]),
                          cfg['min_sizes'], cfg['steps'], cfg['clip'])
    decode_preds = decode_tf(preds, priors, cfg['variances'])

    selected_indices = tf.image.non_max_suppression(
        boxes=decode_preds[:, :4],
        scores=decode_preds[:, -1],
        max_output_size=tf.shape(decode_preds)[0],
        iou_threshold=0.4,
        score_threshold=score_th)

    outputs = tf.gather(decode_preds, selected_indices).numpy()
    return outputs


def queue_img_put(q_put, s):
    cap = cv2.VideoCapture('rtsp://admin:root12300.@172.28.81.157:554/cam/realmonitor?channel=1&subtype=1')
    while True:
        s1 = time.time()
        is_opened, frame = cap.read()
        q_put.put(frame) if is_opened else None
        # q_put.get() if q_put.qsize() > 1 else None
        print('读取摄像头存入队列1的FPS: %.2f' % (1 / (time.time() - s1)))


def queue_img_get(result_img_q, window_name):
    cv2.namedWindow(window_name, flags=cv2.WINDOW_FREERATIO) if window_name else None
    while True:
        s3 = time.time()
        put_value = result_img_q.get()
        frame, outputs_ids, candinators = put_value[0], put_value[1], put_value[2]
        frame_height, frame_width, _ = frame.shape
        for id, outputs_id in enumerate(outputs_ids):
            draw_bbox_landm(frame, outputs_id, frame_height, frame_width, (0, 255, 0))
            # calculate fps
            cv2.putText(frame, str(candinators[id]), (200, 25), cv2.FONT_HERSHEY_DUPLEX, 0.75, (0, 255, 255), 2)
        cv2.imshow('frame', frame)
        if cv2.waitKey(1) == ord('q'):
            exit()
        print('读取队列2的图片进行展示的FPS: %.2f' % (1 / (time.time() - s3)))


class HumanFaceDetection:
    def __init__(self, recognizor_model):
        self.recognizor_model = recognizor_model

    def prepropess(self, frame: numpy.array):
        img_raw = np.float32(frame.copy())
        if down_scale_factor < 1.0:
            img = cv2.resize(img_raw, (0, 0), fx=down_scale_factor,
                             fy=down_scale_factor,
                             interpolation=cv2.INTER_LINEAR)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        else:
            img = cv2.cvtColor(img_raw, cv2.COLOR_BGR2RGB)
        # pad input image to avoid unmatched shape problem
        img, pad_params = pad_input_image(img, max_steps=max(cfg['steps']))
        return img, pad_params

    def inference_from_serving(self, img):
        # run model
        outputs = face_detect_serving(img[np.newaxis, ...])
        outputs = outputs['tf_op_layer_GatherV2']
        return outputs

    def inference_from_local(self, img):
        # 模型本地调用
        model = tf.saved_model.load(face_detection_local_model_path)
        outputs = run_optimal(img, model, cfg, score_th)
        return outputs

    def postprocess(self, outputs, pad_params, frame: numpy.array):
        frame_height, frame_width, _ = frame.shape
        if len(outputs) > 0:
            # recover padding effect
            outputs = recover_pad_output(outputs, pad_params, score_th)
            faces = get_aligned_faces(frame, outputs, frame_width, frame_height)
            id = 0
            outputs_ids = []
            candinators = []
            for face in faces:
                face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
                face = face - 127.5
                face = face * 0.0078125
                embedding = self.recognizor_model.get_embedding(np.expand_dims(face, axis=0).astype('float32'))
                candinator = get_candinator(embedding, os.path.join(BASE_DIR, cfg['face_bank_pth']))
                outputs_ids.append(outputs[id])
                candinators.append(candinator)
                id += 1
            return [frame, outputs_ids, candinators]


def face_detection(frame):
    recognizor = FACENET_TFLITE(os.path.join(BASE_DIR, 'face_detection_serving/mobilenet_arcface_optimized.tflite'))
    human_face_detection = HumanFaceDetection(recognizor_model=recognizor)
    img, pad_params = human_face_detection.prepropess(frame)
    output = human_face_detection.inference_from_serving(img)
    return human_face_detection.postprocess(output, pad_params, frame)


if __name__ == '__main__':
    mp.set_start_method(method='spawn')

    origin_img_q = mp.Queue()
    result_img_q = mp.Queue()

    processes = [
        mp.Process(target=queue_img_put, args=(origin_img_q, 1)),
        mp.Process(target=queue_img_get, args=(result_img_q, 'fram')),
    ]

    # [setattr(process, "daemon", True) for process in processes]
    [process.start() for process in processes]
    [process.join() for process in processes]
