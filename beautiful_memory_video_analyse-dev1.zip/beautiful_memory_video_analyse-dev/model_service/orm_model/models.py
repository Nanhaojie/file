# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2022/4/15 下午3:42
# @author yueyuanbo

from tortoise import models
from tortoise import fields


class SpareFieldModel(models.Model):
    """为模型类补充备用字段"""
    id = fields.BigIntField(pk=True)
    spare_str1 = fields.CharField(max_length=512, null=True, blank=True, description='备用字符串字段1')
    spare_str2 = fields.CharField(max_length=512, null=True, blank=True, description='备用字符串字段2')
    spare_str3 = fields.CharField(max_length=512, null=True, blank=True, description='备用字符串字段3')
    spare_int1 = fields.IntField(null=True, blank=True, description='备用int字段1')
    spare_int2 = fields.IntField(null=True, blank=True, description='备用int字段2')
    spare_int3 = fields.IntField(null=True, blank=True, description='备用int字段3')

    class Meta:
        # 说明是抽象模型类，数据库迁移时不会生成表
        abstract = True


class VideoFrame(SpareFieldModel):
    """
    精彩画面表
    """
    user_id = fields.CharField(max_length=32, index=True)
    video_equipment_id = fields.CharField(max_length=512, null=True, verbose_name='设备id/上传视频url')
    beautiful_time = fields.CharField(max_length=512, description='时间')
    body_coord = fields.CharField(max_length=256, description='身体坐标')
    face_coord = fields.CharField(max_length=256, description='人脸坐标')
    wonderful_tag = fields.CharField(max_length=128, description='精彩标签')
    wonderful_weight = fields.IntField(description='精彩权重')
    wonderful_video_ret_id = fields.CharField(max_length=32, index=True)
    create_time = fields.DatetimeField(auto_now_add=True, description="创建时间")
    is_right = fields.BooleanField(null=True, description="是否正确")  # 聚合时候过滤掉 =0 的
    detection_model = fields.CharField(max_length=128, null=True)
    img_url = fields.CharField(max_length=512, null=True)

    class Meta:
        table = 't_video_frame'


class WonderfulVideoAggRet(SpareFieldModel):
    """
    精彩视频聚合结果
    """
    user_id = fields.CharField(max_length=32, index=True)
    body_coord = fields.CharField(max_length=32, description='身体坐标')
    frame_start_offset = fields.BigIntField(description='开始帧')
    frame_end_offset = fields.BigIntField(description='结束帧')
    video_equipment_id = fields.CharField(max_length=512, null=True, verbose_name='设备id/上传视频url')
    occurrence_date = fields.DateField(description='精彩视频日期')
    group_id = fields.CharField(max_length=32, null=True, blank=True, description='聚合组号')
    wonderful_video_ret_id = fields.CharField(max_length=32, index=True)
    wonderful_tag = fields.CharField(max_length=128, description='精彩标签')
    create_time = fields.DatetimeField(auto_now_add=True, description="创建时间")

    class Meta:
        table = 't_wonderful_video_agg_ret'
