import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import cv2
import torch
import configparser
from redis import StrictRedis
IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]

# redis
REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
BODY_TEMPLATE_REDIS_KEY = config.get('redis', 'body_template_key')
BODY_TEMPLATE_REDIS_NAME = config.get('redis', 'body_template_name')
DB = config.get('redis', 'db')
redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD, db=DB)

gender_offsets = (10, 10)
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
server = config.get('tf-serving', 'server')
channel = grpc.insecure_channel(server, options=options)
stub_1 = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request_1 = predict_pb2.PredictRequest()
request_1.model_spec.name = 'beautifulMemory'
request_1.model_spec.signature_name = 'serving_default'
request_1.model_spec.version.value = 15

dist_thres = eval(redis_conn.get('dist_thres').decode())
image_width = 128
image_height = 256


class NameLen(object):
    def __init__(self):
        self.name_len_id = dict()

    def quarry_names_update(self,quarry_names):
        for name_i in quarry_names:
            if name_i not in self.name_len_id.keys():
                self.name_len_id[name_i]=0

    def person_num_update(self, qurray_name):
        num = self.name_len_id[qurray_name] + 1
        self.name_len_id[qurray_name] = num

    def num_destroy(self):
        for k_qurray_name, v in self.name_len_id.items():
            if v == 5:
                self.name_len_id = dict()
                return k_qurray_name
        return None


def body_recognition(person_cuts, person_query_dict):
    #  person_rusult
    person_query = [j['characteristic'] for j in person_query_dict]
    # person_query = np.squeeze(np.array(person_query))
    person_cut = [j['hum_img'] for j in person_cuts]
    person_cut = [cv2.resize(img_cut, (image_width, image_height), interpolation=cv2.INTER_CUBIC).astype('float32').transpose(2,0,1) for img_cut in person_cut]
    imgs = np.array(person_cut)
    request_1.inputs['images'].CopyFrom(tf.make_tensor_proto(imgs.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future_1 = stub_1.Predict.future(request_1, 10.0)  # 10 secs timeout
    result_1 = result_future_1.result()
    data_1 = {}
    for key_1 in result_1.outputs:
        tensor_proto_1 = result_1.outputs[key_1]
        data_1[key_1] = tf.make_ndarray(tensor_proto_1)
    person_result = data_1['output']
    person_result = torch.tensor(person_result)
    gallery_feats = torch.nn.functional.normalize(person_result, dim=1, p=2)  # 计算出查询图片的特征向量 gallery_feats：person_result

    # person_query是身体特征［人数*2048］
    person_query = [torch.tensor(i) for i in person_query]
    person_query = torch.cat(person_query)
    query_feats = torch.nn.functional.normalize(person_query, dim=1, p=2)  # 计算出查询图片的特征向量 gallery_feats：query

    # person_reid ，m:query_number,  n:person_num
    m, n = query_feats.shape[0], gallery_feats.shape[0]
    distmat = torch.pow(query_feats, 2).sum(dim=1, keepdim=True).expand(m, n) + \
              torch.pow(gallery_feats, 2).sum(dim=1, keepdim=True).expand(n, m).t()

    distmat.addmm_(1, -2, query_feats, gallery_feats.t())
    persons = []
    if len(distmat) > 0:
        for i in range(distmat.shape[1]):
            di_person_max_index = distmat[:, i]
            list_a = di_person_max_index.tolist()

            list_min = min(list_a)  # 返回最小值
            min_index = list_a.index(min(list_a))  # 返回最小值的索引
            if list_min < dist_thres:
                person = dict()
                # print('距离：%s' % distmat[i][min_index])
                # plot_one_box(gallery_loc[min_index], im0, label='find!' + str(i), color=colors[int(cls)])
                person['user_id'] = person_query_dict[min_index]['user_id']
                person['video_equipment_id'] = person_cuts[i]['video_equipment_id']
                person['body_coord'] = person_cuts[i]['body_coord']
                person['distance'] = distmat[min_index][i]
                person['beautiful_time'] = person_cuts[i]['beautiful_time']
                persons.append(person)
    return persons
