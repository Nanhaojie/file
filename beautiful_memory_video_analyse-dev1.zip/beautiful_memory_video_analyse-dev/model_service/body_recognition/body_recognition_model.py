#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory 
@File ：human_recognition.py
@Author ：nhj
@Date ：2021/9/17 上午11:15 
"""
import cv2
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import configparser
import os

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

server = config.get('tf-serving', 'server')
channel = grpc.insecure_channel(server)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'beautifulMemory'
request.model_spec.signature_name = ""
request.model_spec.version.value = 15

gpu_options = tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.6)
config = tf.compat.v1.ConfigProto(gpu_options=gpu_options)
session = tf.compat.v1.Session(config=config)

image_width = 128
image_height = 256


def body_rec(image):
    img = cv2.resize(image, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    img = img.astype("float32").transpose(2, 0, 1)[np.newaxis]  # (1, 3, h, w)
    request.inputs['images'].CopyFrom(tf.make_tensor_proto(img.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 80.0)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    box_out = data['output']
    return box_out
