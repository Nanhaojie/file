#!/bin/bash
source /etc/profile
/root/miniconda3/envs/py38/bin/pip install -r requirements.txt -i https://pypi.douban.com/simple
# /root/miniconda3/envs/py38/bin/python  get_conf.py &
# /root/miniconda3/envs/py38/bin/python face_template.py &
/root/miniconda3/envs/py38/bin/python  persist_records.py &
/root/miniconda3/envs/py38/bin/python  chaosuan_analyse_video.py &>chaosuan.log &

