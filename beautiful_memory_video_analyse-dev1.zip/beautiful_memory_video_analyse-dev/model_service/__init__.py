#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：beautiful_memory 
@File ：__init__.py.py
@Author ：nhj
@Date ：2021/9/6 下午4:22 
'''