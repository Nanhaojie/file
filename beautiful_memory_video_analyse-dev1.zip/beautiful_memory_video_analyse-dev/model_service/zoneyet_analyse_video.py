#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory
@File ：main_kafka.py
@Author ：nhj
@Date ：2021/9/9 下午3:32
"""
import cv2
import time
from body_recognition.mul_tf_recgnition import NameLen
from face_detection.test_retinaface import HumanFaceDetection
from common import BeautifulTool, HumanFace
from tools.redis_utils import redis_conn
from pedestrian_detection.human_model import PersonDetection
from tools.log import Logger
from threading import Thread
from persist_records import persist_frame
import multiprocessing as mp


# kafka的参数
add_port = redis_conn.get('local_kafka').decode().split(',')
log = Logger('logs/wonderful_video.log', level='info').logger

# video equipment id
climb_equipment_wall_id = redis_conn.get('climb_equipment_wall_id').decode()
climb_equipment_ce_id = redis_conn.get('climb_equipment_ce_id').decode()
slide_equipment_high_id = redis_conn.get('slide_equipment_high_id').decode()
slide_equipment_low_id = redis_conn.get('slide_equipment_low_id').decode()
sea_equipment_id = redis_conn.get('sea_equipment_id').decode()
jump_equipment_id = redis_conn.get('jump_equipment_id').decode()
door_equipment_id = redis_conn.get('door_equipment_id').decode()

# video equipment ip
climb_equipment_wall_ip = redis_conn.get('climb_equipment_wall_ip').decode()
climb_equipment_ce_ip = redis_conn.get('climb_equipment_ce_ip').decode()
slide_equipment_high_ip = redis_conn.get('slide_equipment_high_ip').decode()
slide_equipment_low_ip = redis_conn.get('slide_equipment_low_ip').decode()
sea_equipment_ip = redis_conn.get('sea_equipment_ip').decode()
jump_equipment_ip = redis_conn.get('jump_equipment_ip').decode()
door_equipment_ip = redis_conn.get('door_equipment_ip').decode()

# 攀岩场景超过秒删除身体底板
climb_limit_time = eval(redis_conn.get('climb_limit_time').decode())

# 存储user_id和对应的人物追踪id
human_have_face_track = dict()

jump_last_c = dict()

# 初始化模型类
face_detectors = HumanFaceDetection()
person_detect = PersonDetection()
name_len = NameLen()


class ThreadedCamera(object):
    def __init__(self, source=0):
        self.capture = cv2.VideoCapture(source)
        self.thread = Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()
        self.status = False
        self.frame = None
        self.video_pos_time = None

    def update(self):
        while True:
            if self.capture.isOpened():
                (self.status, self.frame) = self.capture.read()
                self.video_pos_time = int(self.capture.get(cv2.CAP_PROP_POS_MSEC))

    def grab_frame(self):
        if self.status:
            return self.frame, self.video_pos_time
        return None, None


def consumer_beautiful(image, hum_face_key):
    # 遍历一张图中多个行人
    user_ids = [users['user_id'] for users in hum_face_key]
    for hum_face in hum_face_key:
        beautiful_time = hum_face['beautiful_time']
        # 获取行人的坐标
        body_coord = hum_face['body_coord']
        body_x1, body_y1, body_x2, body_y2 = body_coord[0], body_coord[1], body_coord[2], body_coord[3]
        image_h, image_w, _ = image.shape
        body_x1 = max(0, body_x1)
        body_y1 = max(0, body_y1)
        body_x2 = min(image_w, body_x2)
        body_y2 = min(image_h, body_y2)

        beautiful_tool = BeautifulTool(image, hum_face, beautiful_time, body_x1, body_y1, body_x2, body_y2)

        # 海洋球摄像头，判断是否有手势
        if hum_face['video_equipment_id'] == '1':
            beautiful_tool.expression_beautiful()
            beautiful_tool.gesture_beautiful()

        # 蹦床摄像头， 调用肢体动作的模型
        elif hum_face['video_equipment_id'] == jump_equipment_id:
            if hum_face['user_id'] in jump_last_c.keys():
                if jump_last_c[hum_face['user_id']]:
                    beautiful_tool.pose_beautiful(jump_last_c[hum_face['user_id']])

            jump_last_c[hum_face['user_id']] = [body_x1, body_y1, body_x2, body_y2]


def hum_face_detection(image, video_pos_time, video_start_time, video_equipment_id):
    if image is not None and video_pos_time is not None:
        time_stamp = video_start_time + video_pos_time
        camera_ip = video_equipment_id

        # 调用人脸检测,识别的模型
        face_result = face_detectors.infer(image)

        # 调用行人检测的模型
        human_result = person_detect.infer(image)

        # 行人检测与人脸检测的结果融合
        if human_result:
            # 判断人脸是否在人体框中，如果不在，并且在攀岩场景下，调用人体识别
            human_face_result = HumanFace(face_result, human_result, image, camera_ip, time_stamp)
            human_faces, human_no_faces = human_face_result.human_face()

            # 调用精彩瞬间的模块
            consumer_beautiful(image, human_faces)


def main(rtsps):
    # 读摄像头的流
    rtsp0 = rtsps[0]
    rtsp1 = rtsps[1]

    streamer0 = ThreadedCamera(rtsp0)
    streamer1 = ThreadedCamera(rtsp1)

    video_equipment_id0 = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time0 = int(
            time.mktime(time.strptime(rtsp0.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    video_equipment_id1 = rtsp1.split('/')[-1].split('?')[0][0]
    video_start_time1 = int(
            time.mktime(time.strptime(rtsp1.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    while True:
        image0, video_pos_time0 = streamer0.grab_frame()
        image1, video_pos_time1 = streamer1.grab_frame()

        hum_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0)
        hum_face_detection(image1, video_pos_time1, video_start_time1, video_equipment_id1)


def main_jump(rtsps):
    # 读摄像头的流
    rtsp0 = rtsps[0]
    streamer0 = ThreadedCamera(rtsp0)
    video_equipment_id0 = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time0 = int(
            time.mktime(time.strptime(rtsp0.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    slide_rtsp = rtsps[1]
    slide_streamer = ThreadedCamera(slide_rtsp)
    slide_video_start_time = int(
            time.mktime(time.strptime(slide_rtsp.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    while True:
        image0, video_pos_time0 = streamer0.grab_frame()

        slide_image, slide_video_pos_time = slide_streamer.grab_frame()
        if slide_image is not None and slide_video_pos_time is not None:
            slide_time_stamp = slide_video_start_time + slide_video_pos_time
            # 调用行人检测的模型
            human_result = person_detect.infer(slide_image)
            if human_result:
                redis_conn.set('slide_high_time', slide_time_stamp)
                redis_conn.expire('slide_high_time', 60)

        hum_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0)


def main_zoneyet(rtsp):
    # 读摄像头的流
    streamer0 = ThreadedCamera(rtsp)
    video_equipment_id0 = '1'
    video_start_time0 = int(round(time.time() * 1000))

    while True:
        image0, video_pos_time0 = streamer0.grab_frame()
        hum_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0)


if __name__ == '__main__':
    mp.set_start_method(method='spawn')
    video_img_queue = mp.Queue()
    processes = [
        mp.Process(target=main_zoneyet, args=('rtsp://zhanghengxing:zhanghengxing20@172.17.30.3:554/Streaming/Channels/101?transportmode=unicast',)),
    ]
    [process.start() for process in processes]
    [process.join() for process in processes]
