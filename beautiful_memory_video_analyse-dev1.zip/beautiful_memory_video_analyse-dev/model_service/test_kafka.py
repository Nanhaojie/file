# -*- coding: utf-8 -*-
"""
@Time ： 2022/3/24 下午5:23
@Auth ： nhj
@File ：sport_beautiful.py
"""
import json
import cv2
import time
from tools.redis_utils import redis_conn
from tools.log import Logger
from threading import Thread, Lock
from kafka import KafkaProducer
import configparser
import multiprocessing as mp
from kafka import KafkaConsumer

config = configparser.ConfigParser()
config.read('conf/zoneyet.conf')

# kafka的参数
add_port = config.get('local_kafka', 'servers')
log = Logger('logs/sport.log', level='info').logger

beautiful_model_topic = config.get('local_kafka', 'beautiful_model_topic')
producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip', max_request_size=10 * 1024 * 1024)




class ThreadedCamera(object):
    def __init__(self, source=0):
        self.capture = cv2.VideoCapture(source)
        self.lock = Lock()
        self.thread = Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()

    def update(self):
        while True:
            if self.capture.isOpened():
                with self.lock:
                    self.capture.grab()
                time.sleep(0.001)

    def grab_frame(self):
        with self.lock:
            status, frame = self.capture.retrieve()
            video_pos_time = int(self.capture.get(cv2.CAP_PROP_POS_MSEC))
        if status:
            return frame, video_pos_time
        return None, None


def main(head_video_url):
    print(head_video_url)


def middle(middle_video_url, end_video_url):
    print(middle_video_url, end_video_url)


# if __name__ == '__main__':
#     mp.set_start_method(method='spawn')
#     video_img_queue = mp.Queue()
#
#     face_append_consumer = KafkaConsumer('sports_video', bootstrap_servers='172.16.1.30:9092',
#                                          value_deserializer=lambda v: json.loads(v.decode()),
#                                          auto_offset_reset='earliest', group_id='sport')
#
#
#     for message in face_append_consumer:
#         if redis_conn.get('batch') == message.value.get('batch'):
#             log.info(f'kafka重复消费数据,跳过')
#             continue
#         else:
#             batch = message.value.get('batch')
#             video_id = message.value.get('video_id')
#             video_url = message.value.get('video_url')
#             device_id = message.value.get('device_id')
#             redis_conn.set('batch', batch)
#             time.sleep(3)
#             log.info(f'接收到运动会上传的视频信息：:{video_url}')
#
#         # processes = [
#         #     mp.Process(target=main, args=(video_url[0],)),
#         #     mp.Process(target=middle, args=(video_url[1], video_url[2],)),
#         # ]
#         # [process.start() for process in processes]
#         # [process.join() for process in processes]


if __name__ == '__main__':
    mp.set_start_method(method='spawn')
    video_img_queue = mp.Queue()

    face_append_consumer = KafkaConsumer('sports_video', bootstrap_servers='172.16.1.30:9092',
                                         value_deserializer=lambda v: json.loads(v.decode()),
                                         auto_offset_reset='earliest', group_id='sport')

    for message in face_append_consumer:
        batch = message.value.get('batch')
        video_id = message.value.get('video_id')
        video_url = message.value.get('video_url')
        device_id = message.value.get('device_id')
        log.info(f'接收到运动会上传的视频信息：:{video_url}')
        video_url0 = 0
        video_url1 = 0
        video_url2 = 0
        video_url3 = 0
        if '2DFF6BE6-2715-4603-840E-B83A6D419905' in device_id:
            for j, i in enumerate(device_id):
                if i == '2DFF6BE6-2715-4603-840E-B83A6D419905':
                    video_url0 = video_url[j]
                elif i == '3D4E5960-ABD6-4198-BD23-C4C8120E3CE2':
                    video_url1 = video_url[j]
                elif i == '7AFB4809-2941-4B8D-94BB-BE7A548DA7A5':
                    video_url2 = video_url[j]
                elif i == '8EFAC346-CA7A-4A4E-A33E-12DA7C4EC503':
                    video_url3 = video_url[j]
            print('0', [video_url0, video_url1, video_url2, video_url3])

        elif 'D920E6F7-6AA5-4370-8258-DCE68A047084' in device_id:
            for j, i in enumerate(device_id):
                if i == 'D920E6F7-6AA5-4370-8258-DCE68A047084':
                    video_url0 = video_url[j]
                elif i == 'E5C9B9E4-42A8-4502-948E-53825B6BACB5':
                    video_url1 = video_url[j]
                elif i == 'CB1A7038-ECEE-400C-9D1A-FF5839B55206':
                    video_url2 = video_url[j]
                elif i == 'AC2A0546-7AE1-4B85-BA43-F28940E27D65':
                    video_url3 = video_url[j]
            print('1', [video_url0, video_url1, video_url2, video_url3])
