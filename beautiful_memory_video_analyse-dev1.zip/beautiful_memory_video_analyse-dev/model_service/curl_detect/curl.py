import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import cv2
import torch
from utils.general import non_max_suppression, scale_coords
import time

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]

gender_offsets = (10, 10)
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
server = '172.16.0.18:8500'
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'test'
request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 20511


def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True, stride=32):
    # Resize and pad image while meeting stride-multiple constraints
    shape = im.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    # Compute padding
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return im, ratio, (dw, dh)


def plot_one_box(x, im, color=(0, 0, 255), label=None, line_thickness=3):
    # Plots one bounding box on image 'im' using OpenCV
    assert im.data.contiguous, 'Image not contiguous. Apply np.ascontiguousarray(im) to plot_on_box() input image.'
    tl = line_thickness or round(0.002 * (im.shape[0] + im.shape[1]) / 2) + 1  # line/font thickness
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(im, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(im, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(im, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)


def curl_main(img0):
    imgsz = [640, 640]
    img_copy = img0.copy()
    img0 = img0.astype('float32')
    img = letterbox(img0, 640, stride=64, auto=False)[0]
    img = np.ascontiguousarray(img)
    img = img.astype('float32')
    img /= 255.0
    img = img[None]

    request.inputs['input_1'].CopyFrom(tf.compat.v1.make_tensor_proto(img.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 20)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)

    pred = data['tf_detect']
    pred[..., 0] *= imgsz[1]  # x
    pred[..., 1] *= imgsz[0]  # y
    pred[..., 2] *= imgsz[1]  # w
    pred[..., 3] *= imgsz[0]  # h
    pred = torch.tensor(pred)

    pred = non_max_suppression(pred, 0.65, 0.45, classes=None, agnostic=False,
                               max_det=1000)  # conf_thres=0.25, iou_thres=0.45

    curl_results = []
    for i, det in enumerate(pred):
        img = img.transpose((0, 3, 2, 1))[::-1]
        det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img_copy.shape).round()
        det = det.numpy()
        for *xyxy, conf, cls in reversed(det):
            curl_result = dict()
            if int(cls) == 0:
                curl_result['label'] = 'BH'
                curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
                curl_results.append(curl_result)
            elif int(cls) == 1:
                curl_result['label'] = 'zh'
                curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
                curl_results.append(curl_result)
            elif int(cls) == 2:
                curl_result['label'] = 'dun'
                curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
                curl_results.append(curl_result)
    return curl_results


# path = '/media/nhj/8e593e00-751a-4b70-88c0-e8544cd94ed2/project/beautiful_memory/beautiful_memory_video_analyse/model_service/20220329-094247.mp4'
# cam = cv2.VideoCapture(path)
# while True:
#     _, frame = cam.read()
#     pos_time = int(cam.get(cv2.CAP_PROP_POS_MSEC))
#
#     imgsz = [640, 640]
#     # model = tf.saved_model.load('./tensorflow/saved_model')
#     img0 = frame
#     img_copy = img0.copy()
#     t1 = time.time()
#     img0 = img0.astype('float32')
#     img = letterbox(img0, 640, stride=64, auto=False)[0]
#     # img = cv2.resize(img0,(640,640))
#     # img = img.transpose((2, 0, 1))[::-1]
#     img = np.ascontiguousarray(img)
#     # img = torch.from_numpy(img).to(0)
#     img = img.astype('float32')
#     img /= 255.0
#     img = img[None]
#
#     request.inputs['input_1'].CopyFrom(tf.compat.v1.make_tensor_proto(img.astype(dtype=np.float32)))  # 为模型的输入Name
#     result_future = stub.Predict.future(request, 20)  # 10 secs timeout
#     result = result_future.result()
#     data = {}
#     for key in result.outputs:
#         tensor_proto = result.outputs[key]
#         data[key] = tf.make_ndarray(tensor_proto)
#
#     pred = data['tf_detect']
#     pred[..., 0] *= imgsz[1]  # x
#     pred[..., 1] *= imgsz[0]  # y
#     pred[..., 2] *= imgsz[1]  # w
#     pred[..., 3] *= imgsz[0]  # h
#     pred = torch.tensor(pred)
#     # print(pred)                 # 非空
#
#     pred = non_max_suppression(pred, 0.2, 0.45, classes=None, agnostic=False,
#                                max_det=1000)  # conf_thres=0.25, iou_thres=0.45
#     # print(pred)             # pred---> tensor([], size=(0, 6))
#
#     curl_results = []
#     for i, det in enumerate(pred):
#         img = img.transpose((0, 3, 2, 1))[::-1]
#         det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img_copy.shape).round()
#         det = det.numpy()
#         for *xyxy, conf, cls in reversed(det):
#             curl_result = dict()
#             if int(cls) == 0:
#                 curl_result['label'] = 'BH'
#                 curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
#                 curl_results.append(curl_result)
#             elif int(cls) == 1:
#                 curl_result['label'] = 'zh'
#                 curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
#                 curl_results.append(curl_result)
#             elif int(cls) == 2:
#                 curl_result['label'] = 'dun'
#                 curl_result['coord'] = [int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])]
#                 curl_results.append(curl_result)
#     print('------', time.time()-t1, curl_results)



# p = 'http://aisource.trycan.com/mysp/sports_video/16496465654793684.mp4'
# cam = cv2.VideoCapture(p)
# while True:
#     _, frame = cam.read()
#     curl_results = curl_main(frame)
#     if curl_results:
#         for curl_result in curl_results:
#             if curl_result['label'] == 'dun':
#                 print(curl_result['label'])