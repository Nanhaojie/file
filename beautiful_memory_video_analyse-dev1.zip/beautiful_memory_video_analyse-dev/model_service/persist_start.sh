#!/bin/bash

pip3 install -r persist_app_requirements.txt -i https://pypi.douban.com/simple
python3  persist_records.py
