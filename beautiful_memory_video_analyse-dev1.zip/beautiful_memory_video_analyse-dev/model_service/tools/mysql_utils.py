# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import os
from pathlib import Path

import MySQLdb.cursors
import configparser

from dbutils.pooled_db import PooledDB

BASE_DIR = Path(__file__).resolve().parent.parent

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

# mysql
MYSQL_HOST = config.get('mysql', 'host')
MYSQL_PORT = config.get('mysql', 'port')
MYSQL_USER = config.get('mysql', 'user')
MYSQL_PASSWORD = config.get('mysql', 'password')
MYSQL_DATABASE = config.get('mysql', 'database')


class MysqlPool:
    cmds = ["set names utf8mb4;"]
    conn_args = {
        'host': MYSQL_HOST,
        'port': int(MYSQL_PORT),
        'db': MYSQL_DATABASE,
        'user': MYSQL_USER,
        'passwd': MYSQL_PASSWORD,
        'charset': 'utf8',
        'cursorclass': MySQLdb.cursors.DictCursor
    }
    #  初始化时, 链接池中至少创建的空闲的链接, 0表示不创建, mincached: 5
    #  链接池中最大闲置的链接数(0和None不限制): 20
    pool = PooledDB(MySQLdb, mincached=5, maxcached=20, setsession=cmds, **conn_args)

    def __enter__(self):
        self.conn = MysqlPool.pool.connection()
        self.cursor = self.conn.cursor()
        return self

    def execute_insert(self, tb: str, data: dict):
        values = [str(item) for item in data.values()]
        sentence = 'INSERT %s (' % tb + ','.join(data.keys()) + \
                   ') VALUES (' + ','.join(["%s"] * len(values)) + ');'
        self.cursor.execute(sentence, values)
        self.conn.commit()

    def execute_insert_many(self, tb: str, data_list: list):
        values_list = [[str(item) for item in data.values()] for data in data_list]
        first_data = data_list[0]
        sentence = 'INSERT %s (' % tb + ','.join(first_data.keys()) + \
                   ') VALUES (' + ','.join(["%s"] * len(first_data)) + ');'
        self.cursor.executemany(sentence, values_list)
        self.conn.commit()

    def execute_select(self, tb: str, filter: dict, fields: list, order_part=''):
        sentence = f"""
        SELECT {','.join(fields) if fields else '*'}
        FROM {tb}
        WHERE {','.join([f'{key}=%s' for key in filter.keys()])}
        {order_part};
        """
        values = [item for item in filter.values()]
        self.cursor.execute(sentence, values)
        return self.cursor.fetchall()

    def execute_select_sql(self, sql_str, params):
        self.cursor.execute(sql_str, params)
        return self.cursor.fetchall()

    def __exit__(self, type, value, trace):
        self.cursor.close()
        self.conn.close()


if __name__ == '__main__':
    with MysqlPool() as pool:
        tb = 't_video_frame'
        # dt = [{
        #     "id": 29206,
        #     "spare_str1": None,
        #     "spare_str2": None,
        #     "spare_int1": None,
        #     "spare_int2": None,
        #     "wonderful_tag": "3",
        #     "wonderful_weight": 60,
        #     "create_time": "2021-09-30 16:58:03",
        #     "user_id": "6",
        #     "video_equipment_id": 1,
        #     "wonderful_video_ret_id": 45,
        #     "body_coord": "[658, 115, 793, 299]",
        #     "face_coord": "[718, 129, 750, 171]",
        #     "beautiful_time": "1000000035390",
        #     "spare_int3": None,
        #     "spare_str3": None
        # },
        #     {
        #         "id": 29205,
        #         "spare_str1": None,
        #         "spare_str2": None,
        #         "spare_int1": None,
        #         "spare_int2": None,
        #         "wonderful_tag": "3",
        #         "wonderful_weight": 60,
        #         "create_time": "2021-09-30 16:58:03",
        #         "user_id": "6",
        #         "video_equipment_id": 1,
        #         "wonderful_video_ret_id": 45,
        #         "body_coord": "[658, 115, 793, 299]",
        #         "face_coord": "[718, 129, 750, 171]",
        #         "beautiful_time": "1000000035390",
        #         "spare_int3": None,
        #         "spare_str3": None
        #     }
        # ]
        # pool.execute_insert_many(tb, dt)
        ret = pool.execute_select(tb, {'wonderful_video_ret_id': 45}, ['beautiful_time as b_t'])
        print(ret)
