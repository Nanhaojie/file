# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2022/5/24 上午11:13
# @author yueyuanbo
from kafka import KafkaProducer

from constants import DetectModel
from tools.log import Logger
import cv2

log = Logger('logs/wonderful_video.log', level='info').logger


def img_sliced(image, x1, y1, x2, y2) -> bytes:
    """将img裁剪后 转换为 file bytes 类型"""
    # 按照比例每个方向扩展 0.5
    x_extend = (x2 - x1) * 0.5
    y_extend = (y2 - y1) * 0.5
    x1 -= x_extend
    x2 += x_extend
    x1 = x1 if x1 > 0 else 0
    y1 -= y_extend
    y2 += y_extend
    y1 = y1 if y1 > 0 else 0
    x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
    return cv2.imencode('.jpg', image[y1:y2, x1:x2].copy())[1].tostring()


def pipeline(img, beautiful_record_data, producer: KafkaProducer, beautiful_model_topic):
    """精彩瞬间持久化管道"""
    # 根据检测模型，截取对应图片，一并发送到kafka
    if beautiful_record_data['detection_model'] == DetectModel.FACE_DETECTOR:
        # 截取并保存人脸图片
        img_bytes = img_sliced(img, *beautiful_record_data['face_coord'])
    elif beautiful_record_data['detection_model'] == DetectModel.PERSON_DETECTOR:
        # 截取并保存身体图片
        img_bytes = img_sliced(img, *beautiful_record_data['body_coord'])
    elif beautiful_record_data['detection_model'] == DetectModel.BH_DETECTOR:
        # 截取并保存目标图片
        img_bytes = img_sliced(img, *beautiful_record_data['body_coord'])
    else:
        img_bytes = None
        log.warning(f'截取照片时，未找到配置的模型{beautiful_record_data["detection_model"]}')
    producer.send(beautiful_model_topic, key=[beautiful_record_data], value=img_bytes)
