# -*- coding: utf-8 -*-
"""
@Time ： 2022/3/29 下午2:37
@Auth ： nhj
@File ：video_upload.py
"""
import asyncio

from async_cow.cow import AsyncCow
from qiniu import Auth, put_file

# 七牛
ACCESS_KEY_QINIU = 'gVrvT-thSqZA5iUipLTghCLSgNOwycB3LOtbOyrq'
SECRET_KEY_QINIU = 'gR8d0v2EeovtI20N84mjJDFp9aiVvOa4K2KuZals'
# 要上传的空间
BUCKET_QINIU = 'ai-trycan'
STORAGE_HOST_QINIU = 'http://aisource.trycan.com/'


def upload(key, file_path, file_prefix='sport/video/'):
    """视频文件上传七牛云"""
    access_key = ACCESS_KEY_QINIU
    secret_key = SECRET_KEY_QINIU
    # 要上传的空间
    bucket_name = BUCKET_QINIU
    # 构建鉴权对象
    q = Auth(access_key, secret_key)
    # 生成上传 Token，可以指定过期时间等
    token = q.upload_token(bucket_name)
    key = file_prefix + key
    ret, info = put_file(token, key, file_path)
    if info and info.status_code != 200:
        print("上传文件到七牛失败, 失败状态码为{}， 原因为{}".format(info.status_code, info.text_body))
    return STORAGE_HOST_QINIU + ret['key']


async def async_upload_qiniu(data, file_name):
    access_key = ACCESS_KEY_QINIU
    secret_key = SECRET_KEY_QINIU
    cow = AsyncCow(access_key, secret_key)
    b = cow.get_bucket(BUCKET_QINIU)
    key = 'mysp/' + file_name
    res = await b.put_data(data=data, key=key)
    return STORAGE_HOST_QINIU + res[0]['key']

# s = upload('142445.jpg', '/home/nhj/下载/飞书20220412-142445.jpg')
# print(s)

# p = 'http://aisource.trycan.com/mysp/sports_video/16494322470620780.mp4'
# import cv2
# cam = cv2.VideoCapture(p)
# while True:
#     _, frame = cam.read()
#
#     cv2.imshow('gg', frame)
#     cv2.imwrite('fg9.jpg', frame)
#     cv2.waitKey(3)
if __name__ == '__main__':
    with open('/home/yueyb/下载/webface.trtmodel', 'rb') as f:
        print(asyncio.run(async_upload_qiniu(f.read(), 'engin/ai_self_learning/face_recognition/trt/arcface.web.trtmodel')))