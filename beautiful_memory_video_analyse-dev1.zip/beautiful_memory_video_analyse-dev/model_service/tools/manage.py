# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2022/5/27 上午11:46
# @author yueyuanbo
import os
import asyncio
import json
import socket

import aiofiles
import aiohttp
import multiprocessing as mp
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from urllib3.util import parse_url

from tools.log import Logger
import get_conf

log = Logger('logs/wonderful_video.log', level='info').logger


class ReceiveEngineFile:
    def __init__(self, engine_file_topic, resource_kafka_servers, send_conn, notify_kafka_server=None):
        self.engine_file_topic = engine_file_topic
        self.resource_kafka_servers = resource_kafka_servers
        self.notify_kafka_server = notify_kafka_server
        self.engine_file_save_path = get_conf.ENGINE_FILE_SAVE_PATH
        self.default_arcface_engine_file_name = get_conf.DEFAULT_ARCFACE_ENGINE_FILE_NAME
        self.send_conn = send_conn

    def __await__(self):
        return self.initializer().__await__()

    async def initializer(self):
        """运行任务的前置工作"""
        self.update_frame_kafka_con = AIOKafkaConsumer(self.engine_file_topic,
                                                       bootstrap_servers=self.resource_kafka_servers,
                                                       value_deserializer=lambda x: json.loads(x),
                                                       group_id=f"{get_conf.SCENE_ID}_{socket.gethostname()}",
                                                       auto_offset_reset='latest')  # todo
        # auto_offset_reset='earliest')
        await self.update_frame_kafka_con.start()

        if self.notify_kafka_server:
            self.notify_kafka_producer = AIOKafkaProducer(bootstrap_servers=self.notify_kafka_server,
                                                          value_serializer=lambda x: json.dumps(x).encode())
            await self.notify_kafka_producer.start()
        return self

    async def release_resource(self):
        await self.update_frame_kafka_con.stop()
        if self.notify_kafka_server:
            await self.notify_kafka_producer.stop()

    async def download_engine_file(self, model_file_url):
        ## 保存数据
        try:
            async with aiohttp.ClientSession() as session:
                model_file_name = parse_url(model_file_url).path.replace('/', '_')
                async with session.get(model_file_url, timeout=60) as engine_file_res:
                    async with aiofiles.open(f'{self.engine_file_save_path}{model_file_name}', 'wb') as f:
                        async for chunk in engine_file_res.content.iter_chunked(4096):
                            await f.write(chunk)
                # 建立软连接到默认名称下
                link_file_abs_path = f'{self.engine_file_save_path}{self.default_arcface_engine_file_name}'
                if os.path.islink(link_file_abs_path):
                    os.remove(link_file_abs_path)
                os.symlink(model_file_name, link_file_abs_path)
                return model_file_name
        except Exception:
            log.error(f'存储模型文件{model_file_url}失败', exc_info=True)
        else:
            log.info(f'存储模型文件{model_file_url}成功')

    async def notify_other_node(self, value):
        # 通知本地其他需要模型文件的服务
        if self.notify_kafka_server:
            await self.notify_kafka_producer.send(self.engine_file_topic, value=value)

    async def run_task(self):
        log.info('启动接收引擎模型文件任务')
        try:
            async for message in self.update_frame_kafka_con:
                update_video_frame_data = message.value
                model_file_url = update_video_frame_data.get('model_file_url')
                log.info(f'从kafka中获取到文件url [{model_file_url}]')
                model_file_name = await self.download_engine_file(model_file_url)
                # 发送重新加载模型的消息
                self.send_conn.send(1)
                await self.notify_other_node({'model_file_url': f"{get_conf.ENGINE_FILE_LOCAL_URL}{model_file_name}"})
        finally:
            await self.release_resource()


class ProjectManager:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, face_detectors, resource_kafka_servers: str, notify_kafka_server: str = None):
        self.rec_conn, self.send_conn = mp.Pipe(duplex=False)
        self.face_detectors = face_detectors
        self.resource_kafka_servers = resource_kafka_servers
        self.notify_kafka_server = notify_kafka_server
        self.receive_engine_file_class = ReceiveEngineFile
        mp.set_start_method(method='spawn')
        self.processes_func_list = list()
        self.processes = list()

    def add_func(self, func, args: tuple):
        if not callable(func):
            raise Exception(f"{func}必须是一个callable对象")
        self.processes_func_list.append((func, args))

    def init_project_task(self):
        self.processes = list()
        for processes_func, processes_args in self.processes_func_list:
            self.processes.append(mp.Process(target=processes_func, args=processes_args))

    async def monitor_restart_project(self):
        while True:
            await asyncio.sleep(10)
            if self.rec_conn.poll():
                # 最后将消息清除，避免重复启动
                self.rec_conn.recv()
                self.restart_project()

    def start_project(self):
        """启动工程程序"""
        # 初始化工程任务
        self.init_project_task()
        list(map(lambda process: process.start(), self.processes))

    def restart_project(self):
        log.info("重新加载人脸模型后 重启项目")
        list(map(lambda process: process.terminate(), self.processes))
        self.face_detectors.reload_model()
        self.start_project()

    async def run_async_task(self):
        """启动异步任务"""
        # 启动模型文件接收任务
        receive_engine_task = await self.receive_engine_file_class(get_conf.ENGINE_FILE_TOPIC,
                                                                   self.resource_kafka_servers,
                                                                   self.send_conn, self.notify_kafka_server)
        loop = asyncio.get_running_loop()
        # # 接收模型文件，发送完成信号
        loop.create_task(receive_engine_task.run_task())
        # 启动事件监听任务
        await loop.create_task(self.monitor_restart_project())

    def run_main(self):
        self.start_project()
        asyncio.run(self.run_async_task())
