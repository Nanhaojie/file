import time
from pathlib import Path

import get_conf
import tools.trtpy as tp
import cv2
import os
import numpy as np
import requests
import configparser
from redis import StrictRedis
import json
from tools.log import Logger

log = Logger('logs/face1.log', level='info').logger

BASE_DIR = Path(__file__).resolve().parent.parent

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
FACE_TEMPLATE_REDIS_NAME = config.get('redis', 'face_template_name')
FACE_DATA_LAST_MODIFY_REDIS_KEY = config.get('redis', 'face_data_last_modify')
ACTIVE_SCENE_USER_REDIS_KEY = config.get('redis', 'active_scene_user')


def get_distance(emb1, emb2):
    # diff = emb1 - emb2
    # dist = np.sum(np.square(diff))
    return np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))


def get_candinator(emb, user_id_list, characteristic_list, threshold=1.1):
    try:
        dists = np.sum(np.square(np.array(characteristic_list) - emb), axis=2)
        min_id = np.argmin(dists)
        if dists[min_id] < threshold:
            return user_id_list[min_id]
        else:
            return None
    except Exception:
        log.warning('比对人脸数据失败', exc_info=True)
        return None


'''
def get_candinator(emb, facebank):
    # pickle.load('/Users/destination/Downloads/starface-master/facebank.pkl')
    # pkls = open('/Users/destination/Downloads/starface-master/facebank.pkl', 'rb')  # 明星库
    # pkls = os.listdir(facebank)
    # if '.DS_Store' in pkls:
    #     pkls.remove('.DS_Store')
    dists = []
    try:
        for pkl in facebank:
            # facepkl = open(os.path.join(facebank, pkl), 'rb')
            unmiddown = np.array(pkl['characteristic'][0])
            tmpdist = get_distance(emb, unmiddown)
            dists.append(tmpdist)
        idx = np.argmax(dists)

        if dists[idx] > 0.4:
            # log.logger.info(f'dists:{dists},facebank:{facebank[idx]["user_id"]}')
            candinator = facebank[idx]['user_id']
            return candinator
        else:
            return None
    except:
        return None
'''


class HumanFaceDetection:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        self.arcfacedetector = tp.Arcface(
            os.path.join(BASE_DIR, f'{get_conf.ENGINE_FILE_SAVE_PATH}{get_conf.DEFAULT_ARCFACE_ENGINE_FILE_NAME}')
        )  # _iresnet50.FP32.
        self.facedetector = tp.Retinaface(
            os.path.join(BASE_DIR, f'{get_conf.ENGINE_FILE_SAVE_PATH}retinaface.960x960.fp32.trtmodel'),
            nms_threshold=0.6, confidence_threshold=0.9)
        # self.fqmodel = tf.saved_model.load('/home/ssy/下载/retinaface-tf2-master/image-quality-assessment-master/contrib/tf_serving/tfs_models/mobilenet_aesthetic')
        self.redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD)
        self.face_template_redis_key = FACE_TEMPLATE_REDIS_NAME
        self.last_modify = None
        self.activate_user_ids = list()
        self.not_activate_user_ids = list()
        self.activate_user_faces = list()
        self.not_activate_user_faces = list()

    def reload_model(self):
        self.arcfacedetector = tp.Arcface(
            os.path.join(BASE_DIR, f'{get_conf.ENGINE_FILE_SAVE_PATH}{get_conf.DEFAULT_ARCFACE_ENGINE_FILE_NAME}')
        )  # _iresnet50.FP32.
        log.warning('重新加载模型')

    def infer(self, frame):
        real_last_modify = self.redis_conn.get(FACE_DATA_LAST_MODIFY_REDIS_KEY)
        if not real_last_modify:
            # init face_data_last_modify
            real_last_modify = str(int(time.time())).encode()
            self.redis_conn.set(FACE_DATA_LAST_MODIFY_REDIS_KEY, real_last_modify)

        ## update data of face
        if self.last_modify != real_last_modify:
            ## lock ？
            # 以轻微的数据损失减少服务器很多压力
            self.last_modify = real_last_modify

            with self.redis_conn.pipeline(transaction=False) as pipe:
                # pipeline(smembers active_user)(获取所有用户的key)
                pipe.smembers(ACTIVE_SCENE_USER_REDIS_KEY) \
                    .hkeys(self.face_template_redis_key)
                activate_user_ids, all_user_id_list = pipe.execute()
                # (做差计算得到非活跃用户)
                not_activate_user_ids = list(set(all_user_id_list) - activate_user_ids)
                activate_user_ids = list(activate_user_ids & set(all_user_id_list))
                # （pipeline hmget key1, key2 获取所有活跃用户的的底板和非活跃用户的底板)
                if activate_user_ids:
                    pipe.hmget(self.face_template_redis_key, activate_user_ids)
                if not_activate_user_ids:
                    pipe.hmget(self.face_template_redis_key, not_activate_user_ids)

                # 获取结果
                if activate_user_ids and not_activate_user_ids:
                    activate_user_faces, not_activate_user_faces = pipe.execute()
                elif activate_user_ids:
                    activate_user_faces = pipe.execute()[0]
                    not_activate_user_faces = list()
                elif not_activate_user_ids:
                    not_activate_user_faces = pipe.execute()[0]
                    activate_user_faces = list()
                else:
                    activate_user_faces = list()
                    not_activate_user_faces = list()

                self.activate_user_ids = list()
                self.activate_user_faces = list()
                self.not_activate_user_ids = list()
                self.not_activate_user_faces = list()
                for activate_user_face in activate_user_faces:
                    activate_user_face_data = json.loads(activate_user_face)
                    self.activate_user_faces.append(activate_user_face_data["characteristic"])
                    self.activate_user_ids.append(activate_user_face_data["user_id"])
                for not_activate_user_face in not_activate_user_faces:
                    not_activate_user_face_data = json.loads(not_activate_user_face)
                    self.not_activate_user_faces.append(not_activate_user_face_data["characteristic"])
                    self.not_activate_user_ids.append(not_activate_user_face_data["user_id"])

        faces = self.facedetector.commit(frame).get()
        if len(faces) > 0:
            user_ids = []
            candinators = []
            for face in faces:
                if (face.right - face.left) * (face.bottom - face.top) < 500000:
                    embedding = self.arcfacedetector.commit(frame, face.landmark).get()
                    user_id = None
                    if self.activate_user_ids:
                        # 先使用活跃用户
                        user_id = get_candinator(embedding[0], self.activate_user_ids, self.activate_user_faces, 1.1)
                    if not user_id and self.not_activate_user_ids:
                        # 返回空，使用非活跃用户
                        user_id = get_candinator(embedding[0], self.not_activate_user_ids, self.not_activate_user_faces,
                                                 1.1)
                    if user_id:
                        candinators.append(np.array((face.left, face.top, face.right, face.bottom)))
                        user_ids.append(user_id)
            return [candinators, user_ids]
        return []

    def embedding_f_face(self, image_array):
        faces = self.facedetector.commit(image_array).get()
        if len(faces) == 1:
            face = faces[0]
        elif len(faces) > 1:
            face = sorted(faces, key=lambda face: (face.right - face.left) * (face.bottom - face.top), reverse=True)[0]
        else:
            log.warning('未检测到人脸')
            return
        return self.arcfacedetector.commit(image_array, face.landmark).get()

    def face_embedding(self, user_id: str, image_urls, types):
        embeddings = []
        for image_url in image_urls:
            img_raw = self.cv_url_read(image_url)
            if img_raw is None:
                continue
            # img_raw = cv2.imread(os.path.join(BASE_DIR, '/home/ssy/下载/retinaface-tf2-master/bank/user1/' + image_url))
            # run model
            embedding = self.embedding_f_face(img_raw)
            if embedding is None:
                continue
            # embeddings.append(embedding)
            self.redis_conn.hset(
                self.face_template_redis_key, key=user_id + '_' + str(types),
                value=json.dumps({"user_id": user_id + '_' + str(types), "characteristic": embedding.tolist(),
                                  "url": image_url})
            )
        # with open(os.path.join(os.path.join(BASE_DIR, 'pkl_bank/'), user_id + '_' + str(types) + '.pkl'), 'wb') as f:
        #     pickle.dump((user_id, embeddings), f)

    def cv_url_read(self, image_url):
        try:
            res = requests.get(image_url, timeout=10)
            image_bytes = res.content
        except Exception:
            log.warning(f"转换图片为cv类型时，读取{image_url}失败", exc_info=True)
        else:
            # 图片类型转换
            return cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)


if __name__ == '__main__':
    # pickle.load()
    import sys
    import os

    current_file_path = os.path.abspath(__file__)
    project_base_path = os.path.dirname(os.path.dirname(current_file_path))
    os.chdir(project_base_path)
    sys.path.insert(0, project_base_path)

    cam = cv2.VideoCapture('/home/ssy/下载/D03_20211009154309.mp4')
    face_detection = HumanFaceDetection()
    frame = cv2.imread(
        '/home/zoneyet/project/beautiful_memory/beautiful_memory_video_analyse/model_service/face_detection_serving/bank/user1/2021.jpg')
    print(face_detection.infer(frame))

    # while True:
    #     _, frame = cam.read()
    #     start = time.time()
    #     r = face_detection.infer(frame)
    #     if r:
    #         for a in r[1]:
    #             pt1 = a[0:2].astype(int)
    #             pt2 = a[2:4].astype(int)
    #             cv2.rectangle(frame, (pt1[0], pt1[1]), (pt2[0], pt2[1]), (255, 0, 0), thickness=2)

    #     cv2.namedWindow("enhanced", 0);
    #     cv2.resizeWindow("enhanced", 960, 640);
    #     cv2.imshow('enhanced', frame)
    #     cv2.waitKey(1)
    #     print()
    # print('fps', 1 / (time.time() - start))

