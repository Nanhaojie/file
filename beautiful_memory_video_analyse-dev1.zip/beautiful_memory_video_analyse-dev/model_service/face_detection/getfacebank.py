import tools.trtpy as tp
import cv2
import requests
import numpy as np
import os
import pickle
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
def main(user_id: str, image_urls):
    # init
    arcfacedetector = tp.Arcface('/home/ssy/下载/tensorRT_cpp-main/workspace/arcface.trtmodel')
    facedetector = tp.Retinaface('/home/ssy/下载/tensorRT_cpp-main/workspace/myretinaface.trtmodel',
                                 nms_threshold=0.6)
    embeddings = []
    for image_url in image_urls:
        # image_bytes = requests.get(image_url).content
        # img_raw = cv2.imdecode(np.asarray(bytearray(image_bytes), dtype='uint8'), cv2.IMREAD_COLOR)
        img_raw = cv2.imread('/home/ssy/下载/retinaface-tf2-master/bank/user1/'+image_url)

        # run model
        faces = facedetector.commit(img_raw).get()
        if len(faces) == 1:
            face = faces[0]
            embedding = arcfacedetector.commit(img_raw, face.landmark).get()
            embeddings.append(embedding)

    with open(os.path.join('/home/ssy/下载/retinaface-tf2-master/pkl_bank/', user_id + '.pkl'), 'wb') as f:
        pickle.dump((user_id, embeddings), f)

if __name__ == '__main__':
    image_folder = '/home/ssy/下载/retinaface-tf2-master/bank/user1'
    images = os.listdir(image_folder)
    main('user1', images)
