import os
import sys
import cv2
import time
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
from grpc import insecure_channel
import configparser
import math

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

server = config.get('tf-serving', 'server')

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
STEP = 5
WINDOW_SIZE = 15

KPT_THRESH = 0


def skeleton_detect(img):
    img = cv2.resize(img, (256, 256))
    img = img[np.newaxis]
    channel = insecure_channel(server)
    stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
    request = predict_pb2.PredictRequest()
    request.model_spec.name = 'beautifulMemory'
    request.model_spec.signature_name = 'serving_default'
    request.model_spec.version.value = 4
    s = time.time()
    request.inputs['input'].CopyFrom(tf.make_tensor_proto(img, dtype=tf.int32))  # 为模型的输入Name
    result_future = stub.Predict.future(request)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    return data['output_0']


def action_detect(img):
    channel = insecure_channel(server)
    stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
    request = predict_pb2.PredictRequest()
    request.model_spec.name = 'beautifulMemory'
    request.model_spec.signature_name = 'serving_default'
    request.model_spec.version.value = 5
    s = time.time()
    request.inputs['input_1'].CopyFrom(tf.make_tensor_proto(img, dtype=tf.float32))  # 为模型的输入Name
    result_future = stub.Predict.future(request)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    return data


# preds = np.zeros((WINDOW_SIZE, 26))


def action_classify(preds):
    preds = np.array(preds)[np.newaxis]
    channel = insecure_channel(server)
    stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
    request = predict_pb2.PredictRequest()
    request.model_spec.name = 'beautifulMemory'
    request.model_spec.signature_name = 'serving_default'
    request.model_spec.version.value = 9
    request.inputs['input_1'].CopyFrom(tf.make_tensor_proto(preds, dtype=tf.float32))  # 为模型的输入Name
    result_future = stub.Predict.future(request)  # 10 secs timeout
    result = result_future.result()
    # data = {}
    # for key in result.outputs:
    tensor_proto = result.outputs['dense_2']
    data = tf.make_ndarray(tensor_proto)
    actid = np.argmax(data)
    if data[0][actid] > 0.85:
        return actid
    else:
        return None


def humans_to_skels_list(keypoints, scor_th=0.4):
    ''' Get skeleton data of (x, y * scale_h) from humans.
    Arguments:
        humans {a class returned by self.detect}
        scale_h {float}: scale each skeleton's y coordinate (height) value.
            Default: (image_height / image_widht).
    Returns:
        skeletons {list of list}: a list of skeleton.
            Each skeleton is also a list with a length of 36 (18 joints * 2 coord values).
        scale_h {float}: The resultant height(y coordinate) range.
            The x coordinate is between [0, 1].
            The y coordinate is between [0, scale_h]
    '''

    keypoints = np.squeeze(keypoints)
    keypoints = keypoints[:, [1, 0, 2]]
    for i in range(len(keypoints)):  # iterate dict
        if keypoints[i][2] < scor_th:
            keypoints[i, 0:2] = np.zeros(2)
    skeleton = keypoints[:, 0:2].reshape(34).tolist()

    return skeleton


def cal_ang(point_1, point_2, point_3):
    """
    根据三点坐标计算夹角
    :param point_1: 点1坐标
    :param point_2: 点2坐标
    :param point_3: 点3坐标
    :return: 返回任意角的夹角值，这里只是返回点2的夹角
    """
    a = math.sqrt(
        (point_2[0] - point_3[0]) * (point_2[0] - point_3[0]) + (point_2[1] - point_3[1]) * (point_2[1] - point_3[1]))
    b = math.sqrt(
        (point_1[0] - point_3[0]) * (point_1[0] - point_3[0]) + (point_1[1] - point_3[1]) * (point_1[1] - point_3[1]))
    c = math.sqrt(
        (point_1[0] - point_2[0]) * (point_1[0] - point_2[0]) + (point_1[1] - point_2[1]) * (point_1[1] - point_2[1]))

    B = math.degrees(math.acos((b * b - a * a - c * c) / (-2 * a * c)))

    return B


def act_est(keypoints):
    no_keypoints = np.zeros((17, 3))
    for i in range(len(keypoints)):  # iterate dict
        if keypoints[i][2] < 0.4:
            no_keypoints[i, 0:2] = np.zeros(2)
        else:
            no_keypoints[i, 0:2] = keypoints[i, 0:2]

    index1 = sum(keypoints[0:5, 2] > 0.4)
    index2 = sum(keypoints[11:13, 2] > 0.4)
    index4 = sum(keypoints[13:15, 2] > 0.4)
    index3 = sum(keypoints[15:17, 2] > 0.4)
    index5 = sum(keypoints[5:7, 2] > 0.4)

    if all([index1, index2, index3, index4, index5]):
        p1 = (no_keypoints[0, 0:2] + no_keypoints[1, 0:2] + no_keypoints[2, 0:2] + no_keypoints[3, 0:2] + no_keypoints[
                                                                                                          4,
                                                                                                          0:2]) / sum(
            keypoints[0:5, 2] > 0.4)
        # hip
        p2 = (no_keypoints[11, 0:2] + no_keypoints[12, 0:2]) / sum(keypoints[11:13, 2] > 0.4)
        # keen+ankle
        p3 = (no_keypoints[13, 0:2] + no_keypoints[14, 0:2] + no_keypoints[15, 0:2] + no_keypoints[16, 0:2]) / sum(
            keypoints[13:17, 2] > 0.4)

        p4 = (no_keypoints[11, 0:2] + no_keypoints[12, 0:2]) / sum(keypoints[11:13, 2] > 0.4)
        # keen
        p5 = (no_keypoints[13, 0:2] + no_keypoints[14, 0:2]) / sum(keypoints[13:15, 2] > 0.4)
        # shoulder
        p7 = (no_keypoints[5, 0:2] + no_keypoints[6, 0:2]) / sum(keypoints[5:7, 2] > 0.4)

        h1, w1 = p1 - p2
        ang1 = math.degrees(math.atan(h1 / w1))
        h2, w2 = p3 - p2
        ang2 = math.degrees(math.atan(h2 / w2))
        if all(np.array((p7[0], no_keypoints[10, 0:2][0], no_keypoints[9, 0:2][0]))):
            if cal_ang(no_keypoints[10, 0:2], p7, no_keypoints[9, 0:2]) > 120:
                return 5
        if all(no_keypoints[15, 0:2]) and all(no_keypoints[16, 0:2]):
            if cal_ang(p4, p5, no_keypoints[15, 0:2]) < 70 or cal_ang(p4, p5, no_keypoints[16, 0:2]) < 70:
                return 2
        if all(np.array((p5[0], p2[0], p7[0]))):
            if abs(math.degrees(math.atan((p7 - p2)[0] / (p7 - p2)[1]))) > 60 and cal_ang(p7, p2, p5) < 110:
                return 3
        elif abs(ang1) < 50 and abs(ang2) < 50:
            index = np.where(no_keypoints[:, 2] < 0.4)
            no_keypoints = np.delete(no_keypoints, index, axis=0)[:, 0:2]
            norm_w = no_keypoints[:, 1].max() - no_keypoints[:, 1].min()
            norm_h = no_keypoints[:, 0].max() - no_keypoints[:, 0].min()
            if norm_w / norm_h > 1.:
                return 4
        else:
            return None

    else:
        return None
