
import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import cv2
import torch
import time

# class Extractor(object):
#     def __init__(self, model_path, use_cuda=True):
#         self.net = Net(reid=True)
#         self.device = "cuda" if torch.cuda.is_available() and use_cuda else "cpu"
#         state_dict = torch.load(model_path, map_location=lambda storage, loc: storage)['net_dict']
#         self.net.load_state_dict(state_dict)
#         logger = logging.getLogger("root.tracker")
#         logger.info("Loading weights from {}... Done!".format(model_path))
#         self.net.to(self.device)
#         self.size = (64, 128)
#         self.norm = transforms.Compose([
#             transforms.ToTensor(),
#             transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
#         ])
#
#
#
#     def _preprocess(self, im_crops):
#         """
#         TODO:
#             1. to float with scale from 0 to 1
#             2. resize to (64, 128) as Market1501 dataset did
#             3. concatenate to a numpy array
#             3. to torch Tensor
#             4. normalize
#         """
#         def _resize(im, size):
#             return cv2.resize(im.astype(np.float32)/255., size)
#
#         im_batch = torch.cat([self.norm(_resize(im, self.size)).unsqueeze(0) for im in im_crops], dim=0).float()
#         return im_batch
#
#
#     def __call__(self, im_crops):
#         im_batch = self._preprocess(im_crops)
#         with torch.no_grad():
#             im_batch = im_batch.to(self.device)
#             features = self.net(im_batch)
#         return features.cpu().numpy()

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]

gender_offsets = (10, 10)
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
server = '172.28.81.144:8500'
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'beautifulMemory'
request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 15

imgsz = [320, 320]

class Extractor(object):
    def __init__(self, use_cuda=True):
        # self.net = Net(reid=True)
        self.device = "cuda" if torch.cuda.is_available() and use_cuda else "cpu"

        # # state_dict = torch.load(model_path, map_location=lambda storage, loc: storage)['net_dict']
        # self.net.load_state_dict(state_dict)
        # logger = logging.getLogger("root.tracker")
        # logger.info("Loading weights from {}... Done!".format(model_path))
        # self.net.to(self.device)
        # self.size = (64, 128)
        # self.norm = transforms.Compose([
        #     transforms.ToTensor(),
        #     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        # ])

    # def _preprocess(self, im_crops):
    #     """
    #     TODO:
    #         1. to float with scale from 0 to 1
    #         2. resize to (64, 128) as Market1501 dataset did
    #         3. concatenate to a numpy array
    #         3. to torch Tensor
    #         4. normalize
    #     """
    #
    #     def _resize(im, size):
    #         return cv2.resize(im.astype(np.float32) / 255., size)
    #
    #     im_batch = torch.cat([self.norm(_resize(im, self.size)).unsqueeze(0) for im in im_crops], dim=0).float()
    #     return im_batch

    def __call__(self, im_crops):
        #  person_rusult
        img_cut_all=[]
        if im_crops:
            for img_index in range(len(im_crops)):
                img_i=im_crops[img_index]
                # img_cut = img_copy[int(x[1]):int(x[3]), int(x[0]):int(x[2])]
                img_i = cv2.resize(img_i, (128, 256), interpolation=cv2.INTER_CUBIC)
                img_i = img_i.astype('float32').transpose(2, 0, 1)

                img_cut_all.append(img_i)

            imgs = np.array(img_cut_all)
            start = time.time()
            request.inputs['images'].CopyFrom(tf.make_tensor_proto(imgs.astype(dtype=np.float32)))  # 为模型的输入Name
            result_future_1 = stub.Predict.future(request, 10.0)  # 10 secs timeout
            result_1 = result_future_1.result()
            data_1 = {}
            for key_1 in result_1.outputs:
                tensor_proto_1 = result_1.outputs[key_1]
                data_1[key_1] = tf.make_ndarray(tensor_proto_1)
            person_result = data_1['output']
            person_result = torch.tensor(person_result)
            gallery_feats = torch.nn.functional.normalize(person_result, dim=1, p=2)  # 计算出查询图片的特征向量


            # im_batch = self._preprocess(im_crops)
            # with torch.no_grad():
            #     im_batch = im_batch.to(self.device)
            #     features = self.net(im_batch)
            return gallery_feats.cpu().numpy()
        else:
            return []


# if __name__ == '__main__':
#     img = cv2.imread("demo.jpg")[:,:,(2,1,0)]
#     extr = Extractor("checkpoint/ckpt.t7")
#     feature = extr(img)
#     print(feature.shape)

