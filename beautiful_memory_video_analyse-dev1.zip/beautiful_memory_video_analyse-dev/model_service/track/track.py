
import cv2
import torch

from track.deep_sort import DeepSort

deepsort = DeepSort('',
                        max_dist=0.2, min_confidence=0.3,
                        nms_max_overlap=0.5, max_iou_distance=0.7,
                        max_age=70, n_init=5, nn_budget=4,
                        use_cuda=True)

palette = (2 ** 11 - 1, 2 ** 15 - 1, 2 ** 20 - 1)


def bbox_rel(*xyxy):
    """" Calculates the relative bounding box from absolute pixel values. """
    bbox_left = min([xyxy[0].item(), xyxy[2].item()])
    bbox_top = min([xyxy[1].item(), xyxy[3].item()])
    bbox_w = abs(xyxy[0].item() - xyxy[2].item())
    bbox_h = abs(xyxy[1].item() - xyxy[3].item())
    x_c = (bbox_left + bbox_w / 2)
    y_c = (bbox_top + bbox_h / 2)
    w = bbox_w
    h = bbox_h
    return x_c, y_c, w, h


def compute_color_for_labels(label):
    """
    Simple function that adds fixed color depending on the class
    """
    color = [int((p * (label ** 2 - label + 1)) % 255) for p in palette]
    return tuple(color)


def draw_boxes(img, bbox, identities=None, offset=(0, 0)):
    for i, box in enumerate(bbox):
        x1, y1, x2, y2 = [int(i) for i in box]
        x1 += offset[0]
        x2 += offset[0]
        y1 += offset[1]
        y2 += offset[1]
        # box text and bar
        id = int(identities[i]) if identities is not None else 0
        color = compute_color_for_labels(id)
        label = '{}{:d}'.format("", id)
        t_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_PLAIN, 2, 2)[0]
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 3)
        cv2.rectangle(
            img, (x1, y1), (x1 + t_size[0] + 3, y1 + t_size[1] + 4), color, -1)
        cv2.putText(img, label, (x1, y1 +
                                 t_size[1] + 4), cv2.FONT_HERSHEY_PLAIN, 2, [255, 255, 255], 2)
    return img


def bbox_r(xyxy):
    """" Calculates the relative bounding box from absolute pixel values. """
    bbox_left = min([xyxy[0], xyxy[2]])
    bbox_top = min([xyxy[1], xyxy[3]])
    bbox_w = abs(xyxy[0] - xyxy[2])
    bbox_h = abs(xyxy[1] - xyxy[3])
    x_c = (bbox_left + bbox_w / 2)
    y_c = (bbox_top + bbox_h / 2)
    w = bbox_w
    h = bbox_h
    return x_c, y_c, w, h


def human_track(human_result, image):
    bbox_xywh = []
    confs = []
    xy = []
    for result in human_result:
        coord = result[0: -1]
        conf = result[-1]
        x_c, y_c, bbox_w, bbox_h = bbox_r(coord)
        obj = [x_c, y_c, bbox_w, bbox_h]

        bbox_xywh.append(obj)
        confs.append(conf)
        xy.append(coord)

    xywhs = torch.Tensor(bbox_xywh)
    confss = torch.Tensor(confs)
    # Pass detections to deepsort
    outputs = deepsort.update(xywhs, confss, image)

    # draw boxes for visualization
    if len(outputs) > 0:
        # if not (outputs.shape[0] == features.shape[0]):
        #     print('butong', outputs.shape[0], features.shape[0])
        #     # exit()
        bbox_xyxy = outputs[:, :4].tolist()
        identities = outputs[:, -1].tolist()
        return [bbox_xyxy, identities]
    else:
        return []
    #     draw_boxes(image, bbox_xyxy, identities)
    # cv2.imshow('1111', image)
    # cv2.waitKey(1)

