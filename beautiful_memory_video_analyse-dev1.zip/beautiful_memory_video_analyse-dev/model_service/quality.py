import tensorflow as tf
import numpy as np
import cv2


class get_quality(object):
    def __init__(self):
        self.fqmodel = tf.saved_model.load(
            '/home/ssy/下载/retinaface-tf2-master/image-quality-assessment-master/contrib/tf_serving/tfs_models/mobilenet_aesthetic')

    def normalize_labels(self, labels):
        labels_np = np.array(labels)
        return labels_np / labels_np.sum()

    def calc_mean_score(self, score_dist):
        score_dist = self.normalize_labels(score_dist)
        return (score_dist * np.arange(1, 11)).sum()

    def get_quality(self, fqmodel, face):
        a = tf.convert_to_tensor(np.expand_dims(cv2.resize(face, (224, 224)), 0), dtype=tf.float32)
        quality = fqmodel.signatures['image_quality'](a)
        quality = quality['quality_prediction'].numpy()
        return round(self.calc_mean_score(quality), 2)
