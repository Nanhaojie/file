import tools.trtpy as tp
import cv2
import time
import os
from pathlib import Path

conf_tch = 0.2
BASE_DIR = Path(__file__).resolve().parent


class GestureDetection(object):
    def __init__(self):
        self.persondetector = tp.Yolo(os.path.join(BASE_DIR, 'shoushi.trtmodel'), type=tp.YoloType.V5, device_id=0)

    def infer(self, frame):
        bboxes = self.persondetector.commit(frame).get()
        result = []
        for box in bboxes:
            if box.class_label == 0 and box.confidence > conf_tch:
                result.append([int(box.left), int(box.top), int(box.right), int(box.bottom)])
        #         left, top, right, bottom = map(int, [box.left, box.top, box.right, box.bottom])
        #         cv2.rectangle(frame, (left, top), (right, bottom), tp.random_color(box.class_label), 5)
        # cv2.imshow('saveto', frame)
        # cv2.waitKey(1)
        return result


if __name__ == '__main__':
    gesture_detect = GestureDetection()
    cam = cv2.VideoCapture(0)
    while True:
        _, frame = cam.read()
        # frame = cv2.imread('./bus.jpg')
        # for _ in range(500):
        #     result = person_detect(frame)
        start = time.time()
        result = gesture_detect.infer(frame)

        print('fps', 1 / (time.time() - start))
