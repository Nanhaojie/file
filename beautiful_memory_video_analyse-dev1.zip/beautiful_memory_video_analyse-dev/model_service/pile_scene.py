# -*- coding: utf-8 -*-
"""
@Time ： 2022/3/3 下午4:49
@Auth ： nhj
@File ：pile_scene.py
"""

import json
from multiprocessing.dummy.connection import Connection

import cv2
import time

import get_conf
from constants import DetectModel
from face_detection.test_retinaface import HumanFaceDetection
from common import BeautifulTool, JumpTrack
from tools.manage import ProjectManager
from tools.redis_utils import redis_conn
from pedestrian_detection.human_model import PersonDetection, SlidePersonDetect
from tools.log import Logger
from threading import Thread, Lock
from kafka import KafkaProducer
import configparser
import os
import numpy as np

from tools.img_cut import pipeline

pile_person_detect = SlidePersonDetect()

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

# kafka的参数
add_port = redis_conn.get('local_kafka').decode().split(',')
log = Logger('logs/wonderful_video.log', level='info').logger

# video equipment id
pile_equipment_wall_id = '10'
pile_equipment_ce_id = '8'
jump_equipment_add_id = '9'

climb_coord = eval(redis_conn.get('climb_coord').decode())
climb_weight = redis_conn.get('climb_weight').decode()
beautiful_model_topic = config.get('local_kafka', 'beautiful_model_topic')
producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip', max_request_size=10 * 1024 * 1024)

jump_last_c = dict()

# 初始化模型类
face_detectors = HumanFaceDetection()
person_detect = PersonDetection()
pile_person_detect = SlidePersonDetect()

# 侧面
pile_ce_coord = [450, 0, 2150, 2160]
pile_ce1_coord = [450, 1610, 880, 1750]  # x1,y1,x2,y2
pile_ce2_coord = [960, 1330, 1370, 1500]  # x1,y1,x2,y2

# 墙上
pile_wall1_coord = [3360, 1710, 3590, 1830]
pile_wall2_coord = [2745, 1320, 2975, 1440]
pile_wall3_coord = [1865, 835, 2095, 955]
# pile_wall4_coord = [1140, 880, 1370, 980]

wall1_x, wall1_y = (pile_wall1_coord[0] + pile_wall1_coord[2]) / 2, (pile_wall1_coord[1] + pile_wall1_coord[3]) / 2
wall2_x, wall2_y = (pile_wall2_coord[0] + pile_wall2_coord[2]) / 2, (pile_wall2_coord[1] + pile_wall2_coord[3]) / 2
wall3_x, wall3_y = (pile_wall3_coord[0] + pile_wall3_coord[2]) / 2, (pile_wall3_coord[1] + pile_wall3_coord[3]) / 2


# wall4_x, wall4_y = (pile_wall4_coord[0] + pile_wall4_coord[2]) / 2, (pile_wall4_coord[1] + pile_wall4_coord[3]) / 2


class PileCeDetect(object):
    def __init__(self):
        self.preframe = None

    def slideinfer(self, frame):
        frame = cv2.resize(frame, (int(frame.shape[0] / 5), int(frame.shape[1] / 5)))
        if self.preframe is not None:
            d = frame / 255 - self.preframe
            diff = np.sum(d > 0.5)
            self.preframe = frame / 255
            if diff > 100:
                return 1
            else:
                return 0
        else:
            self.preframe = frame / 255


class PileWallDetect(object):
    def __init__(self):
        self.preframe = None

    def slideinfer(self, frame):
        frame = cv2.resize(frame, (int(frame.shape[0] / 5), int(frame.shape[1] / 5)))
        if self.preframe is not None:
            d = frame / 255 - self.preframe
            diff = np.sum(d > 0.5)
            self.preframe = frame / 255
            if diff > 15:
                return 1
            else:
                return 0
        else:
            self.preframe = frame / 255


class ThreadedCamera(object):
    def __init__(self, source=0):
        self.capture = cv2.VideoCapture(source)
        self.lock = Lock()
        self.thread = Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()

    def update(self):
        while True:
            if self.capture.isOpened():
                with self.lock:
                    self.capture.grab()
                time.sleep(0.001)

    def grab_frame(self):
        with self.lock:
            status, frame = self.capture.retrieve()
            video_pos_time = int(self.capture.get(cv2.CAP_PROP_POS_MSEC))
        if status:
            return frame, video_pos_time
        return None, None


pile_ce_detect = PileCeDetect()
pile_ce2_detect = PileCeDetect()
pile_wall1_detect = PileWallDetect()
pile_wall2_detect = PileWallDetect()
pile_wall3_detect = PileWallDetect()


# pile_wall4_detect = PileWallDetect()


def consumer_beautiful(image, hum_face_key):
    # 遍历一张图中多个行人
    for hum_face in hum_face_key:
        beautiful_time = hum_face['beautiful_time']
        # 获取行人的坐标
        body_coord = hum_face['body_coord']
        body_x1, body_y1, body_x2, body_y2 = body_coord[0], body_coord[1], body_coord[2], body_coord[3]
        image_h, image_w, _ = image.shape
        body_x1 = max(0, body_x1)
        body_y1 = max(0, body_y1)
        body_x2 = min(image_w, body_x2)
        body_y2 = min(image_h, body_y2)

        beautiful_tool = BeautifulTool(image, hum_face, beautiful_time, body_x1, body_y1, body_x2, body_y2)

        # 蹦床摄像头， 调用肢体动作的模型
        if hum_face['video_equipment_id'] == jump_equipment_add_id:
            if hum_face['user_id'] in jump_last_c.keys():
                if jump_last_c[hum_face['user_id']]:
                    beautiful_tool.pose_beautiful(jump_last_c[hum_face['user_id']])

            jump_last_c[hum_face['user_id']] = [body_x1, body_y1, body_x2, body_y2]


def pile_ce_detection(image, video_pos_time, video_start_time, video_equipment_id):
    if image is not None and video_pos_time is not None:
        time_stamp = video_start_time + video_pos_time
        camera_ip = video_equipment_id
        # 对特定区域检测
        pile_img = image[:, pile_ce_coord[0]:pile_ce_coord[2]].copy()
        # 检测小方框是否有变化
        pile_ce1_jpg = pile_img[pile_ce1_coord[1]:pile_ce1_coord[3], pile_ce1_coord[0]:pile_ce1_coord[2]]
        pile_ce2_jpg = pile_img[pile_ce2_coord[1]:pile_ce2_coord[3], pile_ce2_coord[0]:pile_ce2_coord[2]]
        pile_ce1_change = pile_ce_detect.slideinfer(pile_ce1_jpg)
        pile_ce2_change = pile_ce2_detect.slideinfer(pile_ce2_jpg)
        if pile_ce1_change or pile_ce2_change:
            # 如果有变化调用行人检测的模型
            human_result = person_detect.infer(pile_img, video_equipment_id)
            # 行人检测与人脸检测的结果融合
            if human_result:
                # 小方框在行人检测的框里，再检测人脸
                for pile_human in human_result:
                    human_face = dict()
                    if pile_human[0] < (pile_ce1_coord[0] + pile_ce1_coord[2]) / 2 < pile_human[2] and \
                            pile_human[1] < (pile_ce1_coord[1] + pile_ce1_coord[3]) / 2 < pile_human[3]:
                        pile_face_img = pile_img[pile_human[1]:pile_human[3], pile_human[0]:pile_human[2]].copy()
                        try:
                            face_result = face_detectors.infer(pile_face_img)
                            if face_result:
                                coordinate, user_ids = face_result[0], face_result[1]
                                # 遍历一张图中多个人脸
                                for i, coord in enumerate(coordinate):
                                    face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), \
                                                                         int(coord[2]), int(coord[3])
                                    human_face['body_coord'] = [pile_ce_coord[0] + pile_human[0],
                                                                pile_ce_coord[1] + pile_human[1],
                                                                pile_ce_coord[0] + pile_human[2],
                                                                pile_ce_coord[1] + pile_human[3]]
                                    human_face['face_coord'] = [pile_ce_coord[0] + pile_human[0] + face_x1,
                                                                pile_ce_coord[1] + pile_human[1] + face_y1,
                                                                pile_ce_coord[0] + pile_human[0] + face_x2,
                                                                pile_ce_coord[1] + pile_human[1] + face_y2]
                                    human_face['video_equipment_id'] = camera_ip
                                    human_face['beautiful_time'] = time_stamp
                                    human_face['wonderful_tag'] = 'climb_ce'
                                    human_face['wonderful_weight'] = int(climb_weight) + 2
                                    # 人脸比对成功
                                    if user_ids[i]:
                                        human_face['user_id'] = user_ids[i].split('_')[0]
                                        human_face['detection_model'] = DetectModel.FACE_DETECTOR
                                        redis_conn.set('pile_user', json.dumps(human_face), 300)
                                        # cv2.imwrite('face/'+str(time.time())+'.jpg', pile_face_img)
                                        # producer.send(beautiful_model_topic, key=[human_face])
                                        pipeline(pile_img, human_face, producer, beautiful_model_topic)
                                        log.info(f'梅花桩侧面精彩瞬间{human_face}')
                                        return 1
                        except:
                            log.info(f'没有检测到人脸{pile_face_img}')


def main(rtsps, rec_conn: Connection):
    # 读摄像头的流
    rtsp0 = rtsps[0]

    streamer0 = ThreadedCamera(rtsp0)

    video_equipment_id = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time = int(round(time.time() * 1000)) - 600

    while True:
        if rec_conn.poll():
            log.info("main 被终止")
            return
        image, video_pos_time = streamer0.grab_frame()
        if image is not None and video_pos_time is not None:
            time_stamp = video_start_time + video_pos_time
            camera_ip = video_equipment_id
            # 调用人脸检测,识别的模型
            face_result = face_detectors.infer(image)

            # 调用行人检测的模型
            human_result = person_detect.infer(image, video_equipment_id)

            # 行人检测与人脸检测的结果融合
            if human_result:
                # 蹦床人物追踪
                # human_track_result = human_track(human_result, image)
                jump_track = JumpTrack(face_result, human_result, image, camera_ip, time_stamp)
                jump_track_result = jump_track.human_track()
                # 调用精彩瞬间的模块
                consumer_beautiful(image, jump_track_result)


def main_pile(rtsps, rec_conn: Connection):
    # 读摄像头的流
    pile_ce_rtsp = rtsps[0]
    pile_ce_streamer = ThreadedCamera(pile_ce_rtsp)
    pile_ce_id = pile_ce_rtsp.split('/')[-1].split('?')[0][0]
    pile_ce_time = int(round(time.time() * 1000)) - 1000
    # pile_ce_time = int(time.mktime(time.strptime(pile_ce_rtsp.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    pile_wall_rtsp = rtsps[1]
    pile_wall_streamer = ThreadedCamera(pile_wall_rtsp)
    pile_wall_id = '10'
    pile_wall_time = int(round(time.time() * 1000)) - 5000
    # pile_wall_time = int(time.mktime(time.strptime(pile_wall_rtsp.split('?')[1].split('&')[0].split('=')[1], "%Y%m%dt%H%M%Sz"))) * 1000

    while True:
        if rec_conn.poll():
            log.info("main_pile 被终止")
            return
        image0, video_pos_time0 = pile_ce_streamer.grab_frame()
        pile_ce_detection(image0, video_pos_time0, pile_ce_time, pile_ce_id)
        # 梅花桩墙上场景
        pile_wall_image, pile_wall_pos_time = pile_wall_streamer.grab_frame()
        if pile_wall_image is not None and pile_wall_pos_time is not None:
            time_stamp = pile_wall_time + pile_wall_pos_time
            camera_ip = pile_wall_id
            # 对特定区域检测
            pile_wall1_img = pile_wall_image[pile_wall1_coord[1]:pile_wall1_coord[3],
                             pile_wall1_coord[0]:pile_wall1_coord[2]]
            pile_wall2_img = pile_wall_image[pile_wall2_coord[1]:pile_wall2_coord[3],
                             pile_wall2_coord[0]:pile_wall2_coord[2]]
            pile_wall3_img = pile_wall_image[pile_wall3_coord[1]:pile_wall3_coord[3],
                             pile_wall3_coord[0]:pile_wall3_coord[2]]
            # pile_wall4_img = pile_wall_img[pile_wall4_coord[1]:pile_wall4_coord[3],
            #                  pile_wall4_coord[0]:pile_wall4_coord[2]]

            # 检测特定区域图片的变化
            pile_wall1_change = pile_wall1_detect.slideinfer(pile_wall1_img)
            pile_wall2_change = pile_wall2_detect.slideinfer(pile_wall2_img)
            pile_wall3_change = pile_wall3_detect.slideinfer(pile_wall3_img)
            # pile_wall4_change = pile_wall4_detect.slideinfer(pile_wall4_img)

            if pile_wall1_change or pile_wall2_change or pile_wall3_change:
                # 如果有变化调用行人检测的模型
                human_result = person_detect.infer(pile_wall_image, pile_wall_id)
                if human_result:
                    for pile_human in human_result:
                        human_face = dict()
                        # 判断小方框在行人检测的框里
                        status1 = pile_human[0] < wall1_x < pile_human[2] and pile_human[1] < wall1_y < pile_human[3]
                        status2 = pile_human[0] < wall2_x < pile_human[2] and pile_human[1] < wall2_y < pile_human[3]
                        status3 = pile_human[0] < wall3_x < pile_human[2] and pile_human[1] < wall3_y < pile_human[3]
                        # status4 = pile_human[0] < wall4_x < pile_human[2] and pile_human[1] < wall4_y < pile_human[3]
                        if status1 or status2 or status3:
                            try:
                                pile_user = json.loads(redis_conn.get('pile_user').decode())
                                human_face['body_coord'] = [pile_human[0], pile_human[1], pile_human[2], pile_human[3]]
                                human_face['face_coord'] = [pile_human[0], pile_human[1], pile_human[2], pile_human[3]]
                                human_face['video_equipment_id'] = camera_ip
                                human_face['beautiful_time'] = time_stamp
                                human_face['user_id'] = pile_user['user_id']
                                human_face['wonderful_tag'] = 'climb_wall'
                                human_face['wonderful_weight'] = int(climb_weight)
                                human_face['detection_model'] = DetectModel.PERSON_DETECTOR
                                pipeline(pile_wall_image, human_face, producer, beautiful_model_topic)
                                # producer.send(beautiful_model_topic, key=[human_face])
                                log.info(f'梅花桩墙上精彩瞬间{human_face}')
                                cv2.imwrite('face/' + str(time.time()) + '.jpg', pile_wall_image)
                                # pile_ce_switch = 1
                            except:
                                log.info(f'梅花桩没检测到人{redis_conn.get("pile_user")}', exc_info=True)


if __name__ == '__main__':
    project_manager = ProjectManager(face_detectors, get_conf.LOCAL_KAFKA_SERVERS)

    # read_type = 'tracks'
    # rtsp_arg_jump = 'starttime=20220523t155800z&endtime=20220523t155830z'
    # rtsp_arg_pile = 'starttime=20220523t161442z&endtime=20220523t164417z'

    read_type = 'Channels'
    rtsp_arg_jump = 'transportmode=unicast'
    rtsp_arg_pile = 'transportmode=unicast'

    project_manager.add_func(main, (
        [f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/{read_type}/901?{rtsp_arg_jump}'],
        project_manager.rec_conn))

    project_manager.add_func(main_pile, (
        [f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/{read_type}/801?{rtsp_arg_pile}',
         f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/{read_type}/1001?{rtsp_arg_pile}'],
        project_manager.rec_conn))
    project_manager.run_main()

    # import multiprocessing as mp
    # mp.set_start_method(method='spawn')
    # conn_rec, conn_send = mp.Pipe()

    # processes = [
    #     mp.Process(target=main,
    #                args=([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/901?{rtsp_arg_jump}'], conn_rec)),
    #     mp.Process(target=main_pile,
    #                args=([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/801?{rtsp_arg_pile}',
    #                       f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/1001?{rtsp_arg_pile}'], conn_rec)),
    # ]
    # [process.start() for process in processes]
    # [process.join() for process in processes]
