#!/bin/bash
#docker start tf-serving
#source /home/zoneyet/anaconda3/etc/profile.d/conda.sh
#conda activate face
#cd /home/zoneyet/project/beautiful_memory/beautiful_memory_video_analyse/model_service
#python3 get_conf.py &
#python3 face_template.py &
#python3 persist_records.py &
#python3 beautiful_video_frame.py &>beautiful.log &

source /etc/profile
/root/miniconda3/envs/py38/bin/pip install -r requirements.txt -i https://pypi.douban.com/simple
#/root/miniconda3/envs/py38/bin/python  get_conf.py &
# /root/miniconda3/envs/py38/bin/python face_template.py &
/root/miniconda3/envs/py38/bin/python  persist_records.py &
/root/miniconda3/envs/py38/bin/python  beautiful_video_frame.py &>beautiful.log &