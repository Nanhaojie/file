#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：beautiful_memory
@File ：main_kafka.py
@Author ：nhj
@Date ：2021/9/9 下午3:32
"""
import json
from multiprocessing.connection import Connection

import cv2
import time


from face_detection.test_retinaface import HumanFaceDetection
from common import BeautifulTool, JumpTrack, HumanFaceWall
from face_template import append_active_user, append_face
from tools.manage import ProjectManager
from tools.redis_utils import redis_conn
from pedestrian_detection.human_model import PersonDetection, SlidePersonDetect
from tools.log import Logger
from threading import Thread, Lock
from kafka import KafkaProducer
import configparser
import os
import get_conf

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

# kafka的参数
add_port = redis_conn.get('local_kafka').decode().split(',')
log = Logger('logs/wonderful_video.log', level='info').logger

# video equipment id
climb_equipment_wall_id = redis_conn.get('climb_equipment_wall_id').decode()
climb_equipment_ce_id = redis_conn.get('climb_equipment_ce_id').decode()
slide_equipment_high_id = redis_conn.get('slide_equipment_high_id').decode()
slide_equipment_low_id = redis_conn.get('slide_equipment_low_id').decode()
sea_equipment_id = redis_conn.get('sea_equipment_id').decode()
jump_equipment_id = redis_conn.get('jump_equipment_id').decode()
door_equipment_id = redis_conn.get('door_equipment_id').decode()

# video equipment ip
climb_equipment_wall_ip = redis_conn.get('climb_equipment_wall_ip').decode()
climb_equipment_ce_ip = redis_conn.get('climb_equipment_ce_ip').decode()
slide_equipment_high_ip = redis_conn.get('slide_equipment_high_ip').decode()
slide_equipment_low_ip = redis_conn.get('slide_equipment_low_ip').decode()
sea_equipment_ip = redis_conn.get('sea_equipment_ip').decode()
jump_equipment_ip = redis_conn.get('jump_equipment_ip').decode()
door_equipment_ip = redis_conn.get('door_equipment_ip').decode()

climb_coord = eval(redis_conn.get('climb_coord').decode())
climb_weight = redis_conn.get('climb_weight').decode()
beautiful_model_topic = config.get('local_kafka', 'beautiful_model_topic')
producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip', max_request_size=10 * 1024 * 1024)

# 攀岩场景超过秒删除身体底板
climb_limit_time = eval(redis_conn.get('climb_limit_time').decode())
foot_coord = eval(redis_conn.get('foot_coord').decode())
foot_coord_left = eval(redis_conn.get('foot_coord_left').decode())

# 存储user_id和对应的人物追踪id
human_have_face_track = dict()

jump_last_c = dict()

# 初始化模型类
face_detectors = HumanFaceDetection()
person_detect = PersonDetection()
slide_person_detect = SlidePersonDetect()


class ThreadedCamera(object):
    def __init__(self, source=0):
        self.capture = cv2.VideoCapture(source)
        self.lock = Lock()
        self.thread = Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()

    def update(self):
        while True:
            if self.capture.isOpened():
                with self.lock:
                    self.capture.grab()
                time.sleep(0.001)

    def grab_frame(self):
        with self.lock:
            status, frame = self.capture.retrieve()
            video_pos_time = int(self.capture.get(cv2.CAP_PROP_POS_MSEC))
        if status:
            return frame, video_pos_time
        return None, None


def consumer_beautiful(image, hum_face_key):
    # 遍历一张图中多个行人
    for hum_face in hum_face_key:
        beautiful_time = hum_face['beautiful_time']
        # 获取行人的坐标
        body_coord = hum_face['body_coord']
        body_x1, body_y1, body_x2, body_y2 = body_coord[0], body_coord[1], body_coord[2], body_coord[3]
        image_h, image_w, _ = image.shape
        body_x1 = max(0, body_x1)
        body_y1 = max(0, body_y1)
        body_x2 = min(image_w, body_x2)
        body_y2 = min(image_h, body_y2)

        beautiful_tool = BeautifulTool(image, hum_face, beautiful_time, body_x1, body_y1, body_x2, body_y2)

        # 海洋球摄像头，判断是否有手势
        if hum_face['video_equipment_id'] == sea_equipment_id:
            beautiful_tool.expression_beautiful()
            beautiful_tool.gesture_beautiful()

        # 攀岩摄像头
        elif hum_face['video_equipment_id'] == climb_equipment_wall_id:
            beautiful_tool.climb_beautiful()

        elif hum_face['video_equipment_id'] == climb_equipment_ce_id:
            beautiful_tool.gesture_beautiful()

        # 滑梯摄像头，下面的镜头
        elif hum_face['video_equipment_id'] == slide_equipment_low_id:
            beautiful_tool.slide_beautiful()

        # 蹦床摄像头， 调用肢体动作的模型
        elif hum_face['video_equipment_id'] == jump_equipment_id:
            if hum_face['user_id'] in jump_last_c.keys():
                if jump_last_c[hum_face['user_id']]:
                    beautiful_tool.pose_beautiful(jump_last_c[hum_face['user_id']])

            jump_last_c[hum_face['user_id']] = [body_x1, body_y1, body_x2, body_y2]


def hum_face_detection(image, video_pos_time, video_start_time, video_equipment_id):
    if image is not None and video_pos_time is not None:
        time_stamp = video_start_time + video_pos_time
        camera_ip = video_equipment_id

        # 调用人脸检测,识别的模型
        face_result = face_detectors.infer(image)

        # 调用行人检测的模型
        human_result = person_detect.infer(image, video_equipment_id)

        # 行人检测与人脸检测的结果融合
        if human_result:
            if camera_ip == jump_equipment_id:
                # 蹦床人物追踪
                # human_track_result = human_track(human_result, image)
                jump_track = JumpTrack(face_result, human_result, image, camera_ip, time_stamp)
                jump_track_result = jump_track.human_track()
                # 调用精彩瞬间的模块
                consumer_beautiful(image, jump_track_result)
            else:
                # 判断人脸是否在人体框中，如果不在，并且在攀岩场景下，调用人体识别
                # human_face_result = HumanFace(face_result, human_result, image, camera_ip, time_stamp)
                # human_faces, human_no_faces = human_face_result.human_face()
                # 调用人体识别模块
                # consumer_hum_no_face(image, human_no_faces)
                # 调用精彩瞬间的模块
                # consumer_beautiful(image, human_faces)
                # 调用身体模板录入
                # append_body(image, human_faces)

                # 加上安全帽检测
                # human_face_result = HumanFaceSafeHat(face_result, human_result, image, camera_ip, time_stamp)
                # human_faces, human_no_faces, human_face_safe_hats = human_face_result.human_face_safe_hat()
                # # 调用身体模板录入
                # if human_face_safe_hats:
                #     append_body(image, human_face_safe_hats)
                #     consumer_beautiful(image, human_face_safe_hats)
                # # 调用人体识别模块
                # consumer_hum_no_face(image, human_no_faces)
                # # 调用精彩瞬间的模块
                # consumer_beautiful(image, human_faces)

                # 不用人体识别，只用墙上的行人检测
                human_face_result = HumanFaceWall(face_result, human_result, image, camera_ip, time_stamp)
                human_faces, human_face_safe_hats = human_face_result.human_face_wall()
                if human_face_safe_hats:
                    # 只有站在特定区域中才检测手势
                    human_gesture_coord = []
                    # 判断戴安全帽的人是否站在框里面
                    for human_face_safe_hat in human_face_safe_hats:
                        human_safe_hat_x1, human_safe_hat_human_y1, human_safe_hat_human_x2, human_safe_hat_human_y2 = \
                            human_face_safe_hat['body_coord']
                        if foot_coord[1] <= human_safe_hat_human_y2 <= foot_coord[3] and \
                                foot_coord[0] <= (human_safe_hat_x1 + human_safe_hat_human_x2) / 2 <= foot_coord[2]:
                            redis_conn.set('human_safe_hat', json.dumps(human_face_safe_hat), 100)
                            human_gesture_coord.append(human_face_safe_hat)
                            log.info(f'右边身体录入成功')
                        if foot_coord_left[1] <= human_safe_hat_human_y2 <= foot_coord_left[3] and \
                                foot_coord_left[0] <= (human_safe_hat_x1 + human_safe_hat_human_x2) / 2 <= \
                                foot_coord_left[2]:
                            redis_conn.set('human_safe_left_hat', json.dumps(human_face_safe_hat), 100)
                            human_gesture_coord.append(human_face_safe_hat)
                            log.info(f'左边身体录入成功')
                        # redis_conn.hset(
                        #     BODY_TEMPLATE_REDIS_NAME, key=f'{human_face_safe_hat["user_id"]}',
                        #     value=json.dumps(human_face_safe_hat)
                        # )
                    consumer_beautiful(image, human_gesture_coord)
                # 判断其他场景的精彩瞬间
                consumer_beautiful(image, human_faces)


def slide_face_detection(image, video_pos_time, video_start_time, video_equipment_id, slide_push_time):
    if image is not None and video_pos_time is not None:
        time_stamp = video_start_time + video_pos_time
        camera_ip = video_equipment_id
        # 调用人脸检测,识别的模型
        face_result = face_detectors.infer(image)
        # 行人检测与人脸检测的结果融合
        if face_result:
            coordinate, user_ids = face_result[0], face_result[1]
            # 遍历一张图中多个人脸
            human_faces = list()
            for i, coord in enumerate(coordinate):
                human_face = dict()
                # 人脸比对成功
                if user_ids[i]:
                    human_face['user_id'] = user_ids[i].split('_')[0]
                    face_x1, face_y1, face_x2, face_y2 = map(int, coord)
                    human_face['body_coord'] = [face_x1, face_y1, face_x2, face_y2]
                    human_face['face_coord'] = human_face['body_coord']
                    human_face['video_equipment_id'] = camera_ip
                    human_face['beautiful_time'] = slide_push_time or time_stamp
                    human_faces.append(human_face)
                    # 调用精彩瞬间的模块
                    consumer_beautiful(image, human_faces)
                    return 1


def main(rtsps, rec_conn: Connection):
    # 读摄像头的流
    rtsp0 = rtsps[0]
    rtsp1 = rtsps[1]

    streamer0 = ThreadedCamera(rtsp0)
    streamer1 = ThreadedCamera(rtsp1)

    video_equipment_id0 = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time0 = int(round(time.time() * 1000)) - 600

    video_equipment_id1 = rtsp1.split('/')[-1].split('?')[0][0]
    video_start_time1 = int(round(time.time() * 1000)) - 600

    while True:
        if rec_conn.poll():
            log.info("main 被终止")
            return
        image0, video_pos_time0 = streamer0.grab_frame()
        image1, video_pos_time1 = streamer1.grab_frame()

        hum_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0)
        hum_face_detection(image1, video_pos_time1, video_start_time1, video_equipment_id1)


def main_slide(rtsps, rec_conn: Connection):
    # 读摄像头的流
    rtsp0 = rtsps[1]
    streamer0 = ThreadedCamera(rtsp0)
    video_equipment_id0 = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time0 = int(round(time.time() * 1000)) - 600

    slide_rtsp = rtsps[0]
    slide_streamer = ThreadedCamera(slide_rtsp)
    video_equipment_id_slide = slide_rtsp.split('/')[-1].split('?')[0][0]
    slide_video_start_time = int(round(time.time() * 1000)) - 600

    # 滑滑梯场景 玩一次所需要的间隔秒数
    interval_seconds = 50
    # 为1走滑道 为0走垫子
    slide_pad_switch = 0
    slide_push_time = 0
    while True:
        if rec_conn.poll():
            log.info("main_slide 被终止")
            return
        if slide_pad_switch == 0:
            # 优先走滑道摄像头，如果滑道有人，再走下面摄像头
            slide_image, slide_video_pos_time = slide_streamer.grab_frame()
            if slide_image is not None and slide_video_pos_time is not None:
                slide_time_stamp = slide_video_start_time + slide_video_pos_time
                # 调用行人检测的模型
                # slide_image[:, 0:1500, :] = 0
                # slide_image[:, 2300:, :] = 0
                im = slide_image[:, 1500:2300].copy()
                # human_result = person_detect.infer(slide_image, video_equipment_id_slide)
                human_result = slide_person_detect.slideinfer(im)
                if human_result:
                    log.info(f'在{slide_time_stamp}的滑道检测到行人')
                    redis_conn.set('slide_high_time', slide_time_stamp, interval_seconds)
                    slide_pad_switch = 1
                    # 生成计时器
                    start_time = time.time()
        elif slide_pad_switch == 1:
            # 下面摄像头行人检测
            image0, video_pos_time0 = streamer0.grab_frame()
            slide_low_img = image0[:, 1600:2240].copy()
            cv2.imwrite('slide_low.jpg', slide_low_img)
            slide_low_human = person_detect.infer(slide_low_img, '1')
            if slide_low_human:
                slide_push_time = video_start_time0 + video_pos_time0
                slide_pad_switch = 2
                log.info(f'在{slide_push_time}的滑道出口检测到行人')
            if time.time() - start_time >= 3:
                slide_pad_switch = 2
                slide_push_time = None
                log.warning(f'3S内滑道出口未检测到行人')
        elif slide_pad_switch == 2:
            # 下面摄像头人脸识别
            image0, video_pos_time0 = streamer0.grab_frame()
            if slide_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0, slide_push_time):
                slide_pad_switch = 0
                slide_person_detect.preframe = None
            if time.time() - start_time >= interval_seconds:
                slide_pad_switch = 0
                slide_person_detect.preframe = None
                log.info(f'{interval_seconds}S内未检测到行人')


def main_climb(rtsps, rec_conn: Connection):
    # 读摄像头的流
    rtsp0 = rtsps[0]
    streamer0 = ThreadedCamera(rtsp0)
    video_equipment_id0 = rtsp0.split('/')[-1].split('?')[0][0]
    video_start_time0 = int(round(time.time() * 1000)) - 600

    climb_rtsp = rtsps[1]
    climb_streamer = ThreadedCamera(climb_rtsp)
    climb_equipment_id = climb_rtsp.split('/')[-1].split('?')[0][0]
    climb_video_start_time = int(round(time.time() * 1000)) - 600

    num = 0
    rate = 3
    last_right_y = 2160
    last_left_y = 2160
    while True:
        if rec_conn.poll():
            log.info("main_climb 被终止")
            return
        image0, video_pos_time0 = streamer0.grab_frame()
        hum_face_detection(image0, video_pos_time0, video_start_time0, video_equipment_id0)

        climb_image, climb_video_pos_time = climb_streamer.grab_frame()
        if climb_image is not None and climb_video_pos_time is not None:
            climb_time_stamp = climb_video_start_time + climb_video_pos_time
            # 调用行人检测的模型
            wall_x1, wall_y1, wall_x2, wall_y2 = climb_coord[0], climb_coord[1], climb_coord[2], climb_coord[3]
            climb = climb_image[wall_y1:wall_y2, wall_x1:wall_x2].copy()
            if num % rate == 0:
                human_result = person_detect.infer(climb, climb_equipment_id)
                if human_result:
                    try:
                        human_safe_hat = json.loads(redis_conn.get('human_safe_hat').decode())
                        hum_face = dict()
                        if human_safe_hat:
                            for human_coord in human_result:
                                human_x = (human_coord[0] + wall_x1 + human_coord[2] + wall_x1) / 2
                                if 1500 <= human_x <= wall_x2:
                                    if human_coord[1] + wall_y1 <= last_right_y:
                                        hum_face['wonderful_weight'] = int(climb_weight)
                                    else:
                                        hum_face['wonderful_weight'] = int(climb_weight) - 2
                                    hum_face['beautiful_time'] = str(climb_time_stamp)
                                    hum_face['wonderful_tag'] = 'climb_wall'
                                    hum_face['body_coord'] = [human_coord[0] + wall_x1, human_coord[1] + wall_y1,
                                                              human_coord[2] + wall_x1, human_coord[3] + wall_y1]
                                    hum_face['face_coord'] = human_safe_hat['face_coord']
                                    hum_face['video_equipment_id'] = climb_equipment_id
                                    hum_face['user_id'] = human_safe_hat['user_id']
                                    producer.send(beautiful_model_topic, key=[hum_face])
                                    log.info(f'右边攀岩的精彩瞬间{hum_face}')
                                    last_right_y = human_coord[1] + wall_y1
                    except Exception:
                        log.info(f'攀岩侧面右边没有检测到人{redis_conn.get("human_safe_hat")}')

                    try:
                        human_safe_left_hat = json.loads(redis_conn.get('human_safe_left_hat').decode())
                        hum_face = dict()
                        if human_safe_left_hat:
                            for human_coord in human_result:
                                human_x = (human_coord[0] + wall_x1 + human_coord[2] + wall_x1) / 2
                                if wall_x1 <= human_x < 1500:
                                    if human_coord[1] + wall_y1 <= last_left_y:
                                        hum_face['wonderful_weight'] = int(climb_weight)
                                    else:
                                        hum_face['wonderful_weight'] = int(climb_weight) - 2
                                    hum_face['beautiful_time'] = str(climb_time_stamp)
                                    hum_face['wonderful_tag'] = 'climb_wall'
                                    hum_face['body_coord'] = [human_coord[0] + wall_x1, human_coord[1] + wall_y1,
                                                              human_coord[2] + wall_x1, human_coord[3] + wall_y1]
                                    hum_face['face_coord'] = human_safe_left_hat['face_coord']
                                    hum_face['video_equipment_id'] = climb_equipment_id
                                    hum_face['user_id'] = human_safe_left_hat['user_id']
                                    producer.send(beautiful_model_topic, key=[hum_face])
                                    log.info(f'左边攀岩的精彩瞬间{hum_face}')
                                    last_left_y = human_coord[1] + wall_y1
                    except Exception:
                        log.info(f'攀岩侧面左边没有检测到人:{redis_conn.get("human_safe_left_hat")}')
            num += 1


if __name__ == '__main__':
    project_manager = ProjectManager(face_detectors, get_conf.YUN_KAFKA_SERVERS, get_conf.LOCAL_KAFKA_SERVERS)

    # rtsp_args = 'starttime=20220523t173030z&endtime=20220523t173050z'
    # args = ([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/501?{rtsp_args}',
    #          f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/401?{rtsp_args}'],
    #         project_manager.rec_conn)
    # project_manager.add_func(main_climb, args)

    project_manager.add_func(main, ([jump_equipment_ip, sea_equipment_ip], project_manager.rec_conn))
    project_manager.add_func(main_climb, ([climb_equipment_ce_ip, climb_equipment_wall_ip], project_manager.rec_conn))
    project_manager.add_func(main_slide, ([slide_equipment_high_ip, slide_equipment_low_ip], project_manager.rec_conn))
    project_manager.add_func(append_active_user, (project_manager.rec_conn,))
    project_manager.add_func(append_face, (project_manager.rec_conn,))
    project_manager.run_main()

    '''
    # rtsp_args = 'starttime=20211102t161000z&endtime=20211102t180000z'  # .03 play_video
    rtsp_args = 'starttime=20211212t165528z&endtime=20211212t165537z'  # 杨忠滑滑梯

    processes = [
        # mp.Process(target=slide_human, args=(['rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/201?starttime=20211102t174800z&endtime=20211102t175400z'],)),
        mp.Process(target=main, args=([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/301?{rtsp_args}',
                                    f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/701?{rtsp_args}'],)),

        mp.Process(target=main_climb, args=([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/501?{rtsp_args}',
                                        f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/401?{rtsp_args}'],)),

        mp.Process(target=main_slide, args=([f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/201?{rtsp_args}',
                                       f'rtsp://admin:root12300.@192.168.11.11:554/Streaming/tracks/101?{rtsp_args}'],)),
    ]
    [process.start() for process in processes]
    [process.join() for process in processes]
    '''
