import os
from kafka import KafkaProducer
import json
from expression.expression_smile import smile
from gesture_recognition.gesture import GestureDetection
from constants import DetectModel
from pose_recognition.pose_model import skeleton_detect, act_est
from tools.log import Logger
import configparser
from redis import StrictRedis
import numpy as np
from safe_hat import safe_hat_serving, calculate_IoU
import time
import cv2

IS_PRODUCT = os.environ.get('IS_PRODUCT')
config = configparser.ConfigParser()
if IS_PRODUCT == '1':
    config.read('conf/pro.conf')
elif IS_PRODUCT == '2':
    config.read('conf/chaosuan.conf')
elif IS_PRODUCT == '3':
    config.read('conf/zoneyet.conf')
else:
    config.read('conf/dev.conf')

# redis
REDIS_HOST = config.get('redis', 'host')
REDIS_PORT = config.get('redis', 'port')
REDIS_PASSWORD = config.get('redis', 'password')
BODY_TEMPLATE_REDIS_KEY = config.get('redis', 'body_template_key')
BODY_TEMPLATE_REDIS_NAME = config.get('redis', 'body_template_name')
redis_conn = StrictRedis(REDIS_HOST, REDIS_PORT, password=REDIS_PASSWORD)

# kafka的参数
add_port = redis_conn.get('local_kafka').decode().split(',')

# topic
beautiful_model_topic = config.get('local_kafka', 'beautiful_model_topic')

# video equipment id
climb_equipment_wall_id = redis_conn.get('climb_equipment_wall_id').decode()
slide_equipment_high_id = redis_conn.get('slide_equipment_high_id').decode()
climb_equipment_ce_id = redis_conn.get('climb_equipment_ce_id').decode()
sea_equipment_id = redis_conn.get('sea_equipment_id').decode()

# 判断精彩瞬间每个模型的权重
expression_weight = redis_conn.get('expression_weight').decode()
gesture_weight = redis_conn.get('gesture_weight').decode()
climb_weight = redis_conn.get('climb_weight').decode()
slide_weight = redis_conn.get('slide_weight').decode()
face_weight = redis_conn.get('face_weight').decode()
kneel_weight = redis_conn.get('kneel_weight').decode()
sit_weight = redis_conn.get('sit_weight').decode()
jump_arms_weight = redis_conn.get('jump_arms_weight').decode()
fall_weight = redis_conn.get('fall_weight').decode()

log = Logger('logs/beautiful_tool.log', level='info')

# 场景坐标
climb_coord = eval(redis_conn.get('climb_coord').decode())
jump_coord = eval(redis_conn.get('jump_coord').decode())
slide_coord_low = eval(redis_conn.get('slide_coord_low').decode())
slide_coord = eval(redis_conn.get('slide_coord').decode())

producer = KafkaProducer(bootstrap_servers=add_port, key_serializer=lambda v: json.dumps(v).encode(),
                         compression_type='gzip', max_request_size=10 * 1024 * 1024)

# 初始化模型类
gesture_detect = GestureDetection()

human_have_face_track = {}


class BeautifulTool(object):
    def __init__(self, image, hum_face, beautiful_time, body_x1, body_y1, body_x2, body_y2):
        self.image = image
        self.hum_face = hum_face
        self.beautiful_time = beautiful_time
        self.body_x1 = body_x1
        self.body_y1 = body_y1
        self.body_x2 = body_x2
        self.body_y2 = body_y2

    def img_sliced(self, x1, y1, x2, y2) -> bytes:
        """将img裁剪后 转换为 file bytes 类型"""
        # 按照比例每个方向扩展 0.5
        x_extend = (x2 - x1) * 0.5
        y_extend = (y2 - y1) * 0.5
        x1 -= x_extend
        x2 += x_extend
        x1 = x1 if x1 > 0 else 0
        y1 -= y_extend
        y2 += y_extend
        y1 = y1 if y1 > 0 else 0
        x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
        return cv2.imencode('.jpg', self.image[y1:y2, x1:x2].copy())[1].tostring()

    def pipeline(self, beautiful_record_data):
        """精彩瞬间持久化管道"""
        # 根据检测模型，截取对应图片，一并发送到kafka
        if beautiful_record_data['detection_model'] == DetectModel.FACE_DETECTOR:
            # 截取并保存人脸图片
            img_bytes = self.img_sliced(*self.hum_face['face_coord'])
        elif beautiful_record_data['detection_model'] == DetectModel.PERSON_DETECTOR:
            # 截取并保存人脸图片
            img_bytes = self.img_sliced(self.body_x1, self.body_y1, self.body_x2, self.body_y2)
        else:
            img_bytes = None
            log.logger.warning(f'截取照片时，未找到配置的模型{beautiful_record_data["detection_model"]}')
        producer.send(beautiful_model_topic, key=[beautiful_record_data], value=img_bytes)

    def expression_beautiful(self):
        if 'face_coord' in self.hum_face.keys():
            face_x1, face_y1, face_x2, face_y2 = self.hum_face['face_coord']
            face = self.image[face_y1:face_y2, face_x1:face_x2]
            if len(face) > 0:
                smile_result = smile(face)
                if smile_result == 3:
                    self.hum_face['beautiful_time'] = str(self.beautiful_time)
                    self.hum_face['wonderful_tag'] = 'sea'
                    self.hum_face['wonderful_weight'] = int(expression_weight)
                    self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
                    self.pipeline(self.hum_face)
                    log.logger.info(f'调用微表情模型结果:{self.hum_face}')
                else:
                    self.hum_face['beautiful_time'] = str(self.beautiful_time)
                    self.hum_face['wonderful_tag'] = 'face'
                    self.hum_face['wonderful_weight'] = int(face_weight)
                    self.hum_face['body_coord'] = self.hum_face['body_coord']
                    self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
                    self.pipeline(self.hum_face)
                    log.logger.info(f'检测不到微笑的时候，检测到的人脸也算精彩瞬间{self.hum_face}')

    def gesture_beautiful(self):
        gesture_result = gesture_detect.infer(self.image)
        # 遍历所有的手势，判断手势框是否在人体框中
        if len(gesture_result) > 0:
            for gesture in gesture_result:
                gesture_x1, gesture_y1, gesture_x2, gesture_y2 = gesture[0], gesture[1], gesture[2], gesture[3]
                if (self.body_x2 < gesture_x1 or gesture_x2 < self.body_x1) and (
                        self.body_y2 < gesture_y1 or gesture_y2 < self.body_y1):
                    log.logger.info(f'手势和行人没有重合')
                else:
                    if self.hum_face['video_equipment_id'] == sea_equipment_id:
                        self.hum_face['beautiful_time'] = str(self.beautiful_time)
                        self.hum_face['wonderful_tag'] = 'sea'
                        self.hum_face['wonderful_weight'] = int(gesture_weight)
                        self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
                        self.pipeline(self.hum_face)
                        log.logger.info(f'sea调用手势模型的结果{self.hum_face}')
                    else:
                        self.hum_face['beautiful_time'] = str(self.beautiful_time)
                        self.hum_face['wonderful_tag'] = 'climb_ce'
                        self.hum_face['wonderful_weight'] = int(gesture_weight)
                        self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
                        self.pipeline(self.hum_face)
                        log.logger.info(f'climb调用手势模型的结果{self.hum_face}')

    def climb_beautiful(self):
        # 判断人体的坐标是否在攀岩墙内，如果在，则是精彩瞬间
        wall_x1, wall_y1, wall_x2, wall_y2 = climb_coord[0], climb_coord[1], climb_coord[2], climb_coord[3]
        if wall_x1 < self.body_x1 and self.body_x2 < wall_x2 and wall_y1 < self.body_y1 and self.body_y2 < wall_y2:
            self.hum_face['beautiful_time'] = str(self.beautiful_time)
            self.hum_face['wonderful_tag'] = 'climb_wall'
            self.hum_face['wonderful_weight'] = int(climb_weight)
            self.hum_face['body_coord'] = self.hum_face['body_coord']
            self.hum_face['face_coord'] = []
            self.hum_face['detection_model'] = DetectModel.PERSON_DETECTOR
            self.pipeline(self.hum_face)
            log.logger.info(f'攀岩的精彩瞬间{self.hum_face}')
            # cv2.imwrite('jump/' + self.hum_face['user_id'][0:6] + str(self.beautiful_time) + '.jpg',
            #                self.image[self.body_y1:self.body_y2, self.body_x1:self.body_x2])

    def slide_beautiful(self):
        slide_x1, slide_y1, slide_x2, slide_y2 = slide_coord_low[0], slide_coord_low[1], \
                                                 slide_coord_low[2], slide_coord_low[3]
        if slide_x1 < self.body_x1 and self.body_x2 < slide_x2 and slide_y1 < self.body_y1 and self.body_y2 < slide_y2:
            self.hum_face['beautiful_time'] = str(self.beautiful_time)
            self.hum_face['wonderful_tag'] = 'slide_low'
            self.hum_face['wonderful_weight'] = int(slide_weight)
            self.hum_face['body_coord'] = self.hum_face['body_coord']
            self.hum_face['face_coord'] = self.hum_face['face_coord']
            self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
            self.pipeline(self.hum_face)
            log.logger.info(f'下面滑梯的精彩瞬间{self.hum_face}')

            # 从下面的摄像头推理上面的摄像头的精彩瞬间
            try:
                slide_high_time = redis_conn.get('slide_high_time')
                if slide_high_time:
                    self.hum_face['beautiful_time'] = str(int(slide_high_time.decode()))
                    self.hum_face['wonderful_tag'] = 'slide_hight'
                    self.hum_face['wonderful_weight'] = int(slide_weight) + 5
                    self.hum_face['body_coord'] = slide_coord
                    self.hum_face['face_coord'] = []
                    self.hum_face['video_equipment_id'] = slide_equipment_high_id
                    self.hum_face['detection_model'] = DetectModel.PERSON_DETECTOR
                    self.pipeline(self.hum_face)
                    log.logger.info(f'上面滑梯的精彩瞬间{self.hum_face}')
            except:
                log.logger.info(f'上面滑梯redis的key失效')

    def pose_beautiful(self, box):
        # x1, y1, x2 = jump_coord[0], jump_coord[1], jump_coord[2]
        # jump_image = self.image[y1:, x1:x2]
        # jump_body_x1 = self.body_x1 - x1
        body_h = self.body_y2 - self.body_y1
        body_w = self.body_x2 - self.body_x1
        lastc = np.array([(box[0] + box[2]) / 2, (box[1] + box[3]) / 2])
        c = np.array(((self.body_x1 + self.body_x2) / 2, (self.body_y1 + self.body_y2) / 2))
        diff = c - lastc
        dist = np.sum(np.square(diff))

        if dist > 2500:
            skeleton = skeleton_detect(self.image[self.body_y1:self.body_y2, self.body_x1:self.body_x2])
            keypoints = np.squeeze(skeleton)
            if body_w > body_h:
                keypoints = np.squeeze(np.multiply(keypoints, np.array([body_w, body_w, 1])))
                keypoints[:, 0] -= (body_w - body_h) * 0.5
            else:
                keypoints = np.squeeze(np.multiply(keypoints, np.array([body_h, body_h, 1])))
                keypoints[:, 1] -= (body_h - body_w) * 0.5
            act = act_est(keypoints)
            # print('act',act)
            if act in [2, 3, 4, 5]:
                self.hum_face['beautiful_time'] = str(self.beautiful_time)
                self.hum_face['wonderful_tag'] = 'jump'
                if act == 2:
                    self.hum_face['wonderful_weight'] = int(kneel_weight)
                elif act == 3:
                    self.hum_face['wonderful_weight'] = int(sit_weight)
                elif act == 5:
                    self.hum_face['wonderful_weight'] = int(jump_arms_weight)
                else:
                    self.hum_face['wonderful_weight'] = int(fall_weight)
                self.hum_face['body_coord'] = self.hum_face['body_coord']
                self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
                self.pipeline(self.hum_face)
                log.logger.info(f'蹦床的精彩瞬间{self.hum_face}')
        else:
            self.hum_face['beautiful_time'] = str(self.beautiful_time)
            self.hum_face['wonderful_tag'] = 'face'
            self.hum_face['wonderful_weight'] = int(face_weight)
            self.hum_face['body_coord'] = self.hum_face['body_coord']
            self.hum_face['detection_model'] = DetectModel.FACE_DETECTOR
            self.pipeline(self.hum_face)
            log.logger.info(f'蹦床识别到人脸也算精彩瞬间精彩瞬间{self.hum_face}')


class JumpTrack(object):
    def __init__(self, face_result, human_track_result, image, camera_ip, timestp):
        self.face_result = face_result
        self.human_track_result = human_track_result
        self.image = image
        self.camera_ip = camera_ip
        self.timestp = timestp

    def human_track(self):
        human_faces = list()
        ih, iw, ic = self.image.shape
        #  遍历一张图中多个行人，判断人脸框是否在行人框里面
        for human_xy in self.human_track_result:
            human_face = dict()
            human_x1, human_y1, human_x2, human_y2 = max(0, human_xy[0]), max(0, human_xy[1]), \
                                                     min(iw, human_xy[2]), min(ih, human_xy[3])

            # 判断图片中是否检测到人脸
            if self.face_result:
                coordinate, user_ids = self.face_result[0], self.face_result[1]
                # 遍历一张图中多个人脸
                for i, coord in enumerate(coordinate):
                    face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(
                        coord[3])
                    if human_x1 < face_x1 and face_x2 < human_x2 and human_y1 < face_y1 and face_y2 < human_y2:
                        human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                        human_face['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                        human_face['video_equipment_id'] = self.camera_ip
                        human_face['beautiful_time'] = self.timestp
                        # 人脸比对成功
                        if user_ids[i]:
                            human_face['user_id'] = user_ids[i].split('_')[0]
                            human_faces.append(human_face)
                            # cv2.imwrite('face/' + user_ids[i].split('_')[0] + str(time.time()) + '.jpg',
                            #             self.image[human_y1:human_y2, human_x1:human_x2])
        return human_faces


class HumanFace(object):
    def __init__(self, face_result, human_result, image, camera_ip, timestp):
        self.face_result = face_result
        self.human_result = human_result
        self.image = image
        self.camera_ip = camera_ip
        self.timestp = timestp

    def human_face(self):
        ih, iw, ic = self.image.shape
        human_faces = []
        human_no_faces = list()
        #  遍历一张图中多个行人，判断人脸框是否在行人框里面
        for human_xy in self.human_result:
            human_face = dict()
            human_x1, human_y1, human_x2, human_y2 = max(0, human_xy[0]), max(0, human_xy[1]), \
                                                     min(iw, human_xy[2]), min(ih, human_xy[3])

            # 判断图片中是否检测到人脸
            if self.face_result:
                coordinate, user_ids = self.face_result[0], self.face_result[1]
                # 遍历一张图中多个人脸
                for i, coord in enumerate(coordinate):
                    face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(
                        coord[3])
                    if human_x1 < face_x1 and face_x2 < human_x2 and human_y1 < face_y1 and face_y2 < human_y2:
                        human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                        human_face['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                        human_face['video_equipment_id'] = self.camera_ip
                        human_face['beautiful_time'] = self.timestp
                        # 人脸比对成功
                        if user_ids[i]:
                            human_face['user_id'] = user_ids[i].split('_')[0]
                            human_faces.append(human_face)
                            # cv2.imwrite('face/' + user_ids[i].split('_')[0] + str(time.time()) + '.jpg',
                            #             self.image[human_y1:human_y2, human_x1:human_x2])

                # 判断human_face里面是否包含user_id，不包含则说明该行人没有检测到人脸，并且在攀岩摄像头场景下调用人体识别模型
                if 'user_id' not in human_face.keys() and self.camera_ip == climb_equipment_wall_id:
                    human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                    human_face['video_equipment_id'] = self.camera_ip
                    human_face['beautiful_time'] = self.timestp
                    human_no_faces.append(human_face)
            # 一张人脸人没有检测到，并且在攀岩摄像头场景下调用人体识别模型
            elif self.camera_ip == climb_equipment_wall_id:
                human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                human_face['video_equipment_id'] = self.camera_ip
                human_face['beautiful_time'] = self.timestp
                human_no_faces.append(human_face)
        return human_faces, human_no_faces


class HumanFaceSafeHat(object):
    def __init__(self, face_result, human_result, image, camera_ip, timestp):
        self.face_result = face_result
        self.human_result = human_result
        self.image = image
        self.camera_ip = camera_ip
        self.timestp = timestp

    def human_face_safe_hat(self):
        ih, iw, ic = self.image.shape
        human_faces = []
        human_face_safe_hats = []
        human_no_faces = list()
        #  遍历一张图中多个行人，判断人脸框是否在行人框里面
        for human_xy in self.human_result:
            human_face = dict()
            human_face_safe_hat = dict()
            human_x1, human_y1, human_x2, human_y2 = max(0, human_xy[0]), max(0, human_xy[1]), \
                                                     min(iw, human_xy[2]), min(ih, human_xy[3])

            # 判断图片中是否检测到人脸
            if self.face_result:
                coordinate, user_ids = self.face_result[0], self.face_result[1]
                # 遍历一张图中多个人脸
                for i, coord in enumerate(coordinate):
                    face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(
                        coord[3])
                    if human_x1 < face_x1 and face_x2 < human_x2 and human_y1 < face_y1 and face_y2 < human_y2:
                        if self.camera_ip == climb_equipment_ce_id:
                            hat_result = safe_hat_serving(self.image)
                            # 加上安全帽检测
                            for hat in hat_result:
                                iou = calculate_IoU([face_x1, face_y1, face_x2, face_y2],
                                                    [hat[0], hat[1], hat[2], hat[3]])
                                if iou > 0.65 and hat[1] < face_y1:
                                    human_face_safe_hat['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                                    human_face_safe_hat['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                                    human_face_safe_hat['video_equipment_id'] = self.camera_ip
                                    human_face_safe_hat['beautiful_time'] = self.timestp
                                    # 人脸比对成功
                                    if user_ids[i]:
                                        human_face_safe_hat['user_id'] = user_ids[i].split('_')[0]
                                        # cv2.imwrite('face/' + user_ids[i].split('_')[0][0:6] + str(time.time()) + '.jpg',
                                        #            self.image[human_y1:human_y2, human_x1:human_x2])

                                        human_face_safe_hats.append(human_face_safe_hat)
                        else:
                            human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                            human_face['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                            human_face['video_equipment_id'] = self.camera_ip
                            human_face['beautiful_time'] = self.timestp
                            # 人脸比对成功
                            if user_ids[i]:
                                human_face['user_id'] = user_ids[i].split('_')[0]
                                human_faces.append(human_face)
                                # cv2.imwrite('face/' + user_ids[i].split('_')[0][0:6] + str(time.time()) + '.jpg',
                                #                    self.image[human_y1:human_y2, human_x1:human_x2])

                # 判断human_face里面是否包含user_id，不包含则说明该行人没有检测到人脸，并且在攀岩摄像头场景下调用人体识别模型
                if 'user_id' not in human_face.keys() and self.camera_ip == climb_equipment_wall_id:
                    human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                    human_face['video_equipment_id'] = self.camera_ip
                    human_face['beautiful_time'] = self.timestp
                    human_no_faces.append(human_face)
            # 一张人脸人没有检测到，并且在攀岩摄像头场景下调用人体识别模型
            elif self.camera_ip == climb_equipment_wall_id:
                human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                human_face['video_equipment_id'] = self.camera_ip
                human_face['beautiful_time'] = self.timestp
                human_no_faces.append(human_face)
        return human_faces, human_no_faces, human_face_safe_hats


class HumanFaceWall(object):
    def __init__(self, face_result, human_result, image, camera_ip, timestp):
        self.face_result = face_result
        self.human_result = human_result
        self.image = image
        self.camera_ip = camera_ip
        self.timestp = timestp

    def human_face_wall(self):
        ih, iw, ic = self.image.shape
        human_faces = []
        human_face_safe_hats = []
        #  遍历一张图中多个行人，判断人脸框是否在行人框里面
        for human_xy in self.human_result:
            human_face = dict()
            human_face_safe_hat = dict()
            human_x1, human_y1, human_x2, human_y2 = max(0, human_xy[0]), max(0, human_xy[1]), \
                                                     min(iw, human_xy[2]), min(ih, human_xy[3])

            # 判断图片中是否检测到人脸
            if self.face_result:
                coordinate, user_ids = self.face_result[0], self.face_result[1]
                # 遍历一张图中多个人脸
                for i, coord in enumerate(coordinate):
                    face_x1, face_y1, face_x2, face_y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(
                        coord[3])
                    if human_x1 < face_x1 and face_x2 < human_x2 and human_y1 < face_y1 and face_y2 < human_y2:
                        if self.camera_ip == climb_equipment_ce_id:
                            hat_result = safe_hat_serving(self.image)
                            # 加上安全帽检测
                            for hat in hat_result:
                                iou = calculate_IoU([face_x1, face_y1, face_x2, face_y2],
                                                    [hat[0], hat[1], hat[2], hat[3]])
                                if iou > 0.65 and hat[1] < face_y1:
                                    human_face_safe_hat['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                                    human_face_safe_hat['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                                    human_face_safe_hat['video_equipment_id'] = self.camera_ip
                                    human_face_safe_hat['beautiful_time'] = self.timestp
                                    # 人脸比对成功
                                    if user_ids[i]:
                                        human_face_safe_hat['user_id'] = user_ids[i].split('_')[0]
                                        # cv2.imwrite('face/' + user_ids[i].split('_')[0][0:6] + str(time.time()) + '.jpg',
                                        #            self.image[human_y1:human_y2, human_x1:human_x2])

                                        human_face_safe_hats.append(human_face_safe_hat)
                        else:
                            human_face['body_coord'] = [human_x1, human_y1, human_x2, human_y2]
                            human_face['face_coord'] = [face_x1, face_y1, face_x2, face_y2]
                            human_face['video_equipment_id'] = self.camera_ip
                            human_face['beautiful_time'] = self.timestp
                            # 人脸比对成功
                            if user_ids[i]:
                                human_face['user_id'] = user_ids[i].split('_')[0]
                                human_faces.append(human_face)
                                # cv2.imwrite('face/' + user_ids[i].split('_')[0][0:6] + str(time.time()) + '.jpg',
                                #                    self.image[human_y1:human_y2, human_x1:human_x2])
        return human_faces, human_face_safe_hats
