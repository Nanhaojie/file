ps aux|grep python|grep -v grep|cut -c 9-15|xargs
```bash
# yuangang电脑的镜像启动方式
docker run -it -v/home/zongye/PycharmProjects/beautiful_memory_video_analyse/:/opt/apps/ --gpus all --name bm_analyse_video bm_analyse_video:1.0 /bin/bash
# 视频分析服务的时间需要和NVR保持同步
中讯运动会
docker run -itd -v /opt/apps/beautiful_memory_video_analyse/:/opt/apps/beautiful_memory_video_analyse/  --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=1 --name bm_analyse_video f664191e1287 /bin/bash
```

```
设置服务开机自启：
    1. mkdir /etc/systemd/system/rc-local.service,在新建的文件中输入配置信息
        #  SPDX-License-Identifier: LGPL-2.1+
        #
        #  This file is part of systemd.
        #
        #  systemd is free software; you can redistribute it and/or modify it
        #  under the terms of the GNU Lesser General Public License as published by
        #  the Free Software Foundation; either version 2.1 of the License, or
        #  (at your option) any later version.

        # This unit gets pulled automatically into multi-user.target by
        # systemd-rc-local-generator if /etc/rc.local is executable.
        [Unit]
        Description=/etc/rc.local Compatibility
        Documentation=man:systemd-rc-local-generator(8)
        ConditionFileIsExecutable=/etc/rc.local
        After=network.target

        [Service]
        Type=forking
        Environment=IS_PRODUCT=1
        ExecStart=/etc/rc.local start
        TimeoutSec=0
        RemainAfterExit=yes
        GuessMainPID=no

        [Install]
        WantedBy=multi-user.target
        Alias=rc-local.service

    2. mkdir /etc/rc.local, 修改权限：chmod +x rc.local,在rc.local输入配置信息
        #!/bin/bash -e
        # THIS FILE IS ADDED FOR COMPATIBILITY PURPOSES
        #
        # It is highly advisable to create own systemd services or udev rules
        # to run scripts during boot instead of using this file.
        #
        # In contrast to previous versions due to parallel execution during boot
        # this script will NOT be run after all other services.
        #
        # Please note that you must run 'chmod +x /etc/rc.d/rc.local' to ensure
        # that this script will be executed during boot.

        touch /var/lock/subsys/local
        /home/zoneyet001/beautiful_memory_video_analyse/model_service/persist_start.sh

    3. 重新加载配置文件： systemctl daemon-reload
    4. 启动服务：systemctl start rc-local.service
    5. 设置服务开机自启： systemctl enable rc-local.service

```

蹦床馆正式服务

远程连接:ssh zoneyet@121.36.22.179 -p 7022

|服务器地址|账号密码|服务|部署路径|启动方式|备注||
|  ----  | ----  |----|  ----  | ----  |----  |----  |
|192.168.11.35|root/123456|视频剪辑合成编码服务|宿主机,/data/mysp|sh /data/mysp/javacv_start.sh,  build/vccd -c conf/vcc.conf|||
|192.168.11.36|zoneyet001/root12300.|数据库服务,精彩瞬间分段组合|mysql/redis自启动,kafka有时需要手动启动|kafka:systemctl start kafka.service,精彩片段处理:systemctl restart rc-local.service|||
|192.168.11.37|zoneyet/root12300.|视频AI分析服务|宿主机,/home/zoneyet/project/beautiful_memory/beautiful_memory_video_analyse/model_service|systemctl start rc-local.service|||
|192.168.11.38|tqh/root12300.|视频剪辑合成编码服务|docker容器名:mysp_2,/data/|sh start_all.sh |||
|192.168.11.39|zoneyet/root12300.|梅花桩场景ＡＩ分析|docker容器名:bm_analyse_video,/opt/apps/project/beautiful_memory_video_analyse/model_service/|/root/miniconda3/envs/py38/bin/python pile_scene.py &>pile.log & |||

```
摄像头配置：
    总交换机用户名:zoneyet   
    密码:zoneyetadmin
    地址:192.168.11.12
    
    一号交换机
    入口闸机192.168.11.31
    攀爬1    192.168.11.32
    攀爬2   192.168.11.33
    滑梯2  192.168.11.34
    二号交换机
    滑梯1  192.168.11.22
    蹦床    192.168.11.21
    海洋球 192.168.11.23
    摄像头密码 a123456789  用户名admin
    
    新加那台机器的ip地址:192.168.11.38
    用户名zy35
    密码:zy123456
    用户名:tqh（清华的机器）
    密码:root12300.
    
    梅花桩侧面：　192.168.11.24   admin   root12300
    梅花桩墙上：　192.168.11.25   admin   886699hh
    新加蹦床：   192.168.11.26   admin   root12300.
    从梅花桩撤下来的：　　　　　　   admin   root12300
```

```
中讯运动会：

　172.16.1.31 zzunlp  zzunlp   视频分析
  172.16.1.30  root root12300.  数据库
  172.16.0.21  yons 123    视频剪辑
  
  172.16.1.32  zoneyet 123456　　视频剪辑

```
