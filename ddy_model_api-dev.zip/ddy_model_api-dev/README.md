地调院model_api
```
ps_serving部署：
docker run  -p 8292:9292 --name ps_serving -v /root/pd_serving:/root/pd_serving --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=2  -dit registry.baidubce.com/paddlepaddle/serving:0.5.0-cuda10.1-cudnn7-devel bash
进入容器启动服务：
    项目路径：/root/pd_serving/PaddleOCR-dygraph/deploy/pdserving
    启动命令： python3.6 web_service.py &>log.txt &
```

```
ddy_model_api部署：
docker run -p 8296:9292 --name ddy_model_api -v /root/ddy/ddy_model_api:/root/ddy_model_api python:3.6
python3 main.py &>main.log &
```

