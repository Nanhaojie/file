#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：tornadoTest 
@File ：global_config.py
@Author ：nhj
@Date ：2021/4/13 下午2:34 
'''
import configparser

config = configparser.ConfigParser()
config.read('serving.conf')

# tf_serving service
TF_URL = config.get('tf_serving', 'host')
TF_PORT = config.getint('tf_serving', 'port')
TFSERVING_ADDRESS = "%s:%d" % (TF_URL, TF_PORT)

# pd_serving service
PD_URL = config.get('pd_serving', 'host')
PD_PORT = config.getint('pd_serving', 'port')
PDSERVING_ADDRESS = "%s:%d" % (PD_URL, PD_PORT)

# File service
FILE_URL = config.get('file', 'host')
FILE_PORT = config.getint('file', 'port')
FILE_UPLOAD_PATH = config.get('file', 'path')

FILE_SERVER_URL = "http://%s:%d" % (FILE_URL, FILE_PORT)
FILE_SERVER_UPLOAD_PATH = "/upload"