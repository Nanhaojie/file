#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：tornadoTest 
@File ：main.py
@Author ：nhj
@Date ：2021/4/13 下午2:29 
'''
import tornado.web as tw
from tornado.ioloop import IOLoop
from tornado.httpserver import HTTPServer
from services.service_all import MulaController, TTC, JzController, TableController


def make_app():
    app = tw.Application(
        [(r'/ttc', TTC), (r'/fm', MulaController), (r'/jz', JzController), (r'/table', TableController)])
    return app


if __name__ == '__main__':
    app = make_app()
    httpServer = HTTPServer(app)
    httpServer.bind(9292)
    httpServer.start()
    IOLoop.current().start()
