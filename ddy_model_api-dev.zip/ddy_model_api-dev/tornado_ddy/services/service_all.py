#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：tornadoTest 
@File ：service.py
@Author ：nhj
@Date ：2021/4/13 下午2:30 
'''
import settings
from model_serving.pd_ocr.pd_serving import ocr_serving
from model_serving.table.table import table_serving
from model_serving.fm.latex_recognition import freeze_graph_test
import numpy as np
import cv2
from tornado import gen
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor
import tornado
import time
import json
from services.Img import Img
import requests
from io import BytesIO
import time
from urllib.parse import urlparse


def zj_upload_sync(file, path):
    url = settings.FILE_SERVER_URL + settings.FILE_SERVER_UPLOAD_PATH
    files = {'file': file}
    options = {'output': 'json', 'path': path, 'scene': '', 'filename': str(time.time())+'.png'}  # 参阅浏览器上传的选项
    r = requests.post(url, data=options, files=files)
    return urlparse(r.json()['url']).path


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, bytes):
            return str(obj)
        else:
            return super(NpEncoder, self).default(obj)


class TTC(tornado.web.RequestHandler):
    # 线程池
    max_thread_num = 8

    executor = ThreadPoolExecutor(max_workers=max_thread_num)

    @run_on_executor
    def runCode(self, src, file_type):
        img = Img()
        images = img.pdf2img(src, file_type)
        results = []
        urls = []
        for im in images:
            s1 = time.time()
            t = table_serving(im)
            print('table:', time.time() - s1)

            s2 = time.time()
            img_byte = BytesIO()
            im.save(img_byte, format='JPEG') # format: PNG or JPEG
            binary_content = img_byte.getvalue()
            pocr = ocr_serving(binary_content)
            print('ocr:', time.time() - s2)
            success, encoded_image = cv2.imencode(".png", np.array(im))
            url = zj_upload_sync(encoded_image, 'middle_img')
            urls.append(url)

            results.append([t, pocr])
        return [results, urls]

    @gen.coroutine
    def post(self):
        # 获取psot参数,待修正
        print('接收到请求')
        s = time.time()
        file_metas = self.request.files['images']
        file_type = int(self.request.query_arguments['file_type'][0])
        meta = file_metas[0]
        item = dict()
        fn = meta['filename']
        item['name'] = fn
        fb = meta['body']
        # 请求table模型
        b = yield self.runCode(fb, file_type)
        # 组装输出格式
        rst = dict()
        rst['result'] = b
        self.write(json.dumps(rst, cls=NpEncoder))
        print('消耗时间：', time.time() - s)


class MulaController(tornado.web.RequestHandler):
    # 线程池
    max_thread_num = 8
    executor = ThreadPoolExecutor(max_workers=max_thread_num)

    @run_on_executor
    def runCode(self, src):
        fm_result = freeze_graph_test(src)
        return fm_result

    @gen.coroutine
    def post(self):
        # 获取post参数,待修正
        file_metas = self.request.files['images']
        meta = file_metas[0]
        item = dict()
        fn = meta['filename']
        item['name'] = fn
        fb = meta['body']
        # 请求公式模型
        fm_img = cv2.imdecode(np.asarray(bytearray(fb), dtype='uint8'), cv2.IMREAD_COLOR)
        b = yield self.runCode(fm_img)
        # 组装输出格式
        rst = dict()
        rst['fm'] = b
        self.write(json.dumps(rst, cls=NpEncoder))


class JzController(tornado.web.RequestHandler):
    # 线程池
    max_thread_num = 8
    executor = ThreadPoolExecutor(max_workers=max_thread_num)

    @run_on_executor
    def runCode(self, src, file_type):
        img = Img()
        images = img.pdf2img(src, file_type)
        urls = []
        for im in images:
            success, encoded_image = cv2.imencode(".png", np.array(im))
            url = zj_upload_sync(encoded_image, 'middle_img')
            urls.append(url)
        return urls

    @gen.coroutine
    def post(self):
        # 获取post参数,待修正
        file_metas = self.request.files['images']
        file_type = int(self.request.query_arguments['file_type'][0])
        meta = file_metas[0]
        item = dict()
        fn = meta['filename']
        item['name'] = fn
        fb = meta['body']
        s = time.time()
        b = yield self.runCode(fb, file_type)
        print('单独纠正', time.time()-s)
        rst = dict()
        rst['fm'] = b
        self.write(json.dumps(rst, cls=NpEncoder))


class TableController(tornado.web.RequestHandler):
    # 线程池
    max_thread_num = 8
    executor = ThreadPoolExecutor(max_workers=max_thread_num)

    @run_on_executor
    def runCode(self, src):
        im = cv2.imdecode(np.asarray(bytearray(src), dtype='uint8'), cv2.IMREAD_COLOR)
        t = table_serving(im)
        return t

    @gen.coroutine
    def post(self):
        # 获取post参数,待修正
        file_metas = self.request.files['images']
        meta = file_metas[0]
        item = dict()
        fn = meta['filename']
        item['name'] = fn
        fb = meta['body']
        s = time.time()
        b = yield self.runCode(fb)
        print('单独table', time.time()-s)
        rst = dict()
        rst['table'] = b
        self.write(json.dumps(rst, cls=NpEncoder))
