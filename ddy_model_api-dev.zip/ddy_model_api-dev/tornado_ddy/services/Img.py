import fitz
from PIL import Image
import cv2
import io
import numpy as np
# from services.jz.rotated import jz
from model_serving.jz.jz import jz_serving
import time


class Img():
    def pdf2img(self, src, file_type):
        """
        src: pdf file path
        return: list->[Image]
        """
        if file_type == 1:
            pdfDoc = fitz.open(stream=src, filetype='bytes')
            # pdfDoc = fitz.open(src)
            images = list()
            for pg in range(pdfDoc.pageCount):
                page = pdfDoc[pg]
                rotate = int(0)
                # 每个尺寸的缩放系数为1.3，这将为我们生成分辨率提高2.6的图像。
                zoom_x = 3.9  # (1.33333333-->1056x816)   (2-->1584x1224)
                zoom_y = 3.9
                mat = fitz.Matrix(zoom_x, zoom_y).preRotate(rotate)
                pix = page.getPixmap(matrix=mat, alpha=False)
                barr = pix.getPNGData()
                img_jz = cv2.imdecode(np.asarray(bytearray(barr), dtype='uint8'), cv2.IMREAD_COLOR)
                s = time.time()
                barr_jz = jz_serving(img_jz)
                print('jz', time.time() - s)
                c = self.cut_img(barr_jz)
                images += c
            return images
        elif file_type == 2 or file_type == 3:
            images = list()
            img_jz = cv2.imdecode(np.asarray(bytearray(src), dtype='uint8'), cv2.IMREAD_COLOR)
            s = time.time()
            barr_jz = jz_serving(img_jz)
            print('jz', time.time() - s)
            c = self.cut_img(barr_jz)
            images += c
            return images

    def cut_img(self, src):
        """
        src: image content of cv2 type
        return list->[Image]
        """
        cv_src = np.asarray(src)
        # print(cv_src.shape)
        h2 = int(cv_src.shape[0] / 2) - 50
        h1 = int(cv_src.shape[0] / 2) + 50
        img_dis = cv_src[h2:h1, :]
        # show_result(img_dis, 'cut')
        dilatedrow_dis = self.sx(img_dis)
        # 任取一列所有竖线的一行，如果255，说明存在黑线
        dat_dis = dilatedrow_dis[50]
        qs_dis = []
        for q_dis in range(len(dat_dis)):
            if dat_dis[q_dis] == 255:
                qs_dis.append(q_dis)
        # 如果两个相邻的像素相差大于10，说明是两条竖线
        my_dis = []
        xs_dis = np.sort(qs_dis)
        num_row = 0
        for m_dis in range(len(xs_dis) - 1):
            if xs_dis[m_dis + 1] - xs_dis[m_dis] > 50:
                my_dis.append(xs_dis[m_dis])
            num_row += 1
        my_dis.append(xs_dis[num_row])
        h, w, _ = cv_src.shape

        if len(my_dis) > 19 and w > 4000:
            img1 = src.crop((0, 0, int(src.width / 2) + 25, int(src.height)))
            img2 = src.crop((int(src.width / 2) - 15, 0, int(src.width), int(src.height)))
            return [img1, img2]
        else:
            return [src]

    def sx(self, img_sx):
        """
        img_sx:
        return:
        """
        gray = cv2.cvtColor(img_sx, cv2.COLOR_BGR2GRAY)
        binary = cv2.adaptiveThreshold(~gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, -5)
        rows, cols = binary.shape
        scale = 20
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, rows // scale))
        eroded = cv2.erode(binary, kernel, iterations=1)
        dilatedrow_row = cv2.dilate(eroded, kernel, iterations=1)
        return dilatedrow_row
