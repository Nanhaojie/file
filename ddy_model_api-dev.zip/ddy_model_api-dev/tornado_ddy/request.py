#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：tornadoTest 
@File ：request.py
@Author ：nhj
@Date ：2021/4/7 下午6:23 
'''

import requests
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor,as_completed

def gg(s):
    response = requests.get("http://127.0.0.1:8741/ocr")
    print(response)
    return 1

def mt(p):
    # s = time.time()
    with ThreadPoolExecutor(max_workers=p) as t:
       obj_list = list()
       for i in range(p):
           obj = t.submit(gg, 'kk')
           obj_list.append(obj)

       for index, rstline in enumerate(as_completed(obj_list)):
           data = rstline.result()
    # e = time.time()
    # print('结束测试', e-s)

s = time.time()
mt(1)
e = time.time()
print('结束测试', e-s)

'''
s1 = time.time()
for i in range(10):
    s = time.time()
    response = requests.get("http://127.0.0.1:8741/ttc")
    e = time.time()
    print('单步时间：', e-s)
print('总时间：', time.time()-s1)
'''