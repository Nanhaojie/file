#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 9 23:11:51 2020
table ceil
@author: chineseocr
"""
import time
from model_serving.table.utils import draw_lines, minAreaRectbox, measure, eval_angle, draw_boxes, letterbox_image, \
    get_table_line, adjust_lines, line_to_line, draw_boxes_n

from settings import TFSERVING_ADDRESS
import os
import sys

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import cv2
import numpy as np
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc

options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]
server = TFSERVING_ADDRESS
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'test'
request.model_spec.signature_name = ""
request.model_spec.version.value = 20486
#request.model_spec.version.value = 20467

def table_line(img, size=(1024, 1024), hprob=0.5, vprob=0.5, row=10, col=10, alph=15):
    sizew, sizeh = size
    inputBlob, fx, fy = letterbox_image(img[..., ::-1], (sizew, sizeh))
    # img = cv2.resize(img, (64, 64))
    img = np.array([np.array(inputBlob) / 255.0])
    # faces = img[np.newaxis, :]
    request.inputs['input_image:0'].CopyFrom(tf.make_tensor_proto(img.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 30.0)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    pred = data['out:0']

    # pred = model.predict(np.array([np.array(inputBlob) / 255.0]))
    # pred = box_out[0]
    vpred = pred[..., 1] > vprob  ##竖线
    hpred = pred[..., 0] > hprob  ##横线
    vpred = vpred.astype(int)
    hpred = hpred.astype(int)
    # print("hpred",hpred)
    colboxes = get_table_line(vpred, axis=1, lineW=col)
    rowboxes = get_table_line(hpred, axis=0, lineW=row)
    ccolbox = []
    crowlbox = []
    if len(rowboxes) > 0:
        rowboxes = np.array(rowboxes)
        rowboxes[:, [0, 2]] = rowboxes[:, [0, 2]] / fx
        rowboxes[:, [1, 3]] = rowboxes[:, [1, 3]] / fy
        xmin = rowboxes[:, [0, 2]].min()
        xmax = rowboxes[:, [0, 2]].max()
        ymin = rowboxes[:, [1, 3]].min()
        ymax = rowboxes[:, [1, 3]].max()
        ccolbox = [[xmin, ymin, xmin, ymax], [xmax, ymin, xmax, ymax]]
        rowboxes = rowboxes.tolist()

    if len(colboxes) > 0:
        colboxes = np.array(colboxes)
        colboxes[:, [0, 2]] = colboxes[:, [0, 2]] / fx
        colboxes[:, [1, 3]] = colboxes[:, [1, 3]] / fy

        xmin = colboxes[:, [0, 2]].min()
        xmax = colboxes[:, [0, 2]].max()
        ymin = colboxes[:, [1, 3]].min()
        ymax = colboxes[:, [1, 3]].max()
        colboxes = colboxes.tolist()
        crowlbox = [[xmin, ymin, xmax, ymin], [xmin, ymax, xmax, ymax]]

    rowboxes += crowlbox
    colboxes += ccolbox

    rboxes_row_, rboxes_col_ = adjust_lines(rowboxes, colboxes, alph=alph)
    rowboxes += rboxes_row_
    colboxes += rboxes_col_
    nrow = len(rowboxes)
    ncol = len(colboxes)
    for i in range(nrow):
        for j in range(ncol):
            rowboxes[i] = line_to_line(rowboxes[i], colboxes[j], 10)
            colboxes[j] = line_to_line(colboxes[j], rowboxes[i], 10)

    return rowboxes, colboxes


def table_serving(img):
    img = np.asarray(img)
    # img = cv2.imdecode(np.asarray(bytearray(img), dtype='uint8'), cv2.IMREAD_COLOR)
    rowboxes, colboxes = table_line(img[..., ::-1], size=(1024, 1024), hprob=0.5, vprob=0.5)
    # rowboxes, colboxes = table_line(img[..., ::-1], size=(1024, 1024), hprob=0.5, vprob=0.2)
    tmp = np.zeros(img.shape[:2], dtype='uint8')
    tmp = draw_lines(tmp, rowboxes, color=255, lineW=7)
    tmp = draw_lines(tmp, colboxes, color=255, lineW=15)
    tmp = cv2.resize(tmp, (int(tmp.shape[1] / 2), int(tmp.shape[0] / 2)))
    labels = measure.label(tmp < 255, connectivity=2)  # 8连通区域标记
    regions = measure.regionprops(labels)
    ceilboxes = minAreaRectbox(regions, False, tmp.shape[1], tmp.shape[0], True, True)
    ceilboxes = np.array(ceilboxes)
    ceilboxes[:, [0, 2, 4, 6]] += 0
    ceilboxes[:, [1, 3, 5, 7]] += 0
    ceilboxes = ceilboxes * 2
    rboxes = draw_boxes_n(ceilboxes)
    return rboxes


if __name__ == '__main__':
    file = '/home/zhb/PycharmProjects/docr/img'
    file_out = '/home/zhb/PycharmProjects/docr'
    for name in os.listdir(file):
        img_name = os.path.join(file, name)
        img_name_out = os.path.join(file_out, name)
        img = cv2.imread(img_name)
        print(img_name)
        # img_1=cv2.resize(img,(512,512),interpolation=cv2.INTER_AREA)
        # # exit()
        t = time.time()
        rowboxes, colboxes = table_line(img[..., ::-1], size=(512, 512), hprob=0.5, vprob=0.2)
        tmp = np.zeros(img.shape[:2], dtype='uint8')
        tmp = draw_lines(tmp, rowboxes + colboxes, color=255, lineW=2)
        labels = measure.label(tmp < 255, connectivity=2)  # 8连通区域标记
        regions = measure.regionprops(labels)
        ceilboxes = minAreaRectbox(regions, False, tmp.shape[1], tmp.shape[0], True, True)
        ceilboxes = np.array(ceilboxes)
        ceilboxes[:, [0, 2, 4, 6]] += 0
        ceilboxes[:, [1, 3, 5, 7]] += 0

        img = draw_boxes(img, ceilboxes, color=(255, 0, 0))
        # img = draw_lines(img, rowboxes + colboxes, color=(255, 0, 0), lineW=2)
        # print(time.time() - t, len(rowboxes), len(colboxes))
        cv2.imwrite(img_name_out, img)
