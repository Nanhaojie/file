#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ai-eng-model-api 
@File ：pd_serving.py
@Author ：nhj
@Date ：2021/5/12 上午8:52 
'''
from paddle_serving_server.pipeline import PipelineClient
import base64
from settings import PDSERVING_ADDRESS

client = PipelineClient()
client.connect([PDSERVING_ADDRESS])


def cv2_to_base64(image):
    return base64.b64encode(image).decode('utf8')


def ocr_serving(image_data):
    image = cv2_to_base64(image_data)
    ret = client.predict(feed_dict={"image": image}, fetch=["res"])
    list_res = list(ret.value)
    txt = eval(list_res[0])
    coor = eval(list_res[1])
    return [coor, txt]
