#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：application_api 
@File ：global_config.py
@Author ：nhj
@Date ：2021/5/8 上午9:46 
"""

TFSERVING_ADDRESS = '172.16.0.21:8500'  # tfserving的地址

