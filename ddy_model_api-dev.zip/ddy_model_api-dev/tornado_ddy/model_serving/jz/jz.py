#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：jz.py
@Author ：nhj
@Date ：2021/5/7 下午4:37 
'''
import os
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import tensorflow as tf
from keras.applications.vgg16 import preprocess_input
import numpy as np
import cv2
from PIL import Image
from model_serving.jz.rotated import ImgCorrect
from scipy import ndimage
import time
from settings import TFSERVING_ADDRESS
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '0'

options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]
server = TFSERVING_ADDRESS
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'test'
# request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 20481
request.model_spec.signature_name = ""


# 角度纠正
def angle_jz(image_path):
    image_path = image_path
    image_paths = os.listdir(image_path)
    for path in image_paths:
        im = cv2.imread(os.path.join(image_path, path))
        imgcorrect = ImgCorrect(im)
        degree = imgcorrect.img_lines()
        rotate_img = ndimage.rotate(im, degree)
        rotate_img = Image.fromarray(cv2.cvtColor(rotate_img, cv2.COLOR_BGR2RGB))  # 转RGB
        # 对图片进行剪裁之后进行resize成(224,224)
        img = rotate_img.resize((224, 224))
        # img = image.load_img("images/" + path, target_size=(224, 224))     # 预测图片的路径
        x = np.array(img)  # 将图像转化成数组形式
        x = preprocess_input(x.astype(np.float32))
        x = np.array([x])

        request.inputs['input_image:0'].CopyFrom(tf.make_tensor_proto(x.astype(dtype=np.float32)))  # 为模型的输入Name
        result_future = stub.Predict.future(request, 40.0)  # 10 secs timeout
        result = result_future.result()

        data = {}
        for key in result.outputs:
            tensor_proto = result.outputs[key]
            data[key] = tf.make_ndarray(tensor_proto)
        pred = data['out:0']

        angle = np.argmax(pred) * 90
        ims = ndimage.rotate(rotate_img, -angle)
        # cv2.imshow('dfd.png', ims)
        # cv2.waitKey(0)
        # print('模型预测的角度值:', angle)
        # cv2.imwrite("output/{}".format(path), ims)  # 纠正后图片的保存路径
        return ims


def jz_serving(im):
    imgcorrect = ImgCorrect(im)
    degree = imgcorrect.img_lines()
    im_pil = Image.fromarray(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
    rotate_img = im_pil.rotate(degree)
    # rotate_img = ndimage.rotate(im, degree)
    # rotate_img = Image.fromarray(cv2.cvtColor(rotate_img, cv2.COLOR_BGR2RGB))  # 转RGB
    # 对图片进行剪裁之后进行resize成(224,224)
    img = rotate_img.resize((224, 224))
    # img = image.load_img("images/" + path, target_size=(224, 224))     # 预测图片的路径
    x = np.array(img)  # 将图像转化成数组形式
    x = preprocess_input(x.astype(np.float32))
    x = np.array([x])

    request.inputs['input_image:0'].CopyFrom(tf.make_tensor_proto(x.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 40.0)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    pred = data['out:0']
    # angle = np.argmax(pred) * 90
    angle = np.argmax(pred)
    if angle == 0:
        result = 0
    elif angle == 1:
        result = 180
    elif angle == 2:
        result = 270
    else:
        result = 90
    # ims = ndimage.rotate(rotate_img, -result)
    ims = rotate_img.rotate(-result)
    # imgg = cv2.cvtColor(np.asarray(ims), cv2.COLOR_RGB2BGR)
    return ims


if __name__ == '__main__':
    image_path = "test"
    angle_jz(image_path)

