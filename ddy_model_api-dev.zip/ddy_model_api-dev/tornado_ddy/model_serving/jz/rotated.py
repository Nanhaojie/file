#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：rotated.py
@Author ：nhj
@Date ：2021/5/7 下午4:04 
'''
import cv2
import numpy as np
from math import *
import os
import time
from PIL import Image
from scipy import misc, ndimage, stats

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


class ImgCorrect():
    def __init__(self, img):
        # pass
        self.img = img
        self.gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)

    def img_lines(self):
        ret, binary = cv2.threshold(self.gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        kernel = np.ones((3, 3), np.uint8)
        binary = cv2.dilate(binary, kernel, iterations=1)
        edges = cv2.Canny(binary, 50, 150)

        self.lines = cv2.HoughLinesP(edges, 3.0, np.pi / 180, 0, minLineLength=30, maxLineGap=8)
        # print(self.lines)
        # print(self.lines.shape)
        self.lines = self.lines[:, 0, :]
        rotate_angles = []
        for x1, y1, x2, y2 in self.lines:
            if x1 == x2 or y1 == y2:
                rotate_angle = 0
            else:
                t = float(y2 - y1) / (x2 - x1)
                rotate_angle = degrees(atan(t))
                rotate_angle = round(rotate_angle / 2) * 2
                # print(rotate_angle)
                # print(rotate_angles)
            rotate_angles.append(rotate_angle)
        rotate_angle = stats.mode(rotate_angle)[0][0]  # 众数

        # if -45 <= rotate_angle <= 0:
        #     rotate_angle = rotate_angle  # #负角度 顺时针
        # if -90 <= rotate_angle < -45:
        #     rotate_angle = 90 + rotate_angle  # 正角度 逆时针
        # if 0 < rotate_angle <= 45:
        #     rotate_angle = rotate_angle  # 正角度 逆时针
        # if 45 < rotate_angle < 90:
        #     rotate_angle = rotate_angle - 90  # 负角度 顺时针

        return rotate_angle


if __name__ == "__main__":
    t = time.time()
    image_path = "images"
    image_paths = os.listdir(image_path)

    for path in image_paths:
        im = cv2.imread(os.path.join(image_path, path))
        ims = im.copy()
        imgcorrect = ImgCorrect(ims)
        degree = imgcorrect.img_lines()
        print(degree)
        rotate_img = ndimage.rotate(ims, degree)
        cv2.imwrite("output/{}".format(path), rotate_img)

