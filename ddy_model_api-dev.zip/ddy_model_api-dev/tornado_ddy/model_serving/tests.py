from django.test import TestCase

# Create your tests here.
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time


def ocr_all(img):
    url = 'http://172.16.0.18:8502/ttc'
    files = {'images': img}
    r = requests.post(url=url, files=files)
    res = r.json()['result']
    return res


def mt(p):
    with ThreadPoolExecutor(max_workers=p) as t:
        obj_list = list()
        for i in range(p):
            obj = t.submit(ocr_all, open('/home/zhb/PycharmProjects/docr/pdf/ceshi.pdf', 'rb'))
            obj_list.append(obj)
        for index, rstline in enumerate(as_completed(obj_list)):
            data = rstline.result()
            print(data)


s = time.time()
mt(2)
e = time.time()
print('结束测试', e - s)
