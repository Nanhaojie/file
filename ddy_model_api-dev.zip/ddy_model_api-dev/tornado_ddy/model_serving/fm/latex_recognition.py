# -*- coding:utf-8 -*-
from numpy import *
import os
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import grpc
import tensorflow as tf
import numpy as np
from tensorflow.compat.v1 import ConfigProto
from tensorflow.compat.v1 import InteractiveSession
import json
from settings import TFSERVING_ADDRESS

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '0'
options = [('grpc.max_receive_message_length', 100 * 1024 * 1024)]
server = TFSERVING_ADDRESS
channel = grpc.insecure_channel(server, options=options)
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
request = predict_pb2.PredictRequest()
request.model_spec.name = 'test'
# request.model_spec.signature_name = 'serving_default'
request.model_spec.version.value = 20489
request.model_spec.signature_name = ""
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

config = ConfigProto()
config.gpu_options.allow_growth = True
session = InteractiveSession(config=config)


def get_max_shape(arrays):
    """
    Args:
        images: list of arrays

    """
    # hack
    # return [40, 240, 1]
    shapes = list(map(lambda x: list(x.shape), arrays))
    return [max(x) for x in zip(*shapes)]


def pad_batch_images(images, max_shape=None):
    """
    Args:
        images: list of arrays
        target_shape: shape at which we want to pad

    """
    # 1. max shape
    if max_shape is None:
        max_shape = get_max_shape(images)
    # 2. apply formating
    batch_images = 255 * np.ones([len(images)] + list(max_shape))
    for idx, img in enumerate(images):
        batch_images[idx, :img.shape[0], :img.shape[1]] = img
    return batch_images.astype(np.uint8)


def greyscale(state):
    """Preprocess state (:, :, 3) image into greyscale"""
    state = state[:, :, 0] * 0.299 + state[:, :, 1] * 0.587 + state[:, :, 2] * 0.114
    state = state[:, :, np.newaxis]
    return state.astype(np.uint8)


def truncate_end(list_of_ids, id_end):
    """Removes the end of the list starting from the first id_end token"""
    list_trunc = []
    for idx in list_of_ids:
        if idx == id_end:
            break
        else:
            list_trunc.append(idx)
    return list_trunc


def freeze_graph_test(image):
    '''
    :param pb_path:pb文件的路径
    :param image_path:测试图片的路径
    :return:
    '''
    # 读取测试图片
    img = greyscale(image)
    img = pad_batch_images([img])
    dropout = np.array(1)
    request.inputs['img'].CopyFrom(tf.make_tensor_proto(img.astype(dtype=np.uint8)))  # 为模型的输入Name
    request.inputs['dropout'].CopyFrom(tf.make_tensor_proto(dropout.astype(dtype=np.float32)))  # 为模型的输入Name
    result_future = stub.Predict.future(request, 40.0)  # 10 secs timeout
    result = result_future.result()
    data = {}
    for key in result.outputs:
        tensor_proto = result.outputs[key]
        data[key] = tf.make_ndarray(tensor_proto)
    out = data['out']
    hyps = [[] for i in range(2)]
    ids_eval = np.transpose(out, [0, 2, 1])
    with open('model_serving/fm/liudan.json', 'r') as fj:
        diction = json.load(fj)
        dic = list(diction.keys())
        dic_1 = {}
        for dic_index in range(len(diction)):
            a = diction.keys()
            a = int(dic_index)
            dic_1[a] = diction[str(a)]
    for preds in ids_eval:
        for i, pred in enumerate(preds):
            p = truncate_end(pred, 412)
            p = " ".join([dic_1[idx] for idx in p])
            hyps[i].append(p)
    return hyps[0][0]



if __name__ == '__main__':
    # pb_path = 'frozenModel/full_q_v5_model.pb'
    # pb_path = '/home/l/LaTeX_OCR_tf-1.14/results/coding_convert_model/transpose_1/full_q_v5_model.pb'
    image_path = '/home/zhb/PycharmProjects/docr/img/lADPDiCpvAaTGaZYTA_76_88.jpg'
    s = freeze_graph_test(image_path)
    print(s)
