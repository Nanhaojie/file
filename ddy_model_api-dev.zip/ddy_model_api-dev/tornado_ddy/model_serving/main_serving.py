#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：main_test.py
@Author ：nhj
@Date ：2021/5/8 上午10:31 
'''
import os
from model_serving.jz.jz import jz_serving
from model_serving.table.table import table_serving
from model_serving.pd_ocr.pd_serving import ocr_serving
import cv2
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

with open('/home/zhb/PycharmProjects/docr/img/ceshi.png', 'rb') as f:
    imga = f.read()

img = cv2.imread('ceshi.jpg')
'''
s = time.time()
jz_img = jz_serving(img)
e = time.time()
print('jz_time:', e-s)

s1 =time.time()
t_lay = table_serving(jz_img)
e1 = time.time()
print('table_time:', e1-s1)
print(t_lay)
'''


def mt(p):
    with ThreadPoolExecutor(max_workers=p) as t:
        obj_list = list()
        for i in range(p):
            obj = t.submit(jz_serving, img)
            obj_list.append(obj)
        for index, rstline in enumerate(as_completed(obj_list)):
            data = rstline.result()
            # print(data)


s = time.time()
mt(1)
e = time.time()
print('结束测试', e - s)
