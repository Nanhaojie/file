AI标注平台


```bash
# 部署命令
docker run -itd  -p 8005:8005 -p 8006:8006  --name ai_annotation_platform_container -v  /data/logs/ai_annotation_platform:/data/logs -v /opt/apps/ai-annotation-platform:/usr/src/app ai_annotation_platform_image:1.0
# 服务部署在10服务器，拉取最新服务并上线的命令
root@gello:/opt/apps/long_follow_up_applet# bash long_follow_restart.sh 

# openstack测试线
docker run -itd --restart always --name ai_annotation_platform_container  -p 8005:8005 -p 8006:8006 -v  /data/logs/ai_annotation_platform:/data/logs -v /data/publish_apps/AI-Annotation-Platform:/usr/src/app  python:3.6 /bin/bash /usr/src/app/entrypoint.sh
```

```医院docker
docker run -itd --restart always --name mark_api -p 8000:8000 -v /zoneyet_apps/ai-annotation-platform/:/code/ mark_image:v1.0

```

```核对数据

docker run -itd --restart always --name mark_check_api -p 8015:8005 -e IS_PRODUCT=2 -v /opt/apps/ai-annotation-platform/:/usr/src/app/ python:3.6 /bin/bash /usr/src/app/entrypoint_check.sh

```

```
脑电标注平台web正式线
docker run -itd --restart always --name ai_annotation_platform_pro  -p 8009:8005 -e IS_PRODUCT=3 -v  /data/logs/ai_annotation_platform_pro:/data/logs -v /opt/apps/ai-annotation-platform-pro/ai-annotation-platform:/usr/src/app  python:3.6 /bin/bash /usr/src/app/entrypoint.sh
```
