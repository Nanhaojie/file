#!/bin/bash
cd /usr/src/app/
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple
cd ai_annotation_platform && python manage.py migrate && \
    cd ai_annotation_platform &&
    uvicorn ai_annotation_platform.asgi:application --host 0.0.0.0 --port 8005 \
    --timeout-keep-alive 60 --workers 5 --limit-max-requests 5000 2>> /data/logs/uvicorn_err.log \
    & cd ai_annotation_platform && export IS_PRODUCT=2 && python manage.py runserver 0.0.0.0:8005
