import hashlib
import logging
import re
import time
from django.conf import settings
from django.db import transaction
from django.shortcuts import render

# Create your views here.
from django.utils import timezone
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from rest_framework_jwt.settings import api_settings
from django_redis import get_redis_connection

from mark.filters import MarkFilter
from mark.models import MarkModel, User, MarkDetailModel, WaveModel
from mark.serializers import MarkSerializer, UserListUpdateSerializer, UserCreateSerializer, MarkDetailSerializer, \
    WaveSerializer, EegMarkSerializer
from utils.common import get_eeg_data
from utils.copyeegfromsvr import main_fun, download_data

logger = logging.getLogger('django')
redis_conn = get_redis_connection('login_user')


class TestView(APIView):

    def get(self, request, *args, **kwargs):
        return Response({'data': '测试接口'})


# 导入脑电数据
class InsertDataView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""导入脑电数据""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['file_path'],
            properties={
                'file_txt_path': openapi.Schema(type=openapi.TYPE_STRING, description='脑电数据txt路径'),
                'file_json_path': openapi.Schema(type=openapi.TYPE_STRING, description='脑电数据json路径')
            }
        ),
        # 接口标题
        operation_summary='导入脑电数据',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['导入脑电数据']
    )
    def post(self, request, *args, **kwargs):
        file_txt_path = request.data['file_txt_path']
        file_json_path = request.data['file_json_path']
        if not [file_txt_path, file_json_path]:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            main_fun(file_txt_path, file_json_path)
            return Response(data={'data': '数据导入成功'}, status=status.HTTP_200_OK)
        except Exception:
            logger.error("数据导入失败", exc_info=True)
            return Response({'detail': '数据导入失败'}, status=status.HTTP_400_BAD_REQUEST)


# 导出标注
class DownloadMarkView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""导出标注""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['save_mark_path'],
            properties={
                'save_mark_path': openapi.Schema(type=openapi.TYPE_STRING, description='导出标注路径')
            }
        ),
        # 接口标题
        operation_summary='导出标注',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['导出标注']
    )
    def post(self, request, *args, **kwargs):
        save_mark_path = request.data['save_mark_path']
        if not save_mark_path:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            download_data(save_mark_path)
            return Response(data={'data': '导出标注成功'}, status=status.HTTP_200_OK)
        except Exception:
            logger.error("导出标注失败", exc_info=True)
            return Response({'detail': '导出标注失败'}, status=status.HTTP_400_BAD_REQUEST)


class MarkListView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    filter_class = MarkFilter

    def get_serializer_class(self):
        return MarkSerializer

    def get_queryset(self):
        return MarkModel.objects.all().order_by(*['-batch', 'case_id'])

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""标注列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='标注列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注列表']
    )
    def list(self, request, *args, **kwargs):
        response = super(MarkListView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""标注列表详细信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            # openapi.Parameter(name="id", in_=openapi.IN_QUERY, description="标注id",
            #                   type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='标注列表详细信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注列表']
    )
    def retrieve(self, request, *args, **kwargs):
        return super(MarkListView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""修改标注状态，标注人""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={'is_mark': openapi.Schema(type=openapi.TYPE_NUMBER, description='标注状态'),
                        'mark_name': openapi.Schema(type=openapi.TYPE_STRING, description='标注人'),
                        'spare_str1': openapi.Schema(type=openapi.TYPE_STRING, description='标注人id')
                        }
        ),
        # 接口标题
        operation_summary='修改标注状态，标注人',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注列表']
    )
    def update(self, request, *args, **kwargs):
        return super(MarkListView, self).update(request, *args, **kwargs)


# 标注详情
class MarkDetailView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return MarkDetailSerializer

    def get_queryset(self):
        mark_id = self.request.query_params.get('mark_id')
        if mark_id:
            return MarkDetailModel.objects.filter(mark_id=mark_id).order_by('start_point')
        else:
            return MarkDetailModel.objects.all().order_by('start_point')

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""获取标注详情""",
        # 接口参数 GET请求参数
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
            openapi.Parameter(name="mark_id", in_=openapi.IN_QUERY, description="标注id", type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='获取标注详情',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注详情']
    )
    def list(self, request, *args, **kwargs):
        response = super(MarkDetailView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""标注""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['mark', 'start_point', 'end_point', 'wave'],
            properties={
                'mark': openapi.Schema(type=openapi.TYPE_STRING, description='标注id'),
                'passageway': openapi.Schema(type=openapi.TYPE_NUMBER, description='通道号'),
                'passageway_name': openapi.Schema(type=openapi.TYPE_STRING, description='通道名称'),
                'start_point': openapi.Schema(type=openapi.FORMAT_FLOAT, description='开始点'),
                'end_point': openapi.Schema(type=openapi.FORMAT_FLOAT, description='结束点'),
                'wave': openapi.Schema(type=openapi.TYPE_STRING, description='波形名称'),
                'dur_time': openapi.Schema(type=openapi.FORMAT_FLOAT, description='持续时长'),
            }
        ),
        # 接口标题
        operation_summary='标注',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注详情']
    )
    def create(self, request, *args, **kwargs):
        data = request.data
        user = request.user
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        mark_id = data['mark']
        user_id = user.id
        mark_object = MarkModel.objects.filter(id=mark_id)
        mark_object.update(spare_str1=user_id, mark_date=time.strftime("%Y-%m-%d %H:%M"))
        return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""编辑标注信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={
                'passageway': openapi.Schema(type=openapi.TYPE_NUMBER, description='通道号'),
                'passageway_name': openapi.Schema(type=openapi.TYPE_STRING, description='通道名称'),
                'start_point': openapi.Schema(type=openapi.FORMAT_FLOAT, description='开始点'),
                'end_point': openapi.Schema(type=openapi.FORMAT_FLOAT, description='结束点'),
                'wave_id': openapi.Schema(type=openapi.TYPE_STRING, description='波形id'),
                'notes': openapi.Schema(type=openapi.TYPE_STRING, description='备注'),
                'wave': openapi.Schema(type=openapi.TYPE_STRING, description='波形名称'),
                'dur_time': openapi.Schema(type=openapi.FORMAT_FLOAT, description='持续时长'),
            }
        ),
        # 接口标题
        operation_summary='编辑标注信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注详情']
    )
    def update(self, request, *args, **kwargs):
        return super(MarkDetailView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""删除标注信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='删除标注信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注详情']
    )
    def destroy(self, request, *args, **kwargs):
        return super(MarkDetailView, self).destroy(request, *args, **kwargs)


# 完成标注
class MarkCompleteView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""完成标注""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['mark'],
            properties={'mark_id': openapi.Schema(type=openapi.TYPE_STRING, description='标注id')}
        ),
        # 接口标题
        operation_summary='完成标注',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['标注详情']
    )
    def post(self, request, *args, **kwargs):
        mark_id = request.data['mark_id']
        if not mark_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        mark_object = MarkModel.objects.filter(id=mark_id)
        mark_object.update(is_mark=2, mark_date=time.strftime("%Y-%m-%d %H:%M"))
        return Response(data={'data': '完成标注'}, status=status.HTTP_200_OK)


# 标注状态
class MarkStatusView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""标注状态""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="id", in_=openapi.IN_QUERY, description="标注id",
                              type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='标注状态',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['eeg数据标注列表']
    )
    def get(self, request, *args, **kwargs):
        mark_id = request.query_params.get('id')
        if not mark_id:
            return Response({'detail': '参数缺失'}, status=status.HTTP_400_BAD_REQUEST)
        mark_obj = MarkModel.objects.filter(id=mark_id).first()
        data = {'is_mark': mark_obj.is_mark,  'mark_name': mark_obj.mark_name, 'mark_name_id': mark_obj.spare_str1}
        return Response(data={'data': data}, status=status.HTTP_200_OK)


# 波形
class WaveView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return WaveSerializer

    def get_queryset(self):
        return WaveModel.objects.all().order_by('-create_time')

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""波形列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='波形列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['波形设置']
    )
    def list(self, request, *args, **kwargs):
        response = super(WaveView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""添加波形""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['wave_name'],
            properties={
                'wave_name': openapi.Schema(type=openapi.TYPE_STRING, description='波形名称')
            }
        ),
        # 接口标题
        operation_summary='添加波形',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['波形设置']
    )
    def create(self, request, *args, **kwargs):
        wave_data = request.data
        serializer = self.get_serializer(data=wave_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(data={'detail': '添加成功'},  status=status.HTTP_201_CREATED, headers=headers)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""编辑波形""",
        manual_parameters=[openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                                             type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={'wave_name': openapi.Schema(type=openapi.TYPE_STRING, description='波形名称')}
        ),
        # 接口标题
        operation_summary='编辑波形',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['波形设置']
    )
    def update(self, request, *args, **kwargs):
        return super(WaveView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""删除波形""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='删除波形',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['波形设置']
    )
    def destroy(self, request, *args, **kwargs):
        return super(WaveView, self).destroy(request, *args, **kwargs)


# 适应web的列表
class EegMarkListView(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    filter_class = MarkFilter

    def get_serializer_class(self):
        return EegMarkSerializer

    def get_queryset(self):
        if self.request.user.username == 'doctor1':
            return MarkModel.objects.filter(is_eeg_data=1, spare_int1=1)
        elif self.request.user.username == 'doctor2':
            return MarkModel.objects.filter(is_eeg_data=1, spare_int1=2)
        elif self.request.user.username == 'doctor3':
            return MarkModel.objects.filter(is_eeg_data=1, spare_int1=3)
        return MarkModel.objects.filter(is_eeg_data=1)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""eeg数据标注列表""",
        # 接口参数 GET请求参数
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='eeg数据标注列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['eeg数据标注列表']
    )
    def list(self, request, *args, **kwargs):
        response = super(EegMarkListView, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""eeg数据标注列表详细信息""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
            # openapi.Parameter(name="id", in_=openapi.IN_QUERY, description="标注id",
            #                   type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='eeg数据标注列表详细信息',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['eeg数据标注列表']
    )
    def retrieve(self, request, *args, **kwargs):
        return super(EegMarkListView, self).retrieve(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""eeg数据修改标注状态，标注人""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING)
        ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={'is_mark': openapi.Schema(type=openapi.TYPE_NUMBER, description='标注状态'),
                        'mark_name': openapi.Schema(type=openapi.TYPE_STRING, description='标注人'),
                        'spare_str1': openapi.Schema(type=openapi.TYPE_STRING, description='标注人id')
                        }
        ),
        # 接口标题
        operation_summary='eeg数据修改标注状态，标注人',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['eeg数据标注列表']
    )
    def update(self, request, *args, **kwargs):
        return super(EegMarkListView, self).update(request, *args, **kwargs)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""eeg数据标注列表""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
                              type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='删除',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['eeg数据标注列表']
    )
    def destroy(self, request, *args, **kwargs):
        return super(EegMarkListView, self).destroy(request, *args, **kwargs)


# 获取eeg文件数据
class EegDataView(APIView):

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""查询eeg数据""",
        manual_parameters=[
            # openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
            #                   type=openapi.TYPE_STRING),
            openapi.Parameter(name="start_offset", in_=openapi.IN_QUERY, description="开始时间/单位秒最多精确两位小数",
                              type=openapi.FORMAT_FLOAT),
            openapi.Parameter(name="time_length", in_=openapi.IN_QUERY, description="持续时间/单位秒最多精确两位小数",
                              type=openapi.FORMAT_FLOAT),
            openapi.Parameter(name="eeg_test_id", in_=openapi.IN_QUERY, description="eeg检测记录id",
                              type=openapi.TYPE_STRING),
            openapi.Parameter(name="test_time", in_=openapi.IN_QUERY, description="检测时间",
                              type=openapi.TYPE_STRING),
        ],
        # 接口标题
        operation_summary='eeg数据',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['查询eeg数据']
    )
    def get(self, request, *args, **kwargs):
        start_offset = request.query_params.get('start_offset')
        time_length = request.query_params.get('time_length')
        eeg_test_id = request.query_params.get('eeg_test_id')
        test_time = request.query_params.get('test_time')
        eeg_data = get_eeg_data(float(start_offset), float(time_length), eeg_test_id, test_time)
        return Response({'data': eeg_data}, status=status.HTTP_200_OK)


# 用户部分
class UserViewSet(ModelViewSet):

    def get_serializer_class(self):
        if self.action in ('list', 'update', 'retrieve'):
            return UserListUpdateSerializer
        elif self.action == 'create':
            return UserCreateSerializer

    def get_queryset(self):
        return User.objects.all().order_by('-create_time')

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户列表""",
        # 接口参数 GET请求参数
        # 接口标题
        operation_summary='用户列表',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def list(self, request, *args, **kwargs):
        response = super(UserViewSet, self).list(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""编辑用户""",
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            properties={'is_active': openapi.Schema(type=openapi.TYPE_NUMBER, description='是否激活'),
                        'real_name': openapi.Schema(type=openapi.TYPE_STRING, description='真实姓名'),
                        'password': openapi.Schema(type=openapi.TYPE_STRING, description='密码')
                        }
        ),
        # 接口标题
        operation_summary='编辑用户',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def update(self, request, *args, **kwargs):
        # response = super(UserViewSet, self).update(request, *args, **kwargs)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        return Response(data=serializer.data, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        response = super(UserViewSet, self).retrieve(request, *args, **kwargs)
        return response

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户注册""",
        # manual_parameters=[
        #     openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token",
        #                       type=openapi.TYPE_STRING)
        # ],
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['username', 'password', 'real_name'],
            properties={
                'username': openapi.Schema(type=openapi.TYPE_STRING, description='账号'),
                'password': openapi.Schema(type=openapi.TYPE_STRING, description='密码'),
                'real_name': openapi.Schema(type=openapi.TYPE_STRING, description='真实姓名'),
                'is_staff': openapi.Schema(type=openapi.TYPE_NUMBER, description='是否是管理员'),
            }
        ),
        # 接口标题
        operation_summary='用户注册',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def create(self, request, *args, **kwargs):
        with transaction.atomic():
            save_id = transaction.savepoint()
            # try:
            username = request.data.get('username', '')
            if username:
                if not re.match('[0-9A-Za-z]{1,20}$', username):
                    return Response(data={'detail': '用户账号只能包含字母或数字且长度应不超过20位'}, status=status.HTTP_400_BAD_REQUEST)
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid(raise_exception=False):
                return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            response = Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
            # except Exception as e:
            #     transaction.savepoint_rollback(save_id)
            #     return Response(data={'detail': '用户创建失败！'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        return response


class UserAuthorizeView(APIView):
    """用户登录视图"""

    def my_md5(self, jwt):
        md = hashlib.md5()
        md.update(jwt.encode(encoding='utf-8'))
        md5_str = md.hexdigest()
        return md5_str

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""用户登录""",
        request_body=openapi.Schema(
            # 构造的请求体为 dict 类型
            type=openapi.TYPE_OBJECT,
            # 构造的请求体中 必填参数 列表
            required=['username', 'password'],
            properties={
                'username': openapi.Schema(type=openapi.TYPE_STRING, description='用户名'),
                'password': openapi.Schema(type=openapi.TYPE_STRING, description='密码')
            }
        ),
        # 接口标题
        operation_summary='用户登录',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def post(self, request, *args, **kwargs):
        # 参数验证
        username = request.data.get("username")
        password = request.data.get("password")
        if not all([username, password]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        # 密码及用户校验
        try:
            user = User.objects.get(username=username)
        except Exception:
            return Response(data={"detail": "账号不存在"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if not user.check_password(password):
                return Response(data={"detail": "密码不正确"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                if user.is_active:
                    request.user = user
                    # 手动生成token验证
                    jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
                    jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
                    payload = jwt_payload_handler(user)
                    token = jwt_encode_handler(payload)
                    md5_str = self.my_md5(token)
                    val = {"token": token, "username": user.username, "user_id": user.id}
                    redis_conn.set(md5_str, str(val), settings.PC_EXP_SECOND)
                    redis_conn.set('mark_user_' + str(user.id) + '_' + md5_str, md5_str, settings.PC_EXP_SECOND)
                    ret = {
                        'token': md5_str,
                        'username': user.username,
                        'real_name': user.real_name,
                        'user_id': user.id,
                        'is_staff': 1 if user.is_staff else 0,
                        'notes': user.notes,
                        'detail': "成功",
                    }
                    user.last_login = timezone.now()
                    user.save(update_fields=['last_login'])
                    return Response(data=ret)
                else:
                    return Response(data={"detail": "用户被禁用"}, status=status.HTTP_400_BAD_REQUEST)

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.check_throttles(request)


class UserLogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    @swagger_auto_schema(
        # 接口描述，支持markdown语法
        operation_description="""退出""",
        manual_parameters=[
            openapi.Parameter(name="Authorization", in_=openapi.IN_HEADER, description="token", type=openapi.TYPE_STRING)
        ],
        # 接口标题
        operation_summary='退出',
        # 接口所属分组，会单独将接口拆出来放到 用户管理 分组中
        tags=['用户']
    )
    def delete(self, request, *args, **kwargs):
        user_id = request.user.id
        token = request.META.get('HTTP_AUTHORIZATION').replace('JWT ', '')
        redis_conn.delete(token)
        redis_conn.delete('mark_user_' + str(user_id) + '_' + token)
        return Response(data={'detail': '成功'}, status=status.HTTP_200_OK)
