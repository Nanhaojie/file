# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 12/14/21 4:10 PM
# @author yueyuanbo

import django_filters

from mark.models import MarkModel


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False


class MarkFilter(django_filters.FilterSet):
    """标注列表过滤类"""
    # field_name 表示要过滤字段；lookup_expr 表示 过滤时要进行的操作，gte 表示 大于等于
    start_date = django_filters.CharFilter(field_name="mark_date", lookup_expr="gte", help_text='开始日期')
    end_data = django_filters.CharFilter(field_name="mark_date", lookup_expr="lte", help_text='结束日期')
    is_mark = django_filters.CharFilter(field_name="is_mark", lookup_expr="exact", help_text='标注状态')
    age = django_filters.CharFilter(field_name="age", method="filter_age", help_text='患者年龄')
    name = django_filters.CharFilter(field_name="name", method="filter_name", help_text='患者id, 姓名')

    def filter_age(self, queryset, name, value):
        age = self.request.query_params['age']
        if '新生儿' in age:
            return queryset.filter(age_float__range=(0, 30))
        elif '婴儿' in age:
            return queryset.filter(age_float__range=(30, 365))
        elif '幼儿' in age:
            return queryset.filter(age_float__range=(365, 1095))
        elif '学前儿童' in age:
            return queryset.filter(age_float__range=(1095, 2190))
        elif '学龄儿童' in age:
            return queryset.filter(age_float__range=(2190, 4745))
        elif '青少年' in age:
            return queryset.filter(age_float__range=(4748, 6570))
        elif '全部年龄段' in age:
            return queryset

    def filter_name(self, queryset, name, value):
        name = self.request.query_params['name']
        if is_number(name):
            return queryset.filter(patient_id=name)
        else:
            return queryset.filter(name__contains=name)



    class Meta:
        model = MarkModel  # 关联的表
        fields = ["is_mark", 'age', 'start_date', 'end_data', 'name']  # 过滤的字段
