# -*- coding: utf-8 -*-
"""
@Time ： 2022/2/10 上午11:17
@Auth ： nhj
@File ：urls.py
"""

from django.urls import path

from mark.views import TestView, MarkListView, UserViewSet, UserAuthorizeView, UserLogoutView, MarkDetailView, WaveView, \
    InsertDataView, DownloadMarkView, MarkCompleteView, EegDataView, EegMarkListView, MarkStatusView

urlpatterns = [
    path('test', TestView.as_view()),
    # 脑电数据导入
    path('insert', InsertDataView.as_view()),
    # 导出标注
    path('download', DownloadMarkView.as_view()),
    # 标注
    path('mark', MarkListView.as_view({'get': 'list'})),
    path('mark/<pk>', MarkListView.as_view({'get': 'retrieve', 'put': 'update'})),
    path('mark_detail', MarkDetailView.as_view({'post': 'create', 'get': 'list'})),
    path('mark_detail/<pk>', MarkDetailView.as_view({'put': 'update', 'delete': 'destroy'})),
    path('mark_complete', MarkCompleteView.as_view()),
    path('mark_status', MarkStatusView.as_view()),
    # 波形
    path('wave', WaveView.as_view({'post': 'create', 'get': 'list'})),
    path('wave/<pk>', WaveView.as_view({'put': 'update', 'delete': 'destroy'})),

    # 用户
    path('users', UserViewSet.as_view({'get': 'list', 'post': 'create'})),
    path('users/<pk>', UserViewSet.as_view({'put': 'update', 'delete': 'destroy', 'get': 'retrieve'})),
    path('login', UserAuthorizeView.as_view()),
    path('logout', UserLogoutView.as_view()),

    # eeg data
    path('eeg_mark', EegMarkListView.as_view({'get': 'list'})),
    path('eeg_mark/<pk>', EegMarkListView.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'})),
    path('eeg_data', EegDataView.as_view()),
]