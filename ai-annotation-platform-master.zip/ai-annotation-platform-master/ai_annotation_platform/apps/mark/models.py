import uuid

from django.contrib.auth.base_user import AbstractBaseUser
from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser, PermissionsMixin
from django.db import models
from django.utils.translation import gettext_lazy as _
from utils.models import SpareFieldModel


class User(AbstractUser):
    staff_choices = (
        (0, '否'),
        (1, '是')
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    username = models.CharField(max_length=128, unique=True, error_messages={'unique': '用户账号已存在'}, verbose_name="用户名")
    password = models.CharField(_('password'), null=True, blank=True, max_length=128)
    real_name = models.CharField(max_length=128, null=True, blank=True, verbose_name="真实姓名")
    is_staff = models.SmallIntegerField(choices=staff_choices, verbose_name="是否管理员")
    is_active = models.BooleanField(null=True, blank=True, default=1, verbose_name="是否激活")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    last_login = models.DateTimeField(auto_now=True, verbose_name='最后登录时间')
    notes = models.CharField(max_length=128, null=True, blank=True, verbose_name="备注")

    class Meta:
        # 指明数据库表名
        db_table = 't_users'
        # 在admin站点中显示的名称
        verbose_name = '用户表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class MarkModel(SpareFieldModel):
    gender_choices = (
        (0, '男'),
        (1, '女')
    )
    mark_choices = (
        (0, '未标注'),
        (1, '标注中'),
        (2, '已标注')
    )
    download_choices = (
        (0, '点击下载'),
        (1, '下载中'),
        (2, '已下载')
    )
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    case_id = models.CharField(max_length=128, null=True, blank=True, verbose_name="病例id")  # json文件获取
    patient_id = models.CharField(max_length=128, null=True, blank=True, verbose_name="患者id")
    name = models.CharField(max_length=128, verbose_name="姓名")
    age = models.CharField(max_length=128, verbose_name="年龄")
    brith_data = models.DateField(null=True, blank=True, verbose_name='出生日期')
    age_float = models.FloatField(max_length=2, null=True, blank=True, verbose_name="年龄小数")
    gender = models.CharField(max_length=32, verbose_name="性别")
    check_date = models.DateTimeField(null=True, blank=True, verbose_name='检查日期')
    is_mark = models.SmallIntegerField(choices=mark_choices, null=True, blank=True, default=0, verbose_name="标注状态")
    mark_name = models.CharField(max_length=128, null=True, blank=True, verbose_name="标注人")
    mark_date = models.DateTimeField(auto_now=False, null=True, blank=True, verbose_name='标注时间')
    insert_data_date = models.DateTimeField(auto_now_add=True, null=True, blank=True, verbose_name='数据导入时间')
    is_download_file = models.SmallIntegerField(choices=download_choices, null=True, blank=True, default=0,
                                                verbose_name="下载状态")
    eeg_file_url = models.CharField(max_length=128, null=True, blank=True, verbose_name="文件url")
    notes = models.CharField(max_length=128, null=True, blank=True, verbose_name="备注")
    batch = models.IntegerField(null=True, blank=True, verbose_name='批次号')
    count_time = models.IntegerField(null=True, blank=True, verbose_name='总时长')
    is_eeg_data = models.IntegerField(null=True, blank=True, verbose_name='是否是web的列表')
    task_type = models.IntegerField(null=True, blank=True, verbose_name='任务类型(2:任务2， 3:任务3)')
    sub_task_type = models.IntegerField(null=True, blank=True, verbose_name='任务类型(1:失神， 2:痉挛)')

    class Meta:
        # 指明数据库表名
        db_table = 't_mark'
        # 在admin站点中显示的名称
        verbose_name = '标注列表'
        # 显示的复数名称
        verbose_name_plural = verbose_name
        ordering = ['task_type', 'sub_task_type']


class WaveModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    wave_name = models.CharField(max_length=128, unique=True, error_messages={'unique': '波形名称已存在'}, verbose_name="波形名称")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    notes = models.CharField(max_length=128, null=True, blank=True, verbose_name="备注")

    class Meta:
        # 指明数据库表名
        db_table = 't_wave'
        # 在admin站点中显示的名称
        verbose_name = '波形表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class MarkDetailModel(SpareFieldModel):
    id = models.CharField(max_length=36, primary_key=True, auto_created=True, default=uuid.uuid4, editable=False)
    mark = models.ForeignKey(MarkModel, on_delete=models.PROTECT, related_name='mark_detail_set', db_constraint=False)
    passageway = models.IntegerField(max_length=128, null=True, blank=True, verbose_name="通道号")
    passageway_name = models.CharField(max_length=128, null=True, blank=True, verbose_name="通道名称")
    start_point = models.FloatField(verbose_name="开始点")
    end_point = models.FloatField(verbose_name="结束点")
    dur_time = models.FloatField(null=True, blank=True, verbose_name="持续时长")
    wave = models.CharField(max_length=128, verbose_name="波形名称")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='添加时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    notes = models.CharField(max_length=128, null=True, blank=True, verbose_name="备注")

    class Meta:
        # 指明数据库表名
        db_table = 't_mark_detail'
        # 在admin站点中显示的名称
        verbose_name = '标注详情表'
        # 显示的复数名称
        verbose_name_plural = verbose_name
