from django.test import TestCase

# Create your tests here.
import os
import chardet  # 需要下载该模块


# def readFile(file_path):
#     with open(file_path, 'rb') as f:
#         cur_encoding = chardet.detect(f.read())['encoding']
#         print(cur_encoding)  # 当前文件编码
#
#     # 用获取的编码读取该文件而不是python3默认的utf-8读取。
#     with open(file_path, encoding=cur_encoding) as file:
#         fileData = file.read()
#         print(fileData)
#
#
# s = readFile('/home/nhj/下载/痉挛/1/NKT/EEG2100/DA1442QW.LOG')
#
# print()

import datetime

month_days = {
    1: 31,
    2: 28,
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
}


def is_leap_year(year):
    """
    判断是否闰年
    :param year:
    :return:
    """
    if year % 400 == 0 or year % 40 == 0 or year % 4 == 0:
        return True
    else:
        return False


def minus_result(nowadays, birthday, mode=False):
    y = nowadays.year - birthday.year
    m = nowadays.month - birthday.month
    d = nowadays.day - birthday.day
    if d < 0:
        if birthday.month == 2:
            if is_leap_year(birthday.year):
                month_days[2] = 29
        d += month_days[birthday.month]
        m -= 1
    if m < 0:
        m += 12
        y -= 1

    if mode is False:
        if y == 0:
            if m == 0:
                return f'{d}天'
            else:
                return f'{m}月{d}天'
        else:
            return f'{y}岁{m}月{d}天'
    else:
        return (nowadays - birthday).days


def calculate_age(year=None, month=None, day=None, mode=False):
    """
    获取年龄
    model=False 返回格式  年月日
    model=True 返回格式  出生总天数
    :param year: 出生年
    :param month: 出生月
    :param day: 出生日
    :param mode: 计算模式 True or False
    :return:
    """
    birthday = datetime.date(year, month, day)
    nowadays = datetime.date.today()
    return minus_result(nowadays, birthday, mode=mode)


def get_age_day(age_day_str):
    if '岁' in age_day_str:
        year = age_day_str.split('岁')[0]
        if '月' in age_day_str.split('岁')[1]:
            month = age_day_str.split('岁')[1].split('月')[0]
            return int(year) * 365 + int(month) * 30
        elif '小时' in age_day_str.split('岁')[1]:
            return int(year) * 365
        else:
            day = age_day_str.split('岁')[1].split('天')[0]
            return int(year) * 365 + int(day)
    elif '天' in age_day_str and '小时' in age_day_str:
        day = age_day_str.split('天')[0]
        return int(day)
    elif '月' in age_day_str and '小时' in age_day_str:
        month = age_day_str.split('月')[0]
        return int(month) * 30
    else:
        month = age_day_str.split('月')[0]
        day = age_day_str.split('月')[1].split('天')[0]
        return int(month) * 30 + int(day)

s = get_age_day('6月14小时')
print(s)