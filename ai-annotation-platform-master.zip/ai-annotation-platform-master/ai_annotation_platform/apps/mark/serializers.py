# -*- coding: utf-8 -*-
"""
@Time ： 2022/2/11 下午2:39
@Auth ： nhj
@File ：serializers.py
"""
import re

from rest_framework import serializers
from django_redis import get_redis_connection
from mark.models import MarkDetailModel, MarkModel, User, WaveModel
from django.conf import settings

redis_conn = get_redis_connection('login_user')


class MarkSerializer(serializers.ModelSerializer):
    patient_id = serializers.CharField(required=False)
    name = serializers.CharField(required=False)
    age = serializers.CharField(required=False)
    gender = serializers.CharField(required=False)
    check_date = serializers.DateTimeField(required=False, format="%Y年%m月%d日%H时%M分")
    is_mark = serializers.IntegerField(required=False)
    mark_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    mark_date = serializers.DateTimeField(required=False, format="%Y年%m月%d日%H时%M分")
    insert_data_date = serializers.DateTimeField(required=False, format="%Y年%m月%d日%H时%M分")
    is_download_file = serializers.IntegerField(required=False)
    eeg_file_url = serializers.CharField(required=False)
    case_id = serializers.CharField(required=False)
    spare_str1 = serializers.CharField(required=False, allow_null=True, allow_blank=True)

    class Meta:
        model = MarkModel
        fields = ('id', 'patient_id', 'name', 'age', 'gender', 'check_date', 'is_mark', 'mark_name', 'mark_date',
                  'insert_data_date', 'is_download_file', 'eeg_file_url', 'case_id', 'spare_str1', 'brith_data')


class MarkDetailSerializer(serializers.ModelSerializer):
    mark = serializers.CharField(source='mark_id', required=False)
    passageway = serializers.IntegerField(required=False)
    passageway_name = serializers.CharField(required=False)
    start_point = serializers.FloatField(required=False)
    end_point = serializers.FloatField(required=False)
    wave = serializers.CharField(allow_blank=True, required=False)
    dur_time = serializers.FloatField(required=False)
    create_time = serializers.DateTimeField(required=False)

    class Meta:
        model = MarkDetailModel
        fields = ('id', 'mark', 'passageway', 'passageway_name', 'start_point', 'end_point', 'wave', 'dur_time', 'create_time')


class WaveSerializer(serializers.ModelSerializer):
    create_time = serializers.DateTimeField(required=False, format="%Y-%m-%d %H:%M:%S")

    class Meta:
        model = WaveModel
        fields = ('id', 'wave_name', 'create_time')


# 用户部分
class UserListUpdateSerializer(serializers.ModelSerializer):
    is_staff = serializers.IntegerField(required=False)
    is_active = serializers.IntegerField(required=False)

    def validate(self, attrs):
        username = attrs.get("username", "")
        if username:
            detail = {"detail": "用户名不可修改"}
            raise serializers.ValidationError(detail)
        password = attrs.get('password', '')
        if password:
            if not re.match('[0-9A-Za-z]{6,12}$', password):
                detail = {'detail': '密码长度为6到12字符'}
                raise serializers.ValidationError(detail)
        return attrs

    def update(self, instance, validated_data):
        password = validated_data.get('password')
        if password:
            instance.set_password(password)
            validated_data['password'] = instance.password
            pc_login_key = redis_conn.keys('mark_user_' + str(instance.id) + '_' + '*')
            for user_key in pc_login_key:
                token_key = redis_conn.get(user_key)
                redis_conn.delete(token_key)
                redis_conn.delete(user_key)
        user = super(UserListUpdateSerializer, self).update(instance, validated_data)
        return user

    class Meta:
        model = User
        fields = [
            'id', 'username', 'password', 'real_name', 'is_staff', 'create_time', 'last_login', 'notes', 'is_active'
        ]

        extra_kwargs = {
            'read_only_fields': ['username', 'date_joined', 'user_num'],
            'username': {'required': False},
            'is_active': {'required': False},
            'real_name': {'required': False},
            'user_num': {'read_only': True},
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, 'required': False},
            'last_login': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, 'required': False},
            'password': {'write_only': True, 'required': False, 'error_messages': {'max_length': '密码长度为6到12位字符'}},
        }


class UserCreateSerializer(serializers.ModelSerializer):

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user

    def validate(self, attrs):
        is_staff = attrs.get('is_staff', '')
        if is_staff:
            is_staff = '1'
        else:
            is_staff = '0'
        # 用户名密码校验
        username = attrs.get('username', '')
        if username:
            if not re.match('[0-9A-Za-z]{1,20}$', username):
                raise serializers.ValidationError({'detail': '用户账号只能包含字母或数字且长度应不超过20位'})
        password = attrs.get('password', '')
        if password:
            if not re.match('[0-9A-Za-z]{6,12}$', password):
                detail = {'detail': '密码长度为6到12位字符'}
                raise serializers.ValidationError(detail)
        return attrs

    class Meta:
        model = User
        fields = [
            'id', 'username', 'password', 'real_name', 'is_active', 'is_staff', 'create_time', 'last_login', 'notes'
        ]
        extra_kwargs = {
            'password': {'write_only': True,'error_messages': {'max_length': '密码长度为6到12位字符'}},
        }


class EegMarkSerializer(serializers.ModelSerializer):
    patient_id = serializers.CharField(required=False)
    name = serializers.CharField(required=False)
    age = serializers.CharField(required=False)
    gender = serializers.CharField(required=False)
    check_date = serializers.DateTimeField(required=False, format="%Y-%m-%d %H:%M:%S")
    is_mark = serializers.IntegerField(required=False)
    mark_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    mark_date = serializers.DateTimeField(required=False, format="%Y-%m-%d %H:%M:%S")
    insert_data_date = serializers.DateTimeField(required=False, format="%Y-%m-%d %H:%M:%S")
    is_download_file = serializers.IntegerField(required=False)
    eeg_file_url = serializers.CharField(required=False)
    case_id = serializers.CharField(required=False)
    spare_str1 = serializers.CharField(required=False, allow_null=True, allow_blank=True)

    class Meta:
        model = MarkModel
        fields = ('id', 'patient_id', 'name', 'age', 'gender', 'check_date', 'is_mark', 'mark_name', 'mark_date',
                  'insert_data_date', 'is_download_file', 'eeg_file_url', 'case_id', 'spare_str1', 'count_time',
                  'is_eeg_data', 'brith_data', 'task_type', 'sub_task_type')

