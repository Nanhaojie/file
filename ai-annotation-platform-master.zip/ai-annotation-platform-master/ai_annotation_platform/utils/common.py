#!/usr/bin/env python
# _*_coding:utf-8_*_
# @Time:2021/12/9上午10:56
# @Author:zwz
import base64
import datetime
import hashlib
import io
import json
import logging

import pytz
import qrcode
import requests
from django.conf import settings
from django_celery_beat.models import CrontabSchedule, PeriodicTask, IntervalSchedule, ClockedSchedule
from django_redis import get_redis_connection
from qiniu import Auth, put_data

logger = logging.getLogger('django')
redis_conn = get_redis_connection('login_user')


def code_2_session(code, AppID, AppSecret):
    url = f"https://api.weixin.qq.com/sns/jscode2session?appid={AppID}&secret={AppSecret}&js_code={code}&grant_type=authorization_code"
    try:
        resp = requests.get(url).json()
    except ConnectionError:
        return '', '', '', ''
    logger.info("登录接口返回数据：" + json.dumps(resp))
    errcode = resp.get('errcode')
    openid = resp.get('openid')
    unionid = resp.get('unionid')
    session_key = resp.get('session_key')
    return errcode, openid, unionid, session_key





def check_sign(rawData, session_key, signature):
    '''
    :param rawData:
    :param session_key:
    :param signature:
    :return:
    '''
    signature1 = hashlib.sha1((rawData + session_key).encode('utf-8')).hexdigest()
    if signature == signature1:
        return True
    else:
        return False


def qiniu_upload_base64(base64_data, file_name=None):
    """图片上传七牛云"""
    access_key = settings.QN_ACCESS_KEY
    secret_key = settings.QN_SECRET_KEY
    # 要上传的空间
    bucket_name = settings.BUCKET_QINIU
    # 构建鉴权对象
    q = Auth(access_key, secret_key)
    # 生成上传 Token，可以指定过期时间等
    token = q.upload_token(bucket_name)
    key = 'kuner/long_follow_up/applet/' + file_name
    byte_data = base64.b64decode(base64_data)
    ret, info = put_data(token, key, byte_data)
    if info and info.status_code != 200:
        logger.error("上传文件到七牛失败, 失败状态码为{}， 原因为{}".format(info.status_code, info.text_body))
        raise Exception("上传七牛失败")
    return settings.DOMIN_QINIU + ret['key']


def common_upload(file_data, file_name=None):
    """图片上传七牛云 通用方法"""
    access_key = settings.QN_ACCESS_KEY
    secret_key = settings.QN_SECRET_KEY
    # 要上传的空间
    bucket_name = settings.BUCKET_QINIU
    # 构建鉴权对象
    q = Auth(access_key, secret_key)
    # 生成上传 Token，可以指定过期时间等
    token = q.upload_token(bucket_name)

    sha1 = hashlib.sha1()
    sha1.update(file_data)
    key = file_name or 'kuner/long_follow_up/applet/' + sha1.hexdigest()

    ret, info = put_data(token, key, file_data)
    if info and info.status_code != 200:
        logger.error("上传文件到七牛失败, 失败状态码为{}， 原因为{}".format(info.status_code, info.text_body))
        raise Exception("上传七牛失败")
    return settings.DOMIN_QINIU + ret['key']


def gen_qrcode(data):
    """
    方式1： URL转换二维码
    :param data: 转换二维码的数据
    :return:  base64编码后的 二进制流 二维码数据
    """
    qr = qrcode.make(data)
    buf = io.BytesIO()
    qr.save(buf)
    img_buf = buf.getvalue()
    return img_buf


# 添加药物提醒
def add_medication_remind_timing(time_list, patient_id, patient_name, open_id):
    for time in time_list:
        hour = int(time.split(':')[0])
        minute = int(time.split(':')[1])
        real_time = datetime.datetime(2000, 1, 1, hour, minute) - datetime.timedelta(
            minutes=settings.MEDICATION_AHEAD_OF_TIME)
        real_hour = real_time.hour
        real_minute = real_time.minute

        # 构造推送微信消息
        remind_msg_data = {
            "touser": open_id,
            "template_id": settings.MEDICATION_REMINDER_TEM_ID,
            "page": settings.MINE_PAGE_PATH,
            "miniprogram_state": settings.MINIPROGRAM_STATE,
            "lang": "zh_CN",
            "data": {
                # 就诊人
                "name1": {"value": patient_name[:10]},
                # 服药时间
                "time2": {
                    "value": time
                },
                # 提示说明
                "thing4": {"value": settings.MEDICATION_NOTICE_CONTENT}
            }
        }
        data = {
            'patient_id': patient_id,
            'patient_name': patient_name,
            'open_id': open_id,
            'remind_time': time,
            'remind_msg_data': remind_msg_data
        }
        schedule, _ = CrontabSchedule.objects.update_or_create(
            minute=str(real_minute),
            hour=str(real_hour),
            timezone=pytz.timezone('Asia/Shanghai')
        )
        PeriodicTask.objects.update_or_create(
            defaults={
                'crontab': schedule,
                'task': 'celery_tasks.patient.tasks.medication_remind',
                'kwargs': json.dumps(data, ensure_ascii=False)
            },
            name='medication_' + patient_id + '_' + time
        )
    return True


def remove_medication_remind_timing(time_list, patient_id):
    name_list = []
    for time in time_list:
        name_list.append('medication_' + patient_id + '_' + time)
    PeriodicTask.objects.filter(name__in=name_list).delete()
    return True

# 添加复诊提醒
def add_subsequent_visit(open_id, clock_datetime:datetime, patient_id, patient_name):
    # 复诊时间
    subsequent_visit_date = clock_datetime + datetime.timedelta(days=1)
    subsequent_visit_date_str = datetime.datetime.strftime(subsequent_visit_date, '%Y年%m月%d日')
    # 构造推送微信消息
    remind_msg_data = {
        "touser": open_id,
        "template_id": settings.SUBSEQUENT_VISIT_TEM_ID,
        "page": settings.MINE_PAGE_PATH,
        "miniprogram_state": settings.MINIPROGRAM_STATE,
        "lang": "zh_CN",
        "data": {
            # 温馨提醒
            "thing1": {"value": settings.DOCTOR_ADVICE_NOTICE_CONTENT},
            # 就诊人
            "phrase2": {
                "value": patient_name[:5]
            },
            # 复诊时间
            "date5": {
                "value": subsequent_visit_date_str
            },
            # 备注
            "thing6": {"value": settings.NOTES}
        }
    }
    clock_datetime = clock_datetime - datetime.timedelta(hours=8)
    clock, _ = ClockedSchedule.objects.update_or_create(clocked_time=clock_datetime)
    PeriodicTask.objects.filter(name='set_subsequent_visit' + patient_id).delete()
    PeriodicTask.objects.update_or_create(
        defaults={
            'clocked': clock,
            'one_off': True,
            'enabled': True,
            'task': 'celery_tasks.patient.tasks.subsequent_visit',
            'kwargs': json.dumps(remind_msg_data, ensure_ascii=False)
        },
        name='set_subsequent_visit' + patient_id
    )
    return True


def update_access_token():
    schedule, _ = IntervalSchedule.objects.update_or_create(every=60, period=IntervalSchedule.MINUTES)
    PeriodicTask.objects.update_or_create(
        defaults={
            "interval": schedule,  # 上面创建10分钟的间隔 interval 对象
            "task": "celery_tasks.patient.tasks.set_access_token",  # 指定需要周期性执行的任务
        },
        name="set_access_token",
    )


def set_access_token():
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={settings.APPID}&secret={settings.APPSECRET}"
    resp = requests.get(url).json()
    access_token = resp.get('access_token')
    # long_follow_up_access_token = redis_conn.get('long_follow_up_access_token').decode()
    if access_token:
        redis_conn.set('long_follow_up_access_token', access_token, 60 * 60 * 2)


def get_eeg_data(start_offset, time_length, eeg_test_id, test_time):
    url = f"http://172.16.1.10:8031/api/v1/eeg_report/eeg_analyse/mark_detail?start_offset={start_offset}&time_length={time_length}&eeg_test_id={eeg_test_id}&test_time={test_time}"
    res = requests.get(url).json()
    return res['data']
