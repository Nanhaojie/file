import os
import uuid
from pathlib import Path
import chardet
import re
import json
import pymysql
import time
from datetime import datetime

# from django.c.settings import DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_DATABASE
from django.conf import settings

BASE_DIR = Path(__file__).resolve().parent


class Database():
    def __init__(self):
        self.conn = pymysql.connect(host='172.16.1.10', port=3309, user='root', passwd='root12300.',
                                    db='ai_annotation_platform')

    def assemble_sql(self, table, fields, values, action):
        """
        table: str-> table name
        fields: str-> (field_name1, field_name2, ...)
        values: list-> [(value1, value2,...), ...]
        action: str-> insert or select or update
        return
        """
        if action == 'insert':
            sql = str()
            if fields and values:
                fields = fields.replace("'", '')
                v = [str(line) for line in values]
                vl = ','.join(v)
                sql = 'INSERT INTO ' + table + ' ' + fields + ' VALUES ' + vl
                return sql
        elif action == 'select':
            # sql = "select 'passageway', 'passageway_name', 'start_point', 'end_point', 'wave_name' from " + table + "wher"
            sql = '''
            select t.eeg_file_url, t.age, t.gender, tmd.passageway, tmd.passageway_name, tmd.start_point, tmd.end_point, tmd.wave_name
from t_mark t inner join
(select t1.mark_id, t1.passageway, t1.passageway_name, t1.start_point, t1.end_point, tw.wave_name from t_mark_detail t1 left join t_wave tw on t1.wave_id = tw.id
    where t1.mark_id='0010f177-ff12-4bfe-ae36-87ae1708ac9f') tmd
on t.id = tmd.mark_id;
            '''
            return sql

    def exec_sql(self, sql_txt):
        """
        table: str-> table name
        fields_values: tuple-> (field_name, field_value) wait?
        """
        with self.conn.cursor() as cursor:
            cursor.execute(sql_txt)
            rst = cursor.fetchall()
            self.conn.commit()

    def select_sql(self, sql_txt):
        """
        table: str-> table name
        fields_values: tuple-> (field_name, field_value) wait?
        """
        with self.conn.cursor() as cursor:
            cursor.execute(sql_txt)
            rst = cursor.fetchall()
            return rst

    def download(self, mark_ids):
        sqls = []
        for mark_id in mark_ids:
            sql = '''select t.case_id, t.eeg_file_url, t.age, t.gender, t1.passageway, t1.passageway_name, t1.start_point, t1.end_point, t1.wave, t1.dur_time
from t_mark t inner join t_mark_detail t1 on t.id = t1.mark_id where t1.mark_id=''' + "'" + mark_id + "';"
            sqls.append(sql)
        return sqls

    def __exit__(self):
        self.conn.close()


database = Database()


def get_age(check_date, birthday):
    # 本函数根据输入的8位出生年月日数据返回截至当天的年龄
    today = str(check_date).split("-")
    brith = str(birthday).split("/")
    # 取出系统当天的年月日数据为列表[年,月,日]
    n_month = today[1]
    # 将月日连接在一起
    n_year = today[0]
    # 单独列出当年年份
    r_month = brith[1]
    # 取出输入日期的月与日
    r_year = brith[0]
    # 取出输入日期的年份
    if int(n_month) >= int(r_month):
        r_age = int(n_year) - int(r_year)
        return r_age + (int(n_month) - int(r_month)) / 10
    else:
        r_age = int(n_year) - int(r_year) - 1
        return r_age + (int(r_month) - int(n_month)) / 10


def get_data(path):
    # path = r'F:/失神/NKT/EEG2100/DA1222AM.PNT'
    f = open(path, 'rb')  # 先用二进制打开
    data = f.read()  # 读取文件内容
    file_encoding = chardet.detect(data).get('encoding')  # 得到文件的编码格式
    with open(path, 'r', encoding=file_encoding) as file:  # 使用得到的文件编码格式打开文件
        try:
            lines = file.readlines()
        except:
            return None
        # for line in lines:
        # print(len(lines))
        ID = lines[2].split('ID')[1][:16]
    return ID


def get_dict(roots):
    dict = {}
    cnt = 0
    for root in roots:
        pntlist = os.listdir(root)
        p = re.compile('D[\d]*')
        for pnt in pntlist:
            ID = get_data(os.path.join(root, pnt))
            if not ID:
                cnt += 1
            else:
                ID = p.findall(ID)
                print(ID)
                if ID:
                    if len(ID) == 1:
                        ID = ID[0]
                        if ID not in dict.keys():
                            dict[ID] = [pnt]
                        else:
                            dict[ID].append(pnt)
    print(dict)
    return dict


def get_valid_IDS_date(paths):
    patient_ids = []
    eeg_ids = []
    names = []
    ages = []
    genders = []
    check_dates = []
    brith_datas = []
    age_ints = []
    for path in paths:
        with open(path) as file:
            lines = file.readlines()
            for line in lines[1:]:
                data = line.split('\t')
                # values = [data[8], data[0], data[3], data[1], data[2]]
                try:
                    eeg_ids.append(data[8].replace("\n", ""))
                    names.append(data[0])
                    genders.append(data[1])
                    ages.append(data[3])
                    br = datetime.strptime(data[5], "%Y-%m-%d %H时%M分").strftime("%Y-%m-%d %H:%M:%S")
                    check_dates.append(br)
                    patient_ids.append(data[4])
                    brith_datas.append('2010/5/24')
                    # age_ints.append(get_age(br, data[2]))
                    age_ints.append(1)
                except Exception as e:
                    print(data)
    return [eeg_ids, names, ages, genders, check_dates, patient_ids, brith_datas, age_ints]


def write_dict(path, dict):
    with open(path, 'w', encoding='utf-8') as jf:
        jf.write(json.dumps(dict, ensure_ascii=False))


def main_fun(file_txt_path, file_json_path, batch):
    file_txt_path = os.path.join(BASE_DIR, file_txt_path)
    file_json_path = os.path.join(BASE_DIR, file_json_path)
    valid = get_valid_IDS_date([file_txt_path])

    with open(file_json_path, 'r') as f:
        dicts = json.load(f)
    for k in list(dicts.keys()):
        if k not in valid[0]:
            del dicts[k]
        else:
            for case_file in dicts[k]:
                values = tuple([str(uuid.uuid4()), valid[0][valid[0].index(k)], valid[1][valid[0].index(k)],
                                valid[2][valid[0].index(k)], valid[3][valid[0].index(k)], valid[4][valid[0].index(k)],
                                str(case_file), 0, time.strftime("%Y-%m-%d %H:%M"), 0, valid[5][valid[0].index(k)],
                                valid[6][valid[0].index(k)], valid[7][valid[0].index(k)], batch])
                sql = database.assemble_sql('t_mark', str(tuple(['id', 'case_id', 'name', 'age', 'gender', 'check_date',
                                                                 'eeg_file_url', 'is_mark', 'insert_data_date',
                                                                 'is_download_file', 'patient_id', 'brith_data',
                                                                 'age_float', 'batch'])), [values], 'insert')
                database.exec_sql(sql)

    # with open('valid.txt', 'w') as txt:
    #     for v in dicts.values():
    #         if v[1].split('-')[0] == '2020':
    #             if v[1].split('-')[1] in ['01', '02', '03']:
    #                 prefixs = '2020_01-2020_03/'
    #             elif v[1].split('-')[1] in ['04', '05', '06']:
    #                 prefixs = '2020_04-2020_06/'
    #             elif v[1].split('-')[1] in ['07', '08', '09']:
    #                 prefixs = '2020_07-2020_09/'
    #             elif v[1].split('-')[1] in ['10', '11', '12']:
    #                 prefixs = '2020_10-2020_12/'
    #         elif v[1].split('-')[0] == '2021':
    #             if v[1].split('-')[1] in ['01', '02', '03']:
    #                 prefixs = '2021_01-2021_03/'
    #             elif v[1].split('-')[1] in ['04', '05', '06']:
    #                 prefixs = '2021_04-2021_06/'
    #
    #         for va in v[0]:
    #             txt.write('copy H:/' + prefixs + 'NKT/EEG2100/' + va[:-4] + '** D:/DDD/NKT/EEG2100' + '\n')
    # write_dict('valid.json', dicts)


def download_data(data_save_path, mark_ids):
    select_sqls = database.download(mark_ids)
    try:
        for select_sql in select_sqls:
            mark_data = database.select_sql(select_sql)
            if not mark_data:
                return 2
            mark_data_json = dict()
            mark_dicts = []
            for i in mark_data:
                mark_dict = {'case_id': i[0], 'eeg_file_url': i[1], 'age': i[2], 'gender': i[3], 'passageway': i[4],
                             'passageway_name': i[5],
                             'start_point': i[6], 'end_point': i[7], 'wave': i[8], 'dur_time': i[9]}
                mark_dicts.append(mark_dict)
            mark_data_json['data'] = mark_dicts
            write_dict(data_save_path + i[0] + '_' + i[1].split('.')[0] + '.json', mark_data_json)
        return 1
    except:
        return 0


if __name__ == '__main__':
    # root = ['/Users/destination/Downloads/PNT2020_10/PNT', '/Users/destination/Downloads/PNT2020_10/PNT2020_10']
    # root = ['/Users/destination/Downloads/1-1']
    # dict = get_dict(root)
    # write_dict('/Users/destination/Downloads/teen.json',dict)

    main_fun('shishen_test.txt', 'shishenxin_txt.json', 1)
    # download_data('/home/nhj/json/', ['000bfffd-25ca-495c-805d-c426778f2954', '0010f177-ff12-4bfe-ae36-87ae1708ac9f'])
    # with open('/Users/destination/Downloads/all.json','r') as f:
    #     dict= json.load(f)
    # with open('/Users/destination/Downloads/2021.json','r') as f2:
    #     dict2= json.load(f2)
    # d = {}
    # # a = dict.keys()&dict2.keys()
    # d.update(dict)
    # d.update(dict2)
    # write_dict('/Users/destination/Downloads/all2020-2021.json', d)
