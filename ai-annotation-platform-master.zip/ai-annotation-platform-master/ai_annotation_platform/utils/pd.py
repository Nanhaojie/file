#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed May 20 14:43:50 2020

@author: liudan
"""

import mne
from scipy.fftpack import fft,ifft
import numpy as np
# import matplotlib.pyploy as plt
import matplotlib.pyplot as plt
import mpl_toolkits.axisartist as axisartist
# from matplotlib import MultipleLocator
from matplotlib.ticker import MultipleLocator
# 从eeg文件读取脑电数据
import os
import json
import time
s = time.time()


raw = mne.io.read_raw_nihon('/run/user/1000/gvfs/ftp:host=172.28.81.171,port=2121/下载/痉挛/1/NKT/EEG2100/DA1442QW.EEG', preload=False)
print('-------------', time.time()-s)
data,times=raw[:]

for i in range(2):
    plt.plot(data[i])
    plt.show()
# rawDataGDF = mne.io.read_raw_nihon("/home/liudan/ld/AI/EEG/EEG/脑电数据/NKT/EEG2100/DA65443X.EEG",preload=True)
# rawDataGDF.plot()
# raw.plot(duration=5, n_channels=35, clipping=None)
# plt.title('EEG波形')
# plt.show()
# exit()

# data_1=data[:,600000:601000]
# data_json={}
# json_str = json.dumps(data_1.tolist())
# with open('./liudan_11.json', 'w') as f:
#    f.write(json_str)

# 获取原始数据中事件
mne_description=raw.annotations.description
print(mne_description)
mne_time_array=raw.annotations.onset
print(mne_time_array)
data,times=raw[:]
epilepsy_array=[]
len_avg=0
len=0
num_epilepsy=0  #


for i_epilepsy, description in enumerate(mne_description):
    if description=='发作':
        start_time=mne_time_array[i_epilepsy]
        end_time=mne_time_array[i_epilepsy+1]
        data_epilepsy=data[:,int(start_time)*1000:int(end_time)*1000]
        data_json={}
        json_str = json.dumps(data_epilepsy.tolist())
        # with open('./liudan_1.json', 'w') as f:
        #    f.write(json_str)

        plt.title('Result Analysis')
        x_axix = np.linspace(1, data_epilepsy[0].shape[0], data_epilepsy[0].shape[0])

        #-----------plt画图-------------
        # for i in range(30):
        #     label='data'+str(i)
        #     plt.plot(x_axix, data_epilepsy[i]+0.005*i, color='green', label=label)
        #     # plt.plot(sub_axix, test_acys, color='red', label='testing accuracy')
        #     # plt.plot(x_axix, train_pn_dis, color='skyblue', label='PN distance')
        #     # plt.plot(x_axix, thresholds, color='blue', label='threshold')
        # plt.legend()  # 显示图例
        # # plt.xlabel('iteration times')
        # # plt.ylabel('rate')
        # plt.show()
        # print('22222222222222')
        exit()
        # data_1, times_1 = raw[picks, t_idx[0]:t_idx[1]]
        plt.plot(data_epilepsy)
        plt.title('EEG波形')
        plt.show()
        epilepsy_array.append(data_epilepsy)
        len=len+(end_time-start_time)
        num_epilepsy=num_epilepsy+1
# len_avg=len/num_epilepsy
# for data_epilepsy in epilepsy_array:
#     # data_epilepsy.plot(n_channels=35,
#     #                 title='Data from arrays',
#     #                 show=True, block=True)
#     for i in range(35):
#         data_chnnel=data_epilepsy[i]
#         xax=np.array(range(data_chnnel.shape[0]))
#         plt.plot(data_chnnel)
#         plt.title(str(i))
        # plt.show()
    # plt.plot(data_epilepsy)
    # plt.title('EEG波形')
# coding:utf-8

#-------
import csv

# f = open('ce1.csv','w')
# import pandas
# writer = pandas.tocsv.writer(f)
#
# for epilepsy_array_dex in epilepsy_array:
#     writer.writerow(1)
#     for i in epilepsy_array_dex:
#         writer.writerow(i)
# f.close()

#
# data,times=raw[:]
# d=data[0]
# fft_y=fft(data[0])
# abs_y = np.abs(fft_y)  # 取复数的绝对值，即复数的模(双边频谱)
# angle_y = np.angle(fft_y)  # 取复数的角度
# # x=len(abs_y)
# abs_y_1=abs_y[0:1000]
# plt.figure()
# plt.plot(abs_y)
# plt.show()
# # if True:
#     z = fft(d)
#     xax = np.array(range(len(d)))*raw.info['sfreq']/len(d)
#     # print(np.max(np.abs(z)))
#
#     # plt.subplot(231)
#     plt.plot(xax, z)
#     plt.title('原始波形')
#
#     plt.show()
#     print(d)
# # exit()
# # # plt.title('双边振幅谱（未归一化）')
# # #
# # # plt.figure()
# # # plt.plot(x, angle_y)
# # # plt.title('双边相位谱（未归一化）')
# # # plt.show()
# #
# # print(raw.info) #读取有用的头信息
# # picks = mne.pick_types(raw.info, meg=True, exclude='bads')
# # t_idx = raw.time_as_index([10., 20.])
# # data, times = raw[picks, t_idx[0]:t_idx[1]]
# # plt.plot(times,data.T)
# # plt.title("Sample channels")
#
# # 查看原始edf文件中保存的event id以及events
# events_from_annot, event_dict = mne.events_from_annotations(raw)
# print(event_dict)
# print(events_from_annot)
# # 绘制事件图
# fig = mne.viz.plot_events(events_from_annot, sfreq=raw.info['sfreq'],
#                           first_samp=raw.first_samp, event_id=event_dict)
# fig.subplots_adjust(right=0.7)

# tmin = 651 - 5
# tmax = 651 + 5
# # chans = ["POL G9", "POL G5", "POL G4", "POL G2", "POL G3", "POL H3", "POL G7", "POL G8", "POL G6", "POL H1"]
# chans = ["EEG FP1-REF", "EEG FP2-REF", "EEG F3-REF"]
# selection = raw.crop(tmin, tmax)
# selection = selection.pick_channels(all)
#
# sl = selection[:, :]  # 抽取为array格式
# offset = np.arange(0, 10 * 0.002, 0.002)
# x = sl[1]  # x轴数据
# y = sl[0].T + offset  # y轴数据
#
# ylabel = ['$G2$', '$G3$', '$G4$', '$G5$', '$G6$', '$G7$', '$G8$', '$G9$', '$H1$', '$H3$']  # y轴刻度的名称
# fig = plt.figure()
# ax = axisartist.Subplot(fig, 111)
# fig.add_axes(ax)
# ax.axis["left"].set_axisline_style("->", size=1.5)  # 设置y轴样式为->箭头
# ax.axis["bottom"].set_axisline_style("->", size=1.5)  # 设置x轴样式为->箭头
# ax.axis["top"].set_visible(False)  # 隐藏上面的轴
# ax.axis["right"].set_visible(False)  # 隐藏右侧的轴
# x_major_locator = MultipleLocator(1)  # 设置刻度间距为1
# ax.xaxis.set_major_locator(x_major_locator)
# plt.yticks(offset.tolist(), ylabel)  # 修改y轴刻度的名称
# plt.xlabel("Time(s)")
# plt.ylabel("Channels")
# plt.axvline(5, linestyle="dotted", color='k')  # 在x=5的地方画垂直点状线
# plt.text(5.17, 0.02, "Seizure")  # 在x=5.17,y=0.02处写上Seizure字样
# plt.plot(x, y, '-k', linewidth=0.5)  # 设置线条颜色、宽度
#
# plt.show()