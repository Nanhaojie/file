import jwt
import hashlib

from rest_framework_jwt.authentication import JSONWebTokenAuthentication, jwt_decode_handler
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework_jwt.settings import api_settings
from django_redis import get_redis_connection
from django.conf import settings
from mark.models import User

redis_conn = get_redis_connection('login_user')

class SlideTokenAuthentication(JSONWebTokenAuthentication):

    def authenticate(self, request):
        """
        Returns a two-tuple of `User` and token if a valid signature has been
        supplied using JWT-based authentication.  Otherwise returns `None`.
        """

        jwt_key = self.get_jwt_value(request)
        if jwt_key is None:
            return None
        user_info = redis_conn.get(jwt_key)
        # 没有user_info 说明已经被挤掉或者登录超时
        if not user_info:
            msg = _('Signature has expired.')
            raise exceptions.AuthenticationFailed(msg)
        user_info = eval(redis_conn.get(jwt_key))
        jwt_value = user_info['token']
        try:
            payload = jwt_decode_handler(jwt_value)
        except jwt.ExpiredSignature:
            user = User.objects.filter(id=user_info['user_id']).first()
            if not user:
                msg = _('用户不存在')
                raise exceptions.AuthenticationFailed(msg)
            jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
            jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
            payload = jwt_payload_handler(user)
            token = jwt_encode_handler(payload)
            val = {"token": token, "username": user.username, "user_id": user.id}
            HTTP_SIGN = request.META.get('HTTP_SIGN')
            if HTTP_SIGN == 'Android' or HTTP_SIGN == 'ios':
                redis_conn.set(jwt_key, str(val), settings.APP_EXP_SECOND)
                redis_conn.set('app_login_user_' + str(user.id), jwt_key, settings.APP_EXP_SECOND)
            else:
                redis_conn.set(jwt_key, str(val), settings.PC_EXP_SECOND)
                redis_conn.set('pc_login_user_' + str(user.id) + '_' + str(jwt_key, encoding='utf-8'), jwt_key, settings.PC_EXP_SECOND)
            return (user, token)
        except jwt.DecodeError:
            msg = _('Error decoding signature.')
            raise exceptions.AuthenticationFailed(msg)
        except jwt.InvalidTokenError:
            raise exceptions.AuthenticationFailed()

        user = self.authenticate_credentials(payload)

        return (user, jwt_value)