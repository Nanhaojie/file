# -*- coding: utf-8 -*-
"""
@Time ： 2022/2/10 下午6:10
@Auth ： nhj
@File ：ftp_client.py
"""
from ftplib import FTP
import os
import time
import mne


class MyFtp:
    ftp = FTP()

    def __init__(self, host, port=2121):
        self.ftp.connect(host, port)

    def login(self, username, pwd):
        self.ftp.set_debuglevel(2)  # 打开调试级别2，显示详细信息
        self.ftp.login(username, pwd)
        files = self.ftp.dir()
        print(self.ftp.welcome)

    def downloadFile(self, localpath, remotepath, filename):
        os.chdir(localpath)  # 切换工作路径到下载目录
        self.ftp.cwd(remotepath)  # 要登录的ftp目录
        self.ftp.nlst()  # 获取目录下的文件
        file_handle = open(filename, "wb").write  # 以写模式在本地打开文件
        raw = mne.io.read_raw_nihon(self.ftp.retrlines('RETR %s' % os.path.basename(filename)), preload=False)
        print(raw)
        self.ftp.retrbinary('RETR %s' % os.path.basename(filename), file_handle, blocksize=1024)  # 下载ftp文件
        # ftp.delete（filename）  # 删除ftp服务器上的文件

    def close(self):
        self.ftp.set_debuglevel(0)  # 关闭调试
        self.ftp.quit()


if __name__ == '__main__':
    ftp = MyFtp('172.28.81.171')
    ftp.login('user', '12345')
    s = time.time()
    ftp.downloadFile('/home/nhj/', 'software/', 'test.txt')
    ftp.close()
    print('===', time.time()-s)
