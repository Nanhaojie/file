AI模型单独对外提服务

```
部署
服务器：172.16.1.10
项目路径：/root/ddy

环境：
    docker run -itd  -p 8088:8088 -p 8089:8089  --name ddy_web_api -v  /root/ddy:/root/ddy   python:3.6

celery -A celery_tasks.main worker -l INFO &>celery.log &

daphne application_api.asgi:application -b 127.0.0.1 -p 8000 &>manage.log &


```
