# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/21
# @author fj
import asyncio
import hashlib
import logging
import datetime
import string
from urllib import parse

import redis_lock
import urllib.request
import filetype

import aiohttp
from django.conf import settings
from django.dispatch import Signal, receiver
from django_redis import get_redis_connection
from django.http import HttpRequest
from django.utils.deprecation import MiddlewareMixin
from rest_framework.authentication import SessionAuthentication
from qiniu import Auth, put_data
import requests
from user.models import LogModel
import json

logger = logging.getLogger("django")
event_list = ["登录", "用户列表查询", "用户信息修改", "用户详情查询", "用户创建", "个人详情查询", "个人信息修改", "文件列表查询",
              "文件名查询", "文件列表查询", "文件删除", "新建文件/文件夹", "文件修改", "文件OCR", "取消识别", "Android取消识别",
              "ocr效果图查询", "识别结果更新", "导出识别结果", "批量导出识别结果", "批量文件下载", "用户目录查询", "获取校验字段列表",
              "获取校对字段对应内容", "修改个人密码", "首页文件信息", "获取OCR状态", "获取识别状态",
              "移动文件", "文件批量上传", "安卓端开始识别", "安卓端ocr结果入库", "安卓端提交识别", "所有用户根目录", "用户退出", "移动端获取子目录",
              "获取工程信息", "首页上传文件统计", "首页用户上传排行", "首页识别信息统计"]

request_finished_custom = Signal(providing_args=["request"])

conn = get_redis_connection('default')
redis_lock.reset_all(conn)
lock = redis_lock.Lock(conn, 'num_lock')


def get_user_ip(request):
    """获得登录用户的IP地址"""
    if 'HTTP_X_FORWARDED_FOR' in request.META.keys():
        return request.META['HTTP_X_FORWARDED_FOR']
    else:
        return request.META['REMOTE_ADDR']


@receiver(request_finished_custom)
def record_event(sender, **kwargs):
    request = kwargs.get("request")
    # 获取请求的参数
    post_params = request.POST.dict() if request.POST.dict() else request.data
    if post_params:
        try:
            del post_params['password']
        except:
            pass
        try:
            del post_params['new_password']
        except:
            pass
    get_params = request.GET.dict()
    req_path = f"{request.method}: {request.path}"
    # content字段的拼接
    detail = f"请求方式：{request.method}，地址：{request.path}，参数：{{'query_params':{get_params}, 'body':{post_params}}};" \
             f"{json.dumps(request.data)}"
    # 保存入数据库
    try:
        LogModel.objects.create(user_id=request.user.id, notes=detail[:1000], ip=get_user_ip(request), path=req_path,
                                event_id=event_list.index(sender), company_id=request.user.company_id)
    except Exception:
        logger.warning('用户操作日志保存失败', exc_info=True)


class CsrfExemptSessionAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return


def zj_upload_sync(file, path='ddy'):
    files = {'file': file}
    options = {'path': path, 'scene': ''}  # 参阅浏览器上传的选项
    return requests.post(settings.FILE_SERVER_URL + settings.FILE_SERVER_UPLOAD_PATH, data=options, files=files,
                         timeout=90).text


async def zj_upload_async(file, path='ddy'):
    data = aiohttp.FormData()
    data.add_field('file', file, content_type='multipart/form-data')
    data.add_field('path', path)
    async with aiohttp.ClientSession() as client:
        async with client.post(settings.FILE_SERVER_URL + settings.FILE_SERVER_UPLOAD_PATH, data=data,
                               timeout=15) as resp:
            img_url = await resp.text()
            return img_url


def get_img(url):
    resp = requests.get(url)
    img = resp.content
    return img


def get_user_num(is_admin='0'):
    _now = datetime.datetime.now()
    year = _now.year
    month = _now.month
    day = _now.day
    while True:
        if lock.acquire(blocking=False):
            user_num_serial = conn.get('user_num_serial')
            if not user_num_serial:
                user_num = str(year)[2:].zfill(2) + str(month).zfill(2) + str(day).zfill(2) + is_admin + '1'.zfill(3)
                conn.set('user_num_serial', '1')
            else:
                user_num_serial = str(int(user_num_serial) + 1)
                user_num = str(year)[2:].zfill(2) + str(month).zfill(2) + str(day).zfill(
                    2) + is_admin + user_num_serial.zfill(3)
                conn.set('user_num_serial', user_num_serial)
            conn.expireat('user_num_serial',
                          datetime.datetime.strptime(str(year) + str(month).zfill(2) + str(day).zfill(2) + ' 23:59:59',
                                                     '%Y%m%d %H:%M:%S'))
            lock.release()
            break

    return user_num


# 根据文件名校验文件类型
def verify_file_type(url, type):
    type_dict = {
        1: "pdf",
        2: "png",
        3: "jpg"
    }
    url_end_with = str(url).split('/')[-1]
    if not url_end_with:
        if type == 0 or type == '0':
            return True
        else:
            return False
    else:
        count = len(url_end_with.split('.'))
        if count == 1:
            if type == 0 or type == '0':
                return True
            else:
                return False
        else:
            real_type = url_end_with.split('.')[-1]
            if real_type == type_dict.get(int(type), ''):
                return True
            elif type == 0 or type == '0':
                return True
            else:
                return False


# 根据文件内容校验文件类型，不校验文件夹
def verify_content(url, _type):
    _type = int(_type)
    type_dict = {
        1: ["pdf"],
        2: ["png", "webp"],
        3: ["jpg", "jpeg", "webp"]
    }
    url = urllib.parse.quote(url, safe='://')
    if _type != 0:
        _type = type_dict.get(_type, '')
        if not _type:
            return False
        else:
            req = urllib.request.Request(url=url)
            with urllib.request.urlopen(req, timeout=10) as f:
                kind = filetype.guess(f)
                if not kind:
                    return False
                else:
                    real_type = kind.extension
                    if real_type in _type:
                        return True
                    else:
                        return False
    else:
        req = urllib.request.Request(url=url)
        with urllib.request.urlopen(req, timeout=10) as f:
            kind = filetype.guess(f)
            if kind:
                return False
            else:
                return True

# 去除url中服务器地址
def cut_file_url(_url):
    return parse.urlparse(_url).path

# 拼接外网文件url
def split_file_url(_path):
    return settings.EXTRANET_FILE_SERVER_URL + _path

# 拼接内网文件url
def split_intra_file_url(_path):
    return settings.FILE_SERVER_URL + _path


def get_urt(address):
    # 以get请求为例http://api.map.baidu.com/geocoder/v2/?address=百度大厦&output=json&ak=你的ak
    queryStr = '/geocoder/v2/?address=%s&region=郑州&output=json&ak=zgBjk2wponQ2KIItdszDFF4GP8jpmQWB' % address
    # 对queryStr进行转码，safe内的保留字符不转换
    encodedStr = parse.quote(queryStr, safe="/:=&?#+!$,;'@()*[]")
    # 在最后直接追加上yoursk
    rawStr = encodedStr + 'zgBjk2wponQ2KIItdszDFF4GP8jpmQWB'
    # 计算sn
    sn = (hashlib.md5(parse.quote_plus(rawStr).encode("utf8")).hexdigest())
    # 由于URL里面含有中文，所以需要用parse.quote进行处理，然后返回最终可调用的url
    url = parse.quote("http://api.map.baidu.com" + queryStr + "&sn=" + sn, safe="/:=&?#+!$,;'@()*[]")
    return url

def qiniu_upload(file_data, file_name=None):
    """图片上传七牛云 通用方法"""
    access_key = settings.QN_ACCESS_KEY
    secret_key = settings.QN_SECRET_KEY
    # 要上传的空间
    bucket_name = settings.BUCKET_QINIU
    # 构建鉴权对象
    q = Auth(access_key, secret_key)
    # 生成上传 Token，可以指定过期时间等
    token = q.upload_token(bucket_name)

    sha1 = hashlib.sha1()
    sha1.update(file_data)
    key = file_name or 'zoneyet/personnel/photo/' + sha1.hexdigest()

    ret, info = put_data(token, key, file_data)
    if info and info.status_code != 200:
        logger.error("上传文件到七牛失败, 失败状态码为{}， 原因为{}".format(info.status_code, info.text_body))
        raise Exception("上传七牛失败")
    return settings.DOMIN_QINIU + ret['key']


if __name__ == '__main__':
    file_name = '/home/zhb/PycharmProjects/docr/pdf/ceshi.pdf'

    loop = asyncio.get_event_loop()  # 创建事件循环

    with open(file_name, "rb") as f:
        # 同步代码
        # print(zj_upload_sync(f.read()))
        task = loop.create_task(zj_upload_async(f.read()))
        loop.run_until_complete(task)  # 运行事件循环，直到任务完成
        loop.close()  # 一旦任务结束，就获取到任务的结果
        print(task.result())
