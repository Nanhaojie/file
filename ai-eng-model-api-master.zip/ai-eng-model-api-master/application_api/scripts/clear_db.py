# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/6/1
# @author fj
import os
import sys

# 导入django配置文件
from django.conf import settings

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, './')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "application_api.settings")

    # 初始化django
    import django

    django.setup()

from scripts.create_superuser_s import createsuperuser
from django.db import connection


def clear_data():
    user_order_input = input('是否清空数据库：(y/n)')
    if user_order_input != 'y':
        print('程序已停止')
    else:
        with connection.cursor() as cursor:
            cursor.execute("""
            SELECT 
                concat('SET foreign_key_checks = 0; DROP TABLE IF EXISTS ', table_name, ';')
            FROM 
                information_schema.tables
            WHERE 
                table_schema = %s;
            """, (settings.DB_DATABASE, ))
            rows = cursor.fetchall()
            for row in rows:
                print(f'执行 sql: {row[0]}')
                cursor.execute(row[0])
            print('数据已清空')

    user_order_input = input('是否创建管理员：(y/n)')
    if user_order_input != 'y':
        print('程序已停止')
    else:
        createsuperuser()


if __name__ == '__main__':
    clear_data()
