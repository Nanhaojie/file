# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/7/22
# @author fj
import csv
import os
import sys

# 导入django配置文件

if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, './')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "application_api.settings")

    # 初始化django
    import django

    django.setup()

from pdf_ocr.models import FileModel


def init_data():
    # 读取csv文件
    with open('gkzk_d.csv', encoding='gbk') as f:
        p_file_id = input('请输入父文件id')
        # 遍历csv文件
        first_flag = 1
        for _, tybh, zkbh, jd, wd in csv.reader(f):
            if first_flag == 1:
                first_flag = 0
                continue
            # 根据用户id及文件名查询文件
            file_obj = FileModel.objects.filter(p_file_id=p_file_id, name=f'{tybh}.pdf')
            file_num = file_obj.count()
            if file_num != 1:
                print(f'{tybh}文件名找到{file_num}个文件，不予处理')
                continue
            eng_info_count = file_obj.first().eng_info_set.count()
            if eng_info_count == 1:
                # 如果文件有一个eng记录，就将 spare_int1 修改为 jd * (10**6)  |  spare_int2 修改为 wd * (10**6)
                file_obj.first().eng_info_set.update(spare_int1=int(float(jd) * (10 ** 6)), spare_int2=int(float(wd) * (10 ** 6)))
            else:
                # 否则抛出eng记录数量
                print(f'文件{tybh}的坐标信息更新失败，对应eng记录共{eng_info_count}条')


if __name__ == '__main__':
    init_data()
