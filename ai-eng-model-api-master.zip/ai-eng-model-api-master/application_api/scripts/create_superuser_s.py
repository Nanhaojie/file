# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/5/25
# @author fj
import os
import sys

# 导入django配置文件
if not os.getenv('DJANGO_SETTINGS_MODULE'):
    sys.path.insert(0, './')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "application_api.settings")

    # 初始化django
    import django

    django.setup()

from pdf_ocr.models import FileModel
from user.models import User
from user.serializers import UserCreateSerializer


def createsuperuser():
    username = input('请输入用户名：')
    password = input('请输入密码：')
    serializer = UserCreateSerializer(
        data={'username': username, 'password': password, 'is_staff': 1, 'superuser': 1, 'is_active': 1})
    if not serializer.is_valid(raise_exception=False):
        print(serializer.errors)
    serializer.save()
    user_id = serializer.data['id']
    username = serializer.data['username']
    file_info = FileModel.objects.create(user_id=user_id, type=0, name=username, file_owner_id=user_id)
    User.objects.filter(id=user_id).update(user_root_dir_id=file_info.id)
    print('创建成功')


if __name__ == '__main__':
    createsuperuser()
