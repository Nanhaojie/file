# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/21
# @author yueyb
# test

from django.urls import path

from user.views import UserAuthorizeView, UserInfoView, UserViewSet, LogListView, DirectoryTreeView, PasswordView, \
    UserFileInfo, UserLogoutView, CompanyViewSet, MenuViewSet, PermissionViewSet, PermissionTreeViewSet, RoleViewSet, \
    RolePermissionViewSet, UserRoleSet, Test

urlpatterns = [
    path('login', UserAuthorizeView.as_view()),
    path('logout', UserLogoutView.as_view()),
    path('info', UserInfoView.as_view()),
    path('directory_tree', DirectoryTreeView.as_view()),  # 文件目录树
    path('users', UserViewSet.as_view({'get': 'list', 'post': 'create'})),
    path('users/<int:pk>', UserViewSet.as_view({'put': 'update', 'delete': 'destroy', 'get': 'retrieve'})),
    path('logs', LogListView.as_view()),
    path('pwd', PasswordView.as_view()),
    path('fileinfo', UserFileInfo.as_view()),
    path('company', CompanyViewSet.as_view({'get': 'list', 'post': 'create'})),
    path('company/<int:pk>', CompanyViewSet.as_view({'put': 'update', 'delete': 'destroy', 'get': 'retrieve'})),
    # 权限部分
    path('menuinfo', MenuViewSet.as_view()),
    path('perm', PermissionViewSet.as_view({'get': 'list', 'post': 'create'})),
    path('perm/<int:pk>', PermissionViewSet.as_view({'put': 'update', 'delete': 'destroy'})),
    path('perm_tree/<int:pk>', PermissionTreeViewSet.as_view()),
    path('role', RoleViewSet.as_view({'get': 'list', 'post': 'create'})),
    path('role/<int:pk>', RoleViewSet.as_view({'put': 'update', 'delete': 'destroy'})),
    path('role_perm_tree/<int:pk>', RolePermissionViewSet.as_view()),
    path('user_role', UserRoleSet.as_view()),
    path('test', Test.as_view()),

]
