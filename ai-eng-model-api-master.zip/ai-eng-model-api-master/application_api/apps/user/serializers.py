import logging
import re

from django.conf import settings
from rest_framework import serializers
from django_redis import get_redis_connection

from pdf_ocr.models import FileModel
from user.models import User, LogModel, Company, PermissionModel, RoleModel
from utils.common import get_user_num, event_list, split_file_url, cut_file_url
from django.db.models import Q

from verifications import constants

logger = logging.getLogger("django")
redis_conn = get_redis_connection('login_user')

class LogListSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username')
    user_num = serializers.CharField(source='user.user_num')

    class Meta:
        model = LogModel
        fields = [
            'spare_str', 'username', 'ip', 'create_time', 'source', 'notes', 'user_num', 'id', 'event_id'
        ]
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }

    def to_representation(self, instance):
        data = super(LogListSerializer, self).to_representation(instance)
        if data['event_id'] or data['event_id']==0:
            try:
                data['event_name'] = event_list[data['event_id']]
            except:
                data['event_name'] = ''
            try:
                data['notes'] = data['notes'].split(';')[1]
            except:
                data['notes'] = ''
        return data


class UserListUpdateSerializer(serializers.ModelSerializer):
    # username = serializers.CharField(source='user.username', required=False)
    is_active = serializers.IntegerField(required=False)
    is_staff = serializers.IntegerField(required=False)

    def validate(self, attrs):
        # user = attrs.get("user", "")
        # if user:
        username = attrs.get("username", "")
        if username:
            detail = {"detail": "用户名不可修改"}
            logger.warning(detail)
            raise serializers.ValidationError(detail)
        password = attrs.get('password', '')
        if password:
            if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', password):
                detail = {'detail': '密码长度为6到18位字母加数字组合'}
                raise serializers.ValidationError(detail)
        return attrs

    def update(self, instance, validated_data):
        password = validated_data.get('password')
        if password:
            instance.set_password(password)
            validated_data['password'] = instance.password
            app_login_key = redis_conn.get('app_login_user_'+str(instance.id))
            pc_login_key = redis_conn.keys('pc_login_user_' + str(instance.id) + '_' + '*')
            if app_login_key:
                redis_conn.delete('app_login_user_'+str(instance.id))
                redis_conn.delete(app_login_key)
            if pc_login_key:
                for user_key in pc_login_key:
                    token_key = redis_conn.get(user_key)
                    redis_conn.delete(token_key)
                    redis_conn.delete(user_key)
        user = super(UserListUpdateSerializer, self).update(instance, validated_data)
        return user


    class Meta:
        model = User
        fields = [
            'username', 'is_active', 'date_joined', 'password', 'id', 'notes', 'user_num', 'is_staff',
            'user_root_dir_id', 'last_login'
        ]

        extra_kwargs = {
            'read_only_fields': ['username', 'date_joined', 'user_num'],
            'username': {'required': False},
            'user_num': {'read_only': True},
            'user_root_dir_id': {'read_only': True},
            'date_joined': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, 'required': False},
            'last_login': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, 'required': False},
            'password': {'write_only': True, 'required': False, 'error_messages': {'max_length': '密码长度为6到18位字母加数字组合'}},
            'notes': {'error_messages': {'max_length': '备注信息不能超过1000个字符。'}}
        }

    def to_representation(self, instance):
        data = super(UserListUpdateSerializer, self).to_representation(instance)
        user_id = data.get('id')
        if id:
            all_file_count = FileModel.objects.filter(~Q(type=0) & Q(file_owner_id=user_id)).count()
            ocr_file_count = FileModel.objects.filter(file_owner_id=user_id, ocr_status=11).count()
            ocr_file_count_fail = FileModel.objects.filter(file_owner_id=user_id, ocr_status=7).count()
            data['file_status'] = {'all_file_count': all_file_count, 'ocr_file_count': ocr_file_count,
                                   'ocr_file_count_fail': ocr_file_count_fail}
        return data


class UserCreateSerializer(serializers.ModelSerializer):

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user

    def validate(self, attrs):
        is_staff = attrs.get('is_staff', '')
        if is_staff:
            is_staff = '1'
        else:
            is_staff = '0'
        # 用户名密码校验
        username = attrs.get('username', '')
        if username:
            if not re.match('[0-9A-Za-z]{1,19}$', username):
                raise serializers.ValidationError({'detail': '用户名只能包含字母或数字且长度应小于20位'})
        password = attrs.get('password', '')
        if password:
            if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', password):
                detail = {'detail': '密码长度为6到18位字母加数字组合'}
                raise serializers.ValidationError(detail)
        attrs['user_num'] = get_user_num(is_staff)
        return attrs

    class Meta:
        model = User
        fields = [
            'username', 'is_active', 'password', 'id', 'is_staff', 'user_num', 'notes'
        ]
        extra_kwargs = {
            'password': {'write_only': True,'error_messages': {'max_length': '密码长度为6到18位字母加数字组合'}},
            'email': {'required': True},
            'notes': {'error_messages': {'max_length': '备注信息不能超过1000个字符。'}}
        }


class UserInfoSerializers(serializers.ModelSerializer):
    is_active = serializers.IntegerField(required=False, read_only=True)
    is_staff = serializers.IntegerField(required=False, read_only=True)
    user_id = serializers.IntegerField(source='id', required=False, read_only=True)
    permission = serializers.CharField(source='first_name', required=False, read_only=True)

    def validate(self, attrs):
        """校验参数 photo和password至少有一个参数存在"""
        if not (attrs.get("photo") or attrs.get("password")):
            detail = "参数缺失"
            logger.warning(detail)
            raise serializers.ValidationError(detail)

        username = attrs.get("username", "")
        if username:
            detail = {"detail": "用户名不可修改"}
            logger.warning(detail)
            raise serializers.ValidationError(detail)
        password = attrs.get('password', '')
        if password:
            if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', password):
                detail = {'detail': '密码长度为6到18位字母加数字组合'}
                raise serializers.ValidationError(detail)
        return attrs

    def validate_photo(self, val):
        if val:
            val = cut_file_url(val)
        return val

    def update(self, instance, validated_data):
        password = validated_data.get('password')
        # photo = validated_data.get('photo')
        # detail = validated_data.get('detail')
        # if password:
        #     instance.set_password(password)
        # if photo:
        #     instance.photo = photo
        # instance.save()
        user = super(UserInfoSerializers, self).update(instance, validated_data)
        if password:
            user.set_password(password)
            user.save()
            app_login_key = redis_conn.get('app_login_user_' + str(instance.id))
            pc_login_key = redis_conn.keys('pc_login_user_' + str(instance.id) + '_' + '*')
            if app_login_key:
                redis_conn.delete('app_login_user_' + str(instance.id))
                redis_conn.delete(app_login_key)
            if pc_login_key:
                for user_key in pc_login_key:
                    token_key = redis_conn.get(user_key)
                    redis_conn.delete(token_key)
                    redis_conn.delete(user_key)
        else:
            user = instance
        return user

    class Meta:
        model = User
        fields = [
            'photo', 'username', 'is_staff', 'is_active', 'date_joined', 'password', 'user_num', 'notes', 'user_root_dir_id', 'user_id', 'permission'
        ]

        extra_kwargs = {
            'read_only_fields': ['username', 'date_joined', 'is_staff', 'user_num'],
            'photo': {'required': False},
            'username': {'required': False, 'read_only': True},
            'user_num': {'read_only': True},
            'is_staff': {'required': False, 'read_only': True},
            'is_active': {'required': False, 'read_only': True},
            'notes': {'required': False, 'error_messages': {'max_length': '备注信息不能超过1000个字符。'}},
            'password': {'write_only': True, 'required': False, 'error_messages': {'max_length': '密码长度为6到18位字母加数字组合'}},
            'date_joined': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT, 'write_only': True},
        }

    def to_representation(self, instance):
        data = super(UserInfoSerializers, self).to_representation(instance)
        photo = data.get('photo')
        if photo:
            data['photo'] = split_file_url(photo)
        return data


class PasswordSerializers(serializers.ModelSerializer):
    new_password = serializers.CharField(max_length=18, required=True, write_only=True, error_messages={'max_length': '新密码长度为6到18位字母加数字组合'})

    class Meta:
        model = User
        fields = [
            "password", "new_password"
        ]
        extra_kwargs = {
            'password': {'required': True, 'write_only': True, 'error_messages': {'max_length': '密码长度为6到18位字母加数字组合'}},
        }

    def validate(self, attrs):
        password = attrs.get('password')
        if not self.instance.check_password(password):
            detail = {'detail': '原始密码不正确'}
            raise serializers.ValidationError(detail)
        new_password = attrs.get('new_password')
        if new_password:
            if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', new_password):
                        detail = {'detail': '新密码长度为6到18位字母加数字组合'}
                        raise serializers.ValidationError(detail)
        return attrs

    def update(self, instance, validated_data):
        new_password = validated_data.get('new_password')
        instance = super(PasswordSerializers, self).update(instance, validated_data)
        instance.set_password(new_password)
        instance.save()
        app_login_key = redis_conn.get('app_login_user_' + str(instance.id))
        pc_login_key = redis_conn.keys('pc_login_user_' + str(instance.id) + '_' + '*')
        if app_login_key:
            redis_conn.delete('app_login_user_' + str(instance.id))
            redis_conn.delete(app_login_key)
        if pc_login_key:
            for user_key in pc_login_key:
                token_key = redis_conn.get(user_key)
                redis_conn.delete(token_key)
                redis_conn.delete(user_key)
        return instance


class CompanySerializer(serializers.ModelSerializer):
    # contacts = serializers.CharField(required=True)
    # email = serializers.CharField(required=True)
    # phone = serializers.CharField(required=True)
    uuid = serializers.UUIDField(required=True, label="用于验证用户的img_code")
    img_code = serializers.CharField(required=True, label="图片验证码")
    company_id = serializers.IntegerField(source='id', required=False, read_only=True)

    def validate_img_code(self, img_code:str):
        # 校验图片验证码是否正确
        uuid = self.context['request'].data.get("uuid")
        redis_conn = get_redis_connection('default')
        # 获取图形验证码
        img_code_redis_key = f'{constants.IMAGE_CODE_REDIS_PREFIX}{uuid}'
        real_img_code = redis_conn.get(img_code_redis_key)
        if not real_img_code:
            raise serializers.ValidationError('图片验证码已过期')
        # 删除图形验证码
        redis_conn.delete(img_code_redis_key)
        # 对比图形验证码
        if real_img_code.decode() != img_code.upper():
            raise serializers.ValidationError('图片验证码错误')
        return img_code


    def update(self, instance, validated_data):
        instance = super(CompanySerializer, self).update(instance, validated_data)
        instance.save()
        return instance

    class Meta:
        model = Company
        # 要显示出来的字段
        fields = ('name', 'contacts', 'email', 'phone', 'examine', 'notes', 'company_id', 'uuid', 'img_code')
        extra_kwargs = {
            'contacts': {'error_messages': {'max_length': '您的称呼不得超过127个字符!'}},
            # 'email': {'error_messages': {'test': 'test'}},
            'name': {'error_messages': {'max_length': '公司全称不能超过100个字符!'}},
            'notes': {'error_messages': {'max_length': '其他说明不能超过1000个字符!'}},
            # 'email': {'error_messages': {'max_length': '邮箱不能超过127个字符!'}},
            'phone': {'error_messages': {'max_length': '联系电话不能超过100个字符!'}},
        }


class PermissionSerializers(serializers.ModelSerializer):
    p_perm = serializers.CharField(source='p_perm_id', required=False, allow_blank=True, allow_null=True)
    # p_perm = serializers.PrimaryKeyRelatedField(queryset=PermissionModel.objects.all())

    class Meta:
        model = PermissionModel
        fields = [
            'id', 'name', 'sign', 'icon', 'order_num', 'href', 'type', 'create_time', 'update_time', 'description' ,'p_perm'
        ]
        extra_kwargs = {
            "name": {"required": False},
            "sign": {"required": False},
            "order_num": {"required": False},
            # "href": {"required": False},
            "type": {"required": False},
            "create_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "update_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }

    def to_representation(self, instance):
        data = super(PermissionSerializers, self).to_representation(instance)
        if not data.get('p_perm'):
            data['p_perm'] = -1
        return data


class RoleSerializers(serializers.ModelSerializer):

    class Meta:
        model = RoleModel
        fields = [
            'id', 'name', 'create_time', 'update_time', 'description'
        ]
        extra_kwargs = {
            "create_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "update_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }


class UserRoleSerializers(serializers.ModelSerializer):
    value = serializers.IntegerField(source='id')

    class Meta:
        model = RoleModel
        fields = [
            'value', 'name'
        ]