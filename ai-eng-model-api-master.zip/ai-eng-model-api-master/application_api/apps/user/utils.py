# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/22
# @author fj

def jwt_response_payload_handler(token, user=None, request=None):
    return {
        'username': user.username,
        'photo': user.photo,
        'token': token,
        'user_id': user.id,
    }