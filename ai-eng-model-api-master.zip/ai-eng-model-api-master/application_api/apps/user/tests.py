from django.test import TestCase


class UserAuthorizeViewTest(TestCase):
    # "	用户登录	"
    def test_post(self):
        resp = self.client.post('/api/user/login', data={"username": "ty","password": "qqq123"})
        self.assertEqual(resp.status_code, 200)

class UserLogoutViewTest(TestCase):
    # 用户退出
    def test_delete(self):
        resp = self.client.delete('/api/user/logout', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class UserInfoViewTest(TestCase):

    # 用户信息
    def test_get(self):
        resp = self.client.get('/api/user/info', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # 用户信息修改
    def test_put(self):
        resp = self.client.put('/api/user/info', data={"photo": "http://172.16.1.144:8900/root/test/123.jpg", "notes": "test"}, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class DirectoryTreeViewTest(TestCase):
    # 用户目录树
    def test_get(self):
        resp = self.client.get('/api/user/directory_tree', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code,200)


class UserViewSetTest(TestCase):
    # 后台用户管理-用户列表查询
    def test_get(self):
        resp = self.client.get('/api/user/users', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # 后台用户管理-新增用户
    def test_post(self):
        data={
                "username": "zwz003",
                "password": "z123456",
                "is_active": 1,
                "is_staff": 1,
                "notes": ""
            }
        resp = self.client.post('/api/user/users', data=data, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # 后台用户管理-用户详情修改
    def test_put(self):
        data = {
            "is_staff": 1
        }
        resp = self.client.put('/api/user/users/115', data=data, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)
    # 后台用户管理-删除用户
    def test_delete(self):
        resp = self.client.delete('/api/user/users/115', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # 后台用户管理-用户详情
    def test_get_one(self):
        resp = self.client.get('/api/user/users/115', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class LogListViewTest(TestCase):
    # 操作日志查询
    def test_get(self):
        resp = self.client.get('/api/user/logs?order_by=0&order_by_key=create_time&page=1&page_size=10', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class PasswordViewTest(TestCase):
    # 用户修改个人密码
    def test_put(self):
        data = {
            "password": "z123456",
            "new_password": "z123456"
        }
        resp = self.client.put('/api/user/pwd', data=data, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class UserFileInfoTest(TestCase):
    # 首页-用户文件信息
    def test_get(self):
        resp = self.client.get('/api/user/fileinfo', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)