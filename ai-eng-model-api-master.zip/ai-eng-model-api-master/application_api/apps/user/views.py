import re
import logging
import traceback
import hashlib

import pandas as pd
from asgiref.sync import sync_to_async
from django.contrib.auth import logout, login
from django.dispatch import receiver
from rest_framework import status
from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.generics import ListAPIView
from rest_framework_jwt.settings import api_settings
from django.http import JsonResponse
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django_redis import get_redis_connection
from django.conf import settings

from user import serializers
from user.models import User, LogModel, Company, RolePermissionModel, PermissionModel, RoleModel, UserRoleModel
from utils.common import request_finished_custom, event_list, split_file_url, get_user_num
from pdf_ocr.models import FileModel

logger = logging.getLogger("django")
redis_conn = get_redis_connection('login_user')


class DirectoryTreeView(APIView):
    permission_classes = (IsAuthenticated,)

    def folder_add_tree(self, tree_dict_node_list: list, folder_id: int, folder_set: pd.DataFrame):
        """文件递归保存到dict中"""
        son_folder_set = folder_set[folder_set.p_file_id == folder_id]
        for index, id, name, p_file_id in son_folder_set.to_records():
            # 如果file为一个文件，那么就压缩到zip中
            node_dict = {'id': id, 'name': name, 'son_files': list()}
            tree_dict_node_list.append(node_dict)
            # 递归存储文件件
            self.folder_add_tree(node_dict['son_files'], id, folder_set)

    def get_user_folder_tree(self, user):
        # 获取用户所有的文件夹
        columns = ("id", "name", "p_file_id")
        folder_set = FileModel.objects.filter(type=0, file_owner_id=user.id).only(*columns).order_by("-id").values_list(
            *columns)
        # 构建pandas DF
        folder_set = pd.DataFrame.from_records(folder_set, columns=columns)
        folder = folder_set[folder_set.id == user.user_root_dir_id]
        tree_dict = {'id': folder.id.item(), 'name': folder.name.item(), 'son_files': list()}
        self.folder_add_tree(tree_dict['son_files'], folder.id.item(), folder_set)
        photo = user.photo
        if photo:
            tree_dict['photo'] = split_file_url(str(photo))
        else:
            tree_dict['photo'] = ''
        return tree_dict

    def get(self, request):
        """返回用户的目录树"""
        current_user_folder_tree = self.get_user_folder_tree(request.user)
        if request.user.is_staff:
            users_folder_tree = {'id': -1, 'name': '', 'son_files': [current_user_folder_tree]}
            # 验证用户参数
            other_user_set = User.objects.filter(Q(id__gt=request.user.id) | Q(id__lt=request.user.id)) \
                .filter(company_id=request.user.company_id) \
                .only("id", "user_root_dir_id")
            for user in other_user_set:
                users_folder_tree['son_files'].append(self.get_user_folder_tree(user))
            # return Response(users_folder_tree)
        else:
            users_folder_tree = current_user_folder_tree
        request_finished_custom.send("用户目录查询", request=self.request)
        return Response(users_folder_tree)


class LogListView(ListAPIView):
    serializer_class = serializers.LogListSerializer
    permission_classes = (IsAdminUser,)

    def get_queryset(self, *args):
        order_by = self.request.query_params.get('order_by')
        order_by_key = self.request.query_params.get("order_by_key")
        objects = LogModel.objects.filter(company_id=self.request.user.company_id)
        # 开始结束时间的筛选
        from_data = self.request.query_params.get("from_data")
        if from_data:
            objects = objects.filter(create_time__gte=from_data)
        to_data = self.request.query_params.get("to_data")
        if to_data:
            objects = objects.filter(create_time__lte=to_data + " 23:59:59")
        # 事件的筛选
        event_keywords = self.request.query_params.get("event_keywords")
        if event_keywords:
            query_event_id_list = [event_id for event_id, event in enumerate(event_list) if event_keywords in event]
            objects = objects.filter(event_id__in=query_event_id_list)
        # 用户的筛选
        username = self.request.query_params.get("username")
        if username:
            objects = objects.filter(user__username__contains=username)
        # 用户编号筛选
        user_num = self.request.query_params.get("user_num")
        if user_num:
            objects = objects.filter(user__user_num__contains=user_num)
        # 对用户名、用户编号、操作详情三项一起搜索
        search_key = self.request.query_params.get("search_key")
        if search_key:
            # query_event_id_list = [event_id for event_id, event in enumerate(event_list) if search_key in event]  # 精确
            query_event_id_list = [event_id for event_id, event in enumerate(event_list) if event.find(search_key) != -1]  # 模糊
            objects = objects.filter(
                Q(user__username__contains=search_key) | Q(user__user_num__contains=search_key) |
                Q(notes__contains=search_key) | Q(event_id__in=query_event_id_list))
        if order_by == '0':
            if order_by_key == 'create_time':
                objects = objects.order_by('-id')
            elif order_by_key == 'event_name':
                objects = objects.order_by('-event_id')
            else:
                objects = objects.order_by('-user__' + order_by_key)
        elif order_by == '1':
            if order_by_key == 'create_time':
                objects = objects.order_by('id')
            elif order_by_key == 'event_name':
                objects = objects.order_by('event_id')
            else:
                objects = objects.order_by('user__' + order_by_key)
        elif order_by == '' or order_by == None:
            objects = objects.order_by('-id')
        return objects


class UserViewSet(ModelViewSet):
    permission_classes = (IsAdminUser,)

    def get_serializer_class(self):
        if self.action in ('list', 'update', 'retrieve'):
            return serializers.UserListUpdateSerializer
        elif self.action == 'create':
            return serializers.UserCreateSerializer

    def get_queryset(self):
        # 对请求参数校验
        keywords = self.request.query_params.get("keywords")
        is_active = self.request.query_params.get("is_active")
        order_by_key = self.request.query_params.get("order_by_key")
        order_by = self.request.query_params.get("order_by")
        objects = User.objects.filter(company_id=self.request.user.company_id)
        if keywords:
            objects = objects.filter(Q(username=keywords) | Q(user_num=keywords))
        if is_active:
            objects = objects.filter(is_active=is_active)
        if order_by == '0':
            objects = objects.order_by('-'+order_by_key)
        elif order_by == '1':
            objects = objects.order_by(order_by_key)
        elif order_by == '' or order_by == None:
            objects = objects.order_by('id')
        return objects

    def list(self, request, *args, **kwargs):
        response = super(UserViewSet, self).list(request, *args, **kwargs)
        request_finished_custom.send("用户列表查询", request=self.request)
        return response

    def update(self, request, *args, **kwargs):
        # response = super(UserViewSet, self).update(request, *args, **kwargs)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        request_finished_custom.send("用户信息修改", request=self.request)
        return Response(data=serializer.data, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        response = super(UserViewSet, self).retrieve(request, *args, **kwargs)
        request_finished_custom.send("用户详情查询", request=self.request)
        return response

    def create(self, request, *args, **kwargs):
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                username = request.data.get('username', '')
                if username:
                    if not re.match('[0-9A-Za-z]{1,19}$', username):
                        return Response(data={'detail': '用户名只能包含字母或数字且长度应小于20位'}, status=status.HTTP_400_BAD_REQUEST)
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid(raise_exception=False):
                    # print(serializers.errors)
                    return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
                self.perform_create(serializer)
                headers = self.get_success_headers(serializer.data)
                user_id = serializer.data['id']
                username = serializer.data['username']
                file_info = FileModel.objects.create(user_id=user_id, type=0, name=username, file_owner_id=user_id,
                                                     company_id=request.user.company_id)
                User.objects.filter(id=user_id).update(user_root_dir_id=file_info.id, company_id=request.user.company_id)
                response = Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
                request_finished_custom.send("用户创建", request=self.request)
            except Exception as e:
                logger.error(e, exc_info=True)
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '用户创建失败！'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        return response


class UserAuthorizeView(APIView):
    """用户登录视图"""
    def my_md5(self, jwt):
        md = hashlib.md5()
        md.update(jwt.encode(encoding='utf-8'))
        md5_str = md.hexdigest()
        return md5_str

    def post(self, request, *args, **kwargs):
        # 参数验证
        username = request.data.get("username")
        password = request.data.get("password")
        if not all([username, password]):
            return Response(data={"detail": "参数缺失"}, status=status.HTTP_400_BAD_REQUEST)

        # 密码及用户校验
        try:
            user = User.objects.get(username=username)
        except Exception:
            return Response(data={"detail": "账号不存在"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if not user.check_password(password):
                return Response(data={"detail": "密码不正确"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                if user.is_active:
                    request.user = user
                    # 手动生成token验证
                    jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
                    jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
                    payload = jwt_payload_handler(user)
                    token = jwt_encode_handler(payload)
                    md5_str = self.my_md5(token)
                    val = {"token": token, "username": user.username, "user_id": user.id}
                    # pc可以多端登录  app只能一端登录
                    HTTP_SIGN = request.META.get('HTTP_SIGN')
                    if HTTP_SIGN == 'Android' or HTTP_SIGN == 'ios':
                        app_login_user = redis_conn.get('app_login_user_' + str(user.id))
                        if app_login_user:
                                redis_conn.delete(app_login_user)
                        redis_conn.set(md5_str, str(val), settings.APP_EXP_SECOND)
                        redis_conn.set('app_login_user_' + str(user.id), md5_str, settings.APP_EXP_SECOND)
                    else:
                        redis_conn.set(md5_str, str(val), settings.PC_EXP_SECOND)
                        redis_conn.set('pc_login_user_' + str(user.id) + '_' + md5_str, md5_str, settings.PC_EXP_SECOND)
                    ret = {
                        'token': md5_str,
                        'username': user.username,
                        'user_num': user.user_num,
                        'user_id': user.id,
                        'photo': user.photo,
                        'user_root_dir_id': user.user_root_dir_id,
                        'is_staff': 1 if user.is_staff else 0,
                        'is_active': 1 if user.is_active else 0,
                        'notes': user.notes,
                        'detail': "成功",
                    }
                    user.last_login = timezone.now()
                    user.save(update_fields=['last_login'])
                    request_finished_custom.send("登录", request=self.request)
                    return Response(data=ret)
                else:
                    return Response(data={"detail": "用户未激活"}, status=status.HTTP_400_BAD_REQUEST)

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.check_throttles(request)

class UserLogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    def delete(self, request, *args, **kwargs):
        user_id = request.user.id
        token = request.META.get('HTTP_AUTHORIZATION').replace('JWT ', '')
        HTTP_SIGN = request.META.get('HTTP_SIGN')
        if HTTP_SIGN == settings.WEB_HEADER_SIGN:
            redis_conn.delete(token)
            redis_conn.delete('pc_login_user_' + str(user_id) + '_' + token)
        if HTTP_SIGN == settings.ANDROID_HEADER_SIGN or HTTP_SIGN == settings.IOS_HEADER_SIGN:
            redis_conn.delete(token)
            redis_conn.delete('app_login_user_' + str(user_id))
        request_finished_custom.send('用户退出', request=self.request)
        return Response(data={'detail': '成功'}, status=status.HTTP_200_OK)


class UserInfoView(RetrieveUpdateAPIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        return self.request.user

    def get_serializer_class(self):
        return serializers.UserInfoSerializers

    def retrieve(self, request, *args, **kwargs):
        response = super(UserInfoView, self).retrieve(request, *args, **kwargs)
        request_finished_custom.send("个人详情查询", request=self.request)
        return response

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        request_finished_custom.send("个人信息修改", request=self.request)
        return Response(data=serializer.data, status=status.HTTP_200_OK)


class PasswordView(RetrieveUpdateAPIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        return self.request.user

    def get_serializer_class(self):
        return serializers.PasswordSerializers

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        resp = serializer.data
        # resp = super(PasswordView, self).update(request, *args, **kwargs)
        request_finished_custom.send("修改个人密码", request=self.request)
        return Response(data=resp, status=status.HTTP_200_OK)


class UserFileInfo(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        user_id = request.user.id
        all_file_count = FileModel.objects.filter(~Q(type=0) & Q(file_owner_id=user_id)).count()
        ocr_file_count = FileModel.objects.filter(file_owner_id=user_id, ocr_status=11).count()
        ocr_file_count_fail = FileModel.objects.filter(file_owner_id=user_id, ocr_status=7).count()
        if not all_file_count:
            success_rate = '0.00%'
            fail_rate = '0.00%'
        else:
            success_rate = '{:.2%}'.format(ocr_file_count / all_file_count)
            fail_rate = '{:.2%}'.format(ocr_file_count_fail / all_file_count)
        request_finished_custom.send("首页文件信息", request=self.request)
        ret = {'all_file_count': all_file_count, 'ocr_file_count': ocr_file_count, 'success_rate': success_rate,
               'ocr_file_count_fail': ocr_file_count_fail, 'fail_rate': fail_rate}
        return Response(ret)


class CompanyViewSet(ModelViewSet):
    def get_serializer_class(self):
        if self.action in ('list', 'update', 'retrieve'):
            return serializers.CompanySerializer
        elif self.action == 'create':
            return serializers.CompanySerializer

    def get_queryset(self):
        objects = Company.objects.all()
        return objects

    def list(self, request, *args, **kwargs):
        response = super(CompanyViewSet, self).list(request, *args, **kwargs)
        # request_finished_custom.send("单位列表查询", request=self.request)
        return response

    def update(self, request, *args, **kwargs):
        # response = super(UserViewSet, self).update(request, *args, **kwargs)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid(raise_exception=False):
            return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            instance._prefetched_objects_cache = {}
        # request_finished_custom.send("单位信息修改", request=self.request)
        return Response(data=serializer.data, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        response = super(CompanyViewSet, self).retrieve(request, *args, **kwargs)
        # request_finished_custom.send("单位详情查询", request=self.request)
        return response

    def create(self, request,  *args, **kwargs):
        with transaction.atomic():
            save_id = transaction.savepoint()
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid(raise_exception=False):
                    return Response(data={"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
                # self.perform_create(serializer)
                headers = self.get_success_headers(serializer.data)
                name = serializer.data['name']
                contacts = serializer.data['contacts']
                email = serializer.data['email']
                phone = serializer.data['phone']
                note = serializer.data['notes']
                user_name = request.data['username']
                password = request.data['password']
                company_name = Company.objects.filter(name=name).exists()
                if company_name:
                    return Response(data={'detail': '公司已存在'}, status=status.HTTP_400_BAD_REQUEST)
                if email:
                    if not re.match(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}$', email):
                        return Response(data={'detail': '邮箱格式不正确'}, status=status.HTTP_400_BAD_REQUEST)
                # if phone:
                #     if not re.match(r'^1(3\d|4[4-9]|5[0-35-9]|6[67]|7[013-8]|8[0-9]|9[0-9])\d{8}$', phone):
                #         return Response(data={'detail': '电话号码格式不正确'}, status=status.HTTP_400_BAD_REQUEST)
                if user_name:
                    if not re.match('[0-9A-Za-z]{1,19}$', user_name):
                        return Response(data={'detail': '用户名只能包含字母或数字且长度应小于20位'}, status=status.HTTP_400_BAD_REQUEST)
                if password:
                    if not re.match('^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$', password):
                        return Response(data={'detail': '密码长度为6到18位字母加数字组合'}, status=status.HTTP_400_BAD_REQUEST)
                # 用户
                if User.objects.filter(username=user_name).exists():
                    return Response(data={'detail': '用户名已存在'}, status=status.HTTP_400_BAD_REQUEST)

                # 单位
                company = Company(contacts=contacts, email=email, name=name, phone=phone, notes=note)
                company.save()
                user = User(company_id=company.id, username=user_name, password=password, is_staff=1, is_active=0, notes=note)
                user.set_password(user.password)
                user.save()
                is_staff = user.is_staff
                if is_staff:
                    is_staff = '1'
                else:
                    is_staff = '0'
                User.objects.filter(id=user.id).update(user_num=get_user_num(is_staff))
                file_info = FileModel.objects.create(user_id=user.id, type=0, name=user_name, file_owner_id=user.id,
                                                     company_id=company.id)
                User.objects.filter(id=user.id).update(user_root_dir_id=file_info.id)
                response = Response(data={'detail': '单位创建成功，等待审核中！'}, status=status.HTTP_201_CREATED, headers=headers)
                # request_finished_custom.send("单位注册", request=self.request)
            except Exception as e:
                logger.error(e, exc_info=True)
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '单位创建失败！'}, status=status.HTTP_400_BAD_REQUEST)
            transaction.savepoint_commit(save_id)
        return response

    def destroy(self, request, *args, **kwargs):
        response = super(CompanyViewSet, self).destroy(request, *args, **kwargs)
        # request_finished_custom.send("删除单位", request=self.request)
        return response


class PermissionViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        return serializers.PermissionSerializers

    def get_queryset(self):
        objects = PermissionModel.objects.all().order_by('order_num')
        return objects

    def list(self, request, *args, **kwargs):
        response = super(PermissionViewSet, self).list(request, *args, **kwargs)
        # request_finished_custom.send("用户列表查询", request=self.request)
        return response

    def create(self, request, *args, **kwargs):
        response = super(PermissionViewSet, self).create(request, *args, **kwargs)
        return response

    def update(self, request, *args, **kwargs):
        response = super(PermissionViewSet, self).update(request, *args, **kwargs)
        return response

    def destroy(self, request, *args, **kwargs):
        response = super(PermissionViewSet, self).destroy(request, *args, **kwargs)
        return response


class PermissionTreeViewSet(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk):
        columns = ('id', 'name', 'p_perm_id')
        perm_set = PermissionModel.objects.all().values_list(*columns)
        perm_set = pd.DataFrame(list(perm_set), columns=columns)
        # p_perm_id = perm_set[perm_set.id==pk].fillna(0).iloc[0,2] if pk else 0
        # 一级菜单
        first_perm_set =perm_set[perm_set.p_perm_id.isnull()]
        perm_data = [{
                        'id': '',
                        'name': '请选择',
                        'open': False,
                        "checked": False
                    }]
        perm_data.extend(self.join_perm_data(first_perm_set, perm_set, pk))
        return Response(data=perm_data)

    # 权限信息
    def join_perm_data(self, first_perm_set:pd.DataFrame, perm_set:pd.DataFrame, pk):
        perm_data = []
        for item in first_perm_set.itertuples():
            cld_perm_set = perm_set[perm_set.p_perm_id == item.id]
            if len(cld_perm_set) != 0:
                if item.id != pk:
                    ret = self.join_perm_data(cld_perm_set, perm_set, pk)
                    # d = {'id': item.id, 'name': item.name, 'open': True, 'children': ret, "checked": True}
                    d = {'id': item.id, 'name': item.name, 'open': True, 'children': ret, "checked": False}
                    perm_data.append(d)
            else:
                if item.id != pk:
                    perm_data.append({
                        'id': item.id,
                        'name': item.name,
                        'open': False,
                        "checked": False
                    })
                # if item.id in checked:
                #     checked_list.append(item.id)

        return perm_data


class RoleViewSet(ModelViewSet):

    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        return serializers.RoleSerializers

    def get_queryset(self):
        role_name = self.request.query_params.get("role_name")
        objects = RoleModel.objects.all()
        if role_name:
            objects = objects.filter(name__contains=role_name)
        return objects

    def list(self, request, *args, **kwargs):
        response = super(RoleViewSet, self).list(request, *args, **kwargs)
        return response

    def create(self, request, *args, **kwargs):
        response = super(RoleViewSet, self).create(request, *args, **kwargs)
        return response

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        if serializer.data.get('code') == 200:
            perm_list = request.data.get('perm_list', [])
            if perm_list:
                for item in perm_list:
                    RolePermissionModel.objects.create(role_id=instance.id, perm_id=item)
        return Response({'detail': '成功'})

    def destroy(self, request, *args, **kwargs):
        response = super(RoleViewSet, self).destroy(request, *args, **kwargs)
        return response


class RolePermissionViewSet(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk):
        columns = ('id', 'name', 'p_perm_id')
        perm_set = PermissionModel.objects.all().order_by('order_num').values_list(*columns)
        perm_set = pd.DataFrame(list(perm_set), columns=columns)
        # 一级菜单
        first_perm_set =perm_set[perm_set.p_perm_id.isnull()]
        checked = list(RolePermissionModel.objects.filter(role_id=pk).values_list('perm_id', flat=True))
        perm_data, checked_list = self.join_perm_data(first_perm_set, perm_set, checked)
        return Response(data={'data': perm_data, 'checked': checked_list})

    # 角色权限信息
    def join_perm_data(self, first_perm_set:pd.DataFrame, perm_set:pd.DataFrame, checked:list):
        perm_data = []
        checked_list = []
        for item in first_perm_set.itertuples():
            cld_perm_set = perm_set[perm_set.p_perm_id == item.id]
            if len(cld_perm_set) != 0:
                ret,ret1 = self.join_perm_data(cld_perm_set, perm_set, checked)
                perm_data.append({'title': item.name, 'id': item.id, 'spread': True, 'children': ret})
                checked_list.extend(ret1)
            else:
                perm_data.append({
                    'title': item.name,
                    'id': item.id,
                })
                if item.id in checked:
                    checked_list.append(item.id)

        return perm_data,checked_list

    # 修改角色权限
    def put(self, request, pk):
        checked_data = request.data.get('checked_data')
        perm_id_list = self.get_checked_id_list(checked_data)
        RolePermissionModel.objects.filter(role_id = pk).delete()
        if perm_id_list:
            for item in perm_id_list:
                RolePermissionModel.objects.create(role_id=pk, perm_id= item)
        return Response(data=[])

    def get_checked_id_list(self, checked_data):
        id_list = []
        for data in checked_data:
            id_list.append(data['id'])
            child_data = data.get('children', '')
            if child_data:
                ret = self.get_checked_id_list(child_data)
                id_list.extend(ret)
        return id_list


class UserRoleSet(APIView):

    permission_classes = (IsAuthenticated,)
    def get(self, request):
        user_id = request.query_params.get('user_id')
        if user_id:
            # 用户编辑
            user_role_id = UserRoleModel.objects.filter(b_user_id=user_id).values_list('role_id', flat=True)
            if user_role_id:
                role_set = RoleModel.objects.all().only('id', 'name')
                data = []
                for role in role_set:
                    if role.id in user_role_id:
                        data.append({'value': role.id, 'name': role.name, 'selected': True})
                    else:
                        data.append({'value': role.id, 'name': role.name})
                return Response(data=data)

        # 用户新增
        role_set = RoleModel.objects.all().only('id', 'name')
        data = serializers.UserRoleSerializers(role_set, many=True).data
        return Response(data=data)


class MenuViewSet(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        role_list = request.user.role_set.all().values_list('role_id', flat=True)
        perm_id_list = list(set(RolePermissionModel.objects.filter(role_id__in=role_list).values_list('perm_id', flat=True)))
        columns = ('id', 'name', 'icon', 'href', 'p_perm_id')
        perm_set = PermissionModel.objects.filter(Q(id__in=perm_id_list)&~Q(type=3)).values_list(*columns)
        perm_set = pd.DataFrame(list(perm_set), columns=columns)
        # 一级菜单
        first_perm_set = perm_set[perm_set.p_perm_id.isnull()]
        perm_data = self.join_perm_data(first_perm_set, perm_set)
        return Response(data=perm_data)

    # 角色权限信息
    def join_perm_data(self, first_perm_set: pd.DataFrame, perm_set: pd.DataFrame):
        perm_data = []
        for item in first_perm_set.itertuples():
            cld_perm_set = perm_set[perm_set.p_perm_id == item.id]
            if len(cld_perm_set) != 0:
                ret = self.join_perm_data(cld_perm_set, perm_set)
                perm_data.append({'title': item.name, 'icon': item.icon, 'href': item.href, 'target': '_self', 'child': ret})
            else:
                perm_data.append({
                    # 'id': item.id,
                    'title': item.name,
                    'icon': item.icon,
                    'href': item.href,
                    'target': '_self',
                })
        return perm_data


class Test(APIView):
    def get(self, request, *args, **kwargs):
        return Response({'data': '测试接口'})
