from django.contrib.auth.models import AbstractUser
from django.db import models

from utils.models import SpareFieldModel


class Company(SpareFieldModel):
    examine_status_choices = (
        (0, "审核未通过"),
        (1, "审核通过"),
        (2, "待审核"),
        (3, "审核中"),
    )
    name = models.CharField(max_length=127, verbose_name="单位名称")
    contacts = models.CharField(max_length=127, null=True, blank=True, verbose_name="联系人")
    email = models.CharField(max_length=127, null=True, blank=True, verbose_name="邮箱")
    phone = models.CharField(max_length=127, null=True, blank=True, verbose_name="电话")
    examine = models.SmallIntegerField(default=2, null=True, blank=True, choices=examine_status_choices)
    notes = models.CharField(max_length=1000, null=True, blank=True, verbose_name="备注")
    business_license = models.CharField(max_length=500, null=True, blank=True, verbose_name="营业执照")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        # 指明数据库表名
        db_table = 't_company'
        # 在admin站点中显示的名称
        verbose_name = '单位表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class User(AbstractUser):
    photo = models.CharField(max_length=255, null=True, blank=True, verbose_name="用户头像")
    company = models.ForeignKey(Company, null=True, blank=True, on_delete=models.DO_NOTHING, related_name="users",
                                db_constraint=False)
    user_num = models.CharField(max_length=15, blank=True, verbose_name="用户编号")
    user_root_dir = models.OneToOneField("pdf_ocr.FileModel", null=True, on_delete=models.DO_NOTHING,
                                         related_name="user_info",
                                         db_constraint=False, verbose_name="用户根目录")
    notes = models.CharField(max_length=1000, blank=True, verbose_name="备注")

    class Meta:
        # 指明数据库表名
        db_table = 't_users'
        # 在admin站点中显示的名称
        verbose_name = '用户表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class LogModel(SpareFieldModel):
    source_choices = (
        (1, "web"),
        (2, "pc"),
        (1, "app"),
    )
    company = models.ForeignKey(Company, null=True, blank=True, on_delete=models.DO_NOTHING, related_name="user_logs",
                                db_constraint=False)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, db_constraint=False)
    ip = models.CharField(max_length=32, verbose_name="用户操作客户端的ip")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="操作时间")
    source = models.SmallIntegerField(default=1, choices=source_choices, verbose_name="用户操作客户端")
    path = models.CharField(max_length=127, verbose_name="请求路径")
    event_id = models.IntegerField(verbose_name="事件对应的id")
    notes = models.CharField(max_length=1000, verbose_name="事件发生的详情，'谁 做了什么事件 操作参数'")

    class Meta:
        # 指明数据库表名
        db_table = 't_log'
        # 在admin站点中显示的名称
        verbose_name = '操作日志表'
        # 显示的复数名称
        verbose_name_plural = verbose_name
        ordering = ['-id']


class PermissionModel(models.Model):
    type_choices =(
        (1, '模块'),
        (2, '菜单'),
        (3, '按钮')
    )

    name = models.CharField(max_length=64, verbose_name='权限名称')
    sign = models.CharField(max_length=32, unique=True, verbose_name='权限标志',error_messages={
        'unique': '权限标志不能重复'
    })
    icon = models.CharField(max_length=128, null=True, blank=True, verbose_name='图标')
    order_num = models.CharField(max_length=16, unique=True, verbose_name='编号',error_messages={
        'unique': '编号不能重复'
    })
    href = models.CharField(max_length=128, null=True, blank=True, verbose_name='菜单path')
    type = models.SmallIntegerField(choices=type_choices) #1模块 2菜单 3按钮
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="权限添加时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="权限修改时间")
    p_perm = models.ForeignKey(to='self', null=True, blank=True, on_delete=models.CASCADE, related_name='cld_perm', db_constraint=False, verbose_name='父权限')
    description = models.CharField(max_length=256, null=True, blank=True, verbose_name='描述')

    class Meta:
        db_table = 't_permission'
        verbose_name = '识别后台权限表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class RoleModel(models.Model):

    name = models.CharField(max_length=64, unique=True, verbose_name='角色名称',error_messages={
        'unique': '角色名称不能重复'
    })
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="角色添加时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="角色修改时间")
    description = models.CharField(max_length=256, null=True, blank=True, verbose_name='描述')

    class Meta:
        db_table = 't_role'
        verbose_name = '识别后台角色表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class RolePermissionModel(models.Model):
    role = models.ForeignKey(RoleModel, on_delete=models.CASCADE, related_name='perm_set', db_constraint=False, verbose_name='角色')
    perm = models.ForeignKey(PermissionModel, on_delete=models.CASCADE, related_name='role_set', db_constraint=False, verbose_name='权限')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="角色添加时间")

    class Meta:
        db_table = 't_role_permission'
        verbose_name = '识别后台角色权限表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class UserRoleModel(models.Model):
    b_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='role_set', db_constraint=False, verbose_name='用户')
    role = models.ForeignKey(RoleModel, on_delete=models.CASCADE, related_name='b_user_set', db_constraint=False, verbose_name='角色')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="角色添加时间")

    class Meta:
        db_table = 't_user_role'
        verbose_name = '识别后台用户角色表'
        # 显示的复数名称
        verbose_name_plural = verbose_name