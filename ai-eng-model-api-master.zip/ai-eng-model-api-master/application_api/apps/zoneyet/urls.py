#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/11/9上午11:00
#@Author:zwz
from django.urls import path

from zoneyet.views import ZoneyetPersonnelLocationView, ControlScopeView, PictureUpload, ZoneyetPersonnelView

urlpatterns = [
    # 人员坐标地图展示
    path('location', ZoneyetPersonnelLocationView.as_view({'get': 'list'})),
    # 中业人员管理
    path('personnel', ZoneyetPersonnelView.as_view({'get': 'list', 'post': 'create'})),
    path('personnel/<int:pk>', ZoneyetPersonnelView.as_view({'put': 'update', 'delete': 'destroy'})),
    # 防控区域管理
    path('control_scope', ControlScopeView.as_view({'get': 'list', 'post': 'create'})),
    path('control_scope/<int:pk>', ControlScopeView.as_view({'put': 'update', 'delete': 'destroy'})),
    # 头像等图片上传
    path('picture_upload', PictureUpload.as_view()),
    #
]