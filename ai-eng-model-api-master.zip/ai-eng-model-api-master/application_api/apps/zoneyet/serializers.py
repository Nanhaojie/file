#!/usr/bin/env python
#_*_coding:utf-8_*_
#@Time:2021/11/9上午11:22
#@Author:zwz
from rest_framework import serializers

from zoneyet.models import ZoneyetPersonnelModel, COVIDControlScopeModel, COVIDControlAreaModel


class ZoneyetPersonnelSerializer(serializers.ModelSerializer):

    class Meta:
        model = ZoneyetPersonnelModel
        fields = ['id', 'name', 'address', 'tel', 'photo', 'lng', 'lat']
        extra_kwargs = {
            'name': {'required': False},
            'address': {'required': False},
        }

class COVIDControlScopeSerializer(serializers.ModelSerializer):

    class Meta:
        model = COVIDControlScopeModel
        fields = ['id', 'lng', 'lat']


class COVIDControlAreaSerializer(serializers.ModelSerializer):

    class Meta:
        model = COVIDControlAreaModel
        fields = ['id', 'name', 'address', 'risk_level', 'lng', 'lat']
        extra_kwargs = {
            'risk_level': {'required': False}
        }