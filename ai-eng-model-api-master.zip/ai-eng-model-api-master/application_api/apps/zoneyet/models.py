from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class ZoneyetPersonnelModel(SpareFieldModel):

    name = models.CharField(max_length=32, verbose_name='名称')
    address = models.CharField(max_length=256, verbose_name='地址')
    tel = models.CharField(max_length=16, null=True, blank=True, verbose_name='电话')
    photo = models.CharField(max_length=256, null=True, blank=True, verbose_name='头像')
    lng = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name='经度')
    lat = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name='纬度')

    class Meta:
        # 指明数据库表名
        db_table = 't_zoneyet_personnel'
        # 在admin站点中显示的名称
        verbose_name = '中业人员信息'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class COVIDControlAreaModel(SpareFieldModel):

    risk_level_choice = [
        (1, '低风险地区'),
        (2, '中低风险地区'),
        (3, '中风险地区'),
        (4, '中高风险地区'),
        (5, '高风险地区')
    ]

    name = models.CharField(max_length=64, null=True, blank=True, verbose_name='名称')
    address = models.CharField(max_length=256, null=True, blank=True, verbose_name='详细地址')
    risk_level = models.SmallIntegerField(choices=risk_level_choice, verbose_name='风险登记')
    lng = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name="经度")
    lat = models.DecimalField(max_digits=20, decimal_places=17, null=True, blank=True, verbose_name="纬度")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")

    class Meta:
        db_table = 't_covid_control_area'
        # 在admin站点中显示的名称
        verbose_name = '新冠防控区域'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class COVIDControlScopeModel(SpareFieldModel):

    lng = models.DecimalField(max_digits=20, decimal_places=17, verbose_name="经度")
    lat = models.DecimalField(max_digits=20, decimal_places=17, verbose_name="纬度")
    control_area = models.ForeignKey(COVIDControlAreaModel, on_delete=models.CASCADE, related_name='control_scope_set', db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")

    class Meta:
        db_table = 't_covid_control_scope'
        # 在admin站点中显示的名称
        verbose_name = '疫情防控范围'
        # 显示的复数名称
        verbose_name_plural = verbose_name