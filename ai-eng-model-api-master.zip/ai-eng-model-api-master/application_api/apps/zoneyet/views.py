import logging
import time

from django.shortcuts import render

# Create your views here.
from filetype import filetype
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet

from utils.common import qiniu_upload
from zoneyet import serializers
from zoneyet.models import ZoneyetPersonnelModel, COVIDControlAreaModel, COVIDControlScopeModel

logger = logging.getLogger('django')

class ZoneyetPersonnelLocationView(ModelViewSet):
    pagination_class = None

    def get_queryset(self):
        return ZoneyetPersonnelModel.objects.all()

    def get_serializer_class(self):
        return serializers.ZoneyetPersonnelSerializer


class ZoneyetPersonnelView(ModelViewSet):

    def get_queryset(self):
        return ZoneyetPersonnelModel.objects.all()

    def get_serializer_class(self):
        return serializers.ZoneyetPersonnelSerializer


class ControlScopeView(ModelViewSet):

    def get_queryset(self):
        return COVIDControlAreaModel.objects.all()

    def get_serializer_class(self):
        return serializers.COVIDControlAreaSerializer

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        data = []
        for control_area in queryset:
            risk_level = control_area.risk_level
            scope = COVIDControlScopeModel.objects.filter(control_area_id=control_area.id)
            if not scope:
                continue
            data.append(
                {
                    'id': control_area.id,
                    'name': control_area.name,
                    'lng': control_area.lng,
                    'lat': control_area.lat,
                    'risk_level': risk_level,
                    'coor_data': serializers.COVIDControlScopeSerializer(scope, many=True).data
                })
        return Response(data=data, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        control_scope_list = request.data.get('control_scope_list')
        # if not control_scope_list:
        #     return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        if control_scope_list:
            for control_scope in control_scope_list:
                COVIDControlScopeModel(lng=control_scope[0], lat=control_scope[1], control_area_id=serializer.data['id']).save()
        return Response(status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        control_scope_list = request.data.get('control_scope_list')
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        if control_scope_list or control_scope_list == []:
            COVIDControlScopeModel.objects.filter(control_area_id=instance.id).delete()
            for control_scope in control_scope_list:
                COVIDControlScopeModel(lng=control_scope[0], lat=control_scope[1],
                                       control_area_id=instance.id).save()
        return Response(status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        return super(ControlScopeView, self).destroy(request, *args, **kwargs)

class PictureUpload(APIView):
    # permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': '文件不能为空'}, status=status.HTTP_200_OK)
        old_file_name = file.name
        new_file_name = 'zoneyet/personnel/photo/' + str(time.time()).replace('.', '') + '.' + old_file_name.split('.')[-1]
        ret = qiniu_upload(file.read(), file_name=new_file_name)
        # 返回资源类型
        file.seek(0)
        try:
            pic_type = (filetype.guess(file).mime or '').split('/')[1]
        except Exception:
            logger.warning('留言接口url参数校验失败', exc_info=True)
            pic_type = None
        return Response(data={'pic_url': ret, 'pic_type': pic_type}, status=status.HTTP_200_OK)

