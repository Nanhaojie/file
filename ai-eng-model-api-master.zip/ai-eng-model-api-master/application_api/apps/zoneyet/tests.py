# from django.test import TestCase

# Create your tests here.

import pandas as pd
import MySQLdb

df = pd.read_excel('./luoyang_2022-03-21.xlsx')
df = df.where(df.notnull(), '')
height, width = df.shape
print(df)
print(height, width)
print(df.iloc[0, 0], df.iloc[0, 1], df.iloc[0, 4], df.iloc[0, 5], df.iloc[0, 6])
conn = MySQLdb.connect(
    db='ddy',
    # host = '172.16.1.10',
    # port = 3309,
    # user = 'root',
    # password = 'root12300.',
    host='172.16.1.146',
    port=3307,
    user='zhangzhengwei',
    password='kaifaDDYzwz',
    charset='utf8',
)
cursor = conn.cursor()
for i in range(height):
    id = df.iloc[i, 0]
    if not id:
        break
    name = df.iloc[i, 1]
    addr = df.iloc[i, 4]
    lng = df.iloc[i, 5]
    lat = df.iloc[i, 6]
    sql = f'insert into  t_zoneyet_personnel(id, name, address, lng, lat) values ({id}, "{name}", "{addr}", {lng}, {lat})'
    if addr == '':
        sql = f'insert into  t_zoneyet_personnel(id, name, address) values ({id}, "{name}", " ")'
    print(sql)
    cursor.execute(sql)

conn.commit()
cursor.close()
