from django.db import models

# Create your models here.
from application_api.utils.models import SpareFieldModel


class ChartContent(SpareFieldModel):
    content = models.CharField(max_length=512, verbose_name="聊天内容")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = 't_chat_content'
        verbose_name = '聊天内容表'
        verbose_name_plural = verbose_name


class Chart(SpareFieldModel):
    user = models.ForeignKey("user.User", on_delete=models.CASCADE, db_constraint=False)
    q_content = models.ForeignKey(ChartContent, on_delete=models.CASCADE, db_constraint=False)
    a_content = models.ForeignKey(ChartContent, on_delete=models.CASCADE, db_constraint=False)

    class Meta:
        db_table = 't_chat'
        verbose_name = '聊天记录表'
        verbose_name_plural = verbose_name
