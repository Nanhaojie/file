from django.apps import AppConfig


class Text2SqlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'text2sql'
