from urllib.parse import quote

from django.test import TestCase

# Create your tests here.
import requests
from urllib.parse import quote

def zj_upload_sync(file, path='ddy'):
    files = {'file': file}
    options = {'path': path, 'scene': ''}  # 参阅浏览器上传的选项
    return requests.post('http://10.11.0.113:9909/upload', data=options, files=files).text


def get_img(url):
    resp = requests.get(url)
    img = resp.content
    return img


pdf = '/home/zhb/PycharmProjects/docr/pdf/455576051001地#.pdf'
res = zj_upload_sync(open(pdf, 'rb'))
sd = quote(res, safe='://')
print(res)
print(sd)

# im = get_img('http://172.16.1.144:8900/ddy/c85174604e9a5909416f4f3c1a218361.pdf')
# print(im)

class FileViewTest(TestCase):
    # 文件夹/文件-列表
    def test_get(self):
        resp = self.client.get('/api/file_ocr/file/787', HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)
    # 文件夹/文件-添加
    def test_post(self):
        data = {
            "url": "http://dtdfile.zoneyet.com:9909/default/20210531/10/05/3/385475465091001.pdf",
            "name": "test1.pdf",
            "upload_status": "1",
            "p_file": "787",
            "type": 1
        }
        resp = self.client.post('/api/file_ocr/file?is_force=1', data=data, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)
    # 文件夹/文件-批量删除
    def test_delete(self):
        data = {
            "pks": [5667]
        }
        resp = self.client.delete('/api/file_ocr/file', data=data, HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # 文件夹 / 文件 - 文件搜索
    def test_search(self):
        resp = self.client.get('/api/file_ocr/file?page=1&page_size=2',
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # def test_patch(self):
    #     pass

# 此接口不再使用
# class FileBatchUploadViewTest(TestCase):
#
#     def test_post(self):
#         resp = self.client.post('/api/file_ocr/file?is_force=1',
#                                 HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
#         self.assertEqual(resp.status_code, 200)

class MoveFilesViewTest(TestCase):
    # 文件夹/文件-批量移动
    def test_put(self):
        data = {
            "pks": [479],
            "p_file_id": 395
        }
        resp = self.client.put('/api/file_ocr/files_move', data=data,
                                  HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class FileOcrViewTest(TestCase):
    # ocr数字化-结果查询-web
    def test_get(self):
        resp = self.client.get('/api/file_ocr/ocr/2267',
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

    # ocr数字化-结果更新-web
    def test_put(self):
        data = {
            "id": 2267,
            "model_name": "eng_model",
            "field_name": "eng_name",
            "field_content": "郑州51中数学楼及地下车程111"
        }
        resp = self.client.put('/api/file_ocr/ocr/2267', data=data,
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class FileBatchOcrViewTest(TestCase):
    # ocr数字化-批量
    def test_post(self):
        data = {
            "pks": [787]
        }
        resp = self.client.post('/api/file_ocr/ocr', data=data,
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)
    # ocr数字化-批量取消
    def test_delete(self):
        data = {
            "pks": [787]
        }
        resp = self.client.delete('/api/file_ocr/ocr', data=data,
                                HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class ExportDataViewTest(TestCase):
    # ocr导出-单个
    def test_get(self):
        resp = self.client.get('/api/file_ocr/export_data/787',
                                  HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class BatchExportDataViewTest(TestCase):
    # ocr导出-批量压缩zip
    def test_post(self):
        data = {
            "pks": [787]
        }
        resp = self.client.post('/api/file_ocr/export_datas', data=data,
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class BatchFileDownloadViewTest(TestCase):
    # 文件夹/文件-批量压缩zip下载
    def test_post(self):
        data = {
            "pks": [5693]
        }
        resp = self.client.post('/api/file_ocr/exports_files', data=data,
                                HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class UserUploadStatTest(TestCase):
    # 首页统计-上传文件
    def test_get(self):
        resp = self.client.get('/api/file_ocr/upload_stat',
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class UserOCRStatTest(TestCase):
    # 首页统计-ocr成功
    def test_get(self):
        resp = self.client.get('/api/file_ocr/ocr_stat',
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)

class UserFileStatTest(TestCase):
    # 首页统计-用户上传文件数量排行
    def test_get(self):
        data = {
            "days": 6
        }
        resp = self.client.get('/api/file_ocr/users_stat', data=data,
                               HTTP_AUTHORIZATION='JWT 833b312bff5216ca6c38059b2c5e56d6')
        self.assertEqual(resp.status_code, 200)