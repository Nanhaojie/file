#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：app_main.py
@Author ：nhj
@Date ：2021/5/20 下午8:06 
'''

#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：pdf_ocr.py
@Author ：nhj
@Date ：2021/4/22 上午9:56 
'''
from pdf_ocr.models import FileModel
from pdf_ocr.tools.app_database import in_db
from pdf_ocr.tools.Table import Table
from pdf_ocr.services.service import ocr_all
import json
import numpy as np
import cv2
from pdf_ocr.tools.update_database import in_db_update
from utils.common import get_img


def table_ocr_merge(id, ocr_result, table_result, jz_imgs):
    tables = list()
    tb = Table()
    coors = []
    urls = jz_imgs
    for i, result in enumerate(ocr_result):
        t_lay = table_result[i]
        # ocr识别的坐标转化为4*2的
        ocr_coors = []
        for ocr_table in result['points']:
            ocr_coor = []
            for c in range(0, len(ocr_table), 2):
                ocr_coor.append([ocr_table[c], ocr_table[c + 1]])
            ocr_coors.append(ocr_coor)

        p_img = [ocr_coors,  result['label']]

        # 补救table模型未识别准确
        img = cv2.imdecode(np.asarray(bytearray(get_img(urls[i])), dtype='uint8'), cv2.IMREAD_COLOR)
        desc = tb.search_desc(p_img, t_lay)
        if isinstance(desc, list):
            cols = tb.search_col(t_lay, desc)
            desc = tb.hoff_line(cols, img)
            t_lay = tb.del_add(t_lay, desc)
        merge = tb.ocr_merge_layout(p_img, t_lay)
        table_layout = tb.semantic_layout(merge)
        table_layout['page'] = i
        tkv = tb.semantic_kv(table_layout, img)
        tables.append(tkv)

        # 坐标
        # coor = [i['table_text_coor'] for i in merge]
        coors.append(merge)

    holes = tb.merge_hole_no(tables)
    for hole in holes:
        hole['file_id'] = id
        hole['position_info'] = coors

    in_db(holes)


def table_ocr_merge_update(pk, merges):
    tables = list()
    tb = Table()
    coors = []
    file = FileModel.objects.filter(id=pk).first()

    img_urls = eval(file.ocr_img_urls)
    for i, merge in enumerate(merges):

        img = cv2.imdecode(np.asarray(bytearray(get_img(img_urls[i])), dtype='uint8'), cv2.IMREAD_COLOR)
        table_layout = tb.semantic_layout(merge)
        table_layout['page'] = i
        tkv = tb.semantic_kv(table_layout, img)
        tables.append(tkv)
        coors.append(merge)

    holes = tb.merge_hole_no(tables)
    for hole in holes:
        hole['file_id'] = pk
    in_db_update(holes, merges)