import json
from pdf_ocr.tools.common import calculation_deep
import time
from pdf_ocr.models import FileModel, EngInfoModel, LandInfoModel
import logging
logger = logging.getLogger("django")


def mer_coor(coors):
    try:
        return [coors[0][0], coors[-1][-1], coors[0][1], coors[0][2]]
    except:
        return []


def in_db_update(engs, merges):
    with open('apps/pdf_ocr/tools/table.json') as t:
        tj = json.load(t)

    for eng_land_index, hole in enumerate(engs):
        id = hole['file_id']
        file = FileModel.objects.get(id=id)
        eng_info = [tables['eng_info'] for tables in hole['content']]
        # 选择效果好的表头入库,需要融入表字段
        keys = [len(tmp['item']) for line in eng_info for tmp in line]
        if eng_info:
            # 选取孔号中第一个工程信息
            keys = list()
            values = list()
            eng_info = eng_info[0][0]
            for item in eng_info['item']:
                try:
                    key = item['key']['text']
                except:
                    key = None
                try:
                    value = item['value']['text']
                    value_coor = item['value']['coordinate']
                except:
                    value = None
                    value_coor = None
                if key and value:
                    t = [k for k, v in tj['eng_info'].items() if key in v]
                    if t:
                        if t[0] in keys:
                            ti = -1
                            for ki, vl in enumerate(keys):
                                if vl == t[0]:
                                    ti = ki
                                    break
                            if ti != -1:
                                values[ti] = str(values[ti]) + ';' + str(value)
                        else:
                            keys.append(t[0])
                            values.append(value)
                if key and value_coor:
                    t = [k + '_coor' for k, v in tj['eng_info'].items() if key in v]
                    if t:
                        if t[0] in keys:
                            ti = -1
                            for ki, vl in enumerate(keys):
                                if vl == t[0]:
                                    ti = ki
                                    break
                            if ti != -1:
                                values[ti] = str(values[ti]) + ';' + str(value_coor)
                        else:
                            keys.append(t[0])
                            values.append(value_coor)
            keys.append('create_time')
            values.append(time.strftime("%Y-%m-%d %H:%M:%S"))
            keys.append('file_id')
            values.append(id)

            EngInfoModel.objects.create(**dict(zip(keys, values)))

        # 土地信息
        land_info = [tables['land_info'] for tables in hole['content']]
        for p, land_info_png in enumerate(land_info):
            values = list()
            page = hole['content'][p]['page']
            for items in land_info_png:
                t_value = list()
                keys = list()
                for item in items['item']:
                    try:
                        key = item['key']['text']
                    except:
                        key = None
                    try:
                        value = item['value']['text']
                        land_coor = item['value']['coordinate']
                    except:
                        value = None
                        land_coor = None
                    if key and value:
                        t = [k for k, v in tj['land_info'].items() if key in v]
                        if t:
                            keys.append(t[0])
                            t_value.append(value)
                    if key and land_coor:
                        t = [k + '_coor' for k, v in tj['land_info'].items() if key in v]
                        if t:
                            keys.append(t[0])
                            t_value.append(land_coor)
                if keys and t_value:
                    keys.append('create_time')
                    t_value.append(time.strftime("%Y-%m-%d %H:%M:%S"))

                    keys.append('eng_info_id')
                    eng_info_id = file.eng_info_set.values()[eng_land_index]['id']
                    t_value.append(eng_info_id)

                    keys.append('page')
                    t_value.append(page)

                    LandInfoModel.objects.create(**dict(zip(keys, t_value)))

        # 计算深度
        for p, tables in enumerate(hole['content']):
            # 深度信息
            page_deep = hole['content'][p]['page']
            sj_qy_value = []
            sj_bg_value = []
            js_qy_value = []
            js_bg_value = []
            stable_water_level = []
            penetration_hit = []
            note = []
            resistance_limit = []
            bearing_capacity = []
            friction_force = []
            sampling_coor = []
            penetration_depth_coor = []
            penetration_hit_coor = []
            stable_water_level_coor = []
            note_coor = []
            resistance_limit_coor = []
            bearing_capacity_coor = []
            friction_force_coor = []
            geological_age = []
            geological_age_coor = []
            for items in tables['deep_info']:
                try:
                    key = items['key']['text']
                except:
                    key = None
                try:
                    value = items['value']['text']
                    value_coor = items['value']['coordinate']
                except:
                    value = None
                    value_coor = None

                # 计算深度
                if key in tj['deep_info']['sampling']:
                    try:
                        js_qy_value = calculation_deep(hole)[0]
                    except:
                        js_qy_value = None
                        logger.warning(f"该文件id:{id}没有取样这一列")
                elif key in tj['deep_info']['penetration_depth']:
                    try:
                        js_bg_value = calculation_deep(hole)[1]
                    except:
                        js_bg_value = None
                        logger.warning(f"该文件id:{id}没有标贯深度这一列")

                # 实际深度
                if key in tj['deep_info']['sampling']:
                    sj_qy_value.append(value)
                    sampling_coor.append(value_coor)
                if key in tj['deep_info']['penetration_depth']:
                    sj_bg_value.append(value)
                    penetration_depth_coor.append(value_coor)

                # 标贯击数
                if key in tj['deep_info']['penetration_hit']:
                    penetration_hit.append(value)
                    penetration_hit_coor.append(value_coor)

                # 稳定水位
                if key in tj['deep_info']['stable_water_level']:
                    stable_water_level.append(value)
                    stable_water_level_coor.append(value_coor)

                # 附注
                if key in tj['deep_info']['note']:
                    note.append(value)
                    note_coor.append(value_coor)

                # 桩侧阻极限标准值
                if key in tj['deep_info']['resistance_limit']:
                    resistance_limit.append(value)
                    resistance_limit_coor.append(value_coor)

                # 承载力基本容许值
                if key in tj['deep_info']['resistance_limit']:
                    bearing_capacity.append(value)
                    bearing_capacity_coor.append(value_coor)

                # 桩侧摩阻力标准值
                if key in tj['deep_info']['resistance_limit']:
                    friction_force.append(value)
                    friction_force_coor.append(value_coor)

                # 时代成因
                if key in tj['deep_info']['geological_age']:
                    geological_age.append(value)
                    geological_age_coor.append(value_coor)

            eng_info_id1 = file.eng_info_set.values()[eng_land_index]['id']

            deep_value = [page_deep, eng_info_id1, time.strftime("%Y-%m-%d %H:%M:%S"), str(sj_qy_value), str(sj_bg_value),
                          str(js_qy_value), str(js_bg_value),str(penetration_hit), str(stable_water_level), str(note),
                          str(resistance_limit), str(bearing_capacity),str(friction_force), str(mer_coor(sampling_coor)),
                          str(mer_coor(penetration_depth_coor)), str(mer_coor(penetration_hit_coor)),
                          str(mer_coor(stable_water_level_coor)), str(mer_coor(note_coor)), str(mer_coor(resistance_limit_coor)),
                          str(mer_coor(bearing_capacity_coor)), str(mer_coor(friction_force_coor)),
                          str(mer_coor(geological_age)), str(mer_coor(geological_age_coor))]
            deep_keys = ['page', 'eng_info_id', 'create_time', 'actual_sampling', 'actual_penetration_depth','sampling',
                         'penetration_depth', 'penetration_hit', 'stable_water_level', 'note', 'resistance_limit',
                         'bearing_capacity', 'friction_force', 'sampling_coor', 'penetration_depth_coor',
                         'penetration_hit_coor', 'stable_water_level_coor', 'note_coor', 'resistance_limit_coor',
                         'bearing_capacity_coor', 'friction_force_coor', 'geological_age', 'geological_age_coor']

            # DeepInfoModel.objects.create(**dict(zip(deep_keys, deep_value)))

        # 更新t_file表table的坐标，及对应的文本
        file.position_info = str(merges)
        file.save()