import io
import itertools
from functools import reduce

import fitz
import pdfplumber
import cv2
import numpy as np
import re
from PIL import Image
import uuid
import pandas as pd
import json
import copy
from pdf_ocr.services.correction.keyword import similar

DEBUG = False


def is_key(text, include: list = None, all_key=True):
    key_words_json_file_path = 'apps/pdf_ocr/tools/table.json'
    assert all_key or include, 'all_key为False 需要指定include'
    if all_key:
        key_words_json_list_list = list(itertools.chain(*list(itertools.chain(
            *[[cell for cell in item.values()] for item in json.load(open(key_words_json_file_path)).values()
              if isinstance(item, dict)]))))
    else:
        key_words_json_list_list = list(itertools.chain(*list(itertools.chain(
            *[[cell for cell in item.values()] for key, item in json.load(open(key_words_json_file_path)).items()
              if key in include]))))
    match_reg = '|'.join(list(map(lambda x: re.sub(r'\(.*?\)|[\(\)m]', '', x), key_words_json_list_list)))
    pre_text = re.sub(r'\s', '', str(text))
    correction_text = similar([pre_text])[0]
    if re.match(match_reg, correction_text, re.I) or re.match(match_reg, pre_text, re.I):
        return correction_text


def show_result(src, window_name, d=True):
    if d:
        cv2.namedWindow(window_name, 0)
        cv2.resizeWindow(window_name, 888, 888)
        cv2.imshow(window_name, src)
        while True:
            k = cv2.waitKey(0)
            if k == ord('q'):
                cv2.destroyAllWindows()
                break


def pdf2img_deprecated1(src: str):
    """
    src: pdf_path
    return list[cv2_img]
    ref:https://github.com/jsvine/pdfplumber
    """
    images = list()
    with pdfplumber.open(src) as pdf:
        for page in pdf.pages:
            im = page.to_image(resolution=150)
            # im.save('kk.png', format="PNG")
            img = im.annotated
            c = cut_img(img)
            images += c
    return images


def pdf2img(src: str):
    pdfDoc = fitz.open(src)
    images = list()
    for pg in range(pdfDoc.pageCount):
        page = pdfDoc[pg]
        rotate = int(0)
        # 每个尺寸的缩放系数为1.3，这将为我们生成分辨率提高2.6的图像。
        # 此处若是不做设置，默认图片大小为：792X612, dpi=72
        zoom_x = 2.1  # (1.33333333-->1056x816)   (2-->1584x1224)
        zoom_y = 2.1
        mat = fitz.Matrix(zoom_x, zoom_y).preRotate(rotate)
        pix = page.getPixmap(matrix=mat, alpha=False)
        barr = pix.getPNGData()
        img = Image.open(io.BytesIO(barr))
        c = cut_img(img)
        images += c
        # pix.writePNG('./' + src + '%s.png' % pg)  # 将图片写入指定的文件夹内
    return images


def pdf2img_deprecated2(src: str):
    """
    src: pdf_path
    return list[cv2_img]
    ref:
    """
    images = list()
    checkXO = r"/Type(?= */XObject)"
    checkIM = r"/Subtype(?= */Image)"
    doc = fitz.open(src)
    imgcount = 0
    lenXREF = doc._getXrefLength()
    for i in range(1, lenXREF):
        text = doc._getXrefString(i)
        isXObject = re.search(checkXO, text)
        isImage = re.search(checkIM, text)
        if not isXObject or not isImage:
            continue
        imgcount += 1
        pix = fitz.Pixmap(doc, i)
        barr = pix.getPNGData()
        img = Image.open(io.BytesIO(barr))
        # img = cv2.cvtColor(np.asarray(img_name), cv2.COLOR_RGB2BGR)
        images.append(img)
    return images


def sx(img_sx):
    gray = cv2.cvtColor(img_sx, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(~gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, -5)
    rows, cols = binary.shape
    scale = 20
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, rows // scale))
    eroded = cv2.erode(binary, kernel, iterations=1)
    dilatedrow_row = cv2.dilate(eroded, kernel, iterations=1)
    return dilatedrow_row


def cut_img(src):
    """
    src: cv2_img
    return list[cv2_img]
    """
    cv_src = np.asarray(src)
    h2 = int(cv_src.shape[0] / 2) - 50
    h1 = int(cv_src.shape[0] / 2) + 50
    img_dis = cv_src[h2:h1, :]
    # show_result(img_dis, 'cut')
    dilatedrow_dis = sx(img_dis)
    # 任取一列所有竖线的一行，如果255，说明存在黑线
    dat_dis = dilatedrow_dis[50]
    qs_dis = []
    for q_dis in range(len(dat_dis)):
        if dat_dis[q_dis] == 255:
            qs_dis.append(q_dis)
    # 如果两个相邻的像素相差大于10，说明是两条竖线
    my_dis = []
    xs_dis = np.sort(qs_dis)
    num_row = 0
    for m_dis in range(len(xs_dis) - 1):
        if xs_dis[m_dis + 1] - xs_dis[m_dis] > 10:
            my_dis.append(xs_dis[m_dis])
        num_row += 1
    my_dis.append(xs_dis[num_row])

    if len(my_dis) > 19:
        img1 = src.crop((0, 0, int(src.width / 2), int(src.height)))
        img2 = src.crop((int(src.width / 2), 0, int(src.width), int(src.height)))
        return [img1, img2]
    else:
        return [src]


def structure_layout(src):
    """
    src: cv2_img
    return list[dict{'img':cv2_img, 'coordinates':[]}]
    """
    pass


def ocr_merge_layout(ocr_cell, layout_cell):
    """
    ocr_cell: list[dict{'img':cv2_img, 'coordinates':[], 'text':''}]
    layout_cell: list[dict{'img':cv2_img, 'coordinates':[]}]
    return layout_cell->list[dict{'img':cv2_img, 'coordinates':[], 'text':''}]
    """
    dt_boxes = ocr_cell[0]
    boxes = dt_boxes
    rec_res = ocr_cell[-1]
    sheet1_hx_all = []
    for lxy in range(len(layout_cell[0])):
        sheet1_hx = []
        for c in range(len(layout_cell[0][lxy])):
            cell = []

            for sxy in range(len(boxes)):
                if layout_cell[0][lxy][c][1] < boxes[sxy].mean(axis=0)[0] < layout_cell[0][lxy][c][2] and \
                        layout_cell[0][lxy][c][0] < \
                        boxes[sxy].mean(axis=0)[1] < layout_cell[0][lxy][c][3]:
                    cell.append(rec_res[sxy][0])
            sheet1_hx.append("".join([line for line in cell]))
        sheet1_hx_all.append(sheet1_hx)

    sheet2_hx_all = []
    for lxy in range(len(layout_cell[1])):
        sheet2_hx = []
        for c in range(len(layout_cell[1][lxy])):
            cell = []
            for sxy in range(len(boxes)):
                if layout_cell[1][lxy][c][0] < boxes[sxy].mean(axis=0)[0] < layout_cell[1][lxy][c][2] and \
                        layout_cell[1][lxy][c][1] < \
                        boxes[sxy].mean(axis=0)[1] < layout_cell[1][lxy][c][3]:
                    cell.append(rec_res[sxy][0])
            sheet2_hx.append("".join([line for line in cell]))
        sheet2_hx_all.append(sheet2_hx)
    sheet1 = []
    sheet2 = []
    for i in range(len(sheet1_hx_all)):
        cell_txt1 = []
        for j in range(len(sheet1_hx_all[i])):
            cell1 = dict()
            cell1['coor'] = layout_cell[0][i][j]
            cell1['txt'] = sheet1_hx_all[i][j]
            cell_txt1.append(cell1)
        sheet1.append(cell_txt1)
    for i in range(len(sheet2_hx_all)):
        cell_txt2 = []
        for j in range(len(sheet2_hx_all[i])):
            cell2 = dict()
            cell2['coor'] = layout_cell[1][i][j]
            cell2['txt'] = sheet2_hx_all[i][j]
            cell_txt2.append(cell2)
        sheet2.append(cell_txt2)
    return sheet1, sheet2


def sort_same(x_hand, all):
    """
    :param x_hand: 所有单元格的第一个坐标list
    :param all: 所有单元格的坐标list
    :return: 排好序的单元格的坐标list
    """
    input_array = np.array(x_hand)
    out_array = [np.where(abs(input_array - element) < 10)[0].tolist() for element in np.unique(input_array)]
    sort_np = np.unique(out_array)
    zu = []
    for i in range(len(sort_np)):
        same = []
        for j in range(len(sort_np[i])):
            try:
                all[sort_np[i][j]][0] = all[sort_np[i][1]][0]
            except:
                print(all[sort_np[i][j]])
            same.append(all[sort_np[i][j]])
        zu.append(sorted(same))
    return zu


def sort_sheet(sheet2):
    """

    :param sheet2:
    :return: 竖排序后的坐标list
    """
    for i in range(len(sheet2)):
        for j in range(len(sheet2[i])):
            sheet2[i][j][0], sheet2[i][j][1] = sheet2[i][j][1], sheet2[i][j][0]
    xys = []
    x1s = []
    tmp_dict = {}
    for i in range(len(sheet2)):
        for j in range(len(sheet2[i])):
            x1, y1, x2, y3 = sheet2[i][j][0], sheet2[i][j][1], sheet2[i][j][2], sheet2[i][j][3]
            xys.append([x1, y1, x2, y3])
            x1s.append(x1)
            tmp_dict[x1] = [x1, y1, x2, y3]
    input_array = np.array(x1s)
    out_array = [np.where(abs(input_array - element) < 10)[0].tolist() for element in np.unique(input_array)]
    sort_np = np.unique(out_array)
    zu = []
    for i in range(len(sort_np)):
        same = []
        for j in range(len(sort_np[i])):
            if j != 0:
                xys[sort_np[i][j]][0] = xys[sort_np[i][1]][0]
            same.append(xys[sort_np[i][j]])
        zu.append(sorted(same))
    return zu


def semantic_layout(src):
    """
    src: 模型识别表格后返回的坐标list
    return list[dict{'semantic': 'head', 'img':cv2_img, 'coordinates':[]}]
    """
    xys = []
    x1s = []
    for i in range(len(src)):
        for j in range(len(src[i])):
            x1, y1, x2, y3 = int(src[i][j].split('.')[0]), int(src[i][j].split('.')[1]), int(
                src[i][j].split('.')[2]), int(src[i][j].split('.')[3])
            xys.append([x1, y1, x2, y3])
            x1s.append(x1)
    zu = sort_same(x1s, xys)
    max_len = []
    for i in range(len(zu)):
        max_len.append(len(zu[i]))
    sheet1 = zu[0: max_len.index(max(max_len))]
    sheet2 = zu[max_len.index(max(max_len)):]
    sheet2 = sort_sheet(sheet2)
    return [sheet1, sheet2]


def semantic_kv(src):
    """
    src: cv2_img
    return list[dict{'semantic': 'head', 'img':cv2_img, 'coordinates':[]}]
    """
    pass


def merge_hole_no(tables):
    hole_no = list()
    tb = list()
    hole = list()
    # table-key-value
    for i, table in enumerate(tables):
        key = 'boring_id'
        value = str(uuid.uuid1())
        t_item = {'key': key, 'value': value}
        # eng_info
        eng_info = dict()
        eng_info['name'] = 'eng_info'
        eng_info['content'] = list()
        eng_info['content'].append(t_item)
        for f_info in table[0]:
            if len(f_info) % 2 == 0:
                for index, value in enumerate(f_info):
                    if index % 2 == 0:
                        key = value['txt']
                        value = f_info[index + 1]
                        item = {'key': key, 'value': value}
                        eng_info['content'].append(item)
                        if key == '孔号' or key == '号孔' or key == '钻孔编号' or key == '孔口' or key == '钻探井号' or key == '探井号':
                            hole.append((value['txt'], i))

        land_info = dict()
        land_info['name'] = 'land_info'
        land_info['content'] = list()
        land_info['content'].append(t_item)
        for f_info in table[1]:
            key = f_info[0]['txt']
            value = f_info[1:]
            item = {'key': key, 'value': value}
            land_info['content'].append(item)
        tb.append([eng_info, land_info])

    # 孔号合并
    h = set([line[0] for line in hole])
    h2p = list()
    for s in h:
        d_hole = dict()
        d_hole['num'] = s
        d_hole['png'] = list()
        for l in hole:
            if s == l[0]:
                d_hole['png'].append(l[-1])
        h2p.append(d_hole)

    rst = list()
    for num in h2p:
        t_rst = dict()
        t_rst['eng_info'] = list()
        t_rst['land_info'] = list()

        t_rst['eng_info'] = tb[num['png'][0]][0]
        for t_index in num['png']:
            t_rst['land_info'].append(tb[t_index][-1])
        rst.append(t_rst)
    out_excel(rst)
    return rst


def out_excel(tables):
    tmp = open('tools/tmp.json')
    tj = json.load(tmp)
    tables = list()
    tables.append(tj)
    tj = dict()
    with open('tools/table.json') as t:
        tj = json.load(t)
    eng_fields = tj['eng_info'].keys()

    eng_table = pd.DataFrame(columns=eng_fields, dtype=str)
    for table in tables:
        item = dict()
        for field in table['eng_info']['content']:
            t = [key for key, value in tj['eng_info'].items() if field['key'] in value]
            if t:
                item[t[0]] = field['value']['txt']
        eng_table = eng_table.append(copy.deepcopy(item), ignore_index=True)

    eng_table.to_excel('tmp.xlsx', index=False)


def single_deep(img, deep_hx, unit_len):
    '''
    计算单张图片的深度
    :param img:
    :param deep_hx: 是否有横线
    :param unit_len: 单位像素的长度
    :return: list
    '''
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(~img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, -5)
    wits = []
    for wit in range(len(binary)):
        if deep_hx == 0:
            if sum(binary[wit]) > 11 * 255:
                wits.append(wit)
        else:
            if sum(binary[wit]) > 60 * 255:
                wits.append(wit)
    nums = []
    nu = 0
    for num in range(len(wits) - 1):
        if wits[num + 1] - wits[num] > 5:
            nums.append(wits[num])
        nu += 1
    nums.append(wits[nu])
    deeps = []
    for cal in range(len(nums) - 1):
        deep = ('%.2f' % ((nums[cal + 1] - nums[0]) * unit_len))
        deeps.append(eval(deep))
    return deeps


def multiple_deep(deeps):
    '''
    多张图片的深度累加
    :param deeps:
    :return: list
    '''
    dv = deeps[0][-1]
    for line in deeps[1:]:
        for i, v in enumerate(line):
            line[i] += dv
            if i == len(line) - 1:
                dv = line[i]
    a = sum(deeps, [])
    return np.around(np.array(a), 2)


def calculation_deep(src):
    '''
    计算深度，生成sheet3
    :param src:
    :return:
    '''
    with open('apps/pdf_ocr/tools/table.json') as t:
        tj = json.load(t)
    content = src['content']
    land_info = content[0]['land_info']
    item = land_info[0]['item']

    unit_len = 0
    for land_item in item:
        head = land_item['key']['text']
        head = similar([head])[0]
        if head in tj['land_info']['bottom_depth']:
            coor = land_item['value']['coordinate']
            txt = land_item['value']['text']
            unit_len = float(txt) / abs(coor[-1] - coor[0])

    bg_deeps = []
    qy_deeps = []
    for info in content:
        deep_info = info['deep_info']
        img = info['img']
        img = np.array(img)
        qy_coors = []
        bg_coors = []
        for deep in deep_info:
            title = deep['key']['text']
            title = similar([title])[0]
            if title in tj['deep_info']['penetration_depth']:
                gb_coor = deep['value']['coordinate']
                bg_coors.append(gb_coor)
            elif title in tj['deep_info']['sampling']:
                qy_coor = deep['value']['coordinate']
                qy_coors.append(qy_coor)
        if bg_coors:
            img = img[bg_coors[0][0] + 5:bg_coors[-1][-1] + 9, bg_coors[0][1] + 3:bg_coors[0][2] - 4]
            if len(bg_coors) == 1:
                deep_hx = 0
            else:
                deep_hx = 1
            try:
                bg_deep = single_deep(img, deep_hx, unit_len)
                bg_deeps.append(bg_deep)
            except:
                pass
            # cv2.imwrite(str(time.time()) + '.png', img)
        if qy_coors:
            img = img[qy_coors[0][0] + 5:qy_coors[-1][-1] + 9, qy_coors[0][1] + 1:qy_coors[0][2] - 2]
            if len(bg_coors) == 1:
                deep_hx = 0
            else:
                deep_hx = 1
            try:
                qy_deep = single_deep(img, deep_hx, unit_len)
                qy_deeps.append(qy_deep)
            except:
                pass
            # cv2.imwrite(str(time.time()) + '.png', img)
    try:
        bg_deepss = multiple_deep(bg_deeps)
    except:
        bg_deepss = ['']
    try:
        qy_deepss = multiple_deep(qy_deeps)
    except:
        qy_deepss = ['']
    return qy_deepss, bg_deepss


def calculation_depth(holes):
    with open('tools/table.json') as t:
        tj = json.load(t)
    for hole in holes:
        qy_value = []
        bg_value = []
        for tables in hole['content']:
            # 深度信息
            for items in tables['deep_info']:
                key = items['key']['text']
                if key in tj['deep_info']['sampling']:
                    try:
                        qy_value = calculation_deep(hole)[0]
                    except:
                        qy_value = None
                        print('获取不到深度列')
                elif key in tj['deep_info']['penetration_depth']:
                    try:
                        bg_value = calculation_deep(hole)[1]
                    except:
                        bg_value = None
                        print('获取不到深度列')
        hole['calculation_deth'] = [qy_value, bg_value]
    return holes


if __name__ == '__main__':
    out_excel('kkk')
