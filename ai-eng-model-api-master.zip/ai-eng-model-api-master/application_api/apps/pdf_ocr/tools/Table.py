import re

import numpy as np
import json
import pandas as pd
import copy
from itertools import islice
from pdf_ocr.tools.common import calculation_deep, is_key
from pdf_ocr.services.correction.keyword import similar
from pdf_ocr.services.service import formula
import cv2
import logging

logger = logging.getLogger("django")


class Table():

    def __init__(self):
        self.mode = int()
        self.dt = list()
        with open('apps/pdf_ocr/tools/table.json') as t:
            tj = json.load(t)
        self.tj = tj

    def search_desc(self, ocr_cell, layout_cell):
        """
        ocr_cell: list[dict{'img':cv2_img, 'coordinates':[], 'text':''}]
        layout_cell: list[dict{'img':cv2_img, 'coordinates':[]}]
        return layout_cell->list[dict{'coordinates':[], 'text':''}]
        """
        boxes = ocr_cell[0]
        rec_res = ocr_cell[-1]
        rst = list()
        for lxy in layout_cell:
            cell = dict()
            cell['coordinate'] = lxy
            cell['text'] = str()
            tc = list()
            for index, content in enumerate(boxes):
                center = np.array(content).mean(axis=0)
                # 小矩形扔进大矩形
                if lxy[1] < center[0] < lxy[2] and lxy[0] < center[1] < lxy[3]:
                    tc.append(rec_res[index])
            target = "".join([line for line in tc])
            target = similar([target])[0]
            if target in self.tj['land_info']['lithology_description']:
                return lxy
        return -1

    def search_col(self, layout_cell, target):
        rst = list()
        for index, line in enumerate(layout_cell):
            try:
                if line[0] > target[0]:
                    if abs(line[1] - target[1]) < 10:
                        rst.append((index, line))
            except:
                logger.warning(f"岩性描述列补救寻找列")
        return rst

    def thr(self, thr, src):
        '''
        thr: int->阈值
        src: list->list->num1, num2, num3, num4
        flag: 归一阈值的位置信息，0是根据第一个元素归一，1是第二个，以此类推
        '''
        for i in range(len(src) - 1):
            if abs(src[i] - src[i + 1]) < thr:
                src[i + 1] = src[i]
        return list(set(src))

    def hoff_line(self, desc_list, img):
        hl = list()
        for t in desc_list:
            img = np.asarray(img)
            tm = img[t[1][0]:t[1][3], t[1][1]:t[1][2]]

            gray = cv2.cvtColor(tm, cv2.COLOR_BGR2GRAY)
            binary = cv2.adaptiveThreshold(~gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, -5)
            rows, cols = binary.shape
            scale = 40
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (cols // scale, 1))
            eroded = cv2.erode(binary, kernel, iterations=1)
            dilatedcol = cv2.dilate(eroded, kernel, iterations=1)

            # 寻找长度为宽度30%的横线
            w = t[1][2] - t[1][1]
            w = w * 0.4
            rst = list()
            for index, d in enumerate(dilatedcol):
                if index > 30 and index < len(dilatedcol) - 30:
                    if sum(d) > 255 * w:
                        rst.append(index)

            #  因为倾斜缘故，剔除横线距离比较近的横线
            rst = self.thr(4, rst)
            rst.sort()
            # for i in range(len(rst) - 1):
            #     rst[i + 1] = rst[i + 1] - rst[i]

            # 根据横线切出新的矩形
            small = list()
            trst = [t[1][0]] + [t[1][0] + line for line in rst] + [t[1][-1]]
            for i in range(len(trst) - 1):
                small.append([trst[i], t[1][1], t[1][2], trst[i + 1]])
            # r = t[1][0]
            # c = t[1][0]
            # small = list()
            # for i, line in enumerate(rst):
            #     c += line
            #     tm = img[r:c, t[1][1]:t[1][2]]
            #     small.append([r, t[1][1], t[1][2], c])
            #     r = c
            hl.append((t[0], small))
        return hl

    def del_add(self, desc, hl):
        pop = hl[::-1]
        for line in pop:
            try:
                if len(line[1]) > 1:
                    desc.pop(line[0])
            except:
                logger.warning(f"没有:{line}")

        for line in pop:
            if len(line[1]) > 1:
                for small in line[1]:
                    desc.append(small)
        return desc

    def sort_box(self, ocrcell):
        means = []
        p1 = ocrcell[0]
        for ele in range(len(p1)):
            a1 = p1[ele]
            mean = np.array(a1).mean(axis=0)
            means.append(mean.mean(axis=0))
        means = np.array(means)
        # print(means)
        sorted_id = sorted(range(len(means)), key=lambda k: means[k], reverse=False)
        ocrcell[0] = np.array(ocrcell[0])[sorted_id]
        ocrcell[1] = np.array(ocrcell[1])[sorted_id]
        return ocrcell

    def extract_projectname(self, ocrcell):
        means = []
        boxes = ocrcell[0]
        temp = 20
        thredhold = 30
        gongcheng = []
        flage = 0
        dict = list()
        if len(boxes) < temp:
            temp = len(boxes)
        for ele in range(temp):
            box = boxes[ele]
            mean = np.array(box).mean(axis=0)
            if ocrcell[1][ele] == '工程名称':
                gongcheng = [ocrcell[0][ele], ocrcell[1][ele]]  # [坐标，字符]
                flage = 1
            means.append(list(mean))

        if flage == 0:
            return dict
        gc_coor = np.array(gongcheng[0]).mean(axis=0)
        row = (np.array(means)[:, 1] - gc_coor[1]) < thredhold
        ocrcell_tex = []
        ocrcell_zuobiao = []
        index_right = 0
        for i in range(temp):
            if row[i]:
                ocrcell_zuobiao.append(ocrcell[0][i])
                ocrcell_tex.append(ocrcell[1][i])
                if ocrcell[1][i] == '工程名称':
                    index_right = i
        a_all = np.array(ocrcell_zuobiao).mean(axis=1)  # 按列排序
        a = np.argsort(a_all[:, 0])
        for i_1 in range(len(a)):
            if a[i_1] == index_right:
                name_gc_index = a[i_1 + 1]
                name_gc = ocrcell_tex[name_gc_index]
                box_gc = ocrcell_zuobiao[name_gc_index]

        dict.append([ocrcell[0][index_right], box_gc])
        dict.append([ocrcell[1][index_right], name_gc])
        # dict[ocrcell[1][index_right]] = ocrcell[0][index_right]
        # dict[name_gc] = box_gc
        return dict

    def ocr_merge_layout(self, ocr_cell, layout_cell):
        """
        ocr_cell: list[dict{'img':cv2_img, 'coordinates':[], 'text':''}]
        layout_cell: list[dict{'img':cv2_img, 'coordinates':[]}]
        return layout_cell->list[dict{'coordinates':[], 'text':''}]
        """
        gongcheng = self.extract_projectname(ocr_cell)
        boxes = ocr_cell[0]
        boxes_lose = ocr_cell[0].copy()
        rec_res = ocr_cell[-1]
        # rec_res_lose = ocr_cell[-1]
        layout_cell_right = layout_cell.copy()
        rst = list()
        for lxy in layout_cell:
            cell = dict()
            cell['coordinate'] = lxy
            cell['text'] = str()
            tc = list()
            text_coors = []
            for index, content in enumerate(boxes):
                center = np.array(content).mean(axis=0)
                # 小矩形扔进大矩形
                if lxy[1] < center[0] < lxy[2] and lxy[0] < center[1] < lxy[3]:
                    boxes_lose[index] = np.zeros((4, 2))
                    # rec_res_lose[index][1]=0
                    tc.append(rec_res[index])
                    text_coors.append(content)
            if all([re.match(r"[!\"#$%&\\'\(\)\*\+,-\./:;<=>\?@\[\]\^_`\{\|\}~\d\s]", line) for line in tc]):
                cell['text'] = "\n".join(tc)
            else:
                cell['text'] = "".join(tc)
            cell['text_coor'] = text_coors
            rst.append(cell)

        if len(gongcheng) == 0:
            return rst
        rst_zj = copy.deepcopy(rst)
        for boxes_index, box_lose in enumerate(boxes_lose):
            aa = np.zeros((4, 2))
            cell_1 = dict()
            if (box_lose != aa).all() and (
                    (rec_res[boxes_index] == gongcheng[1][0]) or rec_res[boxes_index] == gongcheng[1][1]):
                # print(box_lose)
                cell_1['coordinate'] = [int(box_lose[0][1]), int(box_lose[0][0]), int(box_lose[2][1]),
                                        int(box_lose[2][0])]
                cell_1['text'] = str(rec_res[boxes_index])

                a = [int(box_lose[0][1]), int(box_lose[0][0]), int(box_lose[2][0]), int(box_lose[2][1])]
                layout_cell_right.append(a)
                rst_zj.append(cell_1)
        return rst_zj

    # def ocr_merge_layout(self, ocr_cell, layout_cell):
    #     """
    #     ocr_cell: list[dict{'img':cv2_img, 'coordinates':[], 'text':''}]
    #     layout_cell: list[dict{'img':cv2_img, 'coordinates':[]}]
    #     return layout_cell->list[dict{'coordinates':[], 'text':''}]
    #     """
    #     # ocr_cell1 = self.sort_box(ocr_cell)
    #     boxes = ocr_cell[0]
    #     boxes_lose = ocr_cell[0].copy()
    #     layout_cell_right = layout_cell.copy()
    #     rec_res = ocr_cell[-1]
    #     rst = list()
    #     for lxy in layout_cell:
    #         cell = dict()
    #         cell['coordinate'] = lxy
    #         cell['text'] = str()
    #         tc = list()
    #         text_coors = []
    #         for index, content in enumerate(boxes):
    #             center = np.array(content).mean(axis=0)
    #             # 小矩形扔进大矩形
    #             if lxy[1] < center[0] < lxy[2] and lxy[0] < center[1] < lxy[3]:
    #                 tc.append(rec_res[index])
    #                 text_coors.append(content)
    #                 boxes_lose[index] = np.zeros((4, 2))
    #         if all([re.match(r"[!\"#$%&\\'\(\)\*\+,-\./:;<=>\?@\[\]\^_`\{\|\}~\d\s]", line) for line in tc]):
    #             cell['text'] = "\n".join(tc)
    #         else:
    #             cell['text'] = "".join(tc)
    #         cell['text_coor'] = text_coors
    #         # cell['table_text_coor'] = {'table_coor': lxy, 'text_coor': "".join([line for line in tc])}
    #         rst.append(cell)
    #     return rst

    def semantic_layout(self, src):
        """
        根据行焦点分割表
        src: list->[{'coordinate': [int->number], 'text': str->content}]
        return dict->{'eng_info':[{'coordinate':[int->number], 'text': str->content}], 'land_info':[{'coordinate':[int->number],'text':str->content}]}
        """
        # 寻找所有单元格中的y1坐标
        src = self.threshold_classification(30, src, 0)
        # src = self.threshold_classification(30, src, 1)

        row_cord = np.array([line['coordinate'][0] for line in src])
        row_text = np.array([line['text'] for line in src])

        # 寻找到底部单元格的y1
        md = max(row_cord)
        # 根据y1坐标进行分组
        rows = [row_cord[np.where(abs(row_cord - element) < 15)] for element in np.unique(row_cord)]
        # 寻找组内单元格最多的y1, 这个y1就是分割表的线
        m = -1
        max_row_point = -1
        # 找到单元格第一次出现最多的 且 是属于land表里的字段,此时的线就为eng和land的分割线
        land_values = self.tj['lands']
        for i in range(len(rows)):
            if len(rows[i]) > m:
                for index, cor in enumerate(row_cord):
                    if rows[i][0] == cor and similar([row_text[index]])[0] in land_values:
                        m = len(rows[i])
                        max_row_point = rows[i][0]

        rst = dict()
        rst['eng_info'] = list()
        rst['land_info'] = list()
        for line in src:
            if line['coordinate'][0] < max_row_point - 5:
                rst['eng_info'].append(line)
            else:
                # 长宽比
                lw = abs(line['coordinate'][2] - line['coordinate'][1]) / abs(
                    line['coordinate'][3] - line['coordinate'][0])
                # 丢掉最底部的单元格
                if abs(line['coordinate'][0] - md) > 100 and line['coordinate'] and lw < 55:
                    rst['land_info'].append(line)
        return rst

    def eng_kv(self, x):
        '''
        x : group items
        return: key->value
        '''
        t = list(x['text'])
        c = list(x['coordinate'])
        rst = list()
        flag = int()
        for i in range(len(t)):
            rst.append([t[i], c[i]])
        return rst

    # def local_kv(self, rows):
    #     # 解决竖着的坐标单元格，导致kv识别不正确
    #     # 1. 寻找到坐标特征，包含坐标两个字，且单元格的宽高比在一个阈值内
    #     # 2. 将次坐标所在数组外的坐标和数组内的坐标记录
    #     # 3. 在整个list中，剔除某个元素，之后插入到坐标的值中，且做拼接操作
    #     o_i = -1
    #     i_i = int()
    #     f = True
    #     rows = list(rows)
    #     # 出去row为空，及row的key为空的值
    #     for out_i, row in enumerate(rows):
    #         if row == []:
    #             rows.pop(out_i)
    #     for out_i, row in enumerate(rows):
    #         try:
    #             if row[0][0][0] == '':
    #                 rows.pop(out_i)
    #         except:
    #             logger.warning(f"工程信息的key:{row}异常")
    #
    #     for out_i, row in enumerate(rows):
    #         if f:
    #             for iner_i, item in enumerate(row):
    #                 try:
    #                     item_name = similar([item[0][0]])[0]
    #                     if item[0][1][-1] - item[0][1][0] > 110 and item_name in self.tj['eng_info']['coordinates']:
    #                         o_i = out_i
    #                         i_i = iner_i
    #                         f = False
    #                         break
    #                 except Exception:
    #                     logger.warning(Exception)
    #                     f = False
    #         else:
    #             break
    #     # 存在具备特征的'坐标'
    #     if o_i != -1:
    #         rows = list(rows)
    #         # 取得坐标y的值
    #         try:
    #             yl = ';' + str(rows[o_i + 1][i_i * 2][0])
    #         except:
    #             logger.warning(f"该行是奇数个")
    #             return rows
    #
    #         # 融合到坐标x的值中
    #         rows[o_i][i_i][-1][0] += yl
    #         # 提取奇数行
    #         oddl = rows[o_i + 1]
    #         oddl.pop(i_i * 2)
    #         # 构造正确的偶数行
    #         enve = list()
    #         if len(oddl) % 2 == 0:
    #             for i in range(0, len(oddl), 2):
    #                 enve.append([[oddl[i][0], oddl[i][-1]], [oddl[i + 1][0], oddl[i + 1][-1]]])
    #         # 剔除原来行里的奇数列
    #         if enve:
    #             rows.pop(o_i + 1)
    #             rows.append(enve)
    #     return copy.deepcopy(rows)

    def eng_info_kv(self, src):
        """
        src: list->[{'coordinate': [int->number], 'text': str->content}]
        return: list->[{'item':[{'key': {'coordinate': [int->number], 'text': str->content}, 'value':{'coordinate':[int->number], 'text': str->content}]}}]
        """
        # 根据先验字段名称以及单元格位置信息确定K-V
        # todo 分组排序，确认kv
        # 1. 归一一行内的像素值
        # 2. 按照归一后的值进行排序
        # 3. 结合先验知识和位置信息确认kv
        # 根据阈值纠正线条倾斜
        # finish
        ul = list()
        for line in src:
            if abs(line['coordinate'][-1] - line['coordinate'][0]) > 30:
                ul.append(line)
        src = ul
        src = self.threshold_classification(30, src, 0)
        src = pd.DataFrame(src)
        # 新增行列坐标点
        src['clo_p'] = [line[1] for line in src['coordinate']]
        src['row_p'] = [line[0] for line in src['coordinate']]
        # 根据行列坐标点进行排序
        src = src.sort_values(by=['row_p', 'clo_p'])
        # 根据行坐标进行排序
        kv = src.groupby('row_p').apply(self.eng_kv)
        kv = list(kv)
        eng_k_v = list()
        # 定位坐标的字段,合并x,y
        row = -1
        col = -1
        for j, tcs in enumerate(kv):
            for l, tc in enumerate(tcs):
                eng_k = similar([tc[0]])[0]
                if eng_k in self.tj['eng_info']['coordinates'] and tc[1][-1] - tc[1][0] > 110:
                    row = j
                    col = l
                    break
        kv[row][col + 1][0] += ';' + kv[row + 1][col][0]
        # 识别K-V
        for i, tcs in enumerate(kv):
            for h, tc in enumerate(tcs):
                eng_k = similar([tc[0]])[0]
                for k, v in self.tj['eng_info'].items():
                    if eng_k in v:
                        try:
                            eng_k_v.append([[eng_k, tc[1]], [tcs[h + 1][0], tcs[h + 1][1]]])
                        except:
                            tcb = [tc[1][0], tc[1][1] + 10, tc[1][2] + 10, tc[1][3]]
                            eng_k_v.append([[eng_k, tc[1]], ['', tcb]])

        rst = list()
        item = dict()
        item['item'] = list()
        rst.append(item)
        for k in eng_k_v:
            field = dict()
            # todo 接入文本纠正, k[0][0] is key
            # finish
            try:
                text = k[0][0]
                field['key'] = {'text': text, 'coordinate': k[0][1]}
                field['value'] = {'text': k[1][0], 'coordinate': k[1][1]}
                item['item'].append(field)
            except:
                pass
        return rst

        # kv = self.local_kv(kv)
        #
        # with open('apps/pdf_ocr/tools/table.json') as t:
        #     tj = json.load(t)
        # eng_fields = tj['eng_info'].keys()
        #
        # rst = list()
        # item = dict()
        # item['item'] = list()
        # rst.append(item)
        # for row in kv:
        #     for k in row:
        #         field = dict()
        #         # todo 接入文本纠正, k[0][0] is key
        #         # finish
        #         try:
        #             text = k[0][0]
        #             text = similar([text])[0]
        #             field['key'] = {'text': text, 'coordinate': k[0][1]}
        #             field['value'] = {'text': k[1][0], 'coordinate': k[1][1]}
        #             item['item'].append(field)
        #         except:
        #             pass
        #             # logger.warning(f"这行的table是奇数个，row:{row}")
        # return rst

    def threshold_classification(self, thr, src, flag):
        '''
        thr: int->阈值
        src: list->list->num1, num2, num3, num4
        flag: 归一阈值的位置信息，0是根据第一个元素归一，1是第二个，以此类推
        '''
        col_cord = np.array([line['coordinate'][flag] for line in src])
        for c in np.unique(col_cord):
            for l in src:
                if abs(c - l['coordinate'][flag]) < thr:
                    l['coordinate'][flag] = c
        return src

    def land_save(self, x):
        coordinate = list(x['coordinate'])[-1]
        t = list(x['text'])[0]
        clo_p = list(x['clo_p'])[-1]
        row_p = list(x['row_p'])[-1] + 100
        text_count = list(x['text_count'])[-1]
        if t in self.dt:
            fill_txt = dict()
            fill_txt['coordinate'] = coordinate
            fill_txt['text'] = ''
            fill_txt['clo_p'] = clo_p
            fill_txt['row_p'] = row_p
            fill_txt['text_count'] = text_count
            for i in range(self.mode1 - len(x['text'])):
                x = x.append(fill_txt, ignore_index=True)
            return x
        else:
            pass

    def land_info_kv(self, src, img):
        """
        src: list->[{'coordinate': [int->number], 'text': str->content}]
        return: list->[{'item': {'key': {'coordinate': [int->number], 'text': str->content}, 'value':{'coordinate':[int->number], 'text': str->content}}}]
        """
        with open('apps/pdf_ocr/tools/table.json') as t:
            tj = json.load(t)
        # 根据阈值纠正线条倾斜
        src = self.threshold_classification(30, src, 1)

        src = pd.DataFrame(src)
        # 新增行列坐标点
        src['clo_p'] = [line[1] for line in src['coordinate']]
        src['row_p'] = [line[0] for line in src['coordinate']]
        # 根据行列坐标点进行排序
        src = src.sort_values(by=['clo_p', 'row_p'])
        # 根据行列坐标点进行排序，并且分组统计出个字段中item个数
        src['text_count'] = src.groupby('clo_p')['text'].transform('count')

        # print(src['text_count'].mode())

        def filter_land_info(group_data_series, img=img):
            # 过滤出land的数据 如果为公式列 调用公式模型
            land_key = is_key(group_data_series.text.tolist()[0], include=['land_info'], all_key=False)
            if land_key:
                if land_key in self.tj['land_info']['geological_age']:
                    empty_pd = pd.DataFrame(columns=group_data_series.columns)
                    key_flag = 1
                    for cell_series in group_data_series.itertuples():
                        if key_flag:
                            key_flag = 0
                            empty_pd = empty_pd.append(dict(cell_series._asdict()), ignore_index=True)
                            continue
                        try:
                            box = cell_series.text_coor[0]
                            x_list = np.array(box)[:, 0].tolist()
                            y_list = np.array(box)[:, 1].tolist()
                            xmin = min(x_list)
                            xmax = max(x_list)
                            ymin = min(y_list)
                            ymax = max(y_list)
                            img = np.asarray(img)
                            tm = img[int(ymin):int(ymax), int(xmin):int(xmax)]
                            success, encoded_image = cv2.imencode(".png", tm)
                            frm_txt = formula(encoded_image)
                        except:
                            frm_txt = ''
                            logger.warning(f"此table没有公式")
                        cell_series_dict = dict(cell_series._asdict())
                        if frm_txt:
                            cell_series_dict['text'] = frm_txt
                        empty_pd = empty_pd.append(cell_series_dict, ignore_index=True)
                    return empty_pd
                return group_data_series

        # 通过名字筛选出land_info
        all_land_info = src.groupby('clo_p').apply(filter_land_info).reset_index(drop=True)
        base_max_nums = int(all_land_info['text_count'].max())
        # 求出众数，数据表item数量
        base_mode_nums = int(all_land_info['text_count'].mode()[0])

        # 计算text_count = base_max_nums的列数
        clo_p_df = all_land_info[['text_count', 'clo_p']].groupby('clo_p').apply(lambda x: x)
        equal_base_max_nums_col_num = \
            clo_p_df[clo_p_df.text_count == base_max_nums].groupby('clo_p').apply(lambda x: x[:1]).count()[0]
        self.mode1 = base_mode_nums
        self.dt = tj['lands']

        # # 如果与最大行数相等的列的数量 = 1；
        # if equal_base_max_nums_col_num == 1:
        #     # 此时选择众数为基准行；将大于众数的去掉多余的列
        #     base_num = base_mode_nums
        #     big_land_info = all_land_info[all_land_info.text_count > base_num].groupby('clo_p'). \
        #         apply(lambda x: x[:base_num])
        # else:
        #     # 否则 选择最大行数列为基准列
        #     base_num = base_max_nums
        #     big_land_info = pd.DataFrame(columns=all_land_info.columns)

        # 此时选择众数为基准行；将大于众数的去掉多余的列
        base_num = base_mode_nums
        big_land_info = all_land_info[all_land_info.text_count > base_num].groupby('clo_p'). \
            apply(lambda x: x[:base_num])

        # 筛选land_info中不是岩土的。排除基准为岩土名称那一列为基准列
        all_land_info_group_obj = all_land_info[all_land_info.text_count == base_num].groupby('clo_p')
        all_land_info_first_group_id = all_land_info_group_obj.first().index[0]
        base_col = all_land_info_group_obj.get_group(all_land_info_first_group_id)
        base_col['row_p'] = [line[0] for line in base_col['coordinate']]
        base_col['clo_p'] = [line[1] for line in base_col['coordinate']]
        base_col.reset_index(drop=True)

        equal_land_info = all_land_info[(all_land_info['text_count'] == base_num)]
        # 筛选land表中 小于基准行的所有列
        small_land_info = all_land_info[(all_land_info['text_count'] < base_num)]

        def land_save(cur_col_dataframe: pd.DataFrame):
            # 补全land_info缺失的行
            land_text = list(cur_col_dataframe['text'])[0]

            # 如果长度为1，那么直接返回
            if len(cur_col_dataframe) == 1:
                logger.warning(f'{land_text}列下没有值')
                return None

            # 当前列为 岩土名称，直接填充到最后
            if land_text in tj['land_info']['lithology_description']:
                fill_txt = dict()
                y1, x1, x2, y2 = list(cur_col_dataframe['coordinate'])[-1]
                y1 += 200
                y2 += 200
                fill_txt['clo_p'] = x1
                fill_txt['row_p'] = y1
                fill_txt['text'] = ''
                fill_txt['coordinate'] = [y1, x1, x2, y2]
                fill_txt['text_count'] = list(cur_col_dataframe['text_count'])[-1]
                for i in range(self.mode1 - len(cur_col_dataframe['text'])):
                    cur_col_dataframe = cur_col_dataframe.append(fill_txt, ignore_index=True)
                return cur_col_dataframe

            # 初始化一个空array
            empty_data_frame = pd.DataFrame(columns=cur_col_dataframe.columns)
            cur_col_dataframe_iter = cur_col_dataframe.itertuples()
            if land_text in self.dt:
                # 取出当前列第一行元素（key）
                try:
                    cur_col_key = next(cur_col_dataframe_iter)
                except Exception:
                    logger.warning(f'该列没有key{cur_col_dataframe_iter}')
                    return cur_col_dataframe

                # 判断位置是否正确
                # 与基准列第一个元素的坐标相减； 差值 > 100像素
                if (base_col.row_p.iloc[0] - cur_col_key.row_p) > 30:
                    # 该列没有key，打印log，并原样返回，舍弃该列
                    logger.warning(f'该列没有key{cur_col_key}')
                    return cur_col_dataframe

                empty_data_frame = empty_data_frame.append(dict(cur_col_key._asdict()), ignore_index=True)
                # 初始化位置坐标为 第一行元素的y2坐标
                ini_y1 = cur_col_key.coordinate[-1]

                ####递归###############################################
                cur_col_cur_row = []
                before_col_cur_row = []
                while True:
                    # 按照坐标分别取用 当前列最接近的第一行元素 和 基准列大于取用坐标的所有元素
                    if len(cur_col_cur_row):
                        before_col_cur_row = cur_col_cur_row
                    cur_col_cur_row = cur_col_dataframe[cur_col_dataframe.row_p >= ini_y1 - 20].iloc[0:1]
                    if len(before_col_cur_row) and len(cur_col_cur_row) and before_col_cur_row.index.item() == \
                            cur_col_cur_row.index.item():
                        cur_col_cur_row = cur_col_dataframe[cur_col_dataframe.row_p >= ini_y1].iloc[1:2]
                    cur_base_col_rows = base_col[base_col.row_p >= ini_y1 - 20]
                    cur_col_cur_row_is_err_flag = 0
                    # 基准列取出来为空，break
                    if not len(cur_base_col_rows):
                        break
                    cur_base_col_rows = cur_base_col_rows.itertuples()

                    # 如果 cur_col_cur_row 为空，那么为cur_col_cur_row的所在行没有数据了，直接补空
                    if len(cur_col_cur_row) == 0:
                        cur_base_col_row = next(cur_base_col_rows)
                        fill_obj = dict()
                        # 填充下一个基准单元格 用基准列的坐标作为当前列当前行的坐标，值为空；append到空array中
                        dot_x = cur_col_dataframe.clo_p.iloc[-1] - cur_base_col_row.clo_p
                        y1, x1, x2, y2 = cur_base_col_row.coordinate
                        fill_obj['coordinate'] = [y1, x1 + dot_x, x2 + dot_x, y2]
                        fill_obj['clo_p'] = x1 + dot_x
                        fill_obj['row_p'] = y1
                        fill_obj['text'] = ''
                        fill_obj['text_count'] = list(cur_col_dataframe['text_count'])[-1] + 1
                        empty_data_frame = empty_data_frame.append(fill_obj, ignore_index=True)
                        ini_y1 = y2
                        continue

                    # 1. 判断当前列位置是否正确
                    # 如果 与初始化的y坐标相减 差值 > 100像素
                    if abs(ini_y1 - cur_col_cur_row.row_p.item()) >= 30:
                        cur_col_cur_row_is_err_flag = 1
                        # 1.1 在该位置循环填充下一个基准单元格 直到基准元素的y1 - 当前列的当前元素的y1 <= 100;
                        while True:
                            try:
                                cur_base_col_row = next(cur_base_col_rows)
                            except Exception:
                                break
                            # 当基准元素的y2 - 当前列的当前元素的y1 <= 100; 将当前列的当前元素坐标及值append到空array；todo abs
                            dot_x = cur_col_cur_row.clo_p.item() - cur_base_col_row.clo_p
                            fill_obj = dict()
                            # 填充下一个基准单元格 用基准列的坐标作为当前列当前行的坐标，值为空；append到空array中
                            y1, x1, x2, y2 = cur_base_col_row.coordinate
                            fill_obj['coordinate'] = [y1, x1 + dot_x, x2 + dot_x, y2]
                            fill_obj['clo_p'] = x1 + dot_x
                            fill_obj['row_p'] = y1
                            fill_obj['text'] = ''
                            fill_obj['text_count'] = list(cur_col_dataframe['text_count'])[-1] + 1
                            empty_data_frame = empty_data_frame.append(fill_obj, ignore_index=True)

                            if cur_base_col_row.coordinate[-1] - cur_col_cur_row.row_p.item() >= -30:
                                empty_data_frame = empty_data_frame.append(cur_col_cur_row, ignore_index=True)
                                ini_y1 = y2 if y2 < cur_col_cur_row.row_p.item() else cur_col_cur_row.row_p.item()
                                # 跳出循环
                                break
                            # 否则继续循环 填充下一个基准单元格 用基准列的坐标作为当前列当前行的坐标，值为空；append到空array中

                    # 按照坐标分别取用 当前列最接近的第一行元素 和 基准列大于取用坐标的所有元素
                    cur_col_cur_row = cur_col_dataframe[cur_col_dataframe.row_p >= ini_y1 - 20].iloc[0:1]
                    if len(before_col_cur_row) and len(cur_col_cur_row) and before_col_cur_row.index.item() == \
                            cur_col_cur_row.index.item():
                        cur_col_cur_row = cur_col_dataframe[cur_col_dataframe.row_p >= ini_y1].iloc[1:2]
                    cur_base_col_rows_df = base_col[base_col.row_p >= ini_y1 - 20]
                    # 基准列取出来为空，break
                    if not len(cur_base_col_rows_df):
                        break
                    cur_base_col_rows = cur_base_col_rows_df.itertuples()

                    # 2. 判断是否需要分割当前单元格
                    y1, x1, x2, y2 = cur_col_cur_row.coordinate.item()
                    try:
                        cur_base_col_row = next(cur_base_col_rows)
                    except Exception:
                        break
                    base_y1, base_x1, base_x2, base_y2 = cur_base_col_row.coordinate

                    # 如果该单元格的高度 - 基准行高度 差值 大于 30
                    if (y2 - y1) - (base_y2 - base_y1) >= 30:
                        cur_col_cur_row_is_err_flag = 1
                        dot_x = cur_col_cur_row.clo_p.item() - cur_base_col_row.clo_p
                        fill_obj_text_count = 0
                        while True:
                            break_flag = 0
                            if cur_col_cur_row.coordinate.item()[-1] - cur_base_col_row.coordinate[-1] <= 30:
                                # 跳出循环
                                break_flag = 1

                            fill_obj = dict()
                            base_y1, base_x1, base_x2, base_y2 = cur_base_col_row.coordinate
                            # 对该单元格按照基准行分割，循环填充下一个基准单元格 直到基准单元格y2 >= 当前行单元格y2
                            fill_obj['coordinate'] = [base_y1, base_x1 + dot_x, base_x2 + dot_x, base_y2]
                            fill_obj['clo_p'] = base_x1 + dot_x
                            fill_obj['row_p'] = base_y1
                            fill_obj['text'] = cur_col_cur_row.text.item()
                            fill_obj_text_count += 1
                            fill_obj['text_count'] = fill_obj_text_count
                            # 坐标为基准单元格的坐标  值为当前单元格的值；append到空array中
                            empty_data_frame = empty_data_frame.append(fill_obj, ignore_index=True)
                            if break_flag:
                                ini_y1 = base_y2
                                break
                            try:
                                cur_base_col_row = next(cur_base_col_rows)
                            except Exception:
                                break

                    # 3.正常情况直接 将当前列的当前元素坐标及值append到空array
                    if not cur_col_cur_row_is_err_flag:
                        empty_data_frame = empty_data_frame.append(cur_col_cur_row, ignore_index=True)
                        ini_y1 = cur_col_cur_row.coordinate.item()[-1]

                # 断言 array中元素个数与base_col元素个数相同
                if len(empty_data_frame) > len(base_col):
                    empty_data_frame = empty_data_frame[:len(base_col)]
                    logger.warning(f'{land_text}列填充后元素个数{len(empty_data_frame)}与基准{len(base_col)}不一致')
                elif len(empty_data_frame) < len(base_col):
                    fill_txt = dict()
                    y1, x1, x2, y2 = list(cur_col_dataframe['coordinate'])[-1]
                    y1 += 200
                    y2 += 200
                    fill_txt['clo_p'] = x1
                    fill_txt['row_p'] = y1
                    fill_txt['text'] = ''
                    fill_txt['coordinate'] = [y1, x1, x2, y2]
                    fill_txt['text_count'] = list(cur_col_dataframe['text_count'])[-1]
                    for i in range(len(base_col) - len(empty_data_frame)):
                        empty_data_frame = empty_data_frame.append(fill_txt, ignore_index=True)
                    f'{land_text}列填充后元素个数{len(empty_data_frame)}与基准{len(base_col)}不一致'

                assert len(empty_data_frame) == len(base_col), \
                    f'{land_text}列填充后元素个数{len(empty_data_frame)}与基准{len(base_col)}不一致'
                return empty_data_frame
            else:
                pass

        small_land_info = small_land_info.groupby('clo_p').apply(land_save)
        real_land_info = equal_land_info.append(big_land_info.append(small_land_info, ignore_index=True),
                                                ignore_index=True)

        # finish todo 确认字段数量和行数量，融合在一个item中。
        # 根据字段的item数量判断一共循环多少次，根据字段数量判断一个内循环中循环多少次
        # land_info['clo_p1'] = land_info['clo_p']
        # df = df.pivot(index='coordinate',columns='clo_p',values='text')

        land_key = real_land_info.groupby('clo_p').apply(lambda x: x.iloc[0, :])
        land_value = real_land_info.groupby('clo_p', as_index=False).apply(lambda x: x.iloc[1:, :])

        # land_value = land_value.sort_values(by=['row_p', 'clo_p'])

        land_value = land_value[['text', 'clo_p', 'coordinate']]
        land_key = land_key[['text', 'clo_p', 'coordinate']]

        land_key = land_key.to_dict(orient='record')
        # land_value = land_value.to_dict(orient='record')
        # key_tots = len(land_key)
        # value_tots = len(land_value)
        #
        # it = iter(land_value)
        # item_loop = [key_tots] * (base_num - 1)
        # items = [list(islice(it, size)) for size in item_loop]
        groups = []
        for name, group in land_value.groupby(land_value['clo_p']):
            groups.append(group)
        items = list(np.array(groups).T)

        rst = list()
        # 行列合并
        for i, item in enumerate(items[0]):
            it = dict()
            it['item'] = list()
            rst.append(it)
            for li, line in enumerate(land_key):
                kv = dict()
                key_text = line['text']
                key_text = similar([key_text])[0]
                key = {'text': key_text, 'coordinate': line['coordinate']}
                kv['key'] = key
                value = {'text': item[li], 'coordinate': items[2][i][li]}
                kv['value'] = value
                it['item'].append(kv)
        return rst

    def deep_info_kv(self, src):
        # 根据阈值纠正线条倾斜
        src = self.threshold_classification(30, src, 1)

        src = pd.DataFrame(src)
        # 新增行列坐标点
        src['clo_p'] = [line[1] for line in src['coordinate']]
        src['row_p'] = [line[0] for line in src['coordinate']]
        # 根据行列坐标点进行排序
        src = src.sort_values(by=['clo_p', 'row_p'])
        # 根据行列坐标点进行排序，并且分组统计出个字段中item个数
        src['text_count'] = src.groupby('clo_p')['text'].transform('count')
        # print(src['text_count'].mode())
        # 求出众数，数据表item数量
        mode = src['text_count'].mode()[0]

        # 过滤出deep_info信息
        def filter_deep_info(group_data_series):
            land_key = is_key(group_data_series.text.tolist()[0], include=['deep_info'], all_key=False)
            if land_key:
                if land_key in self.tj['deep_info']:
                    empty_pd = pd.DataFrame(columns=group_data_series.columns)
                    key_flag = 1
                    for cell_series in group_data_series.itertuples():
                        if key_flag:
                            key_flag = 0
                            empty_pd = empty_pd.append(dict(cell_series._asdict()), ignore_index=True)
                            continue
                        cell_series_dict = dict(cell_series._asdict())
                        empty_pd = empty_pd.append(cell_series_dict, ignore_index=True)
                    return empty_pd
                return group_data_series

        deep_info = src.groupby('clo_p').apply(filter_deep_info).reset_index(drop=True)
        if deep_info.empty:
            return []
        # deep_info = src[(src['text_count'] != mode)]
        deep_key = deep_info.groupby('clo_p').apply(lambda x: x.iloc[0, :])
        deep_value = deep_info.groupby('clo_p').apply(lambda x: x.iloc[1:, :])
        deep_key = deep_key.to_dict(orient='record')
        deep_value = deep_value.to_dict(orient='record')
        rst = list()
        for line in deep_key:
            key_text = line['text']
            key_text = similar([key_text])[0]
            key = {'text': key_text, 'coordinate': line['coordinate']}
            if key:
                for l1 in deep_value:
                    join = line['clo_p']
                    if l1['clo_p'] == join:
                        count = len(l1['text'].split('\n'))
                        num = int((l1['coordinate'][-1] - l1['coordinate'][0])/count)
                        split_coors = []
                        for c in range(count):
                            split_coors.append([l1['coordinate'][0]+num*c, l1['coordinate'][1], l1['coordinate'][2],
                                                l1['coordinate'][0]+num*(c+1)])

                        for t, tex in enumerate(l1['text'].split('\n')):
                            tmp_item = dict()
                            tmp_item['key'] = key
                            value = {'text': tex, 'coordinate': split_coors[t]}
                            tmp_item['value'] = value
                            rst.append(tmp_item)
                    else:
                        # todo 找到了key但是table_mode上没有识别出v的布局
                        pass
        return rst

    def semantic_kv(self, src, img):
        """
        src dict->{'eng_info':[{'coordinate':[int->number], 'text': str->content}], 'land_info':[{'coordinate':[int->number],'text':str->content}]}
        src dict->{'eng_info':[{'key' :{'coordinate':[int->number], 'text': str->content},'value':{'coordinate':[int->number], 'text':str->content}], 'land_info':[{'coordinate':[int->number],'text':str->content}]}
        """
        rst = dict()
        rst['eng_info'] = self.eng_info_kv(src['eng_info'])
        rst['land_info'] = self.land_info_kv(src['land_info'], img)
        # 接着sheet2向下分，如何确定哪些是sheet2，先验知识，以及不是就补充空
        rst['deep_info'] = self.deep_info_kv(src['land_info'])
        rst['img'] = img
        rst['page'] = src['page']
        return rst

    def merge_hole_no(self, tables):
        holes = list()
        # 寻找孔号
        for i, png in enumerate(tables):
            for line in png['eng_info']:
                for item in line['item']:
                    key = item['key']['text']
                    if key in self.tj['eng_info']['boring_no']:
                        try:
                            value = item['value']['text']
                            holes.append((value, i))
                        except:
                            logger.warning(f"没有找到孔号，item:{item}")

        # 孔号合并
        h = set([line[0] for line in holes])
        h2p = list()
        for s in h:
            d_hole = dict()
            d_hole['num'] = s
            d_hole['png'] = list()
            for l in holes:
                if s == l[0]:
                    d_hole['png'].append(l[-1])
            h2p.append(d_hole)

        rst = list()
        for num in h2p:
            t_rst = dict()
            t_rst['hole'] = num['num']
            t_rst['content'] = list()
            for t_index in num['png']:
                t_rst['content'].append(tables[t_index])
            rst.append(t_rst)

        # 相同孔号的land、deep信息合并
        # merge_holes = list()
        # for hol in rst:
        #     merge_hole = dict()
        #     land_info = list()
        #     deep_info = list()
        #     imgs_info = list()
        #     merge_hole['hole'] = hol['hole']
        #     merge_hole['content'] = [
        #         {'eng_info': hol['content'][0]['eng_info'], 'land_info': land_info, 'deep_info': deep_info}]
        #     for pag, con in enumerate(hol['content']):
        #         for i in con['land_info']:
        #             i['page'] = pag
        #             land_info.append(i)
        #         for j in con['deep_info']:
        #             j['page'] = pag
        #             deep_info.append(j)
        #     merge_holes.append(merge_hole)
        return rst

    def out_excel(self, src, pdf='kk'):
        tj = dict()
        with open('apps/pdf_ocr/tools/table.json') as t:
            tj = json.load(t)
        eng_fields = tj['eng_info'].keys()
        land_fields = tj['land_info'].keys()
        deep_fields = tj['deep_info'].keys()

        eng_table = pd.DataFrame(columns=eng_fields)
        land_table = pd.DataFrame(columns=land_fields)
        deep_table = pd.DataFrame(columns=deep_fields)

        for hole in src:
            for tables in hole['content']:
                # 工程信息
                for items in tables['eng_info']:
                    it = dict()
                    it['boring_id'] = hole['hole']
                    for item in items['item']:
                        key = item['key']['text']
                        value = item['value']['text']
                        if key and value:
                            t = [k for k, v in tj['eng_info'].items() if key in v]
                            if t:
                                it[t[0]] = value
                    eng_table = eng_table.append(copy.deepcopy(it), ignore_index=True)
                # 土地信息
                for items in tables['land_info']:
                    it = dict()
                    it['boring_id'] = hole['hole']
                    for item in items['item']:
                        key = item['key']['text']
                        value = item['value']['text']
                        if key and value:
                            t = [k for k, v in tj['land_info'].items() if key in v]
                            if t:
                                it[t[0]] = value
                    land_table = land_table.append(copy.deepcopy(it), ignore_index=True)

                # 深度信息
                for items in tables['deep_info']:
                    it = dict()
                    it['boring_id'] = hole['hole']
                    key = items['key']['text']
                    if key in tj['deep_info']['sampling']:
                        try:
                            value = calculation_deep(hole)[0]
                        except:
                            value = None
                            logger.warning(f"该文件id:{id}没有取样这一列")
                    elif key in tj['deep_info']['penetration_depth']:
                        try:
                            value = calculation_deep(hole)[1]
                        except:
                            value = None
                            logger.warning(f"该文件id:{id}没有标贯深度这一列")
                    t = [k for k, v in tj['deep_info'].items() if key in v]
                    if t:
                        it[t[0]] = value
                    deep_table = deep_table.append(copy.deepcopy(it), ignore_index=True)

        # eng_table = eng_table.dropna(axis=1,how="all")
        # land_table = land_table.dropna(axis=1,how="all")
        with pd.ExcelWriter(pdf + '.xlsx') as writer:
            eng_table.to_excel(writer, sheet_name='eng_info', index=False)
            land_table.to_excel(writer, sheet_name='land_info', index=False)
            deep_table.to_excel(writer, sheet_name='deep_info', index=False)
        # print('write ' + pdf + ' finish')
