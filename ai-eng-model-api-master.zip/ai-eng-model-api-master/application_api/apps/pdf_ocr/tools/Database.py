import json
import re
from functools import reduce

from django.conf import settings

from pdf_ocr.services.correction.keyword import similar
from pdf_ocr.tools.common import calculation_deep, is_key
import time
from pdf_ocr.models import FileModel, EngInfoModel, LandInfoModel, DeepSplitInfo
import logging

logger = logging.getLogger("django")


def mer_coor(coors):
    try:
        return [coors[0][0], coors[0][1], coors[0][2], coors[-1][-1]]
    except:
        return []


def in_db(engs):
    with open('apps/pdf_ocr/tools/table.json') as t:
        tj = json.load(t)

    for eng_land_index, hole in enumerate(engs):
        id = hole['file_id']
        file = FileModel.objects.get(id=id)
        page = hole['content'][0]['page']
        eng_info = [tables['eng_info'] for tables in hole['content']]
        # 选择效果好的表头入库,需要融入表字段
        keys = [len(tmp['item']) for line in eng_info for tmp in line]
        if eng_info:
            # 选取孔号中第一个工程信息
            keys = list()
            values = list()
            eng_info = eng_info[0][0]
            for item in eng_info['item']:
                try:
                    key = item['key']['text']
                except:
                    key = None
                try:
                    value = item['value']['text']
                    value_coor = item['value']['coordinate']
                except:
                    value = None
                    value_coor = None
                if key and value:
                    t = [k for k, v in tj['eng_info'].items() if key in v]
                    if t:
                        # 存在两个坐标但不是合并单元格的情况时, 保存到同一个字段中
                        if t[0] in keys:
                            ti = -1
                            for ki, vl in enumerate(keys):
                                if vl == t[0]:
                                    ti = ki
                                    break
                            if ti != -1:
                                values[ti] = str(values[ti]) + ';' + str(value)
                        else:
                            keys.append(t[0])
                            values.append(value)
                if key and value_coor:
                    t = [k + '_coor' for k, v in tj['eng_info'].items() if key in v]
                    if t:
                        # 存在两个坐标但不是合并单元格的情况时, 保存到同一个字段中
                        if t[0] in keys:
                            ti = -1
                            for ki, vl in enumerate(keys):
                                if vl == t[0]:
                                    ti = ki
                                    break
                            if ti != -1:
                                values[ti] = str(values[ti])  # + ';' + str(value_coor)
                        else:
                            keys.append(t[0])
                            values.append(value_coor)
            keys.append('create_time')
            values.append(time.strftime("%Y-%m-%d %H:%M:%S"))
            keys.append('file_id')
            values.append(id)
            keys.append('page')
            values.append(page)

            EngInfoModel.objects.create(**dict(zip(keys, values)))

        # 土地信息
        land_info = [tables['land_info'] for tables in hole['content']]
        for p, land_info_png in enumerate(land_info):
            values = list()
            page = hole['content'][p]['page']
            for items in land_info_png:
                t_value = list()
                keys = list()
                for item in items['item']:
                    try:
                        key = item['key']['text']
                    except:
                        key = None
                    try:
                        value = item['value']['text']
                        land_coor = item['value']['coordinate']
                    except:
                        value = None
                        land_coor = None
                    if key and value:
                        t = [k for k, v in tj['land_info'].items() if key in v]
                        if t:
                            keys.append(t[0])
                            t_value.append(value)
                    if key and land_coor:
                        t = [k + '_coor' for k, v in tj['land_info'].items() if key in v]
                        if t:
                            keys.append(t[0])
                            t_value.append(land_coor)

                keys.append('create_time')
                t_value.append(time.strftime("%Y-%m-%d %H:%M:%S"))

                keys.append('eng_info_id')

                eng_info_id = file.eng_info_set.values()[eng_land_index]['id']
                t_value.append(eng_info_id)

                keys.append('page')
                t_value.append(page)

                LandInfoModel.objects.create(**dict(zip(keys, t_value)))

        # 计算深度
        for p, tables in enumerate(hole['content']):
            # 深度信息
            page_deep = hole['content'][p]['page']
            js_qy_value = []
            js_bg_value = []
            for items in tables['deep_info']:
                try:
                    key = items['key']['text']
                except:
                    key = None
                try:
                    value = items['value']['text']
                    value_coor = items['value']['coordinate']
                except:
                    value = None
                    value_coor = None

                # 计算深度
                if key in tj['deep_info']['sampling']:
                    try:
                        js_qy_value = calculation_deep(hole)[0]
                    except:
                        logger.warning(f"该文件id:{id}没有取样这一列")
                elif key in tj['deep_info']['penetration_depth']:
                    try:
                        js_bg_value = calculation_deep(hole)[1]
                    except:
                        logger.warning(f"该文件id:{id}没有标贯深度这一列")

                # 实际深度
                keys = ['eng_info_id', 'deep_field_name', 'deep_field_value', 'deep_field_coor', 'page', 'create_time']
                d_value = [file.eng_info_set.values()[eng_land_index]['id'], key, value, value_coor, page_deep,
                           time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)]
                DeepSplitInfo.objects.create(**dict(zip(keys, d_value)))

            for js_qy in js_qy_value:
                keys = ['eng_info_id', 'deep_field_name', 'deep_field_value', 'page', 'create_time']
                d_value = [file.eng_info_set.values()[eng_land_index]['id'], '计算取样深度', js_qy, page_deep,
                           time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)]
                DeepSplitInfo.objects.create(**dict(zip(keys, d_value)))
            for js_bg in js_bg_value:
                keys = ['eng_info_id', 'deep_field_name', 'deep_field_value', 'page', 'create_time']
                d_value = [file.eng_info_set.values()[eng_land_index]['id'], '计算标贯深度', js_bg, page_deep,
                           time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)]
                DeepSplitInfo.objects.create(**dict(zip(keys, d_value)))

        # 更新t_file表table的坐标，及对应的文本
        position_info = hole['position_info']
        ocr_img_urls = hole['ocr_img_urls']

        def replace_key_text(cell):
            # 把所有纠正过的key保留，并替换原来的元素
            real_key = is_key(cell.get("text", ""))
            if real_key:
                cell["text"] = real_key
                return True

        small_json = [[cell for cell in filter(lambda cell: replace_key_text(cell), big_json_item)] for
                      big_json_item in position_info]
        file.position_info = json.dumps(eval(str(small_json)))
        file.ocr_img_urls = json.dumps(ocr_img_urls)
        file.ocr_time = time.strftime(settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
        file.save()
