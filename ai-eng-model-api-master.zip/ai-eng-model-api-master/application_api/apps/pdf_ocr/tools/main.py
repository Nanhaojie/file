#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：pdf_ocr.py
@Author ：nhj
@Date ：2021/4/22 上午9:56 
'''
import logging

from application_api.settings import FILE_SERVER_URL
from pdf_ocr.models import FileModel
from pdf_ocr.tools.Database import in_db
from pdf_ocr.tools.Table import Table
from pdf_ocr.services.service import ocr_all
import json
import numpy as np
import cv2
from pdf_ocr.tools.draw_table import draw_boxes
from pdf_ocr.tools.update_database import in_db_update
from utils.common import get_img

logger = logging.getLogger('django')


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, bytes):
            return str(obj, encoding='utf-8')
        else:
            return super(NpEncoder, self).default(obj)


def ocr(pdf, id, file_type):
    tables = list()
    tb = Table()
    coors = []
    results = ocr_all(pdf, file_type)
    logger.info(f'文件{id}获取模型服务结果为{str(results)[:300]}')
    urls = results[1]
    for i, result in enumerate(results[0]):
        t_lay = result[0]
        p_img = result[1]

        # 补救table模型未识别准确
        img = cv2.imdecode(np.asarray(bytearray(get_img(FILE_SERVER_URL+urls[i])), dtype='uint8'), cv2.IMREAD_COLOR)
        desc = tb.search_desc(p_img, t_lay)

        # table画图
        # tmp = draw_boxes(img, t_lay, (255, 0, 0))
        # cv2.imwrite('1.png', tmp)

        if isinstance(desc, list):
            cols = tb.search_col(t_lay, desc)
            try:
                desc = tb.hoff_line(cols, img)
                t_lay = tb.del_add(t_lay, desc)
            except:
                logger.info(f'文件{id}补救岩性描述列找不到横线')
        merge = tb.ocr_merge_layout(p_img, t_lay)
        table_layout = tb.semantic_layout(merge)
        table_layout['page'] = i
        tkv = tb.semantic_kv(table_layout, img)
        tables.append(tkv)

        # 坐标
        # coor = [i['table_text_coor'] for i in merge]
        coors.append(merge)

    holes = tb.merge_hole_no(tables)
    if not holes:
        assert holes, '融合孔号时返回空'
    for hole in holes:
        hole['file_id'] = id
        hole['position_info'] = coors
        hole['ocr_img_urls'] = urls

    logger.info(f'文件{id}模型融合后的结果为{str(results)[:300]}')
    in_db(holes)


def update_ocr(pk, merges):
    tables = list()
    tb = Table()
    coors = []
    file = FileModel.objects.filter(id=pk).first()

    img_urls = eval(file.ocr_img_urls)
    for i, merge in enumerate(merges):

        img = cv2.imdecode(np.asarray(bytearray(get_img(img_urls[i])), dtype='uint8'), cv2.IMREAD_COLOR)
        table_layout = tb.semantic_layout(merge)
        table_layout['page'] = i
        tkv = tb.semantic_kv(table_layout, img)
        tables.append(tkv)
        coors.append(merge)

    holes = tb.merge_hole_no(tables)
    for hole in holes:
        hole['file_id'] = pk
    in_db_update(holes, merges)