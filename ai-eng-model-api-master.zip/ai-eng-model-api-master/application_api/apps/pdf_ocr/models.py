from django.db import models

from utils.models import SpareFieldModel


class FileModel(SpareFieldModel):
    ocr_status_choices = (
        (1, "web识别中"),
        (2, "ios识别中"),
        (3, "安卓识别中"),
        (4, "ios排队中"),
        (5, "web排队中"),
        (6, "安卓排队中"),
        (7, "失败"),
        (9, "待识别"),
        (11, "成功")
    )
    upload_status_choices = (
        (0, "失败"),
        (1, "正在进行"),
        (2, "成功"),
    )
    file_type_choices = (
        (0, "文件夹"),
        (1, "pdf"),
        (2, "png"),
        (3, "jpg"),
    )

    company = models.ForeignKey("user.Company", on_delete=models.DO_NOTHING, null=True, blank=True,
                                related_name="company_files", db_constraint=False)
    user = models.ForeignKey("user.User", on_delete=models.DO_NOTHING, related_name="user_upload_files",
                             db_constraint=False)
    file_owner = models.ForeignKey("user.User", on_delete=models.DO_NOTHING, related_name="files_owned_by_user",
                                   db_constraint=False, verbose_name="文件拥有者")
    p_file = models.ForeignKey("self", on_delete=models.CASCADE, null=True, blank=True, related_name="son_files",
                               db_constraint=False)
    type = models.SmallIntegerField(default=1, choices=file_type_choices, verbose_name="文件类型")
    size = models.IntegerField(default=0, db_index=True, verbose_name="文件大小")
    name = models.CharField(max_length=255, verbose_name="文件名称")
    url = models.CharField(max_length=255, db_index=True, null=True, blank=True, verbose_name="文件url")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="图片上传时间")
    ocr_time = models.DateTimeField(null=True, blank=True, db_index=True, verbose_name="图片上传时间")
    ocr_status = models.SmallIntegerField(default=9, choices=ocr_status_choices)
    upload_status = models.SmallIntegerField(default=2, choices=upload_status_choices)
    is_delete = models.BooleanField(max_length=1, default=0, verbose_name="文件是否删除")
    is_review = models.BooleanField(max_length=1, default=0, verbose_name="文件是否被检查过")
    ocr_img_urls = models.CharField(max_length=5000, null=True, blank=True, verbose_name="ocr中间图片列表")
    position_info = models.TextField(null=True, blank=True, verbose_name="table及文本位置信息")
    celery_task_id = models.CharField(null=True, blank=True, max_length=64, verbose_name="celery 任务id")
    err_code = models.SmallIntegerField(null=True, blank=True, verbose_name="ocr任务错误代码")

    class Meta:
        # 指明数据库表名
        db_table = 't_file'
        # 在admin站点中显示的名称
        verbose_name = '文件表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class EngInfoModel(SpareFieldModel):
    file = models.ForeignKey(FileModel, on_delete=models.CASCADE, related_name="eng_info_set", db_constraint=False)
    eng_name = models.CharField(max_length=128, blank=True, null=True, verbose_name="工程名称")
    eng_no = models.CharField(max_length=128, blank=True, null=True, verbose_name="工程编号")
    boring_no = models.CharField(max_length=128, blank=True, null=True, verbose_name="钻孔编号")
    orifice_height = models.CharField(max_length=128, blank=True, null=True, verbose_name="孔口标高")
    orifice_diameter = models.CharField(max_length=128, blank=True, null=True, verbose_name="孔口直径")
    hole_depth = models.CharField(max_length=128, blank=True, null=True, verbose_name="终孔深度")
    coordinates = models.CharField(max_length=128, blank=True, null=True, verbose_name="坐标")
    start_date = models.CharField(max_length=128, blank=True, null=True, verbose_name="开工日期")
    completion_date = models.CharField(max_length=128, blank=True, null=True, verbose_name="竣工日期")
    water_depth = models.CharField(max_length=128, blank=True, null=True, verbose_name="稳定水位深度")
    water_date = models.CharField(max_length=128, blank=True, null=True, verbose_name="测量水位日期")
    stable_water_level = models.CharField(max_length=128, blank=True, null=True, verbose_name="稳定水位")
    pressure_water_level = models.CharField(max_length=128, blank=True, null=True, verbose_name="承压水位")
    initial_water_level = models.CharField(max_length=128, blank=True, null=True, verbose_name="初见水位")
    mileage = models.CharField(max_length=128, blank=True, null=True, verbose_name="里程")
    offset = models.CharField(max_length=128, blank=True, null=True, verbose_name="偏移")
    drill_depth = models.CharField(max_length=128, blank=True, null=True, verbose_name="钻孔深度")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="数字化时间")
    # 坐标信息  '1-124,156,145,175'  横线前面是页码信息，后面的坐标信息
    eng_name_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="工程名称坐标")
    eng_no_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="工程编号坐标")
    boring_no_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="钻孔编号坐标")
    orifice_height_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="孔口标高坐标")
    orifice_diameter_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="孔口直径坐标")
    hole_depth_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="终孔深度坐标")
    coordinates_coor = models.CharField(max_length=128, blank=True, null=True, verbose_name="坐标字段的坐标")
    start_date_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="开工日期坐标")
    completion_date_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="竣工日期坐标")
    water_depth_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="稳定水位深度坐标")
    water_date_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="测量水位日期坐标")
    stable_water_level_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="稳定水位坐标")
    pressure_water_level_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="承压水位坐标")
    initial_water_level_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="初见水位坐标")
    mileage_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="里程坐标")
    offset_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="偏移坐标")
    drill_depth_coor = models.CharField(max_length=64, blank=True, null=True, verbose_name="钻孔深度坐标")
    page = models.IntegerField(default=0, verbose_name="页数")

    class Meta:
        # 指明数据库表名
        db_table = 't_eng_info'
        # 在admin站点中显示的名称
        verbose_name = '工程信息表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class LandInfoModel(SpareFieldModel):
    eng_info = models.ForeignKey(EngInfoModel, on_delete=models.CASCADE, related_name="land_info_set",
                                 db_constraint=False)
    geological_age = models.CharField(max_length=128, null=True, blank=True, verbose_name="地质时代")
    floor_number = models.CharField(max_length=128, null=True, blank=True, verbose_name="层号")
    stratum_name = models.CharField(max_length=128, null=True, blank=True, verbose_name="地层名称")
    bottom_elevation = models.CharField(max_length=128, null=True, blank=True, verbose_name="层底标高(m)")
    bottom_depth = models.CharField(max_length=128, null=True, blank=True, verbose_name="层底深度(m)")
    delamination_thickness = models.CharField(max_length=128, null=True, blank=True, verbose_name="分层厚度(m)")
    histogram = models.CharField(max_length=128, null=True, blank=True, verbose_name="柱状图1:250")
    state = models.CharField(max_length=128, null=True, blank=True, verbose_name="状态风华程度")
    lithology_description = models.CharField(max_length=2000, null=True, blank=True, verbose_name="岩性描述")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="数字化时间")
    # 坐标信息
    geological_age_coor = models.CharField(max_length=512, null=True, blank=True, verbose_name="地质时代坐标")
    floor_number_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="层号坐标")
    stratum_name_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="地层名称坐标")
    bottom_elevation_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="层底标高(m)坐标")
    bottom_depth_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="层底深度(m)坐标")
    delamination_thickness_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="分层厚度(m)坐标")
    histogram_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="柱状图1:250坐标")
    state_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="状态风华程度坐标")
    lithology_description_coor = models.CharField(max_length=64, null=True, blank=True, verbose_name="岩性描述坐标")
    page = models.IntegerField(default=0, verbose_name="页数")

    class Meta:
        # 指明数据库表名
        db_table = 't_land_info'
        # 在admin站点中显示的名称
        verbose_name = '土地信息表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class DeepSplitInfo(SpareFieldModel):
    eng_info = models.ForeignKey(EngInfoModel, on_delete=models.CASCADE, related_name="deep_split_info_set",
                                 db_constraint=False)
    deep_field_name = models.CharField(max_length=128, verbose_name="深度字段名称")
    deep_field_value = models.CharField(max_length=512, null=True, blank=True, verbose_name="深度字段内容")
    deep_field_coor = models.CharField(max_length=128, null=True, blank=True, verbose_name="深度字段表格坐标")
    page = models.IntegerField(default=0, verbose_name="页数")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="数字化时间")

    class Meta:
        # 指明数据库表名
        db_table = 't_deep_split_info'
        # 在admin站点中显示的名称
        verbose_name = '深度信息字段分割表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


# 名称字典
coor_info = {
    'eng_model': {
        'eng_name': '工程名称',
        'eng_no': '工程编号',
        'boring_no': '钻孔编号',
        'orifice_height': '孔口标高',
        'orifice_diameter': '孔口直径',
        'hole_depth': '终孔深度',
        'coordinates': '坐标',
        'start_date': '开工日期',
        'completion_date': '竣工日期',
        'water_depth': '稳定水位深度',
        'water_date': '测量水位日期',
        'stable_water_level': '稳定水位',
        'pressure_water_level': '承压水位',
        'initial_water_level': '初见水位',
        'mileage': '里程',
        'offset': '偏移',
        'drill_depth': '钻孔深度'
    },
    'land_model': {
        'geological_age': '地质时代',
        'floor_number': '层号',
        'stratum_name': '地层名称',
        'bottom_elevation': '层底标高(m)',
        'bottom_depth': '层底深度(m)',
        'delamination_thickness': '分层厚度(m)',
        'histogram': '柱状图',
        'state': '状态风华程度',
        'lithology_description': '岩性描述'
    },
    'deep_model': {
        'geological_age': '地质时代',
        'actual_sampling': '计算取样深度',
        'sampling': '取样',
        'actual_penetration_depth': '计算标贯深度',
        'penetration_depth': '标贯中点深度(m)',
        'penetration_hit': '标贯实测击数',
        'stable_water_level': '稳定水位w和水位日期',
        'note': '附注',
        'resistance_limit': '桩侧阻极限标准值',
        'bearing_capacity': '承载力基本容许值',
        'friction_force': '桩侧摩阻力标准值'
    }
}
