#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Title   : 关键字法纠错
@File    : keyword_corrector.py
@Author  : Tian
@Time    : 2020/06/16 5:04 下午
@Version : 1.0
"""
import logging
import os
import json
from pdf_ocr.services.correction.BKtree import BKTree
import re

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%H:%M:%S')


def build_tree():
    tree = BKTree("apps/pdf_ocr/services/correction/key_words.json")
    tree.plant_tree()
    return tree


def load_key_words_dict():
    file = 'apps/pdf_ocr/services/correction/key_words.json'
    content = open(file, "r").read()
    a = json.loads(content)
    return a


key_words = load_key_words_dict()
tree = build_tree()


def correct_all(texts):
    results = []
    for text in texts:
        text = text.replace('（', '(')
        text = text.replace('）', ')')
        if re.match(r"(?=.{0,3}岩)(?=.{0,3}性)(?=.{0,3}描)(?=.{0,3}述)[岩性描述]{4}", text):
            text = "岩性描述"
        if re.match(r"(?=.{0,3}地)(?=.{0,3}层)(?=.{0,3}描)(?=.{0,3}述)[地层描述]{4}", text):
            text = "地层描述"
        text = re.sub('[(]', '', text)
        text = re.sub('[)]', '', text)
        text = re.sub('[m]', '', text)

        try:
            flag = 0
            for key in key_words:
                if text in key_words[key]:
                    flag = 1
                    text = key
                    results.append(text)
                    # logger.debug('【%s】在关键词表中，跳过',text)
                    break
            if flag == 0:
                # 根据编辑距离找到近似的关键词
                k = tree.search(text, 1)
                if not k:
                    results.append(text)
                    continue
                # logger.debug('找到编辑距离在1以内的关键词【%s】', k)
                for key in key_words:
                    if k[0] in key_words[key]:
                        k[0] = key
                        results.append(k[0])
                        break
        except Exception:
            # import traceback
            # logger.error(traceback.format_exc())
            logger.error('纠错出现错误，跳过【%s】', text)
            continue
    return results


def similar(src):
    '''
    src: list->str
    return: list->str
    '''
    ocr_res_corrected = correct_all(src)
    return ocr_res_corrected
