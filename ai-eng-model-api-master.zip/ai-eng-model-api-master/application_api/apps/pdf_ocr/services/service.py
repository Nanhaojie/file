#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ai-eng-model-api 
@File ：service.py
@Author ：nhj
@Date ：2021/4/19 上午11:18 
'''

import requests

from application_api.settings import MODEL_URL


def jz_service(img, file_type):
    url = MODEL_URL + '/jz'
    files = {'images': img}
    params = {'file_type': file_type}
    r = requests.post(url=url, files=files, params=params)
    res = r.json()['fm']
    assert res, '纠正接口返回空'
    return res


def table_service(img):
    url = MODEL_URL + '/table'
    files = {'images': img}
    r = requests.post(url=url, files=files)
    res = r.json()['table']
    assert res, 'table接口返回空'
    return res


# def ocr_service(img):
#     url = 'http://172.16.0.18:8502/ocr'
#     files = {'images': img}
#     r = requests.post(url=url, files=files)
#     res = r.json()['ocr']
#     return res


def formula(img):
    url = MODEL_URL + '/fm'
    files = {'images': img}
    r = requests.post(url=url, files=files)
    res = r.json()['fm']
    return res


def ocr_all(img, file_type):
    # url = 'http://172.16.0.18:8502/ttc' # 18服务器掉本地模型
    url = MODEL_URL + '/ttc'  # 21服务器tfserving模型
    files = {'images': img}
    params = {'file_type': file_type}
    r = requests.post(url=url, files=files, params=params)
    res = r.json()['result']
    assert res, '识别全流程接口返回空'
    assert res[0], '识别全流程接口item1返回空'
    assert res[1], '识别全流程接口item2返回空'
    return res


# im = 'fm.png'
# res = formula(open(im, 'rb'))
# print(res)
