#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：application_api 
@File ：serializers.py
@Author ：nhj
@Date ：2021/4/21 下午2:33 
'''
import urllib.parse
from datetime import datetime
import re

from django.conf import settings
from rest_framework import serializers
from pdf_ocr.models import FileModel, EngInfoModel, LandInfoModel
from user.models import User
from utils.common import verify_content, split_file_url, cut_file_url


class FileSearchSerializer(serializers.ModelSerializer):
    p_file_name = serializers.CharField(source='p_file.name', default=None, label='父文件夹名称')

    class Meta:
        # 指定序列化器对应的模型
        model = FileModel
        fields = ["name", "url", "create_time", "ocr_time", "ocr_status", "upload_status", "is_review", "id", "p_file",
                  "type", "size", "p_file_name"]
        extra_kwargs = {
            "create_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "ocr_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "url": {"default": ""}
        }

    def to_representation(self, instance):
        data = super(FileSearchSerializer, self).to_representation(instance)
        url = data.get('url')
        if url:
            data['url'] = split_file_url(url)
        return data


class FileSerializer(serializers.ModelSerializer):

    def validate_name(self, name):
        name = re.sub(r"\s", "", name)
        p_file_id = self.context["request"].data.get("p_file")
        # 查询创建目录下所有文件的文件名
        file_list = FileModel.objects.filter(p_file_id=p_file_id).only("name")
        if name in [file.name for file in file_list]:
            name_keywords = name.rsplit(".", 1)
            if len(name_keywords) == 1:
                return f"{name_keywords[0]}_{datetime.now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}"
            return f"{name_keywords[0]}_{datetime.now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}.{name_keywords[1]}"
        else:
            return name

    def validate_url(self, url):
        # 创建文件时url的校验
        type = self.context["request"].data.get("type")
        if type in [0, '0']:
            return url
        # 如果type不为0，那么url为必填项
        if not url:
            raise serializers.ValidationError("文件的url不能为空")
        # 校验文件内容
        if not verify_content(url, type):
            raise serializers.ValidationError("文件类型异常")
        url = urllib.parse.quote(url, safe='://')
        url = cut_file_url(url)
        is_force = self.context["request"].query_params.get("is_force", 0)
        if is_force == '1':
            return url
        else:
            # 校验文件url是否存在 如果存在并且is_force为False那么抛出异常
            file = FileModel.objects.filter(url=url, company_id=self.context["request"].user.company_id).only("id").first()
            if file:
                raise serializers.ValidationError("exist")
            return url

    def get_folder_layer_level(self, file_obj, level):
        p_file_obj = FileModel.objects.filter(id=file_obj.p_file_id).only('p_file_id', 'id').first()
        if not p_file_obj:
            return level
        return self.get_folder_layer_level(p_file_obj, level + 1)

    def validate(self, attrs):
        # 校验文件 的创建层级
        if attrs.get("type") == 0:
            current_level = self.get_folder_layer_level(attrs.get("p_file"), 2)
            if current_level > settings.FOLDER_MAX_LAYER_LEVEL:
                raise serializers.ValidationError(f"文件夹不能超过{settings.FOLDER_MAX_LAYER_LEVEL}级")
        return attrs

    def create(self, validated_data):
        validated_data["user_id"] = self.context["request"].user.id
        file_owner_id = FileModel.objects.filter(id=validated_data["p_file"].id). \
            only('file_owner_id').first().file_owner_id
        validated_data["file_owner_id"] = file_owner_id
        validated_data["company_id"] = self.context["request"].user.company_id
        return super().create(validated_data)

    class Meta:
        # 指定序列化器对应的模型
        model = FileModel
        fields = ["name", "url", "create_time", "ocr_time", "ocr_status", "upload_status", "is_review", "id", "p_file",
                  "type", "size"]
        extra_kwargs = {
            "create_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "ocr_time": {"read_only": True, "format": settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            "p_file": {"required": True},
            "url": {"default": ""}
        }

    def to_representation(self, instance):
        data = super(FileSerializer, self).to_representation(instance)
        url = data.get('url')
        if url:
            data['url'] = split_file_url(url)
        return data


class FileUpdateSerializer(serializers.ModelSerializer):
    def validate_name(self, name):
        name = re.sub(r"\s", "", name)
        p_file_id = self.instance.p_file_id
        # 查询创建目录下所有文件的文件名
        file_list = FileModel.objects.filter(p_file_id=p_file_id).only("name")
        if name in [file.name for file in file_list]:
            name_keywords = name.rsplit(".", 1)
            if len(name_keywords) == 1:
                return f"{name_keywords[0]}_{datetime.now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}"
            return f"{name_keywords[0]}_{datetime.now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}.{name_keywords[1]}"
        else:
            return name

    class Meta:
        # 指定序列化器对应的模型
        model = FileModel
        fields = ["name", "id"]
        extra_kwargs = {
            "name": {"required": False},
        }


class EngInfoSerializer(serializers.ModelSerializer):
    def update(self, instance, validated_data):
        eng_name = validated_data.get('eng_name')
        if eng_name:
            instance.photo = eng_name
        instance.save()
        return instance

    class Meta:
        # 指定序列化器对应的模型
        model = EngInfoModel
        fields = ['eng_name']


class LandInfoSerializer(serializers.ModelSerializer):
    class Meta:
        # 指定序列化器对应的模型
        model = LandInfoModel
        exclude = ("spare_str", "spare_int1", "spare_int2", "create_time")


class FileEditSerializer(serializers.ModelSerializer):
    eng_info_set = EngInfoSerializer(many=True)

    class Meta:
        model = FileModel
        fields = ['eng_info_set']


class EngInfoUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = EngInfoModel
        exclude = ("spare_str", "spare_int1", "spare_int2", "create_time", "file")


class LandInfoUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LandInfoModel
        exclude = ("spare_str", "spare_int1", "spare_int2", "create_time", "eng_info")


class BoringNoSerializer(serializers.ModelSerializer):
    eng_id = serializers.IntegerField(source='id')

    class Meta:
        model = EngInfoModel
        fields = [
            'eng_id', 'boring_no'
        ]


class SubdirectorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FileModel
        fields = [
            'id', 'name'
        ]


class OcrStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileModel
        fields = [
            'id', 'ocr_status'
        ]


class EngLocationInfo(serializers.ModelSerializer):
    file = serializers.IntegerField(source='file_id')

    class Meta:
        model = EngInfoModel
        fields = [
            'eng_name', 'spare_int1', 'spare_int2', 'file'
        ]

    def to_representation(self, instance):
        data = super(EngLocationInfo, self).to_representation(instance)
        data['content'] = data.pop('eng_name')
        if data.get('spare_int1'):
            data['lng'] = str(data.pop('spare_int1')/1000000)
        else:
            del data['spare_int1']
            data['lng'] = ''
        if data.get('spare_int2'):
            data['lat'] = str(data.pop('spare_int2')/1000000)
        else:
            del data['spare_int2']
            data['lat'] = ''
        data['id'] = data.pop('file')
        return data


class AppEngLocationInfo(serializers.ModelSerializer):
    file = serializers.IntegerField(source='file_id')
    file_name = serializers.CharField(source='file.name')
    ocr_img_url = serializers.CharField(source='file.ocr_img_urls')

    class Meta:
        model = EngInfoModel
        fields = [
            'eng_name', 'spare_int1', 'spare_int2', 'file', 'file_name', 'eng_no', 'boring_no', 'ocr_img_url'
        ]

    def to_representation(self, instance):
        data = super(AppEngLocationInfo, self).to_representation(instance)
        data['content'] = data.pop('eng_name')
        if data.get('spare_int1'):
            data['lng'] = str(data.pop('spare_int1')/1000000)
        else:
            del data['spare_int1']
            data['lng'] = ''
        if data.get('spare_int2'):
            data['lat'] = str(data.pop('spare_int2')/1000000)
        else:
            del data['spare_int2']
            data['lat'] = ''
        data['id'] = data.pop('file')
        # 图片
        ocr_img_url = data.get('ocr_img_url')
        if ocr_img_url:
            ocr_img_url = eval(ocr_img_url)
            for i in range(len(ocr_img_url)):
                ocr_img_url[i] = split_file_url(ocr_img_url[i])
            data['ocr_img_url'] = ocr_img_url
        return data