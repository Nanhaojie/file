import asyncio
import datetime
import logging
import re
import tempfile
import traceback
from copy import deepcopy
import json
from functools import reduce

import aiohttp
import requests
from django.conf import settings
from django.db import connection
from django.db.models import Q, Count, F
from django.db.models.functions import TruncDate
from django.http import JsonResponse, HttpRequest, HttpResponse, StreamingHttpResponse
from django.forms.models import model_to_dict
from django.utils.timezone import now
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView, RetrieveAPIView, UpdateAPIView, CreateAPIView
from rest_framework.viewsets import GenericViewSet, ModelViewSet

from celery_tasks import main
from celery_tasks.ocr.tasks import web_file_ocr, ios_file_ocr, android_file_table, ocr_table_merge
from pdf_ocr import serializers
from pdf_ocr.models import FileModel, EngInfoModel, LandInfoModel, DeepSplitInfo
from pdf_ocr.tools.main import update_ocr
from utils.common import zj_upload_async, request_finished_custom, zj_upload_sync, split_file_url, split_intra_file_url, \
    get_urt
from utils.views import AsyncIsAuthenticated, AsyncAPIView
from user.models import User
from utils.pagination import StandardResultPagination

from itertools import chain

from .serializers import BoringNoSerializer, SubdirectorySerializer, OcrStatusSerializer

import pandas as pd
import zipfile
import time

from .models import coor_info
from .services.service import jz_service
from .tools.common import is_key

from requests.exceptions import ConnectionError
from concurrent.futures._base import TimeoutError
import numpy as np

logger = logging.getLogger("django")


class MobileStartOcrView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, pk, *args):
        """安卓开始识别接口 安卓在ocr前调用"""
        # （兼容重启加标识）
        is_reload = request.data.get("is_reload")
        if is_reload == '1':
            # 接受安卓队列中的文件id, 接受文件ocr类型为正在识别中
            file_obj = FileModel.objects.filter(ocr_status=3, id=pk, company_id=request.user.company_id).first()
        else:
            # 1.校验文件id的状态是否为安卓队列中
            file_obj = FileModel.objects.filter(ocr_status=6, id=pk, company_id=request.user.company_id).first()
        if not file_obj:
            return Response({'detail': '文件状态异常'}, status=status.HTTP_400_BAD_REQUEST)

        # 2.更改文件状态为安卓正在识别中
        file_obj.ocr_status = 3
        file_obj.save()

        # 3.根据文件类型pdf统一转换为png类型 3.2调用纠正接口 3.3上传到文件服务器
        try:
            url_list = jz_service(requests.get(split_file_url(file_obj.url), timeout=10).content, file_obj.type)
        except Exception:
            logger.error(f'安卓端ocr-文件{pk}图片纠正失败', exc_info=True)
            file_obj.ocr_status = 7
            file_obj.save()
            return Response({'detail': '文件纠正失败'}, status=status.HTTP_400_BAD_REQUEST)
        # 6.切割后的图片保存数据库
        file_obj.ocr_img_urls = json.dumps(url_list)
        # 6.启动table异步任务，将结果存储到redis中
        if url_list:
            for i in range(len(url_list)):
                url_list[i] = split_intra_file_url(url_list[i])
        celery_task = android_file_table.s(pk, url_list).apply_async()
        file_obj.celery_task_id = celery_task.task_id
        file_obj.save()

        request_finished_custom.send("安卓端开始识别", request=self.request)

        # 7.返回给安卓被纠正过文件的url列表
        return Response({'url_list': url_list})


class MobileBatchOcrView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_target_file(self, target_file_id_set, file_folder_set: pd.DataFrame, current_file_set: pd.DataFrame):
        for file in current_file_set.itertuples():
            if file.type == 0:
                # 如果文件类型为 0，查询子文件 递归调用
                next_file_set = file_folder_set[file_folder_set.p_file_id == file.id]
                if len(next_file_set) != 0:
                    self.get_target_file(target_file_id_set, file_folder_set, next_file_set)
            else:
                # 否则， 添加到 target_file_id_list 中
                target_file_id_set.add(file.id)

    def post(self, request, *args, **kwargs):
        """移动端批量识别接口 入移动端队列，其他端可以取消"""
        file_id_list = request.data.get('pks')
        if not file_id_list:
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        # 获取查询集合
        if self.request.user.is_staff:
            first_file = FileModel.objects.filter(id__in=file_id_list).only("file_owner_id").first()
            if not first_file:
                return Response({'detail': '数据不存在'}, status=status.HTTP_400_BAD_REQUEST)
            queryset = FileModel.objects.filter(file_owner_id=first_file.file_owner_id).defer("ocr_img_urls",
                                                                                              "position_info")
        else:
            queryset = FileModel.objects.filter(file_owner=self.request.user).defer("ocr_img_urls", "position_info")

        # 1. 查询所有符合条件的文件及子文件的id
        # 1.1 查询用户所有符合条件的文件，user=user,ocr_status__in=(7, 9)
        columns = ('id', 'name', 'type', 'p_file_id')
        file_folder_set = queryset.filter(ocr_status__in=(7, 9)).values_list(*columns)
        # 1.2 构建dataframe
        file_folder_set = pd.DataFrame(list(file_folder_set), columns=columns)
        # 1.3 递归查询用户指定文件及所有子文件的id
        next_file_set = file_folder_set[file_folder_set.id.isin(file_id_list)]
        target_file_id_set = set()
        self.get_target_file(target_file_id_set, file_folder_set, next_file_set)

        # 2.更改文件状态为安卓队列中
        FileModel.objects.filter(id__in=target_file_id_set).update(ocr_status=6)
        # 3.将参数id中，不能识别的文件id及状态返回给前端（前端更新状态）
        not_add_file_set = FileModel.objects.filter(type__in=(1, 2, 3),
                                                    id__in=set(file_id_list).difference(target_file_id_set)) \
            .only('id', 'ocr_status').values('id', 'ocr_status')
        request_finished_custom.send("安卓端提交识别", request=self.request)
        # 4.将所有成功添加队列的id也返回前端
        return Response({'not_add': list(not_add_file_set), 'add': list(target_file_id_set)})


class UserFileStat(APIView):
    permission_classes = (IsAdminUser,)

    def get(self, request):
        nums = request.query_params.get('nums', '6')
        if not re.match(r'\d+', nums):
            return Response({'detail': '参数格式错误'}, status=status.HTTP_400_BAD_REQUEST)
        user_file_stat = FileModel.objects.filter(~Q(type=0) & Q(company_id=request.user.company_id)) \
                             .prefetch_related('user__username', 'user__user_num') \
                             .values('user', 'user__username', 'user__user_num') \
                             .annotate(
            **{'total': Count('user'), 'username': F('user__username'), 'user_num': F('user__user_num')}) \
                             .order_by('-total')[:int(nums)]
        request_finished_custom.send('首页用户上传排行', request=self.request)
        return Response(list(user_file_stat))


class UserOCRStat(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        days = request.query_params.get('days', '6')
        if not re.match(r'\d+', days):
            return Response({'detail': '参数格式错误'}, status=status.HTTP_400_BAD_REQUEST)

        # 6天前的时间
        from_date = now().date() - datetime.timedelta(days=int(days) - 1)

        file_ocr_stat = FileModel.objects.filter(file_owner=request.user.id, ocr_time__gte=from_date, ocr_status=11) \
            .annotate(upload_date=TruncDate('create_time')) \
            .order_by('-upload_date') \
            .values('upload_date') \
            .annotate(**{'total': Count('upload_date')})

        # 数据格式转换
        file_ocr_stat = {ocr_date.get("upload_date").strftime(settings.SERIALIZER_DATE_FIELD_FORMAT):
                             ocr_date.get("total") for ocr_date in file_ocr_stat}

        # 将其他的时间补充为0
        for offset_days in range(int(days) - 1, -1, -1):
            current_date_str = (now().date() - datetime.timedelta(offset_days)).strftime(
                settings.SERIALIZER_DATE_FIELD_FORMAT)
            file_ocr_stat[current_date_str] = file_ocr_stat.get(current_date_str, 0)

        # 对字典排序
        file_upload_stat = sorted(file_ocr_stat.items(), key=lambda x: x[0])
        request_finished_custom.send('首页识别信息统计', request=self.request)
        return Response(file_upload_stat)


class UserUploadStat(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        days = request.query_params.get('days', '6')
        if not re.match(r'\d+', days):
            return Response({'detail': '参数格式错误'}, status=status.HTTP_400_BAD_REQUEST)

        # 6天前的时间
        from_date = now().date() - datetime.timedelta(days=int(days) - 1)

        file_upload_stat = FileModel.objects.filter(user_id=request.user.id, create_time__gte=from_date,
                                                    type__in=(1, 2, 3)) \
            .annotate(upload_date=TruncDate('create_time')) \
            .order_by('-upload_date') \
            .values('upload_date') \
            .annotate(**{'total': Count('upload_date')})

        # 数据格式转换
        file_upload_stat = {upload_date.get("upload_date").strftime(settings.SERIALIZER_DATE_FIELD_FORMAT):
                                upload_date.get("total") for upload_date in file_upload_stat}

        # 将其他的时间补充为0
        for offset_days in range(int(days) - 1, -1, -1):
            current_date_str = (now().date() - datetime.timedelta(offset_days)).strftime(
                settings.SERIALIZER_DATE_FIELD_FORMAT)
            file_upload_stat[current_date_str] = file_upload_stat.get(current_date_str, 0)

        # 对字典排序
        file_upload_stat = sorted(file_upload_stat.items(), key=lambda x: x[0])
        request_finished_custom.send('首页上传文件统计', request=self.request)
        return Response(file_upload_stat)


class TokenCheckView(APIView):
    def post(self, request):
        if request.user.is_authenticated:
            return HttpResponse('ok')
        else:
            return HttpResponse('fail')


async def upload_file(request: HttpRequest, *args):
    """文件上传 没有用户认证"""
    # 参数校验
    if request.method != "post":
        return JsonResponse({"detail": "请求方式不允许"})
    file = request.FILES.get("file")
    if not file:
        return JsonResponse({"detail": "参数缺失"})

    try:
        file_url = await zj_upload_async(file.read())
    except Exception:
        logger.error("上传失败", exc_info=True)
        return JsonResponse({"detail": "上传失败"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
    return JsonResponse({"detail": "成功", "url": file_url})


class FileView(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        keywords = self.request.query_params.get("keywords")
        if keywords:
            return serializers.FileSearchSerializer
        if self.action == "update":
            return serializers.FileUpdateSerializer
        elif self.action == "list":
            return serializers.FileSearchSerializer
        else:
            return serializers.FileSerializer

    def list(self, request, *args, **kwargs):
        response = super(FileView, self).list(request, *args, **kwargs)
        request_finished_custom.send("文件名查询", request=self.request)
        return response

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            queryset = FileModel.objects.filter(company_id=user.company_id).defer("ocr_img_urls", "position_info")
        else:
            # 字段筛选
            queryset = FileModel.objects.filter(file_owner=self.request.user).defer("ocr_img_urls", "position_info")
        from_data = self.request.query_params.get("from_data")
        to_data = self.request.query_params.get("to_data")
        if from_data:
            queryset = queryset.filter(create_time__gte=from_data)
        if to_data:
            queryset = queryset.filter(create_time__lte=to_data + " 23:59:59")

        keywords = self.request.query_params.get("keywords")
        # 如果有 keywords 就进行文件的搜索
        if keywords:
            queryset = queryset.filter(name__contains=keywords, p_file_id__isnull=False)

        # 验证用户传递的排序关键字
        order_by_keywords = self.request.query_params.get("order_by")
        if order_by_keywords:
            order_by_keyword_list = [order_by_filed for order_by_filed in order_by_keywords.split(",")
                                     if order_by_filed in ["-name", "name", "create_time", "-create_time",
                                                           "upload_status", "-upload_status", "ocr_status",
                                                           "-ocr_status", "size", "-size", "ocr_time", "-ocr_time",
                                                           "is_review", "-is_review"]]
            order_by_keyword_list.insert(0, "type")
            if '-create_time' not in order_by_keyword_list:
                order_by_keyword_list.append("-create_time")

            queryset = queryset.order_by(*order_by_keyword_list)
        else:
            # 默认按照先文件夹再文件的排序方式
            queryset = queryset.order_by("type", "-id")
        return queryset

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid(raise_exception=False):
            # 如果为文件已存在
            if 'exist' in serializer.errors.get("url", []):
                return Response({"detail": "该文件已存在 是否重新保存？"}, status=status.HTTP_409_CONFLICT)
            return Response({"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        response = Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        request_finished_custom.send("新建文件/文件夹", request=self.request)
        return response
        # user_id = request.user.id
        # file_owner_id = FileModel.objects.filter(id=serializer.data["p_file"]).only('file_owner_id').first().file_owner_id
        # perform_create_.s(data=serializer.data, user_id=user_id, file_owner_id=file_owner_id).apply_async()
        # return Response({'detail': '成功'})

    def retrieve(self, request, *args, **kwargs):
        keywords = self.request.query_params.get("keywords")
        # 如果有 keywords 就进行文件的搜索
        if keywords:
            queryset = self.get_queryset()
        else:
            # 文件路径查询
            if not self.get_queryset().filter(id=self.kwargs['pk']).exists():
                return Response({"detail": "路径不存在"}, status=status.HTTP_404_NOT_FOUND)
            queryset = self.get_queryset().filter(p_file_id=self.kwargs['pk']).defer("ocr_img_urls", "position_info")
        # 添加类型  过滤字段
        type_filter = self.request.query_params.get("type_filter")
        if type_filter:
            type_filter_list = [type_int for type_int in type_filter.split(",") if type_int in ['1', '2', '3']]
            type_filter_list.append('0')
            queryset = queryset.filter(type__in=type_filter_list)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            request_finished_custom.send("文件列表查询", request=self.request)
            return self.get_paginated_response(serializer.data)

        request_finished_custom.send("文件列表查询", request=self.request)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        request_finished_custom.send("文件修改", request=self.request)
        return Response(serializer.data)

    def judge_exist_ocring_file(self, file_id, file_folder_set):
        current_file = file_folder_set[file_folder_set.id == file_id]
        if len(current_file) == 0:
            return False
        # 如果筛选到为文件
        if current_file.type.item() != 0:
            # 出现在 file_folder_set.id中 返回True
            return True
        else:
            # 如果为筛选到为文件夹 查询子文件
            for file_df in file_folder_set[file_folder_set.p_file_id == file_id].itertuples():
                if file_df.type != 0:
                    # 如果子文件中存在文件，返回True
                    return True
                else:
                    # 子文件中有文件夹继续递归
                    return self.judge_exist_ocring_file(file_df.id, file_folder_set)

    def destroy(self, request, *args, **kwargs):
        # 接受要删除的id list参数
        id_list = request.data.get("pks")
        if not (isinstance(id_list, list) and all([isinstance(file_id, int) for file_id in id_list])):
            return Response({'detail': '参数校验失败'}, status=status.HTTP_400_BAD_REQUEST)
        # 查询文件夹下是否存在正在ocr的文件 如果存在那么不删除 提示用户该文件夹下有文件正在ocr
        # 1. 查询所有正在ocr的文件及所有文件夹
        columns = ('id', 'name', 'p_file_id', 'type')
        # 2. 构造dataframe
        file_folder_set = pd.DataFrame(
            list(self.get_queryset().filter(Q(ocr_status__in=(1, 2, 3, 4, 5, 6)) | Q(type=0)).order_by().values_list(*columns)),
            columns=columns)
        # 3. 递归查询子文件中是否存在正在识别的文件
        judge_id_list = [file_id for file_id in id_list if not self.judge_exist_ocring_file(file_id, file_folder_set)]
        # 4. 将可以删除的文件删除 不可以删除的 构造在detail中
        diff_file_id_set = set(id_list).difference(set(judge_id_list))
        self.get_queryset().order_by().filter(id__in=judge_id_list).delete()
        if judge_id_list:
            request_finished_custom.send("文件删除", request=self.request)
        if diff_file_id_set:
            detail = f"被选定文件中部分未被处理"
            # 处理了部分数据 返回状态码208
            return Response({'detail': detail}, status=208)
        else:
            return Response({'detail': "成功"}, status=status.HTTP_204_NO_CONTENT)


class MoveFilesView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        return FileModel.objects.filter(company_id=self.request.user.company_id)

    def exist_in_son_folder_id(self, target_file_id, folder_set: pd.DataFrame, current_folder_id_list):
        if not current_folder_id_list: return
        # 查询current_folder_id_list的所有直接子文件
        son_folder_id_list = folder_set[folder_set.p_file_id.isin(current_folder_id_list)].id.tolist()
        if target_file_id in son_folder_id_list: return 1
        return self.exist_in_son_folder_id(target_file_id, folder_set, son_folder_id_list)

    def bemove_all_file_id(self, file_set: pd.DataFrame, _file_id_list):
        son_file_id_list = file_set[file_set.p_file_id.isin(_file_id_list)].id.tolist()
        if not son_file_id_list:
            return _file_id_list
        _file_id_list.extend(self.bemove_all_file_id(file_set, son_file_id_list))
        return _file_id_list

    def put(self, request, *args, **kwargs):
        user = request.user
        file_id_list = request.data.get('pks')
        target_file_id = request.data.get('p_file_id')
        # 数据验证
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        # 校验文件是否在数据库中
        files = self.get_queryset().filter(id__in=file_id_list).only('id', 'file_owner_id')
        unexists_list = []
        if files:
            bemovefile_ownerid = files.first().file_owner_id
            db_file_list = [db_file.id for db_file in files]
            for file_id in file_id_list:
                if file_id not in db_file_list:
                    unexists_list.append(file_id)
        else:
            # unexists_list = file_id_list
            return Response({'detail': '被移动文件/文件夹已被删除'}, status=status.HTTP_400_BAD_REQUEST)

        # 验证文件夹是否存在
        if not self.get_queryset().filter(id=target_file_id, type=0, file_owner_id=bemovefile_ownerid).exists():
            if user.is_staff:
                if not self.get_queryset().filter(id=target_file_id, type=0).exists():
                    return Response(data={"detail": "目的文件夹非法"}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    target_user_id = self.get_queryset().filter(id=target_file_id, type=0).only(
                        'file_owner_id').first().file_owner_id
            else:
                return Response(data={"detail": "目的文件夹非法"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            target_user_id = bemovefile_ownerid
        # 验证目的文件没有出现在所要移动的子文件中
        columns = ('id', 'name', 'p_file_id')
        folder_set = self.get_queryset().filter(type=0, file_owner_id=bemovefile_ownerid).only(*columns).values_list(
            *columns)
        folder_set = pd.DataFrame.from_records(folder_set, columns=columns)
        # 查询pks所有的子文件
        if self.exist_in_son_folder_id(int(target_file_id), folder_set, file_id_list):
            return Response(data={"detail": "目的文件路径不能是子文件"}, status=status.HTTP_400_BAD_REQUEST)

        # 筛选出文件重名字的id
        with connection.cursor() as cursor:
            cursor.execute("""
            select 
                distinct t_move_file.id, t_move_file.name
            from 
                (select id, name from t_file where t_file.id in %s ) as t_move_file,
                (select id, name from t_file where t_file.p_file_id = %s ) as t_target_folder
            where 
                t_move_file.name = t_target_folder.name
            """, (file_id_list, target_file_id))
            duplicate_rows = cursor.fetchall()

        # 文件没有重名字的集合 直接更新
        if target_user_id == bemovefile_ownerid:
            self.get_queryset().filter(id__in=file_id_list, file_owner_id=bemovefile_ownerid).update(
                p_file_id=target_file_id)
        else:
            file_set = self.get_queryset().filter(file_owner_id=bemovefile_ownerid).only(*columns).values_list(
                *columns)
            file_set = pd.DataFrame.from_records(file_set, columns=columns)
            _file_id_list = deepcopy(file_id_list)
            # 获取所有文件及子文件id的列表
            bemove_all_file_list = self.bemove_all_file_id(file_set, _file_id_list)
            self.get_queryset().filter(id__in=file_id_list, file_owner_id=bemovefile_ownerid).update(
                p_file_id=target_file_id)
            self.get_queryset().filter(id__in=bemove_all_file_list, file_owner_id=bemovefile_ownerid).update(
                file_owner_id=target_user_id)

        for file_id, file_name in duplicate_rows:
            name_keywords = file_name.rsplit(".", 1)
            if len(name_keywords) == 1:
                file_name = f"{name_keywords[0]}_{now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}"
            else:
                file_name = f"{name_keywords[0]}_{now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}.{name_keywords[1]}"
            # 文件重名字的集合 更新p_file_id，同时更新 文件名
            if target_user_id == bemovefile_ownerid:
                self.get_queryset().filter(id=file_id).update(name=file_name, p_file_id=target_file_id)
            else:
                self.get_queryset().filter(id=file_id).update(name=file_name, p_file_id=target_file_id,
                                                            file_owner_id=target_user_id)
        request_finished_custom.send("移动文件", request=self.request)
        if unexists_list:
            # 处理了部分文件 状态码为208
            return Response(data={'detail': f'被选定文件中部分未被处理'}, status=208)
        else:
            return Response(data={'detail': '成功'})

    # 个人移动到登录用户所在目录
    # def put(self, request, *args, **kwargs):
    #     user_id = request.user.id
    #     file_id_list = request.data.get('pks')
    #     target_file_id = request.data.get('p_file_id')
    #     # 数据验证
    #     if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
    #         logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
    #         return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     # 校验文件是否在数据库中
    #     files = FileModel.objects.filter(user_id=user_id).only('id')
    #     db_file_list = []
    #     unexists_list = []
    #     if files:
    #         db_file_list = [db_file.id for db_file in files]
    #         for file_id in file_id_list:
    #             if file_id not in db_file_list:
    #                 unexists_list.append(file_id)
    #     else:
    #         unexists_list = file_id_list
    #
    #     # 验证文件夹是否存在
    #     if not FileModel.objects.filter(id=target_file_id, type=0, user=request.user).exists():
    #         return Response(data={"detail": "目的文件夹非法"}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     # 验证目的文件没有出现在所要移动的子文件中
    #     columns = ('id', 'name', 'p_file_id')
    #     folder_set = FileModel.objects.filter(type=0, user=request.user).only(*columns).values_list(*columns)
    #     folder_set = pd.DataFrame.from_records(folder_set, columns=columns)
    #     # 查询pks所有的子文件
    #     if self.exist_in_son_folder_id(int(target_file_id), folder_set, file_id_list):
    #         return Response(data={"detail": "目的文件路径不能是子文件"}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     # 筛选出文件重名字的id
    #     with connection.cursor() as cursor:
    #         cursor.execute("""
    #         select
    #             distinct t_move_file.id, t_move_file.name
    #         from
    #             (select id, name from t_file where t_file.id in %s ) as t_move_file,
    #             (select id, name from t_file where t_file.p_file_id = %s ) as t_target_folder
    #         where
    #             t_move_file.name = t_target_folder.name
    #         """, (file_id_list, target_file_id))
    #         duplicate_rows = cursor.fetchall()
    #
    #     # 文件没有重名字的集合 直接更新
    #     FileModel.objects.filter(id__in=file_id_list, user=request.user).update(p_file_id=target_file_id)
    #
    #     for file_id, file_name in duplicate_rows:
    #         name_keywords = file_name.rsplit(".", 1)
    #         if len(name_keywords) == 1:
    #             file_name = f"{name_keywords[0]}_{now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}"
    #         else:
    #             file_name = f"{name_keywords[0]}_{now().strftime(settings.FILE_NAME_DATE_TIME_FORMAT)}.{name_keywords[1]}"
    #         # 文件重名字的集合 更新p_file_id，同时更新 文件名
    #         FileModel.objects.filter(id=file_id).update(name=file_name, p_file_id=target_file_id)
    #
    #     if unexists_list:
    #         # 处理了部分文件 状态码为208
    #         return Response(data={'detail': f'被选定文件中部分未被处理'}, status=208)
    #     else:
    #         return Response(data={'detail': '成功'})


class BatchFileDownloadView(APIView):
    permission_classes = (IsAuthenticated,)

    tempfile_max_size = settings.BATCH_FILE_MAX_SIZE

    def get_son_file(self, target_file_list, target_file_id_list, file_set: pd.DataFrame, current_file_df: pd,
                     current_path):
        """
        递归构建 file_df 的子文件
        :param target_file_list:  将符合条件的文件 追加到这个文件中
        :param file_set: 所有符合条件的用户文件或文件夹
        :param file_df: 当前需要处理的文件或文件夹
        :param current_path: 当前需要处理的文件或文件夹 所处的路径
        :return:
        """
        # 对当前id进行查询构建数据 添加到 target_file_list 筛选出文件类型的数据
        if current_file_df.type == 0:
            # 查询当前文件集合的直接子文件 并递归调用
            for son_file in file_set[file_set.p_file_id == current_file_df.id].itertuples():
                self.get_son_file(target_file_list, target_file_id_list, file_set, son_file,
                                  f"{current_path}{current_file_df.name}/")
        else:
            # 添加path属性 并追加到 target_file_list中
            current_file_dict = dict(current_file_df._asdict())
            current_file_dict['path'] = f"{current_path}{current_file_df.name}"
            target_file_list.append(current_file_dict)
            target_file_id_list.append(current_file_df.id)

    async def download_save_2_zip(self, zip_obj: tempfile.TemporaryFile, url: str, file_path: str):
        async with aiohttp.ClientSession() as client:
            async with client.get(url, timeout=60) as resp:
                try:
                    content = await resp.read()
                except Exception:
                    logger.warning(f'文件{file_path}下载失败', exc_info=True)
                    raise TimeoutError
                else:
                    zip_obj.writestr(file_path, content)

    def post(self, request, *args, **kwargs):
        # 参数校验
        file_id_list = request.data.get('pks')
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        # 获取查询集合
        if self.request.user.is_staff:
            first_file = FileModel.objects.filter(id__in=file_id_list).only("file_owner_id").first()
            if not first_file:
                return Response({'detail': '数据未找到'}, status=status.HTTP_400_BAD_REQUEST)
            queryset = FileModel.objects.filter(file_owner_id=first_file.file_owner_id).defer("ocr_img_urls",
                                                                                              "position_info")
        else:
            queryset = FileModel.objects.filter(file_owner=self.request.user).defer("ocr_img_urls", "position_info")

        # 查询用户成功ocr的所有文件及文件路径 并保存为df结果
        file_columns = ('id', 'name', 'type', 'p_file_id', 'url', 'size')
        file_set = queryset.filter().values_list(*file_columns)
        file_set = pd.DataFrame(file_set, columns=file_columns)

        # 筛选出其中 用户本次选择的文件及子文件  添加path属性 供后面zip逻辑使用 [{name:name, path:path...},{...}...]
        target_file_list = list()
        target_file_id_list = list()
        for file_df in file_set[file_set.id.isin(file_id_list)].itertuples():
            self.get_son_file(target_file_list, target_file_id_list, file_set, file_df, '/')
        zip_file_size = reduce(lambda x, y: x + y.get('size'), target_file_list, 0) / (10 ** 6)
        if zip_file_size > self.tempfile_max_size:
            return Response({'detail': f'下载文件不能超过{self.tempfile_max_size}M'}, status=status.HTTP_400_BAD_REQUEST)

        # 将多个文件压缩到zip中
        temp = tempfile.TemporaryFile()
        zip_obj = zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED)
        # 读取文件内容
        tasks = list()
        for file in target_file_list:
            tasks.append(self.download_save_2_zip(zip_obj, split_intra_file_url(file.get('url')), file.get('path')))
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(asyncio.gather(*tasks))
        except TimeoutError:
            return Response({'detail': '选择下载文件过多，建议减少一次性下载文件个数！'}, status=status.HTTP_400_BAD_REQUEST)
        loop.close()

        # 调用该方法才会往文件中写
        zip_obj.close()
        # 将文件指针移到开始处，准备读取文件
        temp.seek(0)
        try:
            url = zj_upload_sync(
                (f'file_{time.strftime(settings.FILE_NAME_DATE_TIME_FORMAT[:-2])}.zip',
                 temp.read(),
                 'application/zip')
            )
        except ConnectionError:
            logger.error(traceback.format_exc(), exc_info=True)
            return Response({'detail': '批量下载文件过多，建议减少批量下载文件个数！'}, status=status.HTTP_400_BAD_REQUEST)
        temp.close()
        request_finished_custom.send("批量文件下载", request=self.request)
        return Response({'url': url})


class FileBatchOcrView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_target_file(self, target_file_id_set, file_folder_set: pd.DataFrame, current_file_set: pd.DataFrame):
        for file in current_file_set.itertuples():
            if file.type == 0:
                # 如果文件类型为 0，查询子文件 递归调用
                next_file_set = file_folder_set[file_folder_set.p_file_id == file.id]
                if len(next_file_set) != 0:
                    self.get_target_file(target_file_id_set, file_folder_set, next_file_set)
            else:
                # 否则， 添加到 target_file_id_list 中
                target_file_id_set.add(file.id)

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            queryset = FileModel.objects.filter(company_id=user.company_id).defer("ocr_img_urls", "position_info")
        else:
            queryset = FileModel.objects.filter(file_owner=user).defer("ocr_img_urls", "position_info")
        return queryset

    def post(self, request, *args, **kwargs):
        """批量ocr"""
        file_id_list = request.data.get('pks')
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        # 1. 查询所有符合条件的文件及子文件的id
        # 1.1 查询用户所有符合条件的文件，user=user,ocr_status__in=(7, 9)
        columns = ('id', 'name', 'type', 'p_file_id')
        file_folder_set = self.get_queryset().filter(ocr_status__in=(7, 9)).values_list(*columns)
        # 1.2 构建dataframe
        file_folder_set = pd.DataFrame(list(file_folder_set), columns=columns)
        # 1.3 递归查询用户指定文件及所有子文件的id
        next_file_set = file_folder_set[file_folder_set.id.isin(file_id_list)]
        target_file_id_set = set()
        self.get_target_file(target_file_id_set, file_folder_set, next_file_set)

        # 2. 发送celery任务
        for pk in target_file_id_set:
            if request.META.get('HTTP_SIGN') == settings.IOS_HEADER_SIGN:
                ocr_status = 4
                celery_task = ios_file_ocr.delay(pk)
            else:
                celery_task = web_file_ocr.delay(pk)
                ocr_status = 5
            # 3. 修改文件的状态为队列中
            FileModel.objects.filter(id=pk).update(ocr_status=ocr_status, celery_task_id=celery_task.task_id)
        request_finished_custom.send("文件OCR", request=self.request)

        # 4. 返回响应
        return Response(data={"detail": "成功"}, status=status.HTTP_200_OK)

    def delete(self, request, *args, **kwargs):
        """批量取消识别"""
        file_id_list = request.data.get('pks')
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        # 筛选出所有正在队列中的文件及所有文件夹
        columns = ('id', 'name', 'type', 'p_file_id', 'celery_task_id', 'ocr_status')
        file_folder_set = self.get_queryset().filter(Q(ocr_status__in=[4, 5, 6]) | Q(type=0)).values_list(*columns)

        # 构造dataframe
        file_folder_set = pd.DataFrame(list(file_folder_set), columns=columns)
        if len(file_folder_set) == 0:
            return Response({'detail': '不支持该操作'}, status=status.HTTP_400_BAD_REQUEST)

        # 递归查询用户输入文件的所有子文件
        next_file_set = file_folder_set[file_folder_set.id.isin(file_id_list)]
        target_file_id_set = set()
        self.get_target_file(target_file_id_set, file_folder_set, next_file_set)

        # 取消这些文件的ocr 发送celery任务
        for pk in target_file_id_set:
            target_file = file_folder_set[(file_folder_set.id == pk) & (file_folder_set.ocr_status.isin([4, 5]))]
            if len(target_file) == 1:
                main.celery_app.control.revoke(target_file.celery_task_id.item())
        FileModel.objects.filter(id__in=target_file_id_set).update(ocr_status=9)

        # 记录log
        request_finished_custom.send("取消识别", request=self.request)
        # 返回响应
        return Response(data={"detail": "成功"}, status=status.HTTP_200_OK)


class ExportDataView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk, *args, **kwargs):
        # 判断如果是pk是文件夹，则走导出文件夹的逻辑
        if FileModel.objects.filter(id=pk, type=0).exists():
            resp = self.export_folder(request,pk)
            return resp
        # 如果pk不是文件夹则走导出单个文件的逻辑
        else:
            if not FileModel.objects.filter(id=pk, type__in=(1, 2, 3), ocr_status=11, ocr_time__isnull=False).exists():
                logger.warning(f"参数pk={pk}的文件数据不存在", exc_info=True)
                return Response(data={"detail": "数据不存在"}, status=status.HTTP_404_NOT_FOUND)

            # 一次性查询出所有的文件需要的信息
            file_obj = FileModel.objects.filter(id=pk).only('id', 'name', 'type').prefetch_related(
                'eng_info_set',
                'eng_info_set__land_info_set',
                'eng_info_set__deep_split_info_set').first()
            # 遍历保存每个文件的ocr结果
            file_temp = tempfile.TemporaryFile()

            eng_info_columns_e_z_dict = {"file_id": "文件id", "id": "工程信息id", "eng_name": "工程名称", "eng_no": "工程编号",
                                         "boring_no": "钻孔编号", "orifice_height": "孔口标高", "orifice_diameter": "孔口直径",
                                         "hole_depth": "终孔深度", "coordinates": "坐标", "start_date": "开工日期",
                                         "completion_date": "竣工日期", "water_depth": "稳定水位深度", "water_date": "测量水位日期",
                                         "stable_water_level": "稳定水位", "pressure_water_level": "承压水位",
                                         "initial_water_level": "初见水位", "mileage": "里程", "offset": "偏移",
                                         "drill_depth": "钻孔深度"}
            eng_info_columns = [eng_info_column_e for eng_info_column_e in eng_info_columns_e_z_dict.keys()]

            land_info_columns_e_z_dict = {
                "eng_info_id": "工程信息id", "geological_age": "地质时代", "floor_number": "层号", "stratum_name": "地层名称",
                "bottom_elevation": "层底标高(m)", "bottom_depth": "层底深度(m)", "delamination_thickness": "分层厚度(m)",
                "histogram": "柱状图", "state": "状态风华程度", "lithology_description": "岩性描述"}
            land_info_columns = [eng_info_column_e for eng_info_column_e in land_info_columns_e_z_dict.keys()]

            deep_info_columns = ['deep_field_name', 'deep_field_value']

            with pd.ExcelWriter(file_temp) as writer:
                for eng_info in file_obj.eng_info_set.all():
                    # 获取eng信息
                    eng_info_data = pd.DataFrame([{column: getattr(eng_info, column) for column in eng_info_columns}])

                    land_info_data = eng_info.land_info_set.values_list(*land_info_columns)
                    land_info_data = pd.DataFrame.from_records(land_info_data, columns=land_info_columns)

                    deep_info_data = eng_info.deep_split_info_set.order_by('deep_field_name', 'id').\
                        values_list(*deep_info_columns)
                    deep_info_data = pd.DataFrame.from_records(deep_info_data, columns=deep_info_columns)

                    # 往临时文件中写入当前file的ocr结果
                    eng_info_data.rename(columns=eng_info_columns_e_z_dict) \
                        .to_excel(writer, sheet_name=f'工程信息（孔号为：{eng_info.id}）')
                    land_info_data.rename(columns=land_info_columns_e_z_dict) \
                        .to_excel(writer, sheet_name=f'土地信息（孔号为：{eng_info.id}）')
                    deep_info_data.to_excel(writer, header=False, index=False, sheet_name=f'深度信息（孔号为：{eng_info.id}）')

            # 将临时文件指针移动到最开始位置
            file_temp.seek(0)
            url = zj_upload_sync((f'{file_obj.name.rsplit(".", 1)[0]}.xls', file_temp.read(), 'application/vnd.ms-excel'))
            file_temp.close()
            request_finished_custom.send("导出识别结果", request=self.request)
            return Response({'url': url})

    # 导出单个文件夹
    def export_folder(self, request, pk):
        file_id_list = [pk]
        first_file = FileModel.objects.filter(id__in=file_id_list).only("file_owner_id").first()
        if not first_file:
            return Response({'detail': '数据不存在'}, status=status.HTTP_400_BAD_REQUEST)
        # 获取查询集合
        if self.request.user.is_staff:
            queryset = FileModel.objects.filter(company_id=first_file.company_id).defer("ocr_img_urls",
                                                                                        "position_info")
        else:
            queryset = FileModel.objects.filter(file_owner=self.request.user).defer("ocr_img_urls", "position_info")

        # 查询用户成功ocr的所有文件及文件路径 并保存为df结果
        file_columns = ('id', 'name', 'type', 'p_file_id')
        file_set = queryset.filter(Q(ocr_status=11, ocr_time__isnull=False) | Q(type=0)).values_list(*file_columns)
        file_set = pd.DataFrame(file_set, columns=file_columns)

        # 筛选出其中 用户本次选择的文件及子文件  添加path属性 供后面zip逻辑使用 [{name:name, path:path...},{...}...]
        target_file_list = list()
        target_file_id_list = list()
        for file_df in file_set[file_set.id.isin(file_id_list)].itertuples():
            self.get_son_file(target_file_list, target_file_id_list, file_set, file_df, '/')

        # 判断没有要导出的文件
        if not target_file_id_list:
            return Response(data={"detail": "没有可以导出的文件"}, status=status.HTTP_400_BAD_REQUEST)

        # 进行ocr结果的查询，缓存到dataframe中，供后面zip逻辑使用
        # 一次性查询出所有的文件需要的信息
        file_set = FileModel.objects.filter(id__in=target_file_id_list).only('id', 'name', 'type').prefetch_related(
            'eng_info_set',
            'eng_info_set__land_info_set',
            'eng_info_set__deep_split_info_set')

        eng_info_columns_e_z_dict = {"file_id": "文件id", "id": "工程信息id", "eng_name": "工程名称", "eng_no": "工程编号",
                                     "boring_no": "钻孔编号", "orifice_height": "孔口标高", "orifice_diameter": "孔口直径",
                                     "hole_depth": "终孔深度", "coordinates": "坐标", "start_date": "开工日期",
                                     "completion_date": "竣工日期", "water_depth": "稳定水位深度", "water_date": "测量水位日期",
                                     "stable_water_level": "稳定水位", "pressure_water_level": "承压水位",
                                     "initial_water_level": "初见水位", "mileage": "里程", "offset": "偏移",
                                     "drill_depth": "钻孔深度"}
        eng_info_columns = [eng_info_column_e for eng_info_column_e in eng_info_columns_e_z_dict.keys()]

        eng_info_data = pd.DataFrame(columns=eng_info_columns)
        land_info_columns_e_z_dict = {
            "eng_info_id": "工程信息id", "geological_age": "地质时代", "floor_number": "层号", "stratum_name": "地层名称",
            "bottom_elevation": "层底标高(m)", "bottom_depth": "层底深度(m)", "delamination_thickness": "分层厚度(m)",
            "histogram": "柱状图", "state": "状态风华程度", "lithology_description": "岩性描述"}
        land_info_columns = [eng_info_column_e for eng_info_column_e in land_info_columns_e_z_dict.keys()]

        land_info_data = pd.DataFrame(columns=land_info_columns)
        deep_info_columns = ['deep_field_name', 'deep_field_value', 'eng_info_id']

        deep_info_data = pd.DataFrame(columns=deep_info_columns)

        for file_obj in file_set.all():
            # 遍历保存每个文件的ocr结果
            for eng_info in file_obj.eng_info_set.all():
                # 获取eng信息
                eng_info_data = eng_info_data.append(
                    [{column: getattr(eng_info, column) for column in eng_info_columns}], ignore_index=True)
                # 获取land信息
                land_info_data = land_info_data.append(list(eng_info.land_info_set.values(*land_info_columns)),
                                                       ignore_index=True)
                # 获取deep信息
                deep_info_data = deep_info_data.append(
                    list(eng_info.deep_split_info_set.order_by('deep_field_name', 'id').values(*deep_info_columns)),
                    ignore_index=True)

        # 遍历文件列表 从dataframe中查询文件的ocr结果 结果保存为临时excel文件，并压到zip对象中
        zip_temp = tempfile.TemporaryFile()
        zip_obj = zipfile.ZipFile(zip_temp, 'w', zipfile.ZIP_DEFLATED)

        for target_file in target_file_list:
            file_temp = tempfile.TemporaryFile()
            file_id = target_file.get("id")
            # 获取eng信息
            eng_info_data_s_file = eng_info_data[eng_info_data.file_id == file_id]
            eng_info_id_list = eng_info_data_s_file.id.tolist()
            if not eng_info_id_list: continue
            with pd.ExcelWriter(file_temp) as writer:
                for eng_info_id in eng_info_id_list:
                    # 往临时文件中写入当前file的ocr结果
                    eng_info_data_s_file.rename(columns=eng_info_columns_e_z_dict). \
                        to_excel(writer, sheet_name=f'工程信息（孔号为：{eng_info_id}）')
                    # 获取land信息
                    land_info_data[land_info_data.eng_info_id == eng_info_id] \
                        .rename(columns=land_info_columns_e_z_dict).to_excel(writer,
                                                                             sheet_name=f'土地信息（孔号为：{eng_info_id}）')
                    # 获取deep信息
                    deep_info_data[deep_info_data.eng_info_id == eng_info_id].iloc[:, :-1] \
                        .to_excel(writer, sheet_name=f'深度信息（孔号为：{eng_info_id}）', header=False, index=False)

            # 将临时文件指针移动到最开始位置
            file_temp.seek(0)
            file_name = target_file["path"].rsplit('.', 1)
            # 将临时文件压进zip临时文件
            zip_obj.writestr(f'{file_name[0]}.xlsx', file_temp.read())

        # 调用该方法才会往zip文件中写
        zip_obj.close()
        zip_temp.seek(0)
        url = zj_upload_sync(
            (f'data_{time.strftime(settings.FILE_NAME_DATE_TIME_FORMAT[:-2])}.zip',
             zip_temp.read(),
             'application/zip')
        )
        zip_temp.close()
        request_finished_custom.send("批量导出识别结果", request=self.request)
        return Response({'url': url})

    def get_son_file(self, target_file_list, target_file_id_list, file_set: pd.DataFrame, current_file_df: pd,
                     current_path):
        """
        递归构建 file_df 的子文件
        :param target_file_list:  将符合条件的文件 追加到这个文件中
        :param file_set: 所有符合条件的用户文件或文件夹
        :param file_df: 当前需要处理的文件或文件夹
        :param current_path: 当前需要处理的文件或文件夹 所处的路径
        :return:
        """
        # 对当前id进行查询构建数据 添加到 target_file_list 筛选出文件类型的数据
        if current_file_df.type == 0:
            # 查询当前文件集合的直接子文件 并递归调用
            for son_file in file_set[file_set.p_file_id == current_file_df.id].itertuples():
                self.get_son_file(target_file_list, target_file_id_list, file_set, son_file,
                                  f"{current_path}{current_file_df.name}/")
        else:
            # 添加path属性 并追加到 target_file_list中
            current_file_dict = dict(current_file_df._asdict())
            current_file_dict['path'] = f"{current_path}{current_file_df.name}"
            target_file_list.append(current_file_dict)
            target_file_id_list.append(current_file_df.id)


class BatchExportDataView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_son_file(self, target_file_list, target_file_id_list, file_set: pd.DataFrame, current_file_df: pd,
                     current_path):
        """
        递归构建 file_df 的子文件
        :param target_file_list:  将符合条件的文件 追加到这个文件中
        :param file_set: 所有符合条件的用户文件或文件夹
        :param file_df: 当前需要处理的文件或文件夹
        :param current_path: 当前需要处理的文件或文件夹 所处的路径
        :return:
        """
        # 对当前id进行查询构建数据 添加到 target_file_list 筛选出文件类型的数据
        if current_file_df.type == 0:
            # 查询当前文件集合的直接子文件 并递归调用
            for son_file in file_set[file_set.p_file_id == current_file_df.id].itertuples():
                self.get_son_file(target_file_list, target_file_id_list, file_set, son_file,
                                  f"{current_path}{current_file_df.name}/")
        else:
            # 添加path属性 并追加到 target_file_list中
            current_file_dict = dict(current_file_df._asdict())
            current_file_dict['path'] = f"{current_path}{current_file_df.name}"
            target_file_list.append(current_file_dict)
            target_file_id_list.append(current_file_df.id)

    def post(self, request):
        file_id_list = request.data.get('pks')
        if not (isinstance(file_id_list, list) and all([isinstance(file_id, int) for file_id in file_id_list])):
            logger.warning(f"参数pks={request.data.get('pks')}校验失败", exc_info=True)
            return Response(data={"detail": "参数校验失败"}, status=status.HTTP_400_BAD_REQUEST)

        first_file = FileModel.objects.filter(id__in=file_id_list).only("file_owner_id").first()
        if not first_file:
            return Response({'detail': '数据不存在'}, status=status.HTTP_400_BAD_REQUEST)
        # 获取查询集合
        if self.request.user.is_staff:
            queryset = FileModel.objects.filter(company_id=first_file.company_id).defer("ocr_img_urls",
                                                                                              "position_info")
        else:
            queryset = FileModel.objects.filter(file_owner=self.request.user).defer("ocr_img_urls", "position_info")

        # 查询用户成功ocr的所有文件及文件路径 并保存为df结果
        file_columns = ('id', 'name', 'type', 'p_file_id')
        file_set = queryset.filter(Q(ocr_status=11, ocr_time__isnull=False) | Q(type=0)).values_list(*file_columns)
        file_set = pd.DataFrame(file_set, columns=file_columns)

        # 筛选出其中 用户本次选择的文件及子文件  添加path属性 供后面zip逻辑使用 [{name:name, path:path...},{...}...]
        target_file_list = list()
        target_file_id_list = list()
        for file_df in file_set[file_set.id.isin(file_id_list)].itertuples():
            self.get_son_file(target_file_list, target_file_id_list, file_set, file_df, '/')

        # 判断没有要导出的文件
        if not target_file_id_list:
            return Response(data={"detail": "没有可以导出的文件"}, status=status.HTTP_400_BAD_REQUEST)

        # 进行ocr结果的查询，缓存到dataframe中，供后面zip逻辑使用
        # 一次性查询出所有的文件需要的信息
        file_set = FileModel.objects.filter(id__in=target_file_id_list).only('id', 'name', 'type').prefetch_related(
            'eng_info_set',
            'eng_info_set__land_info_set',
            'eng_info_set__deep_split_info_set')

        eng_info_columns_e_z_dict = {"file_id": "文件id", "id": "工程信息id", "eng_name": "工程名称", "eng_no": "工程编号",
                                     "boring_no": "钻孔编号", "orifice_height": "孔口标高", "orifice_diameter": "孔口直径",
                                     "hole_depth": "终孔深度", "coordinates": "坐标", "start_date": "开工日期",
                                     "completion_date": "竣工日期", "water_depth": "稳定水位深度", "water_date": "测量水位日期",
                                     "stable_water_level": "稳定水位", "pressure_water_level": "承压水位",
                                     "initial_water_level": "初见水位", "mileage": "里程", "offset": "偏移",
                                     "drill_depth": "钻孔深度"}
        eng_info_columns = [eng_info_column_e for eng_info_column_e in eng_info_columns_e_z_dict.keys()]

        eng_info_data = pd.DataFrame(columns=eng_info_columns)
        land_info_columns_e_z_dict = {
            "eng_info_id": "工程信息id", "geological_age": "地质时代", "floor_number": "层号", "stratum_name": "地层名称",
            "bottom_elevation": "层底标高(m)", "bottom_depth": "层底深度(m)", "delamination_thickness": "分层厚度(m)",
            "histogram": "柱状图", "state": "状态风华程度", "lithology_description": "岩性描述"}
        land_info_columns = [eng_info_column_e for eng_info_column_e in land_info_columns_e_z_dict.keys()]

        land_info_data = pd.DataFrame(columns=land_info_columns)
        deep_info_columns = ['deep_field_name', 'deep_field_value', 'eng_info_id']

        deep_info_data = pd.DataFrame(columns=deep_info_columns)

        for file_obj in file_set.all():
            # 遍历保存每个文件的ocr结果
            for eng_info in file_obj.eng_info_set.all():
                # 获取eng信息
                eng_info_data = eng_info_data.append(
                    [{column: getattr(eng_info, column) for column in eng_info_columns}], ignore_index=True)
                # 获取land信息
                land_info_data = land_info_data.append(list(eng_info.land_info_set.values(*land_info_columns)),
                                                       ignore_index=True)
                # 获取deep信息
                deep_info_data = deep_info_data.append(
                    list(eng_info.deep_split_info_set.order_by('deep_field_name', 'id').values(*deep_info_columns)),
                                                       ignore_index=True)

        # 遍历文件列表 从dataframe中查询文件的ocr结果 结果保存为临时excel文件，并压到zip对象中
        zip_temp = tempfile.TemporaryFile()
        zip_obj = zipfile.ZipFile(zip_temp, 'w', zipfile.ZIP_DEFLATED)

        for target_file in target_file_list:
            file_temp = tempfile.TemporaryFile()
            file_id = target_file.get("id")
            # 获取eng信息
            eng_info_data_s_file = eng_info_data[eng_info_data.file_id == file_id]
            eng_info_id_list = eng_info_data_s_file.id.tolist()
            if not eng_info_id_list: continue
            with pd.ExcelWriter(file_temp) as writer:
                for eng_info_id in eng_info_id_list:
                    # 往临时文件中写入当前file的ocr结果
                    eng_info_data_s_file.rename(columns=eng_info_columns_e_z_dict). \
                        to_excel(writer, sheet_name=f'工程信息（孔号为：{eng_info_id}）')
                    # 获取land信息
                    land_info_data[land_info_data.eng_info_id == eng_info_id] \
                        .rename(columns=land_info_columns_e_z_dict).to_excel(writer, sheet_name=f'土地信息（孔号为：{eng_info_id}）')
                    # 获取deep信息
                    deep_info_data[deep_info_data.eng_info_id == eng_info_id].iloc[:, :-1] \
                        .to_excel(writer, sheet_name=f'深度信息（孔号为：{eng_info_id}）', header=False, index=False)

            # 将临时文件指针移动到最开始位置
            file_temp.seek(0)
            file_name = target_file["path"].rsplit('.', 1)
            # 将临时文件压进zip临时文件
            zip_obj.writestr(f'{file_name[0]}.xlsx', file_temp.read())

        # 调用该方法才会往zip文件中写
        zip_obj.close()
        zip_temp.seek(0)
        url = zj_upload_sync(
            (f'data_{time.strftime(settings.FILE_NAME_DATE_TIME_FORMAT[:-2])}.zip',
             zip_temp.read(),
             'application/zip')
        )
        zip_temp.close()
        request_finished_custom.send("批量导出识别结果", request=self.request)
        return Response({'url': url})


# app端试图
class BoringNoView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk, *args, **kwargs):
        file = FileModel.objects.filter(id=pk).first()
        if not file:
            return Response({'detail': '未找到文件信息'}, status=status.HTTP_400_BAD_REQUEST)
        eng_info_set = file.eng_info_set.only('id', 'boring_no')
        data = BoringNoSerializer(eng_info_set, many=True).data
        request_finished_custom.send('获取工程信息', request=self.request)
        return Response(data, status=status.HTTP_200_OK)


class FieldsListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk):
        # 拼接数据结构为
        # data = [
        #     {
        #         'eng_id': '...'
        #         'eng_model': {
        #             'many': 0,
        #             'eng_name': '工程名称',
        #             '...': '...'
        #         },
        #         'land_model': {
        #             'many': 1,
        #             'geological_age': '地质时代',
        #             '...': '...'
        #         },
        #         'deep_model': {
        #             'many': 0,
        #             'geological_age': '取样',
        #             '...': '...'
        #         }
        #     },
        #     {
        #       ...
        #     }
        # ]
        # 数据结构调整为
        # a = [
        #     {
        #         'many': 0,  # 0 无下一级，1 有下一级
        #         'id': 1,
        #         'model_name': 'eng_model',
        #         'field_name': 'eng_name',
        #         'field_name_content': 'xxx',
        #         'field_content': 'xxx',
        #         'field_coor': [1,2,3,4],
        #         'ocr_img_url': 'http://xxx'
        #     },
        #     {
        #         ...
        #     }
        # ]

        try:
            eng_info = EngInfoModel.objects.filter(id=pk).select_related('file').first()
            if not eng_info:
                return Response({'detail': '没有工程识别信息'}, status=status.HTTP_400_BAD_REQUEST)
            # eng表中字段
            ocr_img_urls_json = eng_info.file.ocr_img_urls
            if ocr_img_urls_json:
                ocr_img_url = split_file_url(eval(ocr_img_urls_json)[0])
            else:
                ocr_img_url = ''
            data = []
            eng_info_dict = model_to_dict(eng_info)
            for field_key, fields_name in coor_info['eng_model'].items():
                if eng_info_dict[field_key + '_coor']:
                    item = {
                        'many': 0,
                        'id': pk,
                        'model_name': 'eng_model',
                        'field_name': field_key,
                        'field_name_content': fields_name,
                        'field_content': str(eng_info_dict[field_key]) if eng_info_dict[field_key] else '',
                        'field_coor': eval(eng_info_dict[field_key + '_coor']),
                        'ocr_img_url': ocr_img_url
                    }
                    data.append(item)
            # land表中字段
            land_info = eng_info.land_info_set.first()
            if land_info:
                land_info_dict = model_to_dict(land_info)
                for field_key, fields_name in coor_info['land_model'].items():
                    if land_info_dict[field_key + '_coor']:
                        item = {
                            'many': 1,
                            'id': pk,
                            'model_name': 'land_model',
                            'field_name': field_key,
                            'field_name_content': fields_name,
                            'field_content': '',
                            'field_coor': None,
                            'ocr_img_url': None
                        }
                        data.append(item)
            # deep表中字段
            # fields_dict = {}
            # fields_dict['many'] = 0
            field_name_list = DeepSplitInfo.objects.filter(~Q(deep_field_coor='')&Q(eng_info_id=pk)).values_list('deep_field_name', flat=True).distinct()
            if field_name_list:
                for field_name in field_name_list:
                    # deep_obj = DeepSplitInfo.objects.filter(Q(eng_info_id=pk)&Q(deep_field_name=field_name)&~Q(deep_field_coor='')).first()
                    item = {
                        'many': 1,
                        'id': pk,
                        'model_name': 'deep_model',
                        'field_name': field_name,
                        'field_name_content': field_name,
                        'field_content': '',
                        'field_coor': None,
                        'ocr_img_url': None
                    }
                    data.append(item)
            # item_count = eng_info.deep_info_set.count()
            # deep_info = eng_info.deep_info_set.first()
            # if item_count > 1:
            #     many = 1
            #     if deep_info:
            #         deep_info_dict = model_to_dict(deep_info)
            #         for field_key, fields_name in coor_info['deep_model'].items():
            #             if deep_info_dict[field_key + '_coor'] and deep_info_dict[field_key + '_coor'] != '[]':
            #                 item = {
            #                     'many': many,
            #                     'id': pk,
            #                     'model_name': 'deep_model',
            #                     'field_name': field_key,
            #                     'field_name_content': fields_name,
            #                     'field_content': '',
            #                     'field_coor': None,
            #                     'ocr_img_url': None
            #                 }
            #                 data.append(item)
            # else:
            #     many = 0
            #     if deep_info:
            #         deep_info_dict = model_to_dict(deep_info)
            #         for field_key, fields_name in coor_info['deep_model'].items():
            #             if deep_info_dict[field_key + '_coor'] and deep_info_dict[field_key + '_coor'] != '[]':
            #                 item = {
            #                     'many': many,
            #                     'id': deep_info.id,
            #                     'model_name': 'deep_model',
            #                     'field_name': field_key,
            #                     'field_name_content': fields_name,
            #                     'field_content': str(deep_info_dict[field_key]) if deep_info_dict[field_key] else '',
            #                     'field_coor': eval(deep_info_dict[field_key + '_coor']),
            #                     'ocr_img_url': ocr_img_url
            #                 }
            #                 data.append(item)

            request_finished_custom.send('获取校验字段列表', request=self.request)
        except Exception:
            logger.error(traceback.format_exc(), exc_info=True)
            return Response({'detail': '服务器错误'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data=data, status=status.HTTP_200_OK)


class FieldsInfoView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        query_params = request.query_params
        eng_id = query_params.get('eng_id')
        field_name = query_params.get('field_name')
        model_name = query_params.get('model_name')
        # file_id = query_params.get('file_id')
        if not all([eng_id, field_name, model_name]):
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        # file = FileModel.objects.filter(id=file_id).only('url').first()
        # if not file:
        #     return Response({'detail': '文件信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
        # 工程信息
        eng_info = EngInfoModel.objects.filter(id=eng_id).select_related('file').first()
        if not eng_info:
            return Response({'detail': '工程信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
        ocr_img_urls_json = eng_info.file.ocr_img_urls
        data_list = []
        # 请求获取eng模型字段信息时
        if model_name == 'eng_model':
            field_content = getattr(eng_info, field_name)
            field_coor = getattr(eng_info, field_name + '_coor')
            ocr_img_url = ''
            if ocr_img_urls_json:
                ocr_img_url = split_file_url(eval(ocr_img_urls_json)[0])
            data_list = [
                {'id': eng_info.id, 'model_name': 'eng_model', 'field_name': field_name,
                 'field_content': str(field_content) if field_content else '',
                 'field_coor': eval(field_coor) if field_coor else None, 'ocr_img_url': ocr_img_url}]
        # 请求获取land模型字段信息时
        if model_name == 'land_model':
            land_infos = eng_info.land_info_set.all()
            if not land_infos:
                return Response({'detail': '土地信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            for land_info in land_infos:
                field_content = getattr(land_info, field_name)
                field_coor = getattr(land_info, field_name + '_coor')
                page = land_info.page
                ocr_img_url = ''
                if ocr_img_urls_json:
                    ocr_img_url = split_file_url(eval(ocr_img_urls_json)[page])
                    # ocr_img_urls = json.loads((ocr_img_urls_json).replace("'",'"'))[page]
                data = {'id': land_info.id, 'model_name': 'land_model', 'field_name': field_name,
                        'field_content': str(field_content) if field_content else '',
                        'field_coor': eval(field_coor) if field_coor else None, 'ocr_img_url': ocr_img_url}
                data_list.append(data)
        # 请求获取deep模型字段信息时
        if model_name == 'deep_model':
            deep_infos = DeepSplitInfo.objects.filter(eng_info_id=eng_id,deep_field_name=field_name)
            if not deep_infos:
                return Response({'detail': '深度信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            for deep_info in deep_infos:
                ocr_img_url = ''
                page = deep_info.page
                if ocr_img_urls_json:
                    ocr_img_url = split_file_url(eval(ocr_img_urls_json)[page])
                data = {
                    'id': deep_info.id,
                    'model_name': 'deep_model',
                    'field_name': field_name,
                    'field_content': str(deep_info.deep_field_value) if deep_info.deep_field_value else '',
                    'field_coor': eval(deep_info.deep_field_coor) if deep_info.deep_field_coor else None,
                    'ocr_img_url': ocr_img_url
                }
                data_list.append(data)
            # deep_infos = eng_info.deep_info_set.all()
            # if not deep_infos:
            #     return Response({'detail': '深度信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            # for deep_info in deep_infos:
            #     field_content = getattr(deep_info, field_name)
            #     field_coor = getattr(deep_info, field_name + '_coor')
            #     page = deep_info.page
            #     ocr_img_url = ''
            #     if ocr_img_urls_json:
            #         ocr_img_url = split_file_url(eval(ocr_img_urls_json)[page])
            #     data = {'id': deep_info.id, 'model_name': 'deep_model', 'field_name': field_name,
            #             'field_content': str(field_content) if field_content else '',
            #             'field_coor': eval(field_coor) if field_coor else None, 'ocr_img_url': ocr_img_url}
            #     data_list.append(data)
        request_finished_custom.send('获取校对字段对应内容', request=self.request)
        return Response(data=data_list, status=status.HTTP_200_OK)

    def post(self, request, pk, *args, **kwargs):
        data = request.data
        id = data.get('id')
        model_name = data.get('model_name')
        field_name = data.get('field_name')
        field_content = data.get('field_content')
        if not all([id, model_name, field_name]):
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        if model_name == 'eng_model':
            eng_info = EngInfoModel.objects.filter(id=id).first()
            if not eng_info:
                return Response({'detail': '工程信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            setattr(eng_info, field_name, field_content)
            eng_info.save(update_fields=[field_name])
        if model_name == 'land_model':
            land_info = LandInfoModel.objects.filter(id=id).first()
            if not land_info:
                return Response({'detail': '土地信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            setattr(land_info, field_name, field_content)
            land_info.save(update_fields=[field_name])
        if model_name == 'deep_model':
            deep_info = DeepSplitInfo.objects.filter(id=id).first()
            if not deep_info:
                return Response({'detail': '深度信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            deep_info.deep_field_value = field_content
            deep_info.save(update_fields=['deep_field_value'])
            # deep_info = DeepInfoModel.objects.filter(id=id).first()
            # if not deep_info:
            #     return Response({'detail': '深度信息不存在'}, status=status.HTTP_400_BAD_REQUEST)
            # setattr(deep_info, field_name, field_content)
            # deep_info.save(update_fields=[field_name])
        request_finished_custom.send("识别结果更新", request=self.request)
        is_review = 1
        FileModel.objects.filter(id=pk).update(is_review=is_review)
        return Response({'detail': '成功'}, status=status.HTTP_200_OK)


class FileOcrView(FieldsInfoView):
    permission_classes = (IsAuthenticated,)

    def put(self, request, pk, *arsg, **kwargs):
        return super(FileOcrView, self).post(request, pk, *arsg, **kwargs)

    def get(self, request, pk, *args, **kwargs):
        """
        获取ocr详情
        :param request:
        :param pk: 文件id
        :return: 位置信息的json 及文件url
        """
        file_obj = FileModel.objects.filter(ocr_status=11, id=pk, ocr_time__isnull=False).prefetch_related(
            'eng_info_set',
            'eng_info_set__land_info_set',
            'eng_info_set__deep_split_info_set').only("ocr_img_urls", "position_info").first()
        if not file_obj:
            return Response(data={"detail": "资源不存在"}, status=status.HTTP_404_NOT_FOUND)
        position_info = json.loads(file_obj.position_info)
        eng_info_page_list = list()
        # 查询文件的所有eng_info, land_info, deep_info信息 统一构建为 {model_name, id, field_name, coordinate, text}
        for eng_info in file_obj.eng_info_set.all():
            eng_info_text_columns = ["eng_name", "eng_no", "boring_no", "orifice_height", "orifice_diameter",
                                     "hole_depth", "coordinates", "start_date", "completion_date", "water_depth",
                                     "water_date", "stable_water_level", "pressure_water_level",
                                     "initial_water_level", "mileage", "offset", "drill_depth"]
            # 构建eng_info指定字段的信息
            eng_info_page = eng_info.page
            eng_info_page_list.append(eng_info_page)
            for text_column in eng_info_text_columns:
                coordinate = getattr(eng_info, f'{text_column}_coor', None)
                if coordinate:
                    cell_data = {
                        'text': getattr(eng_info, text_column, ''),
                        'coordinate': eval(coordinate),
                        'model_name': 'eng_model',
                        'id': eng_info.id,
                        'field_name': text_column,
                    }
                    # 仅仅在第一页中都添加工程信息
                    position_info[eng_info_page].append(cell_data)

            # 构建land_info字段的信息
            for land_info in eng_info.land_info_set.all():
                land_info_text_columns = ["geological_age", "floor_number", "stratum_name", "bottom_elevation",
                                          "bottom_depth", "delamination_thickness", "histogram", "state",
                                          "lithology_description", ]
                page = land_info.page
                # 构建eng_info指定字段的信息
                for text_column in land_info_text_columns:
                    coordinate = getattr(land_info, f'{text_column}_coor', None)
                    if coordinate:
                        cell_data = {
                            'text': getattr(land_info, text_column, ''),
                            'coordinate': eval(coordinate),
                            'model_name': 'land_model',
                            'id': land_info.id,
                            'field_name': text_column,
                        }
                        position_info[page].append(cell_data)

            # 构建deep_info实际取样深度字段的信息
            deep_name = ['deep_field_name', 'deep_field_value', 'deep_field_coor', 'id', 'page']
            deep_set = list(eng_info.deep_split_info_set.filter(deep_field_coor__isnull=False).
                                   only(*deep_name))
            if deep_set:
                for deep_obj in deep_set:
                    cell_data = {
                        'text': deep_obj.deep_field_value,
                        'coordinate': eval(deep_obj.deep_field_coor),
                        'model_name': 'deep_model',
                        'id': deep_obj.id,
                        'field_name': deep_obj.deep_field_name,
                    }
                    position_info[deep_obj.page].append(cell_data)
        # 剔除不需要保存的表头
        for page, page_position_info in enumerate(position_info):
            if page in eng_info_page_list:
                continue
            page_position_info_delete_item_list = list()
            for index, cell_item in enumerate(page_position_info):
                if is_key(cell_item.get("text", ""), include=['eng_info'], all_key=False):
                    page_position_info_delete_item_list.append(cell_item)
            [page_position_info.remove(cell_item) for cell_item in page_position_info_delete_item_list]

        # 根据页面拼接到，指定页的list中
        request_finished_custom.send("ocr效果图查询", request=self.request)
        return Response(data={'position_info': position_info, 'ocr_img_urls': [split_file_url(url)
                                                                               for url in
                                                                               json.loads(file_obj.ocr_img_urls)]})


class SubdirectoryView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        return FileModel.objects.filter(company_id=self.request.user.company_id)

    def get(self, request, *args, **kwargs):
        folder_id = request.query_params.get('folder_id')
        super = request.query_params.get('super')
        is_staff = request.user.is_staff

        # 管理员super为1是请求根目录，否则根据文件夹id获取
        if is_staff:
            if super and super == '1':
                objects = self.get_queryset().filter(p_file=None, type=0).only('id', 'name')
                data = SubdirectorySerializer(objects, many=True).data
            else:
                if not folder_id:
                    return Response({'detail': ' 参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
                objects = self.get_queryset().filter(p_file=folder_id, type=0).only('id', 'name')
                data = SubdirectorySerializer(objects, many=True).data
        else:
            if not folder_id:
                return Response({'detail': ' 参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
            objects = self.get_queryset().filter(p_file=folder_id, type=0).only('id', 'name')
            data = SubdirectorySerializer(objects, many=True).data
        # objects = self.get_queryset().filter(p_file=folder_id,type=0, user_id=self.request.user.id).only('id', 'name')
        request_finished_custom.send('移动端获取子目录', request=self.request)
        return Response(data=data, status=status.HTTP_200_OK)


class OcrStatusView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        user = request.user
        file_set = FileModel.objects.filter(file_owner_id=user.id, ocr_status__in=[3, 6]).values_list('id',
                                                                                                      'ocr_status')
        if not file_set:
            return Response(data={}, status=status.HTTP_200_OK)
        file_set = pd.DataFrame(file_set, columns=('id', 'ocr_status'))
        app_sbz_list = file_set[file_set.ocr_status.isin([3])].id.tolist()
        app_dlz_list = file_set[file_set.ocr_status.isin([6])].id.tolist()
        request_finished_custom.send('获取OCR状态', request=self.request)
        return Response(data={'app_sbz_list': app_sbz_list, 'app_dlz_list': app_dlz_list}, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        file_id_list = request.data.get('file_id_list')
        files = FileModel.objects.filter(Q(id__in=file_id_list) & ~Q(type=0)).only('id', 'ocr_status')
        data = OcrStatusSerializer(files, many=True).data
        request_finished_custom.send('获取识别状态', request=self.request)
        return Response(data=data, status=status.HTTP_200_OK)


class AppOcrTableAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, pk, *args, **kwargs):
        """ocr table 融合及入库"""
        ocr_result = request.data
        file_obj = FileModel.objects.filter(id=pk, ocr_status=3, company_id=request.user.company_id) \
            .only('id', 'ocr_img_urls', 'celery_task_id', 'ocr_status').first()
        if not file_obj:
            return Response({'detail': '文件不存在'}, status=status.HTTP_400_BAD_REQUEST)
        is_error = request.query_params.get('is_error')
        if is_error == '1':
            # 安卓端发生错误
            logger.warning("安卓端ocr识别失败", exc_info=True)
            file_obj.ocr_status = 7
            file_obj.save()
            return Response({"detail": "成功"})
        jz_imgs = json.loads(file_obj.ocr_img_urls)
        if jz_imgs:
            for i in range(len(jz_imgs)):
                jz_imgs[i] = split_file_url(jz_imgs[i])
        try:
            table_result = main.celery_app.AsyncResult(id=file_obj.celery_task_id).get(timeout=30)
        except Exception:
            logger.warning("获取table结果失败", exc_info=True)
            file_obj.ocr_status = 7
            file_obj.save()
            return Response(data={"detail": "获取table结果失败"}, status=status.HTTP_400_BAD_REQUEST)

        ocr_table_merge.s(pk, ocr_result, table_result, jz_imgs).apply_async()

        request_finished_custom.send("安卓端ocr结果入库", request=self.request)
        return Response(data={"detail": "成功"})


# class AllUserFolderView(ModelViewSet):
#     permission_classes = (IsAdminUser,)
#
#     def get_serializer_class(self):
#         return serializers.FileSearchSerializer
#
#     def get_queryset(self):
#         user_id = self.request.user.id
#         user_query = User.objects.all().only('id', 'user_root_dir_id').values_list('id', 'user_root_dir_id')
#         file_set = pd.DataFrame(user_query, columns=['id', 'user_root_dir_id'])
#         curr_user_dir_id = file_set[file_set.id == user_id].user_root_dir_id.tolist()[0]
#         file_id_list = file_set.user_root_dir_id.tolist()
#         index = file_id_list.index(curr_user_dir_id)
#         # file_id_list.pop(index)
#         # file_id_list.insert(0,curr_user_dir_id)
#         # queryset1 = FileModel.objects.filter(id=curr_user_dir_id)
#         queryset = FileModel.objects.filter(id__in=file_id_list).defer("ocr_img_urls", "position_info")
#         # queryset = queryset1|queryset2
#         # queryset = chain(queryset1, queryset)
#         return queryset
#
#     def list(self, request, *args, **kwargs):
#         response = super(AllUserFolderView, self).list(request, *args, **kwargs)
#         print(response.data)
#         request_finished_custom.send('所有用户根目录', request=self.request)
#         return response


class AllUserFolderView(APIView):
    permission_classes = (IsAdminUser,)

    def get_queryset(self):
        # 企业隔离
        company_id = self.request.user.company_id
        return FileModel.objects.filter(company_id=company_id)

    def get(self, request, *args, **kwargs):
        # count = FileModel.objects.filter(p_file=None).count()
        page = request.query_params.get('page')
        page_size = request.query_params.get('page_size')
        if not page_size:
            page_size = StandardResultPagination.page_size
        user_id = self.request.user.id
        curr_user_dir_id = User.objects.filter(id=user_id).only('user_root_dir_id').first().user_root_dir_id
        if page and page_size:
            # 分页
            page = int(page)
            page_size = int(page_size)
            if page == 1:
                file = self.get_queryset().filter(id=curr_user_dir_id).first()
                data_curr_user = serializers.FileSearchSerializer(file).data
                files = self.get_queryset().filter(Q(p_file=None)&~Q(id=curr_user_dir_id))[0:((page*page_size)-1)]
                results = serializers.FileSearchSerializer(files, many=True).data
                results.insert(0, data_curr_user)
            else:
                files = self.get_queryset().filter(Q(p_file=None)&~Q(id=curr_user_dir_id))[(((page-1)*page_size)-1):((page*page_size)-1)]
                results = serializers.FileSearchSerializer(files, many=True).data
        else:
            # 不分页
            file = self.get_queryset().filter(id=curr_user_dir_id).first()
            data_curr_user = serializers.FileSearchSerializer(file).data
            files = self.get_queryset().filter(Q(p_file=None) & ~Q(id=curr_user_dir_id))
            results = serializers.FileSearchSerializer(files, many=True).data
            results.insert(0, data_curr_user)
        data = {
            'count': None,
            'next': None,
            'previous': None,
            'results': results
        }
        request_finished_custom.send('所有用户根目录', request=self.request)
        return Response(data, status=status.HTTP_200_OK)


class ShowView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        pk = request.data.get('pk')
        # 一次性查询出所有的文件需要的信息
        file_obj = FileModel.objects.filter(id=pk).only('id', 'name', 'type').prefetch_related(
            'eng_info_set',
            'eng_info_set__land_info_set').first()
        # 遍历保存每个文件的ocr结果
        file_temp = tempfile.TemporaryFile()

        eng_info_columns = ["file_id",  "eng_name", "boring_no", "spare_int1", "spare_int2", "orifice_height", "orifice_diameter",
                            "coordinates"]

        land_info_columns = ["bottom_elevation", "bottom_depth", "delamination_thickness", "lithology_description"]

        result_show = []
        for eng_info in file_obj.eng_info_set.all():
            # 获取eng信息
            eng_info_data = [getattr(eng_info, column) for column in eng_info_columns]
            land_info_data = eng_info.land_info_set.values_list(*land_info_columns)
            eng_data = dict(zip(eng_info_columns, eng_info_data))
            land_data = dict(zip(land_info_columns, np.array(list(land_info_data)).T.tolist()))
            land_data['lithology'] = [re.split(r'[:：\s]\s*', str(i))[0] if i else None for i in land_data['lithology_description']]
            # land_data['description'] = [re.split(r'[:：\s]\s*', str(i))[1] if len(re.split(r'[:：\s]\s*', str(i)))>1
            #                             else 'None' for i in land_data['lithology_description']]
            eng_data.update(land_data)
            try:
                res_coor = requests.get(get_urt('郑州市' + eng_data['eng_name']))
                # eng_data['coordinates'] = eval(res_coor.content)['result']['location']
                if eng_data['spare_int1'] and eng_data['spare_int2']:
                    eng_data['coordinates'] = {'lng': eng_data['spare_int1']/1000000, 'lat': eng_data['spare_int2']/1000000}
                else:
                    print('数据库经纬度为空')
                    eng_data['coordinates'] = eval(res_coor.content)['result']['location']
            except:
                eng_data['coordinates'] = {'lng': 113.605873, 'lat': 34.803502}
            result_show.append(eng_data)
        return Response({'data': result_show})


class LocationView(APIView):

    def get(self, request, pk, *args, **kwargs):
        file_id_list = list(FileModel.objects.filter(p_file_id=pk).values_list('id', flat=True))
        eng_set = EngInfoModel.objects.filter(file_id__in=file_id_list)
        data = serializers.EngLocationInfo(eng_set, many=True).data
        return Response({'data': data}, status=status.HTTP_200_OK)


class FoldersLocationView(APIView):

    def get(self, request, *args, **kwargs):
        # 以param形式传多个以逗号分割的文件夹id
        folder_id = request.query_params.get('folder_id', '')
        if not folder_id:
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        folder_id_list = list(map(int, folder_id.split(',')))
        columns = ['id', 'type', 'p_file_id']
        file_set = FileModel.objects.all().values_list(*columns)
        file_set = pd.DataFrame(file_set, columns=columns)
        file_id_list = self.all_son_file_id(file_set, folder_id_list)
        eng_set = EngInfoModel.objects.filter(file_id__in=file_id_list)
        data = serializers.EngLocationInfo(eng_set, many=True).data
        return Response(data, status=status.HTTP_200_OK)

    # 文件夹下所有文件id
    def all_son_file_id(self, file_set:pd.DataFrame, folder_id_list:list):
        file_id_list = []
        for folder_id in folder_id_list:
            son_folder_id = file_set[(file_set.p_file_id==folder_id) & (file_set.type==0)].id.tolist()
            son_file_id = file_set[(file_set.p_file_id==folder_id) & (file_set.type!=0)].id.tolist()
            if son_folder_id:
                ret_list = self.all_son_file_id(file_set, son_folder_id)
                file_id_list.extend(ret_list)
            file_id_list.extend(son_file_id)
        return file_id_list


class AppLocationView(APIView):

    def get(self, request, *args, **kwargs):
        folder_id = request.query_params.get('folder_id', '')
        if not folder_id:
            return Response({'detail': '参数不完整'}, status=status.HTTP_400_BAD_REQUEST)
        folder_id_list = list(map(int, folder_id.split(',')))
        columns = ['id', 'type', 'p_file_id']
        file_set = FileModel.objects.all().values_list(*columns)
        file_set = pd.DataFrame(file_set, columns=columns)
        file_id_list = self.all_son_file_id(file_set, folder_id_list)
        eng_set = EngInfoModel.objects.filter(file_id__in=file_id_list)
        data = serializers.AppEngLocationInfo(eng_set, many=True).data
        return Response(data, status=status.HTTP_200_OK)

    # 文件夹下所有文件id
    def all_son_file_id(self, file_set:pd.DataFrame, folder_id_list:list):
        file_id_list = []
        for folder_id in folder_id_list:
            son_folder_id = file_set[(file_set.p_file_id==folder_id) & (file_set.type==0)].id.tolist()
            son_file_id = file_set[(file_set.p_file_id==folder_id) & (file_set.type!=0)].id.tolist()
            if son_folder_id:
                ret_list = self.all_son_file_id(file_set, son_folder_id)
                file_id_list.extend(ret_list)
            file_id_list.extend(son_file_id)
        return file_id_list
