# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/22
# @author fj

from django.urls import path

from pdf_ocr.views import upload_file, FileView, FileOcrView, TokenCheckView, \
    BatchExportDataView, BatchFileDownloadView, MoveFilesView, ExportDataView, FieldsListView, FieldsInfoView, \
    FileBatchOcrView, BoringNoView, UserUploadStat, UserOCRStat, UserFileStat, SubdirectoryView, MobileBatchOcrView, \
    MobileStartOcrView, OcrStatusView, AppOcrTableAPIView, AllUserFolderView, ShowView, LocationView, AppLocationView, FoldersLocationView

urlpatterns = [
    # path('file', upload_file), 文件上传
    path('token_check', TokenCheckView.as_view()),  # token_check
    path('file', FileView.as_view({'get': 'list', 'post': 'create', 'delete': 'destroy'})),  # 上传后的文件创建上传记录批量删除
    path('file/<int:pk>', FileView.as_view({'delete': 'destroy', 'get': 'retrieve', 'patch': 'update'})),
    path('files_move', MoveFilesView.as_view()),  # 批量移动文件
    path('ocr/<int:pk>', FileOcrView.as_view()),  # 获取ocr详情
    path('ocr', FileBatchOcrView.as_view()),  # 文件批量ocr识别 批量取消ocr
    path('export_data/<int:pk>', ExportDataView.as_view()),
    path('export_datas', BatchExportDataView.as_view()),
    path('exports_files', BatchFileDownloadView.as_view()),
    path('upload_stat', UserUploadStat.as_view()),
    path('ocr_stat', UserOCRStat.as_view()),
    path('users_stat', UserFileStat.as_view()),
    path('show', ShowView.as_view()),
    path('location/<int:pk>', LocationView.as_view()),
    path('location', FoldersLocationView.as_view()),

    # app不同部分
    path('app/boring_no/<int:pk>', BoringNoView.as_view()),
    path('app/fields_list/<int:pk>', FieldsListView.as_view()),
    path('app/fields_info', FieldsInfoView.as_view()),
    path('app/fields_info/<int:pk>', FieldsInfoView.as_view()),  # post 保存
    path('app/subdir', SubdirectoryView.as_view()),
    path('app/users_folder', AllUserFolderView.as_view()),
    path('app/ocr_status', OcrStatusView.as_view()),    # ocr_状态查询接口
    path('app/ocr_sbz', OcrStatusView.as_view()),
    path('app/ocr_table/<int:pk>', AppOcrTableAPIView.as_view()),
    path('app/ocr', MobileBatchOcrView.as_view()),  # 移动端文件批量ocr识别
    path('app/ocring/<int:pk>', MobileStartOcrView.as_view()),  # 移动端开始ocr识别
    path('app/location', AppLocationView.as_view()),      #移动端地图展示转孔
]
