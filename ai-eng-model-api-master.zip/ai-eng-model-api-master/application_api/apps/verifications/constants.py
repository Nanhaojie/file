# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj

# 图片验证码redis有效期，单位秒
IMAGE_CODE_REDIS_EXPIRES = 60 * 5
IMAGE_CODE_REDIS_PREFIX = 'img_'

