# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/21
# @author yueyb

from django.urls import path

from verifications.views import ImageCodeView

urlpatterns = [
    path('image_codes/<slug:image_code_id>', ImageCodeView.as_view()),
]
