# Create your views here.
import logging

from django.http import HttpResponse

from django_redis import get_redis_connection
from rest_framework.views import APIView

from libs.captcha.captcha import captcha
from verifications import constants

logger = logging.getLogger('django')


class ImageCodeView(APIView):
    """图片验证码"""

    def get(self, request, image_code_id):
        # 生成验证码图片
        text, image = captcha.generate_captcha()

        # 保存验证码内容(为的是后面做校验)
        redis_conn = get_redis_connection('default')
        redis_conn.setex(f"{constants.IMAGE_CODE_REDIS_PREFIX}{image_code_id}", constants.IMAGE_CODE_REDIS_EXPIRES, text)
        logger.info(f"图片验证码内容:[image_code: {text}]")

        # 返回验证码图片
        return HttpResponse(image, content_type='image/jpg')
