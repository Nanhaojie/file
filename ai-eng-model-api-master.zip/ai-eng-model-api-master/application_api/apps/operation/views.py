from django.db import connection
from django.db.models import Count
import datetime

from rest_framework import status
from rest_framework.generics import CreateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet

from operation import serializers
from operation.models import OperationRegisterModel, OperationFileModel, EngTeamModel, ReportFileContentModel, \
    ReportLocationModel, Area, OperationReportModel

import pandas as pd

from user.models import Company


class OperationRegister(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        if self.action == 'create':
            return serializers.OperationCreateSerializer
        if self.action == 'list':
            return serializers.OperationSerializer

    def get_queryset(self):
        object = OperationRegisterModel.objects.all().order_by('-id')
        return object

    def list(self, request, *args, **kwargs):
        response = super(OperationRegister, self).list(request, *args, **kwargs)
        return response


class OperationReport(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        if self.action == 'create':
            return serializers.ReportCreateSerializer
        elif self.action == 'list':
            return serializers.OperationReportListSerializer

    def get_queryset(self):
        return ReportLocationModel.objects.all()

class EngTeam(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    pagination_class = None

    def get_serializer_class(self):
        if self.action == 'list':
            return serializers.EngTeamSerializer

    def get_queryset(self):
        company_id = self.request.user.company_id
        object = EngTeamModel.objects.filter(company_id=company_id)
        return object

    def list(self, request, *args, **kwargs):
        response = super(EngTeam, self).list(request, *args, **kwargs)
        return response


class ReportFileInfo(ModelViewSet):
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        # if self.action == 'list':
        return serializers.ReportFileInfoSerializer

    def get_queryset(self):
        company_id = self.request.user.company_id
        object = ReportFileContentModel.objects.filter(company_id=company_id)
        # object = ReportFileContentModel.objects.all()
        return object

    def list(self, request, *args, **kwargs):
        response = super(ReportFileInfo, self).list(request, *args, **kwargs)
        return response


class DangerLevel(APIView):

    def get(self, request, *args, **kwargs):
        # area_id = request.query_params.get("area_id")
        # is_area = request.query_params.get("is_area")
        # # 如果有area_id,获取指定地区数据
        # object = ReportFileContentModel.objects.all()
        # if area_id and is_area == '0':
        #     area_id = int(area_id)
        #     columns = ('id', 'name', 'p_id')
        #     area_set = Area.objects.all().values_list(*columns)
        #     area_set = pd.DataFrame(list(area_set), columns=columns)
        #     sub_area_set = area_set[area_set.p_id==area_id]
        #     sub_id_list = self.sub_area(area_set, sub_area_set)
        #     object = object.filter(area_id__in=sub_id_list)
        # else:
        #     # 如果没有area_id,获取所有地区数据
        #     object = object.filter(area_id=area_id)
        # # 新版
        # level_set = object.values('danger_level').annotate(num=Count('id'))
        # level_to_eng = {
        #     'I': 'one',
        #     'II': 'two',
        #     'III': 'three',
        #     'IV': 'four',
        #     'V': 'five'
        # }
        # data = {
        #     'five': 0,
        #     'four': 0,
        #     'three': 0,
        #     'two': 0,
        #     'one': 0
        # }
        # for item in level_set:
        #     data[level_to_eng.get(item['danger_level'])] = item['num']

        #  写死
        data = {
            "five":0,
            "four":30,
            "three":3,
            "two":0,
            "one":0,
            "null":4
        }
        return Response(data=data, status=status.HTTP_200_OK)

    def sub_area(self, area_set:pd.DataFrame, sub_area_set:pd.DataFrame):
        id_list = []
        for area in sub_area_set.itertuples():
            _sub_area = area_set[area_set.p_id==area.id]
            if len(_sub_area) != 0:
                ret = self.sub_area(area_set,_sub_area)
                id_list.extend(ret)
            id_list.append(area.id)
        return id_list


class CompanyRepairing(APIView):

    def get(self, request, *args, **kwargs):
        # 写死
        data_list = [
            {
                "id":10,
                "name":"郑州安源工程技术有限公司",
                "contacts":"赵鹏",
                "phone":"13253637588",
                "repairing_count":1,
                "notes":"",
                "repair_status":2
            },
            {
                "id":16,
                "name":"中国电建集团华东勘测设计研究院有限公司（坝道工程医院华东院分院）",
                "contacts":"刘强",
                "phone":"13989869208",
                "repairing_count":1,
                "notes":"账号：中国电建集团华东首字母， 密码：qqq123",
                "repair_status":2
            },
            {
                "id":18,
                "name":"中国电建集团贵阳勘测设计研究院有限公司（坝道工程医院岩溶地区分院）",
                "contacts":"陈志峰",
                "phone":"17200315667",
                "repairing_count":1,
                "notes":"",
                "repair_status":2
            }
        ]
        # 所有单位
        # company_set = Company.objects.all().only('id', 'name', 'contacts', 'phone', 'notes')
        # if not company_set:
        #     return Response({'detail': '暂无单位信息！'}, status=status.HTTP_400_BAD_REQUEST)
        # # 正在修复中
        # column = ('id', 'company_id')
        # object = ReportFileContentModel.objects.filter(repair_status=2).values_list(*column)
        # object_set = pd.DataFrame(object, columns=column)
        # data_list = []
        # for company in company_set:
        #     # count1 = object.filter(company_id=company.id).count()
        #     count = object_set[object_set.company_id == company.id].shape[0]
        #     if not count:
        #         continue
        #     data = {
        #         'id': company.id,
        #         'name': company.name,
        #         'contacts': company.contacts,
        #         'phone': company.phone,
        #         'repairing_count': count,
        #         'notes': company.notes,
        #         'repair_status': 2
        #     }
        #     data_list.append(data)
        return Response(data_list)


class DisasterDayAdd(APIView):

    def get(self, request, *args, **kwargs):
        # 当天年月日
        # year = datetime.datetime.now().year
        # month = datetime.datetime.now().month
        # day = datetime.datetime.now().day
        # data = serializers.DisasterDayAddSerializer(set, many=True).data
        # 比对获取数量
        # count = ReportFileContentModel.objects.filter(create_time__year=year, create_time__month=month, create_time__day=day).count()

        # select = {'day': connection.ops.date_trunc_sql('day', 'create_time')}
        # set = ReportFileContentModel.objects.extra(select=select).values('day').annotate(count=Count('id'))
        # if not set:
        #     return Response({'detail': '暂无数据'}, status=status.HTTP_400_BAD_REQUEST)
        # data = []
        # for item in set:
        #     data.append({
        #         'day': datetime.datetime.strftime(item['day'], "%m-%d"),
        #         'count': item['count']
        #     })

        # 写死
        data = [
            {
                "day":"8-19",
                "count":0
            },
            {
                "day":"8-18",
                "count":12
            },
            {
                "day":"8-17",
                "count":0
            },
            {
                "day":"8-16",
                "count":0
            },
            {
                "day":"8-15",
                "count":0
            },
            {
                "day":"8-14",
                "count":0
            },
            {
                "day":"8-13",
                "count":0
            }
        ]

        # # today = datetime.datetime.now()
        # today =datetime.date.today()
        # first_day = today + datetime.timedelta(days=-6)
        # columns = ('id', 'create_time')
        # rfc_obj = ReportFileContentModel.objects.filter(create_time__gte=first_day).values_list(*columns)
        # rfc_set = pd.DataFrame(rfc_obj, columns=columns)
        # data = []
        # for i in range(7):
        #     day = today + datetime.timedelta(days=-i)
        #     start_day = (today + datetime.timedelta(days=-i)).strftime('%Y%m%d')
        #     end_day = (today + datetime.timedelta(days=-i+1)).strftime('%Y%m%d')
        #     year = day.year
        #     month = day.month
        #     day = day.day
        #     # count1 = ReportFileContentModel.objects.filter(create_time__year=year, create_time__month=month, create_time__day=day).count()
        #     count = rfc_set[(rfc_set['create_time']>=start_day)&(rfc_set['create_time']<end_day)].shape[0]
        #     data.append({'day': str(month) + '-' + str(day), 'count': count})
        return Response(data, status=status.HTTP_200_OK)


class DisasterDayRepair(APIView):

    def get(self, request, *args, **kwargs):
        # 当天年月日
        # year = datetime.datetime.now().year
        # month = datetime.datetime.now().month
        # day = datetime.datetime.now().day
        # # 比对获取数量
        # count = ReportFileContentModel.objects.filter(repair_status=3,update_time__year=year, update_time__month=month, update_time__day=day).count()
        # select = {'day': connection.ops.date_trunc_sql('day', 'update_time')}
        # set = ReportFileContentModel.objects.filter(repair_status=3).extra(select=select).values('day').annotate(count=Count('id'))
        # if not set:
        #     return Response({'detail': '暂无数据'}, status=status.HTTP_400_BAD_REQUEST)
        # data = []
        # for item in set:
        #     data.append({
        #         'day': datetime.datetime.strftime(item['day'], "%m-%d"),
        #         'count': item['count']
        #     })

        # today = datetime.datetime.now()
        # 写死
        data = [
            {
                "day":"8-19",
                "count":0
            },
            {
                "day":"8-18",
                "count":0
            },
            {
                "day":"8-17",
                "count":0
            },
            {
                "day":"8-16",
                "count":0
            },
            {
                "day":"8-15",
                "count":0
            },
            {
                "day":"8-14",
                "count":0
            },
            {
                "day":"8-13",
                "count":0
            }
        ]
        # today = datetime.date.today()
        # first_day = today + datetime.timedelta(days=-6)
        # columns = ('id', 'create_time')
        # rfc_obj = ReportFileContentModel.objects.filter(repair_status=3, create_time__gte=first_day).values_list(*columns)
        # rfc_set = pd.DataFrame(rfc_obj, columns=columns)
        # data = []
        # for i in range(7):
        #     day = today + datetime.timedelta(days=-i)
        #     start_day = (today + datetime.timedelta(days=-i)).strftime('%Y%m%d')
        #     end_day = (today + datetime.timedelta(days=-i+1)).strftime('%Y%m%d')
        #     year = day.year
        #     month = day.month
        #     day = day.day
        #     # count = ReportFileContentModel.objects.filter(repair_status=3, update_time__year=year, update_time__month=month, update_time__day=day).count()
        #     count = rfc_set[(rfc_set['create_time']>=start_day)&(rfc_set['create_time']<end_day)].shape[0]
        #     data.append({'day': str(month) + '-' + str(day), 'count': count})
        return Response(data, status=status.HTTP_200_OK)


class DisasterLocation(APIView):

    def get(self, request, *args, **kwargs):
        # 比对获取数量
        # object = ReportFileContentModel.objects.all().only('id', 'longitude', 'latitude', 'danger_level', 'reporting_unit',
        #                                                    'contacts', 'phone', 'danger_type', 'location_description',
        #                                                    'repair_status', 'real_location')
        # data = serializers.DisasterLocationSerializer(object, many=True).data

        # 写死
        data = [
            {
                "id":110,
                "longitude":"113.5351203",
                "latitude":"34.8075188",
                "danger_level":4,
                "reporting_unit":"深圳安德空间技术有限公司",
                "contacts":"库捷峰",
                "phone":"16671057918",
                "danger_type":"空洞",
                "location_description":"长椿路北往南方向中间车道，科学大道长椿路公交站附近",
                "repair_status":2,
                "real_location":"http://dtdfile.zoneyet.com:9909/disease_img/1627735500.1926367.png"
            },
            {
                "id":112,
                "longitude":"113.4739312067",
                "latitude":"34.8152103627",
                "danger_level":4,
                "reporting_unit":"河南日盛综合检测有限公司 ",
                "contacts":'null',
                "phone":'null',
                "danger_type":"空洞",
                "location_description":'null',
                "repair_status":3,
                "real_location":"http://dtdfile.zoneyet.com:9909/disease_img/1627735501.9651825.png"
            },
            {
                "id":114,
                "longitude":"113.5356021",
                "latitude":"34.8110696",
                "danger_level":3,
                "reporting_unit":"深圳安德空间技术有限公司",
                "contacts":"库捷峰",
                "phone":"16671057918",
                "danger_type":"脱空",
                "location_description":"长椿路南往北方向非机动车道，长椿路科学大道公交站附近",
                "repair_status":1,
                "real_location":"http://dtdfile.zoneyet.com:9909/disease_img/1627735500.5399683.png"
            }
        ]
        return Response(data, status=status.HTTP_200_OK)


class CheckedSection(APIView):

    def get(self, request, *args, **kwargs):
        # 已检测路段
        # check_id_list = OperationReportModel.objects.all().values_list('id', flat=True)
        # if not check_id_list:
        #     return Response({'detail': '暂无已检测路段信息'}, status=status.HTTP_400_BAD_REQUEST)
        # columns = ('id', 'longitude', 'latitude', 'operation_report_id')
        # location_set = ReportLocationModel.objects.all().order_by('id').values_list(*columns)
        # location_set = pd.DataFrame(list(location_set), columns=columns)
        # data = []
        # for id in check_id_list:
        #     report_location_set = location_set[location_set.operation_report_id==id]
        #     location_list = []
        #     for location in report_location_set.itertuples():
        #         location_list.append(location.longitude + ',' + location.latitude)
        #     data.append({
        #         'location_list': location_list
        #     })

        # 写死
        data = [
            {
                "location_list":[
                    "113.62948029558221,34.71243178267379",
                    "113.62960904161272,34.7004675057591",
                    "113.64396958843278,34.69851813049625",
                    "113.65621387237631,34.698254608484056",
                    "113.65736722223298,34.70821603882015",
                    "113.64454626336112,34.71122021929569",
                    "113.6306309632299,34.709902803125296"
                ]
            },
            {
                "location_list":[
                    "113.66155280932911,34.66611958502719",
                    "113.70739310171392,34.671273894724955",
                    "113.68797122656935,34.69797785433768",
                    "113.65789829960883,34.697805847310185",
                    "113.66259618861805,34.666808977360425"
                ]
            },
            {
                "location_list":[
                    "113.61349969454486,34.75572993174626",
                    "113.61417427010058,34.74749548629501",
                    "113.62891300838525,34.7470932743663",
                    "113.62903370778886,34.75510188173181",
                    "113.61416890568263,34.7557563758526"
                ]
            }
        ]
        return Response(data, status=status.HTTP_200_OK)


class TotalRegionalInfo(APIView):

    def sub_area(self, area_set:pd.DataFrame, sub_area_set:pd.DataFrame):
        id_list = []
        for area in sub_area_set.itertuples():
            _sub_area = area_set[area_set.p_id==area.id]
            if len(_sub_area) != 0:
                ret = self.sub_area(area_set,_sub_area)
                id_list.extend(ret)
            id_list.append(area.id)
        return id_list

    def get(self, request, *args, **kwargs):
        area_id = request.query_params.get("area_id")
        # 如果有area_id,获取指定地区数据
        object = ReportFileContentModel.objects.all()
        columns = ('id', 'name', 'p_id')
        area_set = Area.objects.all().values_list(*columns)
        area_set = pd.DataFrame(list(area_set), columns=columns)
        if area_id:
            area_id = int(area_id)
            sub_area_set = area_set[area_set.p_id == area_id]
            sub_id_list = self.sub_area(area_set, sub_area_set)
            object = object.filter(area_id__in=sub_id_list)
        total_regiona = object.values('area').annotate(num=Count('id'))
        for i in total_regiona:
            i['area_name'] = area_set[area_set.id == i['area']].iat[0,1]
            # i['area_name'] = Area.objects.filter(id=i['area']).first().name
        return Response(list(total_regiona))


class DangerTypeStatusInfo(APIView):

    def sub_area(self, area_set:pd.DataFrame, sub_area_set:pd.DataFrame):
        id_list = []
        for area in sub_area_set.itertuples():
            _sub_area = area_set[area_set.p_id==area.id]
            if len(_sub_area) != 0:
                ret = self.sub_area(area_set,_sub_area)
                id_list.extend(ret)
            id_list.append(area.id)
        return id_list

    def get(self, request, *args, **kwargs):
        # area_id= request.query_params.get("area_id")
        # is_area = request.query_params.get("is_area")
        # # 如果有area_id,获取指定地区数据
        # object = ReportFileContentModel.objects.all()
        # if area_id and is_area=='0':
        #     area_id = int(area_id)
        #     columns = ('id', 'name', 'p_id')
        #     area_set = Area.objects.all().values_list(*columns)
        #     area_set = pd.DataFrame(list(area_set), columns=columns)
        #     sub_area_set = area_set[area_set.p_id == area_id]
        #     sub_id_list = self.sub_area(area_set, sub_area_set)
        #     object = object.filter(area_id__in=sub_id_list)
        # else:
        #     object = object.filter(area_id=area_id)
        # danger_type = object.values('danger_type').annotate(num=Count('id'))
        # repair_status = object.values('repair_status').annotate(num=Count('id'))

        # 写死
        danger_type = [
            {
                "danger_type":"空洞",
                "num":26
            },
            {
                "danger_type":"脱空",
                "num":19
            },
            {
                "danger_type":"严重疏松",
                "num":7
            },
            {
                "danger_type":"沉降凹陷",
                "num":4
            }
        ]
        repair_status = [
            {
                "repair_status":2,
                "num":3
            },
            {
                "repair_status":3,
                "num":1
            },
            {
                "repair_status":1,
                "num":52
            }
        ]
        return Response(data={'danger_type': danger_type, 'repair_status': repair_status})