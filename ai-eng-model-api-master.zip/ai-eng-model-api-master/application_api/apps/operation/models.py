from django.db import models

# Create your models here.
from utils.models import SpareFieldModel


class OperationRegisterModel(SpareFieldModel):

    site_desc = models.CharField(max_length=100, verbose_name="位置描述")
    site_coor = models.CharField(max_length=32, null=True, blank=True, verbose_name="位置坐标")
    operate_start_time = models.DateTimeField(null=True, blank=True, verbose_name="作业开始时间")
    operate_end_time = models.DateTimeField(null=True, blank=True, verbose_name="作业结束时间")
    eng_team = models.ForeignKey('EngTeamModel', null=True, blank=True, on_delete=models.DO_NOTHING,
                                 related_name='team_oper_register', db_constraint=False, verbose_name="作业工程队")
    company = models.ForeignKey('user.Company', null=True, blank=True, on_delete=models.CASCADE,
                             related_name="com_oper_register", db_constraint=False, verbose_name="作业公司")
    principal = models.CharField(max_length=32, verbose_name="负责人")
    tel = models.CharField(max_length=16, null=True, blank=True, verbose_name="联系电话")
    user = models.ForeignKey('user.User', null=True, blank=True, on_delete=models.DO_NOTHING,
                             related_name="user_oper_set",
                             db_constraint=False)
    notes = models.CharField(max_length=1024, null=True, blank=True, verbose_name="作业详情")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        # 指明数据库表名
        db_table = 't_operation_register'
        verbose_name = '排险作业登记表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class OperationFileModel(SpareFieldModel):
    file_type_choices = (
        (1, "上传文件"),
        (2, "现场照片"),
    )
    type = models.SmallIntegerField(choices=file_type_choices, verbose_name="文件类型")
    url = models.CharField(max_length=255, verbose_name="文件url")
    operation_register = models.ForeignKey("OperationRegisterModel", on_delete=models.CASCADE, related_name="files",
                                           db_constraint=False)
    eng_team = models.ForeignKey('EngTeamModel', null=True, blank=True, on_delete=models.DO_NOTHING,
                                 related_name='team_oper_file', db_constraint=False, verbose_name="作业工程队")
    company = models.ForeignKey('user.Company', null=True, blank=True, on_delete=models.CASCADE,
                             related_name="com_oper_file", db_constraint=False, verbose_name="作业公司")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")


    class Meta:
        # 指明数据库表名
        db_table = 't_operation_file'
        # 在admin站点中显示的名称
        verbose_name = '排险作业文件表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class OperationReportModel(SpareFieldModel):

    oper_type_choices = (
        (1, "路径作业"),
        (2, "区域作业"),
    )
    eng_team = models.ForeignKey('EngTeamModel', null=True, blank=True, on_delete=models.DO_NOTHING,
                                 related_name='team_oper_report', db_constraint=False, verbose_name="作业工程队")
    company = models.ForeignKey('user.Company', null=True, blank=True, on_delete=models.CASCADE,
                                related_name="com_oper_report", db_constraint=False, verbose_name="作业公司")
    principal = models.CharField(max_length=32, verbose_name="负责人")
    tel = models.CharField(max_length=16, null=True, blank=True, verbose_name="联系电话")
    type = models.SmallIntegerField(choices=oper_type_choices, verbose_name="作业类型")
    operate_start_time = models.DateTimeField(null=True, blank=True, verbose_name="作业开始时间")
    operate_end_time = models.DateTimeField(null=True, blank=True, verbose_name="作业结束时间")
    user = models.ForeignKey('user.User', null=True, blank=True, on_delete=models.DO_NOTHING,
                             related_name="user_report_set", db_constraint=False)
    notes = models.CharField(max_length=1024, null=True, blank=True, verbose_name="备注")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        # 指明数据库表名
        db_table = 't_operation_report'
        verbose_name = '排险作业上报表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class ReportLocationModel(SpareFieldModel):

    longitude = models.CharField(max_length=32, verbose_name="经度")
    latitude = models.CharField(max_length=32, verbose_name="纬度")
    operation_report = models.ForeignKey("OperationReportModel", on_delete=models.CASCADE, related_name="report_location_set",
                                           db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")

    class Meta:
        # 指明数据库表名
        db_table = 't_report_location'
        # 在admin站点中显示的名称
        verbose_name = '排险作业经纬度信息表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class EngTeamModel(SpareFieldModel):
    name = models.CharField(max_length=128, unique=True, verbose_name="作业工程队")
    principal = models.CharField(max_length=32, verbose_name="负责人")
    tel = models.CharField(max_length=16, null=True, blank=True, verbose_name="联系电话")
    notes = models.CharField(max_length=1024, null=True, blank=True, verbose_name="备注")
    company = models.ForeignKey('user.Company', null=True, blank=True, on_delete=models.CASCADE,
                             related_name="com_eng_team", db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        # 指明数据库表名
        db_table = 't_eng_team'
        verbose_name = '排险作业工程队表'
        # 显示的复数名称
        verbose_name_plural = verbose_name


class ReportFileContentModel(SpareFieldModel):
    repair_status_choices = (
        (1, "待修复"),
        (2, "修复中"),
        (3, "已修复"),
    )
    report_file_info = models.ForeignKey(OperationFileModel, on_delete=models.CASCADE,
                                         related_name="report_file_info_set", db_constraint=False)
    reporting_unit = models.CharField(max_length=128, null=True, blank=True, verbose_name="填报单位")
    abstract = models.CharField(max_length=1024, null=True, blank=True, verbose_name="报告摘要")
    road_name = models.CharField(max_length=128, null=True, blank=True, verbose_name="道路名称")
    contacts = models.CharField(max_length=128, null=True, blank=True, verbose_name="联系人")
    phone = models.CharField(max_length=128, null=True, blank=True, verbose_name="联系手机")
    number = models.CharField(max_length=128, null=True, blank=True, verbose_name="编号")
    danger_type = models.CharField(max_length=128, null=True, blank=True, verbose_name="隐患类型")
    size = models.CharField(max_length=128, null=True, blank=True, verbose_name="尺寸")
    buried_depth = models.CharField(max_length=128, null=True, blank=True, verbose_name="埋深")
    latitude = models.CharField(max_length=128, null=True, blank=True, verbose_name="B")
    longitude = models.CharField(max_length=128, null=True, blank=True, verbose_name="L")
    n = models.CharField(max_length=128, null=True, blank=True, verbose_name="N")
    e = models.CharField(max_length=128, null=True, blank=True, verbose_name="E")
    danger_level = models.CharField(max_length=128, null=True, blank=True, verbose_name="隐患等级")
    location_description = models.CharField(max_length=512, null=True, blank=True, verbose_name="地理位置描述")
    map_location = models.CharField(max_length=512, null=True, blank=True, verbose_name="地图位置示意")
    real_location = models.CharField(max_length=512, null=True, blank=True, verbose_name="实景位置示意")
    detection_data = models.CharField(max_length=512, null=True, blank=True, verbose_name="探测数据垂直剖面图")
    retest_data = models.CharField(max_length=512, null=True, blank=True, verbose_name="复测数据垂直剖面图B")
    danger_top = models.CharField(max_length=512, null=True, blank=True, verbose_name="隐患体顶部埋深量测图")
    danger_bottom = models.CharField(max_length=512, null=True, blank=True, verbose_name="隐患体底部埋深量测图")
    drilling_hole = models.CharField(max_length=512, null=True, blank=True, verbose_name="钻孔后孔中影像")
    drilling_core = models.CharField(max_length=512, null=True, blank=True, verbose_name="钻孔芯样实拍")
    detail_json = models.TextField(null=True, blank=True, verbose_name="不涉及分析的数据存储json")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="数字化时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")
    company = models.ForeignKey('user.Company', on_delete=models.DO_NOTHING, related_name="report_file_content_set",
                                db_constraint=False, verbose_name="作业单位")
    operate_company = models.ForeignKey(EngTeamModel, on_delete=models.DO_NOTHING,
                                        related_name="report_file_content_set", db_constraint=False,
                                        verbose_name="作业工程队")
    repair_status = models.SmallIntegerField(choices=repair_status_choices, default=1, verbose_name="修复状态")
    area = models.ForeignKey('Area', on_delete=models.DO_NOTHING, related_name="report_file_content_set",
                             db_constraint=False, verbose_name="所属区域")
    cause_analysis = models.CharField(max_length=1024, null=True, blank=True, verbose_name="成因分析")
    verification_results = models.CharField(max_length=1024, null=True, blank=True, verbose_name="钻探及其他验证结果")
    spare_str1 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str2 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str3 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str4 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str5 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str6 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str7 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str8 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str9 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")
    spare_str10 = models.CharField(max_length=512, null=True, blank=True, verbose_name="备用字段")

    class Meta:
        # 指明数据库表名
        db_table = 't_report_file_content'
        verbose_name = '上报文件信息表'
        # 显示的复数名称
        verbose_name_plural = verbose_name

class Area(SpareFieldModel):
    name = models.CharField(max_length=32, verbose_name="行政区域名称")
    longitude = models.CharField(max_length=16, null=True, blank=True, verbose_name="经度")
    latitude = models.CharField(max_length=16, null=True, blank=True, verbose_name="纬度")
    p = models.ForeignKey('self', on_delete=models.DO_NOTHING, related_name="son_areas",
                          db_constraint=False, verbose_name="区域外键")

    class Meta:
        # 指明数据库表名
        db_table = 't_area'
        verbose_name = '行政区域表'
        # 显示的复数名称
        verbose_name_plural = verbose_name
