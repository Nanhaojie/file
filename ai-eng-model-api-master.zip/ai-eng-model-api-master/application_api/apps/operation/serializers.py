import logging

import requests
from django.conf import settings
from django.db import transaction
from rest_framework import serializers, status
from rest_framework.response import Response

from celery_tasks.operation.tasks import handle_operation_img
from operation.models import OperationRegisterModel, OperationFileModel, ReportLocationModel, OperationReportModel, \
    EngTeamModel, ReportFileContentModel
from utils.common import cut_file_url, split_file_url, split_intra_file_url

logger = logging.getLogger("django")


class OperationCreateSerializer(serializers.ModelSerializer):
    photo_url_list = serializers.ListField(child=serializers.CharField(max_length=1024), required=False)
    file_url_list = serializers.ListField(child=serializers.CharField(max_length=1024), required=False)

    def create(self, validated_data):
        with transaction.atomic():
            # 先创建 OperationRegisterModel 表
            eng_team = validated_data.get('eng_team')
            eng_team_id = eng_team.id
            company_id = eng_team.company_id
            photo_url_list = validated_data.get('photo_url_list')
            if photo_url_list:
                del validated_data['photo_url_list']
            file_url_list = validated_data.get('file_url_list')
            if file_url_list:
                del validated_data['file_url_list']

            validated_data['user_id'] = self.context['request'].user.id
            validated_data['company_id'] = company_id
            opetation_register_obj = super(OperationCreateSerializer, self).create(validated_data)

            # 再创建 OperationFileModel 表
            if photo_url_list:
                for photo_url in photo_url_list:
                    OperationFileModel.objects.create(type=2, url=cut_file_url(photo_url),
                                                      operation_register_id=opetation_register_obj.id,
                                                      eng_team_id=eng_team_id, company_id=company_id)
                opetation_register_obj.photo_url_list = photo_url_list
            if file_url_list:
                for file_url in file_url_list:
                    file = OperationFileModel.objects.create(type=1, url=cut_file_url(file_url),
                                                      operation_register_id=opetation_register_obj.id,
                                                      eng_team_id=eng_team_id, company_id=company_id)
                    handle_operation_img.delay(file.id, opetation_register_obj.eng_team_id,
                                         opetation_register_obj.company_id, split_intra_file_url(cut_file_url(file_url)))
                opetation_register_obj.file_url_list = file_url_list
        return opetation_register_obj

    class Meta:
        model = OperationRegisterModel
        # 要显示出来的字段
        fields = ('site_desc', 'site_coor', 'operate_start_time', 'operate_end_time', 'principal',
                  'tel', 'user', 'notes', 'create_time', 'photo_url_list', 'file_url_list', 'id', 'eng_team')
        extra_kwargs = {
            'site_desc': {'error_messages': {'max_length': '位置描述不能超过100个字符', 'required': '作业位置必填'}},
            'principal': {'error_messages': {'max_length': '负责人不能超过30个字符', 'required': '负责人信息必填'}},
            'tel': {'error_messages': {'max_length': '电话长度过长'}},
            'notes': {'error_messages': {'max_length': '备注信息不能超过1000个字符'}},
            'operate_start_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'operate_end_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }


class OperationSerializer(serializers.ModelSerializer):
    files = serializers.StringRelatedField(many=True)
    company_name = serializers.CharField(source='company.name', required=False)
    eng_team_name = serializers.CharField(source='eng_team.name', required=False)

    class Meta:
        model = OperationRegisterModel
        # 要显示出来的字段
        fields = ('site_desc', 'site_coor', 'operate_start_time', 'operate_end_time', 'principal',
                  'tel', 'user', 'notes', 'create_time', 'id', 'files', 'company_name', 'eng_team_name', 'eng_team')
        extra_kwargs = {
            'operate_start_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'operate_end_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }

    def to_representation(self, instance):
        data = super(OperationSerializer, self).to_representation(instance)
        file_list = []
        photo_list = []
        files = instance.files.all()
        if files:
            for file in files:
                if file.type == 1:
                    file_list.append(split_file_url(file.url))
                else:
                    photo_list.append(split_file_url(file.url))
        data['file_list'] = file_list
        data['photo_list'] = photo_list
        del data['files']
        return data


class ReportCreateSerializer(serializers.ModelSerializer):
    location_list = serializers.ListField(child=serializers.CharField(max_length=64), required=True)

    def create(self, validated_data):
        with transaction.atomic():
            save_id = transaction.savepoint()
            eng_team = validated_data['eng_team']
            validated_data['user_id'] = self.context['request'].user.id
            try:
                location_list = validated_data.get('location_list')
                del validated_data['location_list']
                validated_data['company_id'] = eng_team.company_id
                report_obj = super(ReportCreateSerializer, self).create(validated_data)

                for location_info in location_list:
                    location_info = location_info.split(',')
                    longitude = location_info[0]
                    latitude = location_info[1]
                    ReportLocationModel.objects.create(longitude=longitude,latitude=latitude, operation_report_id=report_obj.id)
                report_obj.location_list = location_list
            except Exception as e:
                logger.error(e, exc_info=True)
                transaction.savepoint_rollback(save_id)
                return Response(data={'detail': '数据存储失败！'}, status=status.HTTP_400_BAD_REQUEST)
        return report_obj

    class Meta:
        model = OperationReportModel
        # 要显示出来的字段
        fields = '__all__'
        extra_kwargs = {
            'principal': {'error_messages': {'max_length': '负责人不能超过30个字符', 'required': '负责人信息必填'}},
            'type': {'error_messages': {'required': '作业类型必填'}},
            'location_list': {'error_messages': {'required': '位置信息必填'}},
            'tel': {'error_messages': {'max_length': '电话长度过长'}},
            'notes': {'error_messages': {'max_length': '备注信息不能超过1000个字符'}},
            'operate_start_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'operate_end_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }


class EngTeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = EngTeamModel
        # 要显示出来的字段
        fields = ('id', 'name', 'principal', 'tel')
        extra_kwargs = {
            'operate_start_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
            'operate_end_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT},
        }


class ReportFileInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportFileContentModel
        # 要显示出来的字段
        fields = ('id', 'number', 'road_name', 'location_description', 'danger_type', 'danger_level', 'repair_status')
        extra_kwargs = {
            'number': {'read_only': True},
            'location_description': {'read_only': True},
            'danger_type': {'read_only': True},
            'danger_level': {'read_only': True}
        }

    def to_representation(self, instance):
        data = super(ReportFileInfoSerializer, self).to_representation(instance)
        road_name = data.get('road_name')
        location_description = data.get('location_description')
        danger_level = data.get('danger_level')
        if not road_name and not location_description:
            data['location_description'] = ''
        elif road_name and not location_description:
            data['location_description'] = road_name
        elif not road_name and location_description:
            data['location_description'] = location_description
        else:
            data['location_description'] = road_name + '：' + location_description
        if not danger_level:
            data['danger_level'] = ''
        return data



class OperationReportListSerializer(serializers.ModelSerializer):
    eng_team_name = serializers.CharField(source="operation_report.eng_team.name")
    company_name = serializers.CharField(source="operation_report.company.name")
    principal = serializers.CharField(source="operation_report.principal")
    tel = serializers.CharField(source="operation_report.tel")
    danger_type = serializers.CharField(source="operation_report.type")
    operate_start_time = serializers.DateTimeField(source="operation_report.operate_start_time",
                                                   format=settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)
    operate_end_time = serializers.DateTimeField(source="operation_report.operate_end_time",
                                                 format=settings.SERIALIZER_DATE_TIME_FIELD_FORMAT)

    class Meta:
        model = ReportLocationModel
        fields = ('id', 'longitude', 'latitude', 'create_time', 'eng_team_name', 'company_name', 'principal', 'tel',
                  'danger_type', 'operate_start_time', 'operate_end_time', 'operation_report_id')
        extra_kwargs = {
            'create_time': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }


class DisasterLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportFileContentModel
        # 要显示出来的字段
        fields = ('id', 'longitude', 'latitude', 'danger_level', 'reporting_unit', 'contacts', 'phone', 'danger_type', 'location_description', 'repair_status', 'real_location')

    def level(self):
        return {
            'I': 1,
            'II': 2,
            'III': 3,
            'IV': 4,
            'V': 5,
            'VI': 6,
            'VII': 7,
            'VIII': 8,
        }

    def to_representation(self, instance):
        data = super(DisasterLocationSerializer, self).to_representation(instance)
        real_location = data.get('real_location')
        danger_level = data.get('danger_level')
        danger_type = data.get('danger_type')
        if real_location:
            data['real_location'] = split_file_url(real_location)
        if danger_level:
            data['danger_level'] = self.level().get(danger_level)
        else:
            data['danger_level'] = ''
        if not danger_type:
            data['danger_type'] = ''
        return data


class DisasterDayAddSerializer(serializers.ModelSerializer):
    count = serializers.IntegerField()
    day = serializers.DateTimeField()

    class Meta:
        model = ReportFileContentModel
        # 要显示出来的字段
        fields = ('count', 'day')
        extra_kwargs = {
            'day': {'format': settings.SERIALIZER_DATE_TIME_FIELD_FORMAT}
        }