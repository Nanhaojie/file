# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/21
# @author yueyb
# test

from django.urls import path
from operation.views import OperationRegister, OperationReport, EngTeam, ReportFileInfo, DangerLevel, CompanyRepairing, \
    DisasterDayAdd, DisasterDayRepair, DisasterLocation, DangerTypeStatusInfo, TotalRegionalInfo, CheckedSection

urlpatterns = [
    path('register', OperationRegister.as_view({'get': 'list','post': 'create'})),
    path('report', OperationReport.as_view({'post': 'create', 'get': 'list'})),
    path('oper_company', EngTeam.as_view({'get': 'list','post': 'create'})),
    path('report_info', ReportFileInfo.as_view({'get': 'list'})),
    path('report_info/<int:pk>', ReportFileInfo.as_view({'put': 'update'})),


    # 大屏展示
    path('total_regional', TotalRegionalInfo.as_view()),
    path('danger_type_status', DangerTypeStatusInfo.as_view()),
    path('danger_level', DangerLevel.as_view()),                    # 风险等级
    path('com_repairing', CompanyRepairing.as_view()),              # 各单位修复中个数统计
    path('disaster_day_add', DisasterDayAdd.as_view()),             # 灾害新增数量日统计
    path('disaster_day_repair', DisasterDayRepair.as_view()),       # 灾害修复数量日统计
    path('disaster_location', DisasterLocation.as_view()),          # 灾害位置地图展示
    path('checked_section', CheckedSection.as_view()),              # 检测路段位置展示
]
