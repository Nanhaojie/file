# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 2021/4/26
# @author fj
import logging

import requests

from application_api.settings import FILE_SERVER_URL
from celery_tasks.main import celery_app
from pdf_ocr.models import FileModel
from pdf_ocr.services.service import table_service
from pdf_ocr.tools.main import ocr
from pdf_ocr.tools.app_main import table_ocr_merge

from utils.common import cut_file_url

logger = logging.getLogger("django")


@celery_app.task(name='web_file_ocr')
def web_file_ocr(pk):
    logger.info(f"开始id:{pk}文件的web端ocr任务")
    file = FileModel.objects.filter(id=pk).only('id', 'url', 'type').first()
    if file:
        try:
            file.ocr_status = 1
            file.save()
            ocr(requests.get(FILE_SERVER_URL+file.url).content, pk, file.type)
        except Exception:
            logger.error(f"id:{pk}文件web端ocr任务失败", exc_info=True)
            FileModel.objects.filter(id=pk).update(ocr_status=7, err_code=0)
        else:
            logger.info(f"id:{pk}文件web端ocr任务成功")
            FileModel.objects.filter(id=pk).update(ocr_status=11)
    else:
        logger.warning(f"未找到id:{pk}且可以ocr的文件")


@celery_app.task(name='ios_file_ocr')
def ios_file_ocr(pk):
    logger.info(f"开始id:{pk}文件的ios端ocr任务")
    file = FileModel.objects.filter(id=pk).only('id', 'url', 'type').first()
    if file:
        try:
            file.ocr_status = 2
            file.save()
            ocr(requests.get(FILE_SERVER_URL+file.url).content, pk, file.type)
        except Exception:
            logger.error(f"id:{pk}文件ios端ocr任务失败", exc_info=True)
            FileModel.objects.filter(id=pk).update(ocr_status=7, err_code=0)
        else:
            logger.info(f"id:{pk}文件ios端ocr任务成功！")
            FileModel.objects.filter(id=pk).update(ocr_status=11)
    else:
        logger.warning(f"未找到id:{pk}且可以ocr的文件")


@celery_app.task(name='android_file_table')
def android_file_table(pk, url_list):
    table_ret_list = []
    logger.info(f"开始id:{pk}文件的安卓端table任务")
    for url in url_list:
        try:
            table_ret = table_service(requests.get(url, timeout=10).content)
        except Exception:
            logger.error(f"id:{pk}的文件移动端table任务失败", exc_info=True)
            FileModel.objects.filter(id=pk).update(ocr_status=7, err_code=0)
        else:
            logger.info(f"id:{pk}的文件移动端table任务成功", exc_info=True)
            table_ret_list.append(table_ret)
    return table_ret_list


@celery_app.task(name='ocr_table_merge')
def ocr_table_merge(pk, ocr_result, table_result, jz_imgs):
    logger.info(f"开始id:{pk}的文件安卓端table_ocr融合任务")
    try:
        table_ocr_merge(pk, ocr_result, table_result, jz_imgs)
    except Exception:
        logger.error(f"id:{pk}的文件移动端table_ocr融合任务失败", exc_info=True)
        FileModel.objects.filter(id=pk).update(ocr_status=7, err_code=0)
    else:
        FileModel.objects.filter(id=pk).update(ocr_status=11, err_code=0)
        logger.info(f"id:{pk}的文件安卓端table_ocr融合任务成功")


# @celery_app.task(name='perform_create_')
# def perform_create_(data, user_id, file_owner_id):
#     data['user_id'] = user_id
#     data['file_owner_id'] = file_owner_id
#     data['p_file_id'] = data.get('p_file','')
#     url = data.get('url', '')
#     if url:
#         print()
#         url = cut_file_url(url)
#         data['url'] = url
#     try:
#         del data['p_file']
#     except:
#         pass
#     file = FileModel(**data)
#     file.save()