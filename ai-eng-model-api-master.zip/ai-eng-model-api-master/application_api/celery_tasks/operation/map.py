#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ddy_web_api 
@File ：map.py
@Author ：nhj
@Date ：2021/7/31 下午1:58 
'''
import logging
import requests
logger = logging.getLogger("django")


def get_district(lat, log):
    logger.info(f"经纬度信息:{lat, log}")
    try:
        # 百度
        # location = requests.get('https://api.map.baidu.com/reverse_geocoding/v3/?ak=gKQ3foHPbc1YHly7Z56VUFMgSFxkh9v6'
        #                         '&output=json&coordtype=wgs84ll&location=%s,%s' % (lat, log))
        # 高德
        location = requests.get('https://restapi.amap.com/v3/geocode/regeo?output=json&location=%s,%s&key=bcefbf51c21f9d80fe491d4bb8d2572d'%(log,lat))
        # logger.info(f"经纬度结果信息:{location, location.text}")
        # 高德解析
        district = eval(location.text)['regeocode']['addressComponent']['district']
        # 百度解析
        # district = eval(location.text)['result']['addressComponent']['district']
    except:
        district = '郑州市'
        logger.info(f"经纬度信息获取失败，默认郑州市")
    return district

if __name__=='__main__':
    print(get_district('34.812568','113.543043'))