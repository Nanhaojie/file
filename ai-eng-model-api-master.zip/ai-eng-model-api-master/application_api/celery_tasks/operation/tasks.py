# !usr/bin/env python
# -*- coding:utf-8 -*-
# create in 
# @author fj
import json
import io
import logging
from application_api import settings
from celery_tasks.main import celery_app
import pdfplumber
import fitz
import requests
from urllib.parse import urlparse
import time
from kafka import KafkaProducer

from celery_tasks.operation.map import get_district
from operation.models import ReportFileContentModel, Area

with open('celery_tasks/operation/disease.json') as t:
    tj = json.load(t)
logger = logging.getLogger("django")


def zj_upload_sync(file, path):
    url = settings.FILE_SERVER_URL + settings.FILE_SERVER_UPLOAD_PATH
    files = {'file': file}
    options = {'output': 'json', 'path': path, 'scene': '', 'filename': str(time.time())+'.png'}  # 参阅浏览器上传的选项
    r = requests.post(url, data=options, files=files)
    return urlparse(r.json()['url']).path


def read_img(src, text_type):
    pdf_file = fitz.open(stream=src, filetype='bytes')
    img_pages = []
    for page_index in range(len(pdf_file)):
        page = pdf_file[page_index]
        img_data = dict()
        img_data['page'] = page_index
        page_imgs = []
        for image_index, img in enumerate(page.getImageList(), start=1):
            xref = img[0]
            base_image = pdf_file.extractImage(xref)
            image_bytes = base_image["image"]
            img_url = zj_upload_sync(image_bytes, 'disease_img')
            page_imgs.append(img_url)
            # image.save(str(page_index) + str(image_index) + '.png')
        if text_type:
            img_data['imgs'] = page_imgs[1:]
            img_pages.append(img_data)
        else:
            img_data['imgs'] = page_imgs
            img_pages.append(img_data)
    return img_pages


# def get_district(lat, log):
#     logger.info(f"经纬度信息:{lat, log}")
#     location = requests.get('https://api.map.baidu.com/reverse_geocoding/v3/?ak=gKQ3foHPbc1YHly7Z56VUFMgSFxkh9v6'
#                             '&output=json&coordtype=wgs84ll&location=%s,%s' % (lat, log))
#     logger.info(f"经纬度结果信息:{location, location.text}")
#     district = eval(location.text)['result']['addressComponent']['district']
#     return district


@celery_app.task(name='handle_operation_img')
def handle_operation_img(file_id, eng_team_id, company_id, img_url):
    # 对记录文件进行查询
    # 提取文件信息
    # kafka
    logger.info(f"开始id:{file_id}pdf文件的解析任务")
    try:
        src = requests.get(img_url).content
        f = io.BytesIO(src)
        pdf = pdfplumber.load(f)  # .load(f)方法可以读取BytesIO二进制流的数据

        pages = pdf.pages

        # 根据每一页文本的长度判断两页是一部分还是一页是一部分
        text_all_length = True
        for p in range(len(pages)):
            text = pages[p].extract_text()
            if len(text) < 150:
                text_all_length = False
                break

        imgs = read_img(src, text_all_length)
        if text_all_length:
            # 一页就是一部分
            disease_datas = []
            for p in range(len(pages)):
                disease_data = {}
                # 第一页摘要信息
                lat = ''
                log = ''
                if p == 0:
                    abstract = pages[p].extract_text()
                    if imgs[p]['imgs']:
                        disease_data['abstract'] = [abstract, imgs[p]['imgs']]
                    else:
                        disease_data['abstract'] = [abstract]
                    continue
                # 解析文本，公司及联系人的信息
                title = [i for i in pages[p].extract_text().split('\n') if i != " "][1]
                title = title.split('：')
                for tkv in range(0, len(title), 2):
                    t = [k for k, v in tj["data"].items() if title[tkv] in v]
                    if t:
                        disease_data[t[0]] = title[tkv + 1]
                # 解析表格
                for table in pages[p].extract_tables():
                    num = 0
                    for t in table:
                        # 去掉None,中心坐标
                        data = list(filter(None, t))
                        data = [''.join(i.split('\n')) for i in data]
                        stop_word = ['中心坐标', '中心 坐标']
                        for s in stop_word:
                            if s in data:
                                data.remove(s)
                        # 原始的key替换统一的英文单词，封装kv
                        have_img = [x for x in tj['img_list'] if x in data]
                        if not have_img:
                            for kv in range(0, len(data), 2):
                                t = [k for k, v in tj["data"].items() if data[kv] in v]
                                if t:
                                    disease_data[t[0]] = data[kv + 1]
                                    if t[0] == 'latitude':
                                        lat = data[kv + 1]
                                    elif t[0] == 'longitude':
                                        log = data[kv + 1]
                        else:
                            for kv in range(0, len(data)):
                                t = [k for k, v in tj["img"].items() if data[kv] in v]
                                if t and num < 3:
                                    disease_data[t[0]] = imgs[p]['imgs'][num]
                                    num += 1
                                elif t:
                                    disease_data[t[0]] = [im for im in imgs[p]['imgs'][num:]]
                # 根据区域从区域表查到id
                district = get_district(lat, log)
                area = Area.objects.filter(name=district).first().id
                disease_data['report_file_info_id'] = file_id
                disease_data['area_id'] = area
                disease_data['company_id'] = company_id
                disease_data['operate_company_id'] = eng_team_id
                ReportFileContentModel.objects.create(**disease_data)

                # 存储到数据库
        else:
            for p in range(0, len(pages), 2):
                num = 0
                disease_data = {}
                lat = ''
                log = ''
                title = pages[p].extract_text().split('\n')[1]
                title = [text for text in title.split(' ') if text]
                # 解析文本，公司联系人的信息
                for tkv in range(0, len(title), 2):
                    t_info = [k for k, v in tj["data"].items() if title[tkv] in v]
                    if t_info:
                        disease_data[t_info[0]] = title[tkv + 1]
                # 解析表格
                for table in pages[p].extract_tables():
                    for t in table:
                        # 去掉None,中心坐标
                        data = list(filter(None, t))
                        data = [''.join(i.split('\n')) for i in data]
                        if '中心坐标' in data:
                            data.remove('中心坐标')
                        # 原始的key替换统一的英文单词，封装kv
                        have_img = [x for x in tj['img_list'] if x in data]
                        if not have_img:
                            for kv in range(0, len(data), 2):
                                t = [k for k, v in tj["data"].items() if data[kv] in v]
                                if t:
                                    disease_data[t[0]] = data[kv + 1]
                                    if t[0] == 'latitude':
                                        lat = data[kv + 1]
                                    elif t[0] == 'longitude':
                                        log = data[kv + 1]
                        else:
                            for kv in range(0, len(data)):
                                t = [k for k, v in tj["img"].items() if data[kv] in v]
                                if t:
                                    disease_data[t[0]] = imgs[p]['imgs'][num]
                                    num += 1
                # 存入数据库
                # 根据区域从区域表查到id
                district = get_district(lat, log)
                area = Area.objects.filter(name=district).first().id
                disease_data['report_file_info_id'] = file_id
                disease_data['area_id'] = area
                disease_data['company_id'] = company_id
                disease_data['operate_company_id'] = eng_team_id
                ReportFileContentModel.objects.create(**disease_data)

        # kafka
        # add_port = ['172.16.1.12:9092', '172.16.1.15:9092', '172.16.1.16:9092']
        # producer = KafkaProducer(bootstrap_servers=add_port)
        # topic = 'ddy_road_info'
        # try:
        #     future = producer.send(topic, key=b'ddy_road', value=json.dumps(disease_datas).encode('utf-8'))
        #     result = future.get(timeout=100)
        #     print('成功传到kafka')
        #     logger.info(f"{operation_id}成功传到kafka")
        # except Exception as e:
        #     print(str(e))
        # producer.close()
    except Exception:
        logger.error(f"id:{file_id}pdf文件解析任务失败", exc_info=True)
    else:
        logger.info(f"id:{file_id}pdf文件解析任务成功")


if __name__ == '__main__':
    handle_operation_img(123)
