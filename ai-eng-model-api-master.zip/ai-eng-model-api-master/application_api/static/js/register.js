var vm = new Vue({
    el: '#app',
    data: {
        host: host,

        // 联系人称呼
        error_contacts: false,
        error_contacts_code: '',
        contacts: '',

        // 公司全程
        error_name: false,
        error_name_code: '',
        name: '',

        error_email: false,
        error_email_code: '',
        email: '',

        error_phone: false,
        error_phone_code: '',
        phone: '',

        error_username: false,
        error_username_code: '',
        username: '',

        error_password: false,
        error_password_code: '',
        password: '',

        error_notes: false,
        error_notes_code: '',
        notes: '',

        error_img_code: false,
        error_img_code_code: '',
        img_code: '',

        // 图形验证码:
        uuid: '',
        image_code_url: '',

    },
    mounted: function () {
        // 向服务器获取图片验证码
        this.generate_image_code();
    },
    methods: {
        // 生成一个图片验证码的编号，并设置页面中图片验证码img标签的src属性
        generate_image_code: function () {
            // 生成一个编号 : 严格一点的使用uuid保证编号唯一， 不是很严谨的情况下，也可以使用时间戳
            this.uuid = generateUUID();
            // 设置页面中图片验证码img标签的src属性
            this.image_code_url = this.host + "/api/verify/image_codes/" + this.uuid;
        },
        check_contacts: function () {
            if (!this.contacts) {
                this.error_contacts = true;
            } else {
                this.error_contacts = false;
            }
        },
        check_name: function () {
            if (!this.name) {
                this.error_name = true;
            } else {
                this.error_name = false;
            }
        },
        check_email: function () {
            if (!this.name) {
                this.error_email = true;
            } else {
                this.error_email = false;
            }
        },
        // 检查用户名
        check_username: function () {
            var re = /^[a-zA-Z0-9]{1,20}$/;
            // var re2 = /^[0-9]+$/;
            // if (re.test(this.username) && !re2.test(this.username)) {
            if (re.test(this.username)) {
                this.error_username = false;
            } else {
                this.error_username = true;
            }
        },
        check_password: function () {
            var re = /^[a-zA-Z0-9]{6,18}$/;
            var re2 = /^[0-9]+$/;
            if (re.test(this.password) && !re2.test(this.password)) {
                this.error_password = false;
            } else {
                this.error_password = true;
            }
        },
        // 检查手机号
        check_phone: function () {
            var re = /^1[345789]\d{9}$/;

            if (re.test(this.mobile)) {
                this.error_phone = false;
            } else {
                this.error_phone = true;
            }
        },
        // 检查图片验证码
        check_img_code: function () {
            if (!this.image_code) {
                this.error_img_code = true;
            } else {
                this.error_img_code = false;
            }
        },
        // 注册
        on_submit: function () {
            // this.check_username();
            // this.check_pwd();
            // this.check_cpwd();
            // this.check_phone();
            // this.check_sms_code();
            // this.check_allow();

            // 点击注册按钮之后, 发送请求 (下面的代码是通过请求体传参的)
            if (1) {
                axios.post(this.host + '/api/user/company', {
                    contacts:this.contacts,
                    name:this.name,
                    email:this.email,
                    phone:this.phone,
                    username:this.username,
                    password:this.password,
                    notes:this.notes,
                    uuid:this.uuid,
                    img_code:this.img_code,
                }, {
                    responseType: 'json',
                    withCredentials: true,
                })
                    .then(response => {
                        if (response.data.code == 200) {
                            alert(response.data.msg)
                        }
                        if (response.data.code == 400) {
                            alert(response.data.msg)
                        }
                        else{
                            alert(response.data.msg)
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    })
            }
        }
    }
});