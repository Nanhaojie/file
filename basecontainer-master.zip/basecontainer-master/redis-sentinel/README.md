```bash
mkdir -p /etc/redis/redis-cluster
#  将3个redis服务和3个sentinel服务配置文件放在该目录；redis-node0.conf  redis-node1.conf  redis-node2.conf  sentinel-node0.conf  sentinel-node1.conf  sentinel-node2.conf

mkdir -p /usr/local/docker/redis
# 将docker-compose.yml文件放到该路径

# sentinel-node 配置文件中的ip需要修改为本地电脑的ip

# 创建docker 网络 mybridge
docker network create mybridge

# 编排容器
docker-compose up -d

# 查询运行状态
docker ps | grep redis
```
