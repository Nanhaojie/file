   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Think of an Experiment as a space that contains the history of all pipelines and their associated runs#"可以将实验看成一个空间管道和其相关都在这里运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose a pipeline package file from your computer, and give the pipeline a unique name.#"在本地选择一个管道文件，给管道提供唯一的名字。#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"This run will be associated with the following experiment#"这个运行跟随的实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Parameters will appear after you select a pipeline#"参数将在选择管道后出现#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose a method by which new runs will be triggered#"选择一个触发方法#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"You can also drag and drop the file here.#"你也可以拖拽文件到这里。#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Specify parameters required by the pipeline#"指定管道所需参数#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"URL must be publicly accessible.#"URL必须可以访问#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Upload and name your pipeline#"上传并且命名管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Experiment name is required#"需要指定实验名称#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"A pipeline must be selected#"指定管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start a recurring run#"开始一个反复运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Maximum concurrent runs#"最大并发数量#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run name is required#"需要运行名称#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose an experiment#"选择一个实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Use this experiment#"使用这个实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Use this pipeline#"使用这个管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start a new run#"开始一个新的运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose a pipeline#"选择一个管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Filter experiments#"过滤实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Experiment details#"实验详情#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Create experiment#"创建实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Import by URL#"通过URL导入#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Filter pipelines#"过滤管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Upload pipeline#"上传管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Upload a file#"上传一个文件#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Experiment name#"实验名称#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"All experiments#"所有实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run parameters#"运行参数#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"New experiment#"新的实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Pipeline name#"管道名称#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Last 5 runs#"最后5个运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Trigger type#"触发类型#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Rows per page#"前几行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Has start date#"开始#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Compare runs#"对比运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Uploaded on#"上传日期#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start time#"开始时间#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start date#"开始日期#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run trigger#"运行类型#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run details#"运行详情#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Filter runs#"过滤运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose file#"选择文件#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start time#"开始时间#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Has end date#"结束#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Create run#"创建运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Created at#"创建时间#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run every#"运行间隔#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Experiments#"实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"End time#"结束时间#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"End date#"结束日期#g' &&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Description#"描述#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Clone run#"克隆运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run Type#"运行类型#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Run name#"运行名称#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Recurring#"反复性#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Pipelines#"管道集#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Experiment#"实验#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Duration#"持续时间#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"All runs#"所有运行#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Pipeline#"管道#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"One-off#"一次性#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Restore#"恢复#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Refresh#"刷新#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Delete#"删除#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Choose#"选择#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Cancel#"取消#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Next#"下一步#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"File#"文件#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Archive#"存档#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Upload#"上传#g'&&
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Status#"状态#g'
   find ./ -name 'main.37b4e39a.js' | xargs sed  -i 's#"Start#"开始#g'
