   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Name#"名称#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Version#"版本#g'
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Artifacts#"工件#g'
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Filter#"过滤#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Refresh#"刷新#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Details#"详情#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Type#"类型#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Workspace#"类型#g'&&
   find ./ -name 'main.73dad239.chunk.js' | xargs sed  -i 's#"Created at#"创建日期#g'
