
# CMD
```
conda env list
source activate snowflakes
```
