# Dashboard
k8s-web部署指南
# 操作步骤
1. 在k8s中创建可视化任务，后面的命令验证是否安装成功
```
kubeclt apply -f dashboard.yaml 
kubectl -n kubernetes-dashboard get pods
kubectl -n kubernetes-dashboard get svc
```
2. 创建NodePort访问方式,命令内两个方法都可以，任选其一
```
kubeclt apply -f recommended.yaml 
kubectl  patch svc kubernetes-dashboard -n kubernetes-dashboard \
-p '{"spec":{"type":"NodePort","ports":[{"port":443,"targetPort":8443,"nodePort":30443}]}}'
```
3. 生成token
```
kubeclt apply -f dashboard_token.yml
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')

登录token
eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLWhuNHFxIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI4NjQxZGM1My03OWU0LTQ1MzAtYjIzYS1kNGNmNTE1NjQwMjAiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZXJuZXRlcy1kYXNoYm9hcmQ6YWRtaW4tdXNlciJ9.coe1FBl-QWZC-lsXU-8QcsrOF5zUdXMoR_LnBKq4v6vpkTb_BeK0fXweBiNT2EPURuTvGuVTPbnql8UZqdqWjufk3Pmwlt21LBwI1hvMc0BkZrnjfpqTLkfe4W_FG3_6U_z0N8u_EWVvteb4sqYju8ltZvr5g9iG69YyYgAYvlkaGqsYTGrNqGqRjvmkdHARIfR0ijCWrUSJY3CZ7qO554oid0S0Br-U-74VJVbp2PtnR6TTWmAD-hhJ0Ny8Qc4USmBF9esqyboyX9CkZ9yafjQqHy5Jrn0_smNyQVsnZNlpthXqPzZdrsJvNG92bQh4da1ofkIUhO7nwQ74XriAkw
```
5. 访问
```
# https://172.16.0.21:30443

https://172.16.1.10:30443/#/overview?namespace=default
选择token输入3步骤生成的token
6. cert证书
> 更新证书时间 `kubeadm alpha certs renew all`
> 查询证书时间 `kubeadm alpha certs check-expiration`

```
# 主页
https://172.16.0.21:30443/#/overview?namespace=ai-dev
# 后记
1. 参考链接
https://blog.csdn.net/networken/article/details/85607593
2. 更改token时长以及创建集群外浏览器访问
