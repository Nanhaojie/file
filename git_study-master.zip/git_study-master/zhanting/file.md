<center><font color=blue size=67><strong>交接主文档</strong></font></center>
<center><strong>含所有项目信息</strong></center>

<p align=right><font color=red size=3>交接人---马贝贝</font></p>

### 总述

- 下文中所有提及到的数据库指的是mysql数据库（紧急情况下可切换到10.11.0.205服务器上的数据库，目前所有库表已同步）：

  ​	IP: 172.16.0.11

  ​	PORT: 3306

  ​	USERNAME: root

  ​	PASSWD: root12300.

- 下文中所说的thrift默认为18服务器上的thrift
- 项目涉及的所有redis,密码统一为：9803216
- 本人电脑密码: 普通用户：mabeibei   密码：9803216    root用户：root   密码：9803216
- 本人在中业科技所有的自设密码基本都是9803216，如有忘记交接到的地方涉及到，可自行验证
- 以下所有内容需在了解需求和代码结构的情况下，效果更佳！
- 文档所有内容如有不清楚的地方，文档第一接收人可联系18537312072（微信）

注：文档所有的超链接使用方法----按住ctrl + 鼠标点击 可实现页内/外跳转（建议查看文档工具：typora，[window下载链接](https://www.typora.io/#windows),  ubuntu可直接在商店下载）



### 一.展厅人机交互项目

+++

- 概述

`主要介绍展厅相关服务的部署存放位置,以及各个服务的调用关系(启动命令以及可能出现的相关问题和处理方法详见对应的附属文档)`

`项目采用flask框架进行开发,thrift和tf_serving提供GRPC服务,redis作为缓存介质,celery提供异步/定时任务,socketio提供websocket服务,nginx处理静态资源并转发请求,图片采集硬件包含网络摄像头,手机以及华为hilens盒子`

*`目前展厅项目整体来看暂无打的逻辑上的bug存在;存在的问题:1.讯飞语音识别精度不够  2.话筒收音那套设备收音效果不好,尤其是话筒电量不多时,经常出现说两三次才能收到音频的情况  3.项目中部分模型识别效果受使用场景的影响(背景人的多少、光线等) 4.性别检测偶尔会出错  5.行人检测人数过多时,相互遮挡会出现个别识别不出(可以解释的通)  6.手势翻页目前按要求指标做很准,连续动作过快或位置不对任然会存在问题   7.语义理解目前采用先数据库匹配,后bert的方案,对于个别语句出现的错误匹配已经在工程化中处理;但bert仍需要抽时间再次优化实现方案，以应对复杂的文本输入`





- 包含功能:
  1. ​	[手势唤醒](#1)*
  2. ​    [闲聊](#2)*
  3. ​    [技能介绍](#3)
  4. ​    [行人检测](#4)*
  5. ​    [天气查询](#5)*
  6. ​    [OCR文字识别翻译/手势(左右)翻页/语音控制翻页](#6)*
  7. ​    [中业介绍/手势暂停、恢复、停止](#7)*
  8. ​    [猜拳游戏](#8)*
  9. ​    [表情大作战](#9)*
  10. ​    [手势(剪刀)拍照](#10)
  11. ​    [查看灯光/监控](#11)
  12. ​    [播放音乐/手势控制暂停、恢复、停止](#12)
  13. ​    [图谱查询电影相关内容展示](#12)
  14. ​    [静态/动态肢体识别](#14)
  15. ​    [发送邮件](#15)
  16. ​    [人脸识别控制门禁](#16)
  17. ​    [性别检测](#17)



- <span id='1'>手势唤醒</span>

~~~python
采用tf_serving调用模型; 模型相关配置:request.model_spec.name = 'ssdCT',request.model_spec.signature_name = 'predict', request.model_spec.version.value = 102;调用以及返回方式均为socket(my event)
此功能受华为hilens盒子影响,不应有别的程序占用hilens摄像头;另外需定时清除hilens日志,防止因内存超限导致性能问题(具体处理方法见附属文档)
~~~



- <span id='2'>闲聊</span>

~~~python
闲聊采用图灵机器人,调用的为java封装的服务:http://chatapi.trycan.com/service/robotApi/chartWithRobot.do
当闲聊出错时,大概率情况为图灵机器人接口调用异常,联系恒星进行java服务重启即可解决
验证相关代码(根据返回状态码可判断图灵机器人服务是否运行正常)/也可查看展厅主服务日志信息进行判断:
    params = {
            'apiKey': '9aea9aca09754c5bbf1361846452dc38',
            'question': '你好'
        }

res = requests.get('http://chatapi.trycan.com/service/robotApi/chartWithRobot.do', params=params)
print(res.text, res.status_code)
~~~



- <span id='3'>技能介绍</span>

~~~python
技能介绍新增加功能:对各个技能的详细信息的询问,例如:'什么是人脸识别'
此功能暂未出现bug,维护好mysql数据库信息即可(介绍信息位于ai_skill_info表中)
~~~



- <span id='4'>行人检测</span>

~~~python
此功能是通过thrift服务调用yolo_tiny.h5模型,采用推流服务器取帧检测人数
已优化响应速度(重启thrift后第一次调用模型相对较慢)
存在问题,由于采用推拉流方案,大屏展示的画面会存在3s左右的延迟
等人都站稳后调用此功能(身体被大部分遮挡会大概率检测不到)
暂未出现bug
~~~



- <span id='5'>天气查询</span>

~~~python
响应速度已优化,目前满足系统要求(后台定时任务每隔30分钟查询一次,并存入/更新redis)
调用第三方api,响应速度会受到此影响(不至于影响到展厅性能)
非地级市一般不能查询到结果,此时会走闲聊
需保证celery处于运行状态,保证定时任务的执行
目前暂未发现bug
~~~



- <span id='6'>OCR文字识别翻译/手势(左右)翻页/语音控制翻页</span>

~~~python
OCR翻译出现问题(即无翻译内容返回),基本上是由于百度API所需的token参数过期(过期时间官方说法为一个月);目前已采用定时任务每周定时更新,基本不会有啥问题.如果出现上述情况,手动更新一次即可,更新token相关代码如下:
url = 'https://aip.baidubce.com/oauth/2.0/token'
app_key = 'RdGceDtgqHAxdcy9BHOnNWsW'
secret_key = 'eGCc4CcZMgO45BlAZwp7o1RzVLjYSRqe'
grant_type = 'client_credentials'
data = {
    'grant_type': grant_type,
    'client_id': app_key,
    'client_secret': secret_key
}
res = requests.post(url=url, data=data)
token = res.json().get('access_token')
print(token)
获得token后更新数据库zt_keybook表中ACCESS_TOKEN和OCR_URL_BAIDU两个字段值即可
对于手势翻页目前只要按照标准做动作,没问题(由于采用hilens取帧,需保证hilens可用)
翻页功能采用thrift调用相关pb模型,需保证thrift服务可用
暂无其它bug
~~~



- <span id='7'>中业介绍/手势暂停、恢复、停止</span>

~~~python
 手势暂停、恢复、停止采用tf_serving远程调用模型,相对应的模型调用配置信息:request.model_spec.name = 'ssdCT';request.model_spec.signature_name = 'predict'; request.model_spec.version.value = 102
 模型采用hilens取帧,需保证hilens正常运行,不会发生摄像头资源抢占(建议定时清除hilens日志信息,防止由于内存问题导致hilens性能下降或出错)
此功能暂无逻辑上的bug;如果出现手势全无响应(三个手势都不行),首先登录华云hilens管理平台,确保hand技能处于运行状态.如果技能自动关闭了,登录172.16.0.19 /home/login/alog/hilens/hda下查看对应日志信息,根据日志信息处理即可(大概率是日志把内存占完了,删除后重新启动即可);如果技能处于正常运行状态,大概率是发生资源抢占(即测试机也在连hilens摄像头,关闭测试机的展厅程序即可).
~~~



- <span id='8'>猜拳游戏</span>

~~~python
猜拳游戏采用tf_serving远程GRPC调用对应模型,模型调用相关的配置信息:request.model_spec.name = 'test',request.model_spec.signature_name = 'predict',request.model_spec.version.value = 118
猜拳游戏唯一可能存在的问题是:某些场景下会出现识别不出手势的情况(三期优化后出现概率很低)
~~~



- <span id='9'>表情大作战</span>

~~~python
表情大作战,模型嵌入到移动端(出现问题找移动端解决即可)
暂无逻辑bug;识别准确率和误检情况需依赖模型自身的优化
~~~



- <span id='10'>手势(剪刀)拍照</span>

~~~python
手势拍照采用tf_serving远程调用模型,对应模型的调用配置信息(优化后和猜拳游戏用的同一模型):request.model_spec.name = 'test',request.model_spec.signature_name = 'predict',request.model_spec.version.value = 118
手势拍照采用http请求;为了实现扫码共享,每次拍取照片后都需要重新编辑对应html文件,编辑后上传青牛云
此功能目前暂无逻辑上的bug;可能会出现识别较慢的情况(受网速或模型识别快慢的影响)
~~~



- <span id='11'>查看灯光/监控</span>

~~~python
目前查看监控无问题;只要保证网络通畅即可
查看灯光:目前判断开/关灯依赖两个信息,一个是图片的亮度,一个是图片的色彩度,目前两个值已经调整到较优的状态,亮度的临界值为1.4,色彩度的临界值为20;如果后期换场景出现开关灯识别错误的情况,根据实际情况调整这两个值的参数(大概率可解决)即可
灯光目前采用celery定时任务,每晚22:30拍取图片进行判断,并记录入库,对应的代码在celery_task文件夹下,需保证定时任务服务处于正常状态
此功能目前暂无逻辑上的bug
~~~



- <span id='12'>播放音乐/手势控制暂停、恢复、停止</span>

~~~python
手势功能同唤醒/和中业介绍中的一致
播放的音乐依赖于neo4j中是否有存储
播放音乐的资源:一个爬虫的服务,图谱中查询到歌曲名后,会自动去网易云抓取该歌曲的播放链接;所以需要保证爬虫服务的正常运行
网易云爬虫服务:位于项目目录中的Netease文件夹
此功能暂无bug;需要注意的是(不一定会发生):如果爬虫被禁或网易云页面调整或前后端数据交互发生改变会造成该服务的执行出错,需要根据网站最新规则重新修改代码或者寻找其他的替代方案(最优的是本地抓取歌曲播放资源存放公司本地服务器)
~~~



- <span id='13'>图谱查询电影相关内容展示</span>

~~~python
此功能暂无逻辑上的bug,能否查询到依赖于neo4j是否有对应信息
~~~



- <span id='14'>静态/动态肢体识别</span>

~~~python
静态肢体识别目前调用的pb模型,涉及8个动作,由后端随机(并且保证相邻不重复)生成动作码,存入redis用于判断和取出重复码
静态肢体在正确的场景下识别效果较好
静态肢体目前采用http,每次安卓传输5张图片
静态肢体标志码:'000'
动态肢体需要openpose环境,采用thrift调用相关的模型文件,图片传输和结果的反馈都依赖与redis队列,需保证redis服务可用(此thrift部署在15服务器)
动态肢体标志码:'001'
暂无大的逻辑错误出现(目前,由于动态肢体只有三个动作,所以动作码没有采用随机生成的方式,而是依次'1,2,3'按顺序依次执行);
~~~



- <span id='15'>发送邮件</span>

~~~python
发送邮件目前可能存在的问题,姓名提取可能会出现问题(当名字很稀奇古怪),三期优化后应该出现几率不大,具体的提取程序在项目目录下mydrawkey文件夹下
支持单人/多人邮件发送
此功能暂无逻辑上的bug
~~~



- <span id='16'>人脸识别控制门禁</span>

~~~python
门禁采用thrift调用模型
目前存在的问题:第一次启动门禁功能时,启动时间较长(大概30s左右模型程序才能正常运行起来,开始检测人脸.)
暂时未发现逻辑上的错误,当无效果或检测延时明显过高时,要么查看拉流地址是否正常,要么重启thrift服务(应该不会出现这种情况,除非thrift服务由于外部原因停止了,重启即可)
门禁除了人脸识别外,还加了层逻辑上的判断,数据库中可以禁用或放开某个人的门禁权限,库表名称ai_menjin
~~~



- <span id='17'>性别检测</span>

~~~python
性别检测采用tf_serving调用模型,模型调用的相关配置信息:request.model_spec.name = 'test', request.model_spec.signature_name = 'serving_default', request.model_spec.version.value = 111
性别检测目前会出现性别检测出错的情况(发生此情况大概率是由于人脸未完全入框,不排除其他原因)
~~~





### 二.展厅相关服务启动命令

- 概述

- 172.16.0.15

  `此模块涉及flask主服务、网易云抓取服务、neo4j知识图谱、thrift、tf_serving、bert、docker、celery、nginx、supervisor等各个服务的存放位置以及启动管理命令`

  `其中大部分服务采用supervisor统一进行管理`[supervisor教程](https://www.jianshu.com/p/0b9054b33db3)

  `以下所有提到的服务，全部需要进入到docker容器内执行，下文不再阐述`

  `上述大部分服务可通过supervisor进行统一管理：supervisord -c /etc/supervisor.conf， 前台管理页面地址：http://172.16.0.15:9001/`

  `项目存放位置前15服务器：/home/datadocker/zhanting-2下的flask_for_display文件夹`



- flask主服务（supervisor管理）

~~~python
主服务是以docker方式启动, 文件以挂载的方式映射到容器内部.如果docker守护进程未开启(该服务是开机自启动方式),需先启动docker服务
服务器ip：172.16.0.15  username：root  passwd: root12300.
docker容器id：0fa5965d5602
创建容器命令（已创建，不需要此部操作）：docker run -it --name=zhanting-two --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 -p 6006:6006 -p 9001:9001 -v /home/datadocker/zhanting-2:/data/mylpr zhanting-two /bin/bash；其中--name:指代镜像名称  --runtime:指定GPU  --p:指代映射IP  --v:指代映射目录
目前的映射目录为：/home/datadocker/zhanting-2 映射/data/mylpr
通过docker ps查看当前正运行的容器, 若未查到, 可通过docker ps -a查看所有容器, 找到对应容器通过docker start 容器名/容器id启动
启动容器（原则上除非15宕机，否则不需此操作）：docker start 0fa5965d5602
关闭容器：docker stop 0fa5965d5602
删除容器：docker rm 0fa5965d5602
进入容器：docker exec -it 0fa5965d5602 /bin/bash
启动主服务：cd /data/mylpr/flask_for_display   执行：python3 main.py(建议非调试模式下采用后台方式启动 nohup python3 main.py > main.log 2>&1&)  
~~~



- nginx服务（supervisor管理）

~~~python
nginx主要是转发功能，端口号：6006 转发端口 6007
启动nginx: nginx -c /etc/nginx/nginx.conf
~~~



- bert服务（supervisor管理）

~~~python
启动：bert-serving-start -model_dir /data/mylpr/flask_for_display/info/modules/common/textMatch/chinese_L-12_H-768_A-12 -num_worker=1
~~~



- celery服务（supervisor管理）

~~~python
启动：cd /data/mylpr/flask_for_display   执行celery -B -A celery_task worker --loglevel=info
~~~



- 爬虫网易云音乐服务（supervisor管理）

~~~python
启动：cd /data/mylpr/flask_for_display/info/modules/common/Netease  执行：npm start
~~~



- thrift服务

~~~
thrift项目存在于18服务器
所有相关操作：
	进入容器：docker exec -it 3fcce3b02ad7 /bin/bash
	进入项目目录：cd /data/mythrift/thriftServer/tiny_model  执行python3 thrift_server.py (建议nohup)
	如果想要重启服务：ps -ef|grep python3 找到相应进程号kill掉（kill -9 PID）,然后再次执行启动命令即可
~~~



- neo4j服务

~~~python
neo4j服务搭建地址：172.16.0.18
启动服务命令： cd /data/neo4j-community-3.0.7/bin  执行./neo4j start
修改配置文件（改变服务端口号等相关操作）：cd /data/neo4j-community-3.0.7/conf  执行vim neo4j.conf
~~~



- tf_serving服务

~~~python
tf_serving 部署于18服务器，采用docker部署，拉取tensorflow/serving:latest-gpu镜像创建的容器
容器id:c4c618bd2066 
模型存放位置：/data/tf-serving/multiModel
增加新的模型时：需要在models.config 文件内加入相关配置
当老的模型增加新的版本时，只需要在对应文件夹创建不重复的版本号文件夹即可，例如：‘10000’, '10001'
服务采用热启动，增加或改变时无需重启服务（当重启docker后若出现docker自动停止或根本启动不开，说明新加入的模型出错，删除后再次启动即可）
tf_serving启动命令参考（一般不再需要此操作）：docker run -p 8501:8501 --mount type=bind,source=/home/jerry/tmp/multiModel/,target=/models/multiModel \
 -t tensorflow/serving --model_docker config_file=/models/multiModel/models.config
当18宕机或者其他原因导致tf_serving的docker的容器关闭时，只需执行 docker start c4c618bd2066 ,tf_serving服务会随着容器自动启动

~~~



### 三.18服务器Docker容器相关

目前18服务器在用docker汇总(需保证以下docker处于正常运行状态即可)

~~~python
容器id:3fcce3b02ad7     ---展厅thrift服务
容器id:b1acda1888c6     ---测试环境（目前空闲）
容器id:39d22d13e4a6     ---ct肺片服务部署环境
容器id:c4c618bd2066     ---tf_serving服务
容器id:000873c23007     ---郑大专用docker
~~~



### 四.大数据智能分析平台相关
- 服务搭建以及配置相关

  ~~~python
  智能数据分析系统项目采用Django框架,项目拉取的是git开源项目:https://github.com/DjangoGirls/tutorial.git
  web项目服务器:10.11.0.205  存放路径:/root/tutorial   启动命令为常规django启动命令:python3 manage.py runserver 0.0.0.0:8000(用nohup也行)
  注意:以上项目启动需要进入虚拟环境,环境名:DJANGO_PROJECT_DSJ  
          进入虚拟环境命令:workon DJANGO_PROJECT_DSJ
  模型部署在17服务器;项目存放位置:/home/zoneyet/face/dsj 
      启动命令为常规thrift启动命令:python3 thrift_server.py(在项目目录下执行/home/zoneyet/face/dsj/kkk)
  项目界面:http://10.11.0.205:8000/login   
              账号1:mabeibei   123456
              账号2:zoneyet    18537312072
  ~~~


- 模型api调用

~~~python
模型调用api相关信息:
    情感分析和用户评论观点抽取
    data = {
    'input': '这车的配置真垃圾',
    'app_key': '6717040708118503424',
    'app_secret': 'a763cd88a1d05f0e856c6cc07f39f145',
    'skill_id': 2
	}
    response = requests.post(url='http://10.11.0.205:8000/opinion_analyze', data=data)
    print(response.text)
    
    其中各个参数的含义:
        input: 用户输入的文本
        app_key:每个新增用户调用api是的app_key
        app_secret:app_key所对应的app_secret
        skill_id:调用模型所对应的id(1:代表情感分析   2:代表汽车用户评论观点抽取)
    以上四个字段均为必传参数
    
~~~



### 五.FTP服务相关

`ftp服务部署在10.11.0.205服务,项目位于根目录下的ftpServer.py和config.ini文件`

`ftp文件存放目录:/data/AI事业部文件`

`205宕机后直接nohup python3 ftpServer.py > ` ftp.log 2>&1 & 启动即可



### 六.其他

- 为大数据部门提供的人脸检测接口部署于10.11.0.117服务，flask框架，nginx 80端口转发，暂无登录服务器账号密码（此项目应该不会再动了，无须改动，别人提到时知道有这回事就行）[配置密钥](ai-root.key)

  ~~~python
  117服务登录需要配置密钥登陆
  服务需要nginx:sudo nginx -c /usr/local/nginx/conf/nginx.conf
  主服务:/home/ubuntu/aiForDisplay   启动命令: nohup python3 app.py > app.log 2>&1&
  简单测试服务通畅: http://10.11.0.117/sendEmail/test/  正常返回值说明服务正常工行
  ~~~

  

- 手势采集项目位于205服务器，原先端口号8088（目前已经不用）

- 部分爬虫程序以及数据清洗已上传svn,爬取的数据位于本地mongo库，无密码（各个item存放的内容根据名字可判断）

- 目前11和15都搭建有redis,服务自动重启，无需其他操作（redis不好使的卫衣原因就是服务器宕机）

- 其他一些项目详见[附属交接文档1.docx](附属交接文档1.docx)

华为盒子：admin@172.16.0.19      zoneyet12300.   登上后,   先输入develop,然后输密码:Huawei@SYS3   即可进入hilens   /home/log/alog/hilens/skillframework
rm -rf hilens_media*     df
华为云:  17788172164    xing1218
