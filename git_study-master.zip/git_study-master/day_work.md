#  概论
日常工作的常用命令
#  tfsevering
    1. tfsevering模型查看地址:http://172.16.0.18:8501/v1/models/faceDetectionYolo/versions/10021/metadata
    2. tf-serving启动docker容器：docker run -d   -p 8500:8500 -p 8501:8501   --mount type=bind,source=/data2/city_zhanting/tfserving/multiModel/,target=/models/multiModel/  --name citysh-tf-serving   --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0  -t registry.cn-hangzhou.aliyuncs.com/nhj_images/zhanting_tfserving:v3.0   --model_config_file=/models/multiModel/models.config
# nginx
    启动：nginx -c /etc/nginx/nginx.conf
    重新加载：nginx -s reload
    停止：nginx -s stop
# Anaconda
    创建环境：conda create -n beautiful python=3.8
    环境列表：conda env list
	切换环境：source activate zhanting
# GPU显卡及conda
    1. 查看显卡信息   cat /proc/driver/nvidia/version
    2. 查看NVIDIA驱动版本   sudo dpkg --list | grep nvidia-*
    3. 查看 CUDA 版本：cat /usr/local/cuda/version.txt
    4. 查看 CUDNN 版本：cat /usr/local/cuda/include/cudnn.h | grep CUDNN_MAJOR -A 2
    5. 查看显卡温度的：watch nvidia-smi -q -i 0,1 -d TEMPERATURE

    测试GPU是否可用：
    import tensorflow as tf
    print(tf.test.is_gpu_available())

# python 安装mysql报错：
    sudo apt-get install python3.6-dev libmysqlclient-dev
# docker
```
    1.创建私有仓库
    docker run -d -p 8900:5000 --mount source=private_registry_store,target=/var/lib/registry --name private_registry  --restart=always registry
    查看私有仓库中的镜像：curl http://172.16.1.10:8900/v2/_catalog
    查看私有仓库中的镜像tag：curl http://172.16.1.10:8900/v2/镜像名字/tags/list
    查看单个image、container大小：docker system df -v

    上传镜像到私有仓库：
        换标签：docker tag   镜像ID   172.16.1.10:8900/镜像名字:版本号
        上传镜像：docker push  172.16.1.10:8900/镜像名字:版本号

    下载私有仓库镜像：docker pull 172.16.1.10:8900/镜像名字:版本号

    2. 容器自启动
        docker服务自动重启设置： systemctl enable docker.service

        docker容器自动启动设置： 
            docker容器自动启动设置：docker run --restart=always
            如果已经启动了则可以使用如下命令： docker update --restart=always <CONTAINER ID>

    3. 查看日志
        查看后一百行的日志：docker logs -f  --tail=100  容器名

    4. 导出容器
        docker export 容器id  > 名字.tar
        docker import 名字.tar  镜像：版本
```


    
# AI开放平台项目
    服务器：172.16.0.17      用户：zoneyet        密码：root12300.
    AI开放平台docker构建基础thrift环境：
        docker run -itd --name open-ai-thrift --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 -p 9001:9001  -v /root/gitlab/zoneyet-ai-service-thrift/project/face:/home/face python-gpu:v1.0 /bin/bash
    
    AI开放平台启动命令：
        1. 宿主机路径：/home/zoneyet/aiopenAPI
        进入容器aidjango：docker exec -it 488ff80d7dcf /bin/bash
             uwsgi启动: cd /home/aiopenAPI          nohup uwsgi -x web.xml >nohup.out 2>&1 &
	         nginx启动：nginx -c /etc/nginx/nginx.conf

	    2.进入open-ai-thrift容器： docker exec -it baa23f08e343 /bin/bash
            thrift启动：cd /home/face      nohup python3 service.py >nohup.out 2>&1 &

	    3.启动vue： docker start 7aa7b0cfce7a



# 城市展厅
```
 城市展厅flask:
	    docker run -itd --name city_zhanting_flask --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 -p 80:80 -p 9001:9001 -v /data2/city_zhanting/flask/city_zhanting_flask:/data/mylpr registry.cn-hangzhou.aliyuncs.com/nhj_images/city_zhangting_flask:v1.0 /bin/bash

城市展厅thrift：
	docker run -itd --name city_zhanting_thrift --device=/dev/video0 --device=/dev/video2 --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 --expose=22 --expose=5001 --expose=5010 --expose=6000 --expose=6001 -p 6005:6005 --expose=6006 --expose=6007 --expose=80 -p 9002:9002 -v /root/city_zhanting/thrift/thriftServer:/data/mythrift city_zhanting_thrift:v2.0 /bin/bash

城市展厅tfserving:
	docker run -d   -p 8500:8500 -p 8501:8501   --mount type=bind,source=/data2/city_zhanting/tfserving/multiModel/,target=/models/multiModel/  --name citysh-tf-serving   --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0  -t registry.cn-hangzhou.aliyuncs.com/nhj_images/zhanting_tfserving:v3.0   --model_config_file=/models/multiModel/models.config

neo4j:
	docker run --name city_zhanting_neo4j -it -d -p 7474:7474 -p 7687:7687 -v /home/zhb/neo4j:/var/lib/neo4j/data  neo4j:3.0.7

mysql:
	docker run -itd --name city_zhanting_mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root12300. mysql:5.6
    
redis:
	docker run -itd --name city_zhanting_redis -p 6379:6379 redis:4.0.9 --requirepass "root12300."

遇到的问题：
    tf显存不足：（代码中指定显存大小）
        import tensorflow as tf
        import os
        os.environ["CUDA_VISIBLE_DEVICES"] = '0' #指定第一块GPU可用
        config = tf.ConfigProto()
        config.gpu_options.per_process_gpu_memory_fraction = 0.5 # 程序最多只能占用指定gpu50%的显存
        config.gpu_options.allow_growth = True #程序按需申请内存
        sess = tf.Session(config = config)

    tfserving占满显存：
        docker run -d   -p 8500:8500 -p 8501:8501   --mount type=bind,source=/data2/city_zhanting/tfserving/multiModel/,target=/models/multiModel/  --name city_zhanting_tfserving   --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0  -t registry.cn-hangzhou.aliyuncs.com/nhj_images/zhanting_tfserving:v3.0   --model_config_file=/models/multiModel/models.config --platform_config_file=/models/multiModel/platform.config

        上述命令用到platform.config配置文件内容：
platform_configs {
  key: "tensorflow"
  value {
    source_adapter_config {
      [type.googleapis.com/tensorflow.serving.SavedModelBundleSourceAdapterConfig] {
        legacy_config {
          session_config {
            gpu_options {
		per_process_gpu_memory_fraction: 0.4
            }
          }
        }
      }
    }
  }
}

常见错误解决方法：
		AttributeError: 'NoneType' object has no attribute 'excluded_of'
	1、pip install --upgrade pip~=20.2.0
		中文乱码
	2、sudo apt-get install language-pack-zh-hans     打开：vim ~/.bashrc     环境变量：export LC_ALL=zh_CN.utf8     source ~/.bashrc
		安装npm
	3、sudo apt-get install nodejs-dev node-gyp libssl1.0-dev              sudo apt install npm

	4、ssh-keygen -t rsa -C "your_email@example.com"
	5、apt install mysql-server                     apt-get install libmysqld-dev
	6、opencv报错：       apt-get install -y libglib2.0-dev
	7、apt-get install -y libsm6 libxext6 libxrender-dev

```
# 大数据采集项目
```
访问地址：http://172.16.1.10:8000/login           账号： zoneyet         密码：18537312072
    服务器：172.16.1.10       账号：hello            密码： root12300.
        flask路径：/home/hello/tutorial
        启动命令：nohup python manage.py runserver 0.0.0.0:8000 >nohup.log 2>1&1

        mysql数据库：
            数据库账号：root    密码： root12300.
            登陆方式： mysql -h 172.16.1.10 -P 3306 -u root -p
            常用命令：show databases;   use [数据库名];  show tables; 

    服务器：172.16.0.17  账号：root           密码：root12300.
        用户观点服务：
        路径： cd /home/zoneyet/face/dsj/kkk   
        启动命令：nohup python3 thrift_server.py  >thrift.log  2>&1 &
        insert into snippets_skillcount (id,uid,skillid,result,count,created) values (9,1,2,'动力',21,'2020-11-10');
        update snippets_skill set logo=' static/temp/brand/qinggan.png' where id=1;

        情感分析服务：
        路径：/home/zoneyet
        启动命令：nohup hub serving start -m senta_lstm > senta_lstm.log 2>&1&

```

# transformer翻译引擎
```
英中翻译引擎：
    访问地址：http://172.16.0.17/ui_tran_en_zh/
    服务器：172.16.0.17  账号：root           密码：root12300.
        flask路径：/home/zoneyet/transformer
        启动命令：nohup python3 test.py >out.log  2>&1 &

        nginx和前端界面在容器488ff80d7dcf里面
        前端路径：/home/dialogue/flask_backend/ui_tran_en_zh

中英翻译引擎：
    访问地址：http://172.16.0.17/ui_tran_zh_en/
    服务器：172.16.0.17  账号：root           密码：root12300.
        flask路径：/home/zoneyet/transformer_zh_en
        启动命令：nohup python3 test.py >out.log  2>&1 &

        nginx和前端界面在172.16.0.17服务器，容器488ff80d7dcf里面
        前端路径：/home/dialogue/flask_backend/ui_tran_en_zh

英法翻译引擎：
    访问地址：http://172.16.0.17/ui_tran_en_fr/
    服务器：172.16.0.17  账号：yons           密码：123

    docker run -itd --name transformer_fanyi  --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=3  -p 8701:8701 -p 8702:8702 -p 8703:8703 -p 8704:8704 -p 8705:8705 -p 8706:8706 -p 8707:8707 -v /root/nhj/transformer/zoneyet-ai-service-thrift/transformers:/home/transformers transformers:v1.0 /bin/bash

    docker 容器：9ca59e582266            容器名字：transformer_fanyi
        路径：/home/transformers/transformer_en_fr
        启动命令： nohup python3 test.py >out.log  2>&1 &

        nginx和前端界面在172.16.0.17服务器，容器488ff80d7dcf里面
        前端路径：/home/dialogue/flask_backend/ui_tran_en_fr

英日翻译引擎：
    访问地址：http://172.16.0.17/ui_tran_en_ja/
    服务器：172.16.0.17  账号：yons           密码：123

    docker run -itd --name transformer_fanyi  --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=3  -p 8701:8701 -p 8702:8702 -p 8703:8703 -p 8704:8704 -p 8705:8705 -p 8706:8706 -p 8707:8707 -v /root/nhj/transformer/zoneyet-ai-service-thrift/transformers:/home/transformers transformers:v1.0 /bin/bash

    docker 容器：9ca59e582266            容器名字：transformer_fanyi
        路径：/home/transformers/transformer_en_ja
        启动命令： nohup python3 test.py >out.log  2>&1 &

        nginx和前端界面在172.16.0.17服务器，容器488ff80d7dcf里面
        前端路径：/home/dialogue/flask_backend/ui_tran_en_ja


```
# 郑大实验室项目
```
生成对话：
    访问地址： 172.16.0.17:8880
    服务器： 172.16.0.17  账号：root           密码：root12300.
    Django路径：/home/zoneyet/chat/DialoGPT_Chat
    启动命令：nohup python3 manage.py runserver 0.0.0.0:8880 >nohup.out 2>1&1

性格预测：
    访问地址：http://172.16.1.10:8007/
    服务器： 172.16.1.10   账号：hello    密码： root12300.
    Django路径： /home/hello/ai-project/personality_webv0.0
    anaconda环境： personality
    启动命令： 弃用：nohup python3 manage.py runserver 0.0.0.0:8001 >nohup.out 2>1&1
                在用：　/root/anaconda3/envs/personality/bin/python3 manage.py runserver 0.0.0.0:8007 &>manage.log &

多轮对话：
    访问地址：http://172.16.0.17/ui_auto_diag/
    服务器： 172.16.0.17  账号：root           密码：root12300.
	聊天记录：prj_home:user_dialogue/002.csv
	docker exec -it dfd38990ca4d bash
	目录: /home/face/
	运行服务:nohup python service.py &

```
# K8S和Kubeflow项目
```
ssh yons@172.16.0.21
ssh hello@172.16.1.10
K8S前端管理界面：https://172.16.0.21:30443
Kubeflow使用界面：http://172.16.0.21:31380/
```
# 图像处理引擎服务
```
ssh yons@172.16.0.21
前端页面展示：http://172.16.0.21:8800/
资源使用：GPU1：显存10G， 内存2G，CPU1。
```

# gunicorn_thrift 多进程并发
```
 gunicorn_thrift --workers=2 gunicon_thrift.thrift_app:app -k thriftpy_sync  --thrift-protocol-factory   thriftpy2.protocol:TCyBinaryProtocolFactory   --thrift-transport-factory    thriftpy2.transport:TCyBufferedTransportFactory
```

# 图片的格式转换
```
1. 二进制转opencv的格式：
    with open(image_path, "rb") as file:
        jpg_bin = file.read()
        image = cv2.imdecode(np.asarray(bytearray(jpg_bin),dtype='uint8'), cv2.IMREAD_COLOR)
    
    with open(tmp_image_path, 'wb') as tmp_file:
        tmp_jpg_bin = np.array(cv2.imencode('.jpg', image)[1]).tobytes()
        tmp_file.write(tmp_jpg_bin)

2.PIL_Image对象转为字节流
    from PIL import Image
    from io import BytesIO
    im = Image.open("code.jpg")
    img_byte = BytesIO()
    im.save(img_byte, format='JPEG') # format: PNG or JPEG
    binary_content = img_byte.getvalue()  # im对象转为二进制流
```













# tensorflow训练模型的显存不足解决办法
    os.environ["CUDA_VISIBLE_DEVICES"] = '0' #指定第一块GPU可用
    config = tf.ConfigProto()
    config.gpu_options.per_process_gpu_memory_fraction = 0.5 # 程序最多只能占用指定gpu50%的显存
    config.gpu_options.allow_growth = True #程序按需申请内存
    sess = tf.Session(config = config)


# CentOS7.x系统自带的3.10.x内核存在一些Bug，Docker运行不稳定，建议升级内核
```
#下载内核源
rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
# 安装最新版本内核
yum --enablerepo=elrepo-kernel install -y kernel-lt
# 查看可用内核
cat /boot/grub2/grub.cfg |grep menuentry
# 设置开机从新内核启动
grub2-set-default "CentOS Linux (4.4.230-1.el7.elrepo.x86_64) 7 (Core)"
# 查看内核启动项
grub2-editenv list
# 重启系统使内核生效
reboot
# 查看内核版本是否生效
uname -r
```

```
pip安装mysqlclient报错：
 sudo apt-get install -y mysql-client
 sudo apt-get install libmysqlclient-dev
```


内网穿透

        # 下载
        wget https://github.com/fatedier/frp/releases/download/v0.34.0/frp_0.34.0_linux_amd64.tar.gz
        # 解压缩
        tar -zxf frp_0.34.0_linux_amd64.tar.gz
        # 复制到bin中
        sudo cp frpc /usr/bin/
        sudo cp frps /usr/bin/
        # 复制配置文件 - 如果不是新安装则跳过这一步，不然会把旧配置覆盖掉
        sudo mkdir /etc/frp/
        sudo cp frp*.ini /etc/frp/
        # 启动frp服务
        sudo cp systemd/* /lib/systemd/system/
        sudo systemctl start frps # 云服务器启动这个
        sudo systemctl start frpc # 本地启动这个
