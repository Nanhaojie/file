AI开放平台地址：172.16.1.130:8080/vue/index.html

tfsevering模型查看地址:http://172.16.0.18:8501/v1/models/faceDetectionYolo/versions/10021/metadata
tf-serving启动容器
    docker run -p 8501:8501 -p 8500:8500 --mount type=bind,source=/home/zoneyet/multiModel,target=/models/multiModel \
    -itd registry.cn-hangzhou.aliyuncs.com/nhj_images/tfserving:latest-gpu --model_docker config_file=/models/multiModel/models.config

tf-serving启动容器
    docker run -itd -p 8500:8500 -p8501:8501 --mount source=tf-models,target=/models/multiModel/  \
    	  --name tf-modelserver \
    	  --network bridge \
      	   registry.cn-hangzhou.aliyuncs.com/nhj_images/tfserving:latest-gpu \
       	  --model_config_file=/models/multiModel/models.config

自动回复模型：（最新）
	内网：172.16.0.17:8880
	外网：1.192.159.5:8088 (205机器挂了)


自动回复模型（哲均部署）
	172.16.0.17/ui_sr_diag/   
	聊天记录：prj_home:reply.csv

多轮对话（哲均部署）
	172.16.0.17/ui_auto_diag/
	聊天记录：prj_home:user_dialogue/002.csv
	docker exec -it dfd38990ca4d bash
	目录: /home/face/
	运行服务:nohup python service.py &

	GPU机器
	地址：zoneyet@172.16.0.17 root12300.
	docker_模型地址:docker exec -it cac1ffd9677b bash
	docker_Web地址:docker exec -it 488ff80d7dcf bash


Nginx：
	启动：nginx -c /etc/nginx/nginx.conf
	重新加载：nginx -s reload
	停止：nginx -s stop

Anaconda:
	环境列表：conda env list
	切换环境：source activate zhanting
	# To activate this environment, use:
	# > source activate bigdata
	#
	# To deactivate an active environment, use:
	# > source deactivate

命令行中输入   cat /proc/driver/nvidia/version查看显卡信息
查看NVIDIA驱动版本   sudo dpkg --list | grep nvidia-*
nohup python manage.py runserver 0.0.0.0:8000 >nohup.log 2>1&1

docker
	docker run -d -p 5000:5000 --mount source=private_registry_store,target=/var/lib/registry --name private_registry  --restart=always registry
	查看私有仓库中的镜像：curl http://172.16.0.21:5000/v2/_catalog
	查看私有仓库中的镜像tag：curl http://172.16.0.21:5000/v2/镜像名字/tags/list

自动回复模型：
	172.16.0.17:8880
多轮对话：
	172.16.0.17/ui_auto_diag/
性格预测：
	172.16.1.10:8001

GPU—AI开放平台
	docker run -itd --name open-ai-thrift --runtime=nvidia -e NVIDIA_VISIBLE_DEVICES=0 -p 9001:9001  -v /root/gitlab/zoneyet-ai-service-thrift/project/face:/home/face python-gpu:v1.0 /bin/bash
