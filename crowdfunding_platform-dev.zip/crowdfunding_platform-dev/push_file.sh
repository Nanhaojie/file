#!/bin/bash
sshpass -p root12300. scp -r ./entrypoint.sh ./target/renren-fast.jar root@172.16.1.10:/opt/apps/crowdfunding_platform/