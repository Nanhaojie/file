#!/bin/bash
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime && cd /crowdfunding_platform && java -jar ./renren-fast.jar --server.host=0.0.0.0 --server.port=8011