#!/bin/bash
cd /crowd && java -jar ./target/renren-fast.jar --server.host=0.0.0.0 --server.port=8011