package io.renren.common.form;

import lombok.Data;

import java.io.Serializable;

@Data
public class PageForm implements Serializable {
    public String page;
    public String limit;
}
