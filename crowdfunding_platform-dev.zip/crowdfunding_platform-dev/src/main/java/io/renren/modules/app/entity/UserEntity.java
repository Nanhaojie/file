/**
 * Copyright (c) 2016-2019 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package io.renren.modules.app.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;


/**
 * 用户
 *
 * @author Mark sunlightcs@gmail.com
 */
@Data
@TableName("t_user")
public class UserEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 用户ID
	 */
	@TableId
	private long id;
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	private String password;
	/**
	 * 类型	1：小程序，2：web，3：后台
	 */
	private Integer type;
	/**
	 * 手机号
	 */
	private String mobile;
	/**
	 * 微信号
	 */
	private String wechatNumber;
	/**
	 *
	 */
	private String openId;
	/**
	 *
	 */
	private String unionId;
	/**
	 * 	性别 0：女  1：男
	 */
	private Integer gender;
	/**
	 *	是否后台用户 0否
	 */
	private Integer isStaff;
	/**
	 * 是否激活
	 */
	private Integer isActive;
	/**
	 * 注册日期
	 */
	private Date dateJoined;
	/**
	 * 最后登录时间
	 */
	private Date lastLogin;
	/**
	 * 更新时间
	 */
	private Date updateTime;
	/**
	 * 备注
	 */
	private String notes;
	private String sessionKey;

	public long getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDateJoined() {
		return dateJoined;
	}

	public void setDateJoined(Date dateJoined) {
		this.dateJoined = dateJoined;
	}
}
