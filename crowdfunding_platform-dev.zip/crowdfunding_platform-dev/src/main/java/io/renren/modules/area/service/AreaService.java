package io.renren.modules.area.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.area.entity.AreaEntity;

import java.util.Map;

/**
 * 
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-17 10:49:06
 */
public interface AreaService extends IService<AreaEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

