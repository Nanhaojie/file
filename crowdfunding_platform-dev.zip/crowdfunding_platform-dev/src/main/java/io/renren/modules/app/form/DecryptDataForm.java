package io.renren.modules.app.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@ApiModel(value = "手机号信息加密表单")
public class DecryptDataForm {

    @ApiModelProperty(value = "加密数据")
    @NotBlank(message="加密不能为空")
    private String encryptedData;

    @ApiModelProperty(value = "iv")
    @NotBlank(message="iv不能为空")
    private String iv;
}
