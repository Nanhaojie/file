package io.renren.modules.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.project.entity.ProjectEntity;

import java.util.Map;

/**
 * 
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-12 13:59:39
 */
public interface ProjectService extends IService<ProjectEntity> {

    PageUtils queryPage(Map<String, Object> params);

    ProjectEntity getObjectById(Integer id);
}

