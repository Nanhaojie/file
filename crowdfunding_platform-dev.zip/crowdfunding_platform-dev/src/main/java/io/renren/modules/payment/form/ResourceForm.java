package io.renren.modules.payment.form;

import io.swagger.annotations.ApiModelProperty;

public class ResourceForm {

    @ApiModelProperty(value = "加密算法类型")
    private String algorithm;
    @ApiModelProperty(value = "数据密文")
    private String ciphertext;
    @ApiModelProperty(value = "原始类型")
    private String original_type;
    @ApiModelProperty(value = "随机串")
    private String nonce;
}
