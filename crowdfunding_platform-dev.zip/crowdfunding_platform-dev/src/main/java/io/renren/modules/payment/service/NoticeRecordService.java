package io.renren.modules.payment.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.payment.entity.NoticeRecordEntity;

import java.util.Map;

/**
 * 微信支付通知记录表
 *
 * @author zwz
 * @email test@gmail.com
 * @date 2022-05-23 15:02:55
 */
public interface NoticeRecordService extends IService<NoticeRecordEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

