package io.renren.modules.payment.form;

import io.renren.common.form.PageForm;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Pattern;


@Data
public class OrderListForm extends PageForm {

    @ApiModelProperty(value = "用户手机号")
    public String mobile = "";

    @ApiModelProperty(value = "订单号")
    public String orderNumber = "";

    //  回报产品（模糊搜索，默认为空）
    @ApiModelProperty(value = "产品名称")
    public String projectName = "";

    //    订单状态（全部、未支付、已支付，默认为全部）
    @ApiModelProperty(value = "订单状态")
    public Long status;

    //    订单创建时间（可选择年月日，开始时间默认0点,结束时间默认24点
    @ApiModelProperty(value = "下订单开始时间")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "日期格式错误")
    public String startCreateTime;

    @ApiModelProperty(value = "下订单结束时间")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "日期格式错误")
    public String endCreateTime;

    public String getEndCreateTime() {
        if (this.endCreateTime == null) {
            return null;
        } else {
            return this.endCreateTime + " 23:59:59";
        }

    }
}
