package io.renren.modules.payment.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.payment.entity.OrderEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PaymentDao extends BaseMapper<OrderEntity> {

}
