package io.renren.modules.project.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.common.exception.RRException;
import io.renren.modules.project.entity.ProjectImgEntity;
import io.renren.modules.project.service.ProjectImgService;
import io.renren.modules.project.entity.ReturnProductEntity;
import io.renren.modules.project.service.ReturnProductService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.*;

import io.renren.modules.project.entity.ProjectEntity;
import io.renren.modules.project.service.ProjectService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.xml.crypto.Data;


/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-12 13:59:39
 */
@RestController
@RequestMapping("")
@Api(tags = {"项目管理"})
public class ProjectController {
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectImgService projectImgService;
    @Autowired
    private ReturnProductService returnProductService;

    private int crow_status;

    @Value("${app.defaultId}")
    private String defaultId;

    /**
     * 列表
     */
    @GetMapping("project/project/list")
    @ApiOperation("项目列表")
    /*@RequiresPermissions("project:project:list")*/
    public R list(@RequestParam Map<String, Object> page){
        PageUtils pages = projectService.queryPage(page);

        return R.ok().put("page", pages);
    }


    /**
     * 信息
     */
    public static int day(Date start_time, Date endDay) {
        try {
            Date star = start_time;//开始时间
            Date nextDay=star;
            int i=0;
            while(nextDay.before(endDay)){//当明天不在结束时间之前是终止循环
                Calendar cld = Calendar.getInstance();
                cld.setTime(star);
                cld.add(Calendar.DATE, 1);
                star = cld.getTime();
                //获得下一天日期字符串
                nextDay = star;
                i++;
            }
            return +i;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @GetMapping("project/project/info/{id}")
    @ApiOperation("项目详细信息")
    /*@RequiresPermissions("project:project:info")*/
    public R info(@PathVariable("id") String id) throws ParseException {

        //项目图片
        long project_id =  Long.valueOf(id).longValue();
        ArrayList<ProjectImgEntity> projectImgEntityList = (ArrayList<ProjectImgEntity>) projectImgService.list(new QueryWrapper<ProjectImgEntity>().eq("project_id", project_id));

        //项目产品
        ArrayList<ReturnProductEntity> returnProductEntityList = (ArrayList<ReturnProductEntity>) returnProductService.list(new QueryWrapper<ReturnProductEntity>().eq("project_id", project_id));

        /*剩余多少天*/
		ProjectEntity project = projectService.getById(id);
        Date endDate = project.getEndTime();
        String now_time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        Date now_time_date = new SimpleDateFormat("yyyy-MM-dd").parse(now_time);
        // 剩余多少天
        int leftDay = day(now_time_date, endDate);
        // 已筹金额默认为0
        if (project.getRaisedAmount() == null){
            BigDecimal raisedAmountNew = new BigDecimal(0);
            project.setRaisedAmount(raisedAmountNew);
        }
        // progress默认为0
        if(project.getProgress() == null){
            project.setProgress("0%");
        }
        // peopleNumber 默认为0
        if (project.getPeopleNumber()==null){
            Integer peoNumber = 0;
            project.setPeopleNumber(peoNumber);
        }
        project.setLeftDay(leftDay+1);

        /*更新众筹流程*/
        Date prepareTime = project.getPrepareTime();
        Date startTime  = project.getStartTime();
        Date endTime = project.getEndTime();
        Date sendGoodsTime = project.getSendGoodsTime();
        int pre_start = day(prepareTime, startTime);
        int pre_end = day(prepareTime, endTime);
        int pre_send = day(prepareTime, sendGoodsTime);
        int pre_now = day(prepareTime, now_time_date);

        if (pre_now<pre_start){
            // 项目筹备
            crow_status = 1;
        }else if(pre_start<pre_now & pre_now<pre_end){
            // 众筹开始
            crow_status = 2;
        }else if(pre_end<pre_now & pre_now<pre_send){
            // 众筹结束
            crow_status = 3;
        }else if(pre_send<pre_now){
            // 发货
            crow_status = 4;
        }

        //转换json格式
        JSONArray imgList = (JSONArray) JSONArray.toJSON(projectImgEntityList);
        JSONArray productList = (JSONArray) JSONArray.toJSON(returnProductEntityList);
        JSONObject product = (JSONObject) JSONObject.toJSON(project);
        product.put("img_list", imgList.toString());
        product.put("product_list", productList.toString());
        product.put("crow_status", crow_status);

        return R.ok().put("data", product);
    }

    /**
     * 保存
     */
    @PostMapping("project/project/save")
    @ApiOperation("添加项目")
    /*@RequiresPermissions("project:project:save")*/
    public R save(@Valid @RequestBody ProjectEntity project){
        Date prepareTime =project.getPrepareTime();
        Date startTime = project.getStartTime();
        Date endTime = project.getEndTime();
        Date sendGoodsTime = project.getSendGoodsTime();
        Date earlyBirdStartTime = project.getEarlyBirdStartTime();
        Date earlyBirdEndTime = project.getEarlyBirdEndTime();
        if(prepareTime.compareTo(startTime) > 0){
            throw new RRException("众筹开始时间必须晚于项目众筹准备时间");
        }else if(startTime.compareTo(endTime) > 0){
            throw new RRException("众筹结束时间必须晚于众筹开始时间");
        }else if(endTime.compareTo(sendGoodsTime) > 0){
            throw new RRException("发货时间必须晚于众筹结束时间");
        }
        if (project.getEarlyBirdPrice()!=null){
            if(earlyBirdStartTime!=null & earlyBirdEndTime!=null){
                if (earlyBirdStartTime.compareTo(earlyBirdEndTime) > 0){
                    throw new RRException("早鸟价结束时间必须晚于开始时间");
                }
        }
            else {
                throw new RRException("早鸟价开始时间和结束时间不能为空");
            }
        }
        if(earlyBirdStartTime!=null & earlyBirdEndTime!=null){
            if(project.getEarlyBirdPrice()==null){
                throw new RRException("早鸟价不能为空");
            }
        }
        project.setCreateTime(new Date());
		projectService.save(project);
        long project_id = project.getId();

        // 项目相关图片
        List<ProjectImgEntity> imgList = project.getImgList();
        ProjectImgEntity projectImg = new ProjectImgEntity();
        for(ProjectImgEntity im: imgList){
            projectImg.setProjectId(project_id);
            projectImg.setImgUrl(im.getImgUrl());
            projectImg.setNumber(im.getNumber());
            projectImg.setDisplayType(im.getDisplayType());
            projectImg.setCreateTime(new Date());
            projectImgService.save(projectImg);
        }

        // 回报产品
        List<ReturnProductEntity> productList = project.getProductList();
        ReturnProductEntity returnProduct = new ReturnProductEntity();
        for (ReturnProductEntity rp: productList){
            returnProduct.setProjectId(project_id);
            if (rp.getProductParameter().length()>50){
                throw new RRException("回报产品类别不能超过50字符!");
            }
            returnProduct.setProductParameter(rp.getProductParameter());
            returnProduct.setCreateTime(new Date());
            returnProductService.save(returnProduct);
        }


        return R.ok().put("data", project);
    }

    /**
     * 修改
     */
    public static BigDecimal divide(BigDecimal first, BigDecimal last) {
        if (first == null) first = new BigDecimal(0);
        if (last == null) last = new BigDecimal(0);
        BigDecimal s = new BigDecimal(100);
        return first.divide(last, 4, BigDecimal.ROUND_HALF_UP).multiply(s).setScale(2, BigDecimal.ROUND_HALF_UP);
    }
    public static BigDecimal add(BigDecimal... param) {
        BigDecimal sumAdd = BigDecimal.valueOf(0);
        for (int i = 0; i < param.length; i++) {
            BigDecimal bigDecimal = param[i] == null ? new BigDecimal(0) : param[i];
            sumAdd = sumAdd.add(bigDecimal);
        }
        return sumAdd;
    }

    @RequestMapping(value = "project/project/update", method = RequestMethod.PUT)
    @ApiOperation("项目修改")
    /*@RequiresPermissions("project:project:update")*/
    public R update(@Valid @RequestBody ProjectEntity project){
        Date prepareTime =project.getPrepareTime();
        Date startTime = project.getStartTime();
        Date endTime = project.getEndTime();
        Date sendGoodsTime = project.getSendGoodsTime();
        Date earlyBirdStartTime = project.getEarlyBirdStartTime();
        Date earlyBirdEndTime = project.getEarlyBirdEndTime();
        if(prepareTime.compareTo(startTime) > 0){
            throw new RRException("众筹开始时间必须晚于项目众筹准备时间");
        }else if(startTime.compareTo(endTime) > 0){
            throw new RRException("众筹结束时间必须晚于众筹开始时间");
        }else if(endTime.compareTo(sendGoodsTime) > 0){
            throw new RRException("发货时间必须晚于众筹结束时间");
        }
        if (project.getEarlyBirdPrice()!=null){
            if(earlyBirdStartTime!=null & earlyBirdEndTime!=null){
                if (earlyBirdStartTime.compareTo(earlyBirdEndTime) > 0){
                    throw new RRException("早鸟价结束时间必须晚于开始时间");
                }
            }
            else {
                throw new RRException("早鸟价开始时间和结束时间不能为空");
            }
        }
        if(earlyBirdStartTime!=null & earlyBirdEndTime!=null){
            if(project.getEarlyBirdPrice()==null){
                throw new RRException("早鸟价不能为空");
            }
        }
        long project_id = project.getId();
        project.setUpdateTime(new Date());
		projectService.updateById(project);

        // 更新项目相关图片
        List<ProjectImgEntity> imgListNew = project.getImgList();
        ProjectImgEntity projectImgNew = new ProjectImgEntity();
        if (imgListNew!=null){
            //先删除之前的
            ArrayList<ProjectImgEntity> projectImgEntityList = (ArrayList<ProjectImgEntity>) projectImgService.list(new QueryWrapper<ProjectImgEntity>().eq("project_id", project_id));
            ArrayList<Integer> idList = new ArrayList<>();
            for (ProjectImgEntity pi:projectImgEntityList){
                Integer id1 = pi.getId();
                idList.add(id1);
            }
            projectImgService.removeByIds(idList);
            //重新添加
            for(ProjectImgEntity im1: imgListNew){
                projectImgNew.setProjectId(project_id);
                projectImgNew.setImgUrl(im1.getImgUrl());
                projectImgNew.setNumber(im1.getNumber());
                projectImgNew.setDisplayType(im1.getDisplayType());
                projectImgNew.setUpdateTime(new Date());
                projectImgService.save(projectImgNew);
            }
        }

        // 回报产品
        List<ReturnProductEntity> productList = project.getProductList();
        ReturnProductEntity returnProduct = new ReturnProductEntity();
         if (productList!=null){
             //先删除之前的
             ArrayList<ReturnProductEntity> returnProductEntityList = (ArrayList<ReturnProductEntity>) returnProductService.list(new QueryWrapper<ReturnProductEntity>().eq("project_id", project_id));
             ArrayList<Integer> idListReturn = new ArrayList<>();
             for (ReturnProductEntity rp2:returnProductEntityList){
                 Integer id2 = rp2.getId();
                 idListReturn.add(id2);
             }
             returnProductService.removeByIds(idListReturn);
             //重新添加
             for (ReturnProductEntity rp: productList){
                 returnProduct.setProjectId(project_id);
                 returnProduct.setProductParameter(rp.getProductParameter());
                 returnProduct.setUpdateTime(new Date());
                 returnProductService.save(returnProduct);
             }
         }
        return R.ok().put("data", project);
    }

    //添加数据
    @RequestMapping(value = "project/project/add", method = RequestMethod.PUT)
    @ApiOperation("添加数据")
    public R add(@RequestBody ProjectEntity project){
        long project_id = project.getId();
        // 后台添加的金额
        BigDecimal getRaisedAmount = project.getRaisedAmount();
        if (getRaisedAmount!=null){
            BigDecimal v1 = new BigDecimal(1);
            BigDecimal v2 = new BigDecimal(100000);
            int r = getRaisedAmount.compareTo(v2);
            int r1 = v1.compareTo(getRaisedAmount);
            if(r==1 | r1==1){
                throw new RRException("添加众筹金额需要在1-100000!");
            }
            BigDecimal haveRaisedAmount = projectService.getById(project_id).getRaisedAmount();
            BigDecimal addRaisedAmount = add(project.getRaisedAmount(), haveRaisedAmount);
            project.setRaisedAmount(addRaisedAmount);

            /*及众筹进度*/
            BigDecimal targetAmount = projectService.getById(project_id).getTargetAmount();
            BigDecimal process = divide(addRaisedAmount, targetAmount);
            project.setProgress(process.toString()+"%");
        }

        // 后台添加支持人数
        Integer peopleNumber = projectService.getById(project_id).getPeopleNumber();
        if(peopleNumber==null){
            Integer addPeopleNumber = project.getPeopleNumber();
            if (addPeopleNumber!=null){
                project.setPeopleNumber(addPeopleNumber);
            }
        }else{
            Integer addPeopleNumber = project.getPeopleNumber();
            if (addPeopleNumber!=null){
                project.setPeopleNumber(peopleNumber+addPeopleNumber);
            }
        }
        project.setUpdateTime(new Date());
        projectService.updateById(project);
        return R.ok().put("data", project);
    }

    /**
     * 删除
     */
    @RequestMapping(value = "project/project/delete",method = RequestMethod.DELETE)
    @ApiOperation("删除项目")
    /*@RequiresPermissions("project:project:delete")*/
    public R delete(@RequestBody String[] ids){
		projectService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

    // 小程序返回默认数据
    @GetMapping("/applet/default/info")
    @ApiOperation("小程序详细信息")
    /*@RequiresPermissions("project:project:info")*/
    public R defaultInfo() throws ParseException {

        //项目图片
        String id = defaultId;
        long project_id =  Long.valueOf(id).longValue();
        ArrayList<ProjectImgEntity> projectImgEntityList = (ArrayList<ProjectImgEntity>) projectImgService.list(new QueryWrapper<ProjectImgEntity>().eq("project_id", project_id));

        //项目产品
        ArrayList<ReturnProductEntity> returnProductEntityList = (ArrayList<ReturnProductEntity>) returnProductService.list(new QueryWrapper<ReturnProductEntity>().eq("project_id", project_id));

        /*剩余多少天*/
        ProjectEntity project = projectService.getById(id);
        Date endDate = project.getEndTime();
        String now_time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        Date now_time_date = new SimpleDateFormat("yyyy-MM-dd").parse(now_time);
        // 剩余多少天
        int leftDay = day(now_time_date, endDate);
        // 已筹金额默认为0
        if (project.getRaisedAmount() == null){
            BigDecimal raisedAmountNew = new BigDecimal(0);
            project.setRaisedAmount(raisedAmountNew);
        }
        // progress默认为0
        if(project.getProgress() == null){
            project.setProgress("0%");
        }
        // peopleNumber 默认为0
        if (project.getPeopleNumber()==null){
            Integer peoNumber = 0;
            project.setPeopleNumber(peoNumber);
        }
        project.setLeftDay(leftDay);

        /*更新众筹流程*/
        Date prepareTime = project.getPrepareTime();
        Date startTime  = project.getStartTime();
        Date endTime = project.getEndTime();
        Date sendGoodsTime = project.getSendGoodsTime();
        int pre_start = day(prepareTime, startTime);
        int pre_end = day(prepareTime, endTime);
        int pre_send = day(prepareTime, sendGoodsTime);
        int pre_now = day(prepareTime, now_time_date);

        if (pre_now<pre_start){
            // 项目筹备
            crow_status = 1;
        }else if(pre_now<pre_end){
            // 众筹开始
            crow_status = 2;
        }else if(pre_now<pre_send){
            // 众筹结束
            crow_status = 3;
        }else{
            // 发货
            crow_status = 4;
        }

        //转换json格式
        JSONArray imgList = (JSONArray) JSONArray.toJSON(projectImgEntityList);
        JSONArray productList = (JSONArray) JSONArray.toJSON(returnProductEntityList);
        JSONObject product = (JSONObject) JSONObject.toJSON(project);
        product.put("img_list", imgList.toString());
        product.put("product_list", productList.toString());
        product.put("crow_status", crow_status);

        return R.ok().put("data", product);
    }

}
