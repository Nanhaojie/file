package io.renren.modules.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:52:36
 */
@Data
@TableName("tb_return_product")
public class ReturnProductEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	@TableId
	private Integer id;
	/**
	 * 关联项目id
	 */
	private Long projectId;
	/**
	 *
	 */
	private String productName;
	/**
	 * 产品颜色型号
	 */
	@NotEmpty(message = "产品型号不能为空!")
	@Length(min=1, max = 50, message = "最多50个字符!")
	private String productParameter;
	/**
	 *
	 */
	private Date createTime;
	/**
	 *
	 */
	private Date updateTime;
	/**
	 *
	 */
	//private String spareStr1;
	/**
	 *
	 */
	//private String spareStr2;
	/**
	 *
	 */
	//private String spareStr3;
	/**
	 *
	 */
	//private Integer spareInt1;
	/**
	 *
	 */
	//private Integer spareInt2;
	/**
	 *
	 */
	//private Integer spareInt3;

}
