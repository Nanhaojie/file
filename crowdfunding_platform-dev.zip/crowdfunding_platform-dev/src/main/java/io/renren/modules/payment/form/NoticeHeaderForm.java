package io.renren.modules.payment.form;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class NoticeHeaderForm {

    @ApiModelProperty(value = "项目ID")
    @NotNull(message = "项目ID不能为空")
    private Integer projectId;


}
