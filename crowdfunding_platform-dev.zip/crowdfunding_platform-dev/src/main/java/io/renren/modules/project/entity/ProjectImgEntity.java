package io.renren.modules.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:55:27
 */
@Data
@TableName("tb_project_img")
public class ProjectImgEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	@TableId
	private Integer id;
	/**
	 * 关联项目id
	 */
	private Long projectId;
	/**
	 * 图片_url
	 */
	private String imgUrl;
	/**
	 * 序号
	 */
	private Integer number;
	/**
	 * 图片类型：1：项目图片，2：项目详情图片
	 */
	//private Integer type;
	/**
	 * 图片所属展示端：1：pc端，2：移动端
	 */
	private Integer displayType;
	/**
	 *
	 */
	private Date createTime;
	/**
	 *
	 */
	private Date updateTime;
	/**
	 *
	 */
	//private String notes;
	/**
	 *
	 */
	//private String apsreStr1;
	/**
	 *
	 */
	//private String apsreStr2;
	/**
	 *
	 */
	//private String apsreStr3;
	/**
	 *
	 */
	//private Integer apsreInt1;
	/**
	 *
	 */
	//private Integer apsreInt2;
	/**
	 *
	 */
	//private Integer apsreInt3;

}
