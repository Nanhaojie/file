/**
 * Copyright (c) 2016-2019 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package io.renren.modules.app.service.impl;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.exception.RRException;
import io.renren.config.WeChatConfig;
import io.renren.modules.app.dao.UserDao;
import io.renren.modules.app.entity.UserEntity;
import io.renren.modules.app.form.LoginForm;
import io.renren.modules.app.service.UserService;
//import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


@Service("userService")
public class UserServiceImpl extends ServiceImpl<UserDao, UserEntity> implements UserService {

//	@Override
//	public UserEntity queryByMobile(String mobile) {
//		return baseMapper.selectOne(new QueryWrapper<UserEntity>().eq("mobile", mobile));
//	}
    @Autowired
	public RestTemplate restTemplate;

	@Autowired
	private WeChatConfig weChatConfig;


	@Override
	public UserEntity queryByOpenId(JSONObject jsonObject) {
		String openId = jsonObject.getString("openid");
		String unionid = jsonObject.getString("unionid");
		String sessionKey = jsonObject.getString("session_key");
		UserEntity user = baseMapper.selectOne(new QueryWrapper<UserEntity>().eq("open_id", openId));
		// 如果为空就创建用户
		if (user == null) {
			user = new UserEntity();
			user.setType(1);
			user.setOpenId(openId);
			user.setUnionId(unionid);
			user.setIsStaff(0);
			user.setIsActive(1);
			user.setDateJoined(new Date());
			user.setUpdateTime(new Date());
			user.setSessionKey(sessionKey);
			this.save(user);
		} else {
			user.setSessionKey(sessionKey);
			this.updateById(user);
		}
		return user;
	}

	// 根据code获取微信用户openid
	@Override
	public JSONObject getUserOpenId(String code){
		System.out.println("333333333333");

		String url = "https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code";
		Map<String, String> requestMap = new HashMap<>();
		requestMap.put("appid", weChatConfig.getAppid());
		requestMap.put("secret", weChatConfig.getAppSecret());
		requestMap.put("code", code);
		System.out.println("44444444444444");

		ResponseEntity<String> responseEntity = restTemplate.getForEntity(url, String.class, requestMap);
		System.out.println("555555555555");

		JSONObject jsonObject = JSONObject.parseObject(responseEntity.getBody());
		System.out.println("code登录返回信息:"+responseEntity.getBody());

		// 测试
//		JSONObject jsonObject = new JSONObject();
//		jsonObject.put("openid", code);
//		jsonObject.put("unionid", code);

		return jsonObject;
	}

	@Override
	public UserEntity login(LoginForm form) {
		JSONObject jsonObject = getUserOpenId(form.getCode());
		System.out.println("666666666666666");

		// 调用微信返回错误信息
		if (jsonObject.containsKey("errcode")) {
			throw new RRException(jsonObject.getString("errmsg"));
		}
		UserEntity user = queryByOpenId(jsonObject);

//		Assert.isNull(user, "手机号或密码错误");

		//密码错误
//		if(!user.getPassword().equals(DigestUtils.sha256Hex(form.getPassword()))){
//			throw new RRException("手机号或密码错误");
//		}

		return user;
	}
}
