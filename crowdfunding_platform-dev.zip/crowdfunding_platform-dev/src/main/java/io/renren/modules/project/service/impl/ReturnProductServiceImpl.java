package io.renren.modules.project.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;
import io.renren.modules.project.dao.ReturnProductDao;
import io.renren.modules.project.entity.ReturnProductEntity;
import io.renren.modules.project.service.ReturnProductService;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service("returnProductService")
public class ReturnProductServiceImpl extends ServiceImpl<ReturnProductDao, ReturnProductEntity> implements ReturnProductService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<ReturnProductEntity> page = this.page(
                new Query<ReturnProductEntity>().getPage(params),
                new QueryWrapper<ReturnProductEntity>()
        );

        return new PageUtils(page);
    }

}
