package io.renren.modules.receiving_addr.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-17 10:42:40
 */
@Data
@TableName("tb_receiving_addr")
@ApiModel(description = "收货地址")
public class ReceivingAddrEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    @TableId
    private Long id;
    /**
     * 收货人姓名
     */
    @ApiModelProperty(value = "收货人姓名")
//    @NotNull(message = "收货人姓名不能为空!")
    @Length(min=1, max = 100, message = "收货人姓名长度1-100个字符!")
    private String name;
    /**
     *
     */
    @ApiModelProperty(value = "手机号")
    private String mobile;
    /**
     *
     */
    @ApiModelProperty(value = "用户id")
    private Long userId;
    /**
     *
     */
    @ApiModelProperty(value = "省份行政区号")
    private Integer provinceId;

    @TableField(exist=false)
    private String provinceName;
    /**
     *
     */
    @ApiModelProperty(value = "城市行政区号")
    private Integer cityId;

    @TableField(exist=false)
    private String cityName;
    /**
     *
     */
    @ApiModelProperty(value = "区县行政区号")
    private Integer countyId;

    @TableField(exist=false)
    private String countyName;
    /**
     *
     */
    @ApiModelProperty(value = "详细地址")
//    @NotNull(message = "详细地址不能为空!")
    private String detailedAddress;
    /**
     *
     */
    @ApiModelProperty(value = "是否是默认地址")
    private Integer isDefault;
    /**
     *
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;
    /**
     *
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;
    /**
     *
     */
    @ApiModelProperty(value = "是否最后使用地址")
    private Integer isLastUse;
//	/**
//	 *
//	 */
//	private String notes;
//	/**
//	 *
//	 */
//	private String spareStr1;
//	/**
//	 *
//	 */
//	private String spareStr2;
//	/**
//	 *
//	 */
//	private String spareStr3;
//	/**
//	 *
//	 */
//	private Integer spareInt1;
//	/**
//	 *
//	 */
//	private Integer spareInt2;
//	/**
//	 *
//	 */
//	private Integer spareInt3;

}
