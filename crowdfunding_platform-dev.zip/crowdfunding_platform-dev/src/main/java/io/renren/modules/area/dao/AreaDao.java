package io.renren.modules.area.dao;

import io.renren.modules.area.entity.AreaEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-17 10:49:06
 */
@Mapper
public interface AreaDao extends BaseMapper<AreaEntity> {
	
}
