package io.renren.modules.project.dao;

import io.renren.modules.project.entity.ProjectEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-12 13:59:39
 */
@Mapper
public interface ProjectDao extends BaseMapper<ProjectEntity> {
	
}
