package io.renren.modules.receiving_addr.service;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import io.renren.common.utils.PageUtils;
import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;

import java.util.List;
import java.util.Map;

/**
 * @author yyb
 * @email yyb@gmail.com
 * @date 2022-05-17 10:42:40
 */
public interface ReceivingAddrService extends IService<ReceivingAddrEntity> {

    PageUtils queryPage(Map<String, Object> params);

    // 将该用户全部地址修改为非默认地址
    void cancelOtherDefault(ReceivingAddrEntity entity);

    // 获取默认地址
    Map<String,String> getDefaultAddr(Long userId);

    // 修改地址
    boolean updateById(ReceivingAddrEntity entity);

    // 更新最后使用地址
    void updateLastUseAddr(long addrId, long userId);

}

