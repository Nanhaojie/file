package io.renren.modules.receiving_addr.form;

import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;

@Data
public class AddrForm extends ReceivingAddrEntity {

    @ApiModelProperty(hidden = true)
    private Long id;

    @ApiModelProperty(value = "收货人姓名")
    @NotEmpty(message = "姓名不能为空")
    @Size(max = 100, message = "长度需要控制在100以内")
    private String name;
    /**
     *
     */
    @ApiModelProperty(value = "手机号")
    @NotNull(message = "手机号不能为空")
    @Pattern(regexp = "^((13[0-9])|(14(0|[5-7]|9))|(15([0-3]|[5-9]))|(16(2|[5-7]))|(17[0-8])|(18[0-9])|(19([0-3]|[5-9])))\\d{8}$",
            message = "手机号格式错误")
    private String mobile;
    /**
     *
     */
    @ApiModelProperty(value = "省份行政区号")
    @NotNull(message = "省份行政区号不能为空")
    private Integer provinceId;
    /**
     *
     */
    @ApiModelProperty(value = "城市行政区号")
    @NotNull(message = "城市行政区号不能为空")
    private Integer cityId;
    /**
     *
     */
    @ApiModelProperty(value = "区县行政区号")
    @NotNull(message = "区县行政区号不能为空")
    private Integer countyId;
    /**
     *
     */
    @ApiModelProperty(value = "详细地址")
    @NotEmpty(message = "详细地址不能为空")
    @Length(max = 500, message = "详细地址长度1-500个字符!")
    private String detailedAddress;
    /**
     *
     */
    @ApiModelProperty(value = "是否是默认地址")
    private Integer isDefault;

    @ApiModelProperty(hidden = true)
    private Long userId;

    @ApiModelProperty(hidden = true)
    private Date createTime;

    @ApiModelProperty(hidden = true)
    private Date updateTime;
}

