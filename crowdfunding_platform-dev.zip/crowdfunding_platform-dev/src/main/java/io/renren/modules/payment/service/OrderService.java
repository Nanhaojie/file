package io.renren.modules.payment.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.payment.entity.OrderEntity;
import io.renren.modules.payment.form.OrderListForm;

import java.util.Map;

public interface OrderService extends IService<OrderEntity> {

    PageUtils queryPage(Map<String, Object> params);

    PageUtils queryPage(OrderListForm params);

    OrderEntity queryByOrderNo(String orderNo);

    Integer getUserOrderCount(Integer userId);
}
