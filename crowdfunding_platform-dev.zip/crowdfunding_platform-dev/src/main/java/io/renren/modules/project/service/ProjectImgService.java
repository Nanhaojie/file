package io.renren.modules.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.project.entity.ProjectImgEntity;

import java.util.Map;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:55:27
 */
public interface ProjectImgService extends IService<ProjectImgEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

