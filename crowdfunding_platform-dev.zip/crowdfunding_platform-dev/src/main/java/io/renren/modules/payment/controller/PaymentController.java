package io.renren.modules.payment.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder;
import com.wechat.pay.contrib.apache.httpclient.util.AesUtil;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;
import io.renren.common.validator.ValidatorUtils;
import io.renren.config.WeChatConfig;
import io.renren.modules.app.annotation.Login;
import io.renren.modules.app.annotation.LoginUser;
import io.renren.modules.app.entity.UserEntity;
import io.renren.modules.payment.entity.NoticeRecordEntity;
import io.renren.modules.payment.entity.OrderEntity;
import io.renren.modules.payment.form.NoticeBodyForm;
import io.renren.modules.payment.form.NoticeHeaderForm;
import io.renren.modules.payment.form.PlaceOrderForm;
import io.renren.modules.payment.service.NoticeRecordService;
import io.renren.modules.payment.service.OrderService;
import io.renren.modules.payment.utils.PaymentUtils;
import io.renren.modules.project.entity.ProjectEntity;
import io.renren.modules.project.service.ProjectService;
import io.renren.modules.receiving_addr.service.ReceivingAddrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/applet")
@Api(tags = {"APP支付相关接口"})
public class PaymentController {

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    private OrderService orderService;
    private Object OrderEntity;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private NoticeRecordService noticeRecordService;

    @Autowired
    private ReceivingAddrService receivingAddrService;

    /**
     * 下单
     */
    @Login
    @PostMapping("payment/placeOrder")
    @ApiOperation("支付下单")
    public R placeOrder(@LoginUser UserEntity user, @RequestBody PlaceOrderForm form) {
        // 表单校验
        ValidatorUtils.validateEntity(form);

        // 订单号
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String datetimeStr = formatter.format(new Date());
        String order_no = datetimeStr + getRandom2(6);

        // 构造请求参数 requestJson
        JSONObject requestJson = new JSONObject();
        requestJson.put("appid", weChatConfig.getAppid());
        requestJson.put("mchid", weChatConfig.getMchid());
        requestJson.put("description", form.getProductParam());
        requestJson.put("out_trade_no", order_no);
        requestJson.put("notify_url", weChatConfig.getNotifyUrl());
        JSONObject amount = new JSONObject();
        // 计算支付总金额
        Integer productNumber = form.getProductNumber();
        Integer projectId = form.getProjectId();
        ProjectEntity projectEntity = projectService.getObjectById(projectId);
        BigDecimal price;
        Boolean isEarlyBird = projectEntity.getIsEarlyBird();
        if (isEarlyBird) {
            price = projectEntity.getEarlyBirdPrice();
        } else {
            price = projectEntity.getCrowdfundingPrice();
        }
        // 金额防篡改
        Integer total = price.multiply(new BigDecimal(productNumber*100)).intValue();
        // 测试写法
//        Integer total = form.getPaymentAmount();

        amount.put("total", total);
        requestJson.put("amount", amount);
        JSONObject payer = new JSONObject();
        payer.put("openid", user.getOpenId());
        requestJson.put("payer", payer);
        String requestJsonStr = requestJson.toString();
        String url = "https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi";
        PaymentUtils paymentUtils = new PaymentUtils();
        String ret = paymentUtils.basePostRequest(url, requestJsonStr, weChatConfig);
        System.out.println(ret);
        if (ret == null) {
            return R.error("发起支付失败");
        }
        // 成功数据入库
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setUserId(user.getId());
        orderEntity.setProjectId(form.getProjectId());
        orderEntity.setOrderNumber(order_no);
        orderEntity.setPrepayId(user.getOpenId());  // 联调的时候看返回数据格式
        orderEntity.setProductParam(projectEntity.getProjectName() + "(" + form.getProductParam() + ")");
        orderEntity.setProductNumber(form.getProductNumber());
        orderEntity.setPaymentAmount(total);
        orderEntity.setName(form.getName());
        orderEntity.setMobile(form.getMobile());
        orderEntity.setProvince(form.getProvince());
        orderEntity.setCity(form.getCity());
        orderEntity.setCountry(form.getCountry());
        orderEntity.setDetailedAddress(form.getDetailedAddress());
        orderEntity.setStatus(0);
        orderEntity.setCreateTime(new Date());
        orderEntity.setUpdateTime(new Date());
        orderEntity.setNotes(form.getNotes());
        orderEntity.setIsEarlyBirdPrice(isEarlyBird);
//        orderEntity.setBankType();    // 支付方式/银行
        orderService.save(orderEntity);

        // 更新最新使用收货地址
        Integer addrId = form.getAddrId();
        receivingAddrService.updateLastUseAddr(addrId, user.getId());

        // 生成签名给前端并返回
        Map<String, String> packageMap = (Map<String, String>) JSON.parse(ret);
        String packageStr = "prepay_id=" + packageMap.get("prepay_id");
        Map<String, Object> map = paymentUtils.createPayParams(packageStr, weChatConfig);

//        Map<String, Object> map = new HashMap<>();
//        map.put("test", "test");
        return R.ok().put("data", map);
    }

    public static String getRandom2(int len) {
        Random r = new Random();
        StringBuilder rs = new StringBuilder();
        for (int i = 0; i < len; i++) {
            rs.append(r.nextInt(10));
        }
        return rs.toString();
    }

    @PostMapping("payment/notice")
    @ApiOperation("支付通知")
    public R notice(@RequestHeader("Wechatpay-Timestamp") String timeStamp, @RequestHeader("Wechatpay-Nonce") String nonce, @RequestHeader("Wechatpay-Serial") String serial, @RequestHeader("Wechatpay-Signature") String signature, HttpServletRequest request) throws GeneralSecurityException, IOException, ParseException {
        NoticeRecordEntity noticeRecordEntity = new NoticeRecordEntity();
        noticeRecordEntity.setCreateTime(new Date());
        R ret = R.ok("SUCCESS", "失败");
        try {
            noticeRecordEntity.setWechatpayTimestamp(timeStamp);
            noticeRecordEntity.setWechatpayNonce(nonce);
            noticeRecordEntity.setWechatpaySerial(serial);
            noticeRecordEntity.setWechatpaySignature(signature);

            // request body json 读取请求体
            ServletInputStream inputStream = request.getInputStream();
            StringBuffer stringBuffer = new StringBuffer();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String s;
            while ((s = bufferedReader.readLine()) != null) {
                stringBuffer.append(s);
            }
            String s1 = stringBuffer.toString();
            noticeRecordEntity.setReqBody(s1);
            Map requestMap = (Map) JSON.parse(s1);

            // String id = requestMap.get("id");
            //通知的类型，支付成功通知的类型为TRANSACTION.SUCCESS
            String eventType = String.valueOf(requestMap.get("event_type"));
            String resource = String.valueOf(requestMap.get("resource"));
            noticeRecordEntity.setEventType(eventType);
            Map<String, String> requestMap2 = (Map) JSON.parse(resource);

            if (!eventType.equals("TRANSACTION.SUCCESS")) {
                System.out.println("微信返回支付失败");
                ret = R.ok("SUCCESS", "微信返回支付失败");
            } else {

                String associated_data = requestMap2.get("associated_data");
                String nonce_body = requestMap2.get("nonce");
                String ciphertext = requestMap2.get("ciphertext");

                // 验签
                PaymentUtils paymentUtils = new PaymentUtils();
                Boolean verify_ret = paymentUtils.responseSignVerify(serial, signature, timeStamp, nonce, s1, weChatConfig);
                if (!verify_ret) {
                    System.out.println("验签失败");
                    ret = R.ok("SUCCESS", "验签失败");
                } else {

                    // 解密
                    AesUtil wxAesUtil = new AesUtil(weChatConfig.getApiV3Key().getBytes());
                    String jsonStr = wxAesUtil.decryptToString(associated_data.getBytes(), nonce_body.getBytes(), ciphertext);
                    System.out.println(jsonStr);
                    Map<String, String> cipherJson = (Map) JSON.parse(jsonStr);
                    String orderNo = String.valueOf(cipherJson.get("out_trade_no"));
                    String transactionId = String.valueOf(cipherJson.get("transaction_id"));
                    String trade_state = String.valueOf(cipherJson.get("trade_state"));
                    String bankType = String.valueOf(cipherJson.get("bank_type"));
                    String successTime = String.valueOf(cipherJson.get("success_time"));
                    Date payTime = null;
                    SimpleDateFormat formatrer = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
                    payTime = formatrer.parse(successTime);
                    System.out.println("555555555555555555555555");

                    // 测试
                    //        String orderNo = "20220520105812398149567";
                    //        String transactionId = "4200001426202205205923421756";
                    //        Date payTime = new Date();
                    //        String bankType = "UPQUICKPASS_DEBIT";

                    // 入库
                    OrderEntity orderEntity = orderService.queryByOrderNo(orderNo);
                    orderEntity.setWxTransactionId(transactionId);
                    orderEntity.setUpdateTime(new Date());
                    orderEntity.setPayTime(payTime);
                    orderEntity.setBankType(bankType);
                    orderEntity.setStatus(1);
                    orderService.updateById(orderEntity);
                    System.out.println("666666666666666666666666666666666666");
                    //更新项目表 已筹金额 raised_amount 实际支付金额 actual_amount 支持人数 people_number 实际购买人数 actual_people_number  人数去重
                    Integer paymentAmount = orderEntity.getPaymentAmount();
                    Integer count = orderService.getUserOrderCount((int)orderEntity.getUserId());
                    ProjectEntity projectEntity = projectService.getObjectById(orderEntity.getProjectId());
                    BigDecimal raisedAmount = projectEntity.getRaisedAmount();
                    BigDecimal paymentAmount1 = new BigDecimal(paymentAmount);
                    BigDecimal scale = new BigDecimal(100);
                    BigDecimal addAmount = paymentAmount1.divide(scale);
                    BigDecimal newRaisedAmount = raisedAmount.add(addAmount);
                    BigDecimal actualAmount = projectEntity.getActualAmount();
                    BigDecimal newActualAmount = actualAmount.add(addAmount);
                    projectEntity.setRaisedAmount(newRaisedAmount);
                    projectEntity.setActualAmount(newActualAmount);
                    //购买人数更新
                    Integer addProductNumber = orderEntity.getProductNumber();
                    System.out.println("=============addProductNumber:"+addProductNumber);
                    Integer productNum = projectEntity.getProductNumber();
                    System.out.println("===============productNum:"+productNum);
                    Integer finalProductNum = productNum+addProductNumber;
                    System.out.println("=============finalProductNum:"+String.valueOf(finalProductNum));
                    projectEntity.setProductNumber(finalProductNum);
                    //更新进度
                    DecimalFormat df = new DecimalFormat("0.00%");
                    BigDecimal targetAmount = projectEntity.getTargetAmount();
                    String process = df.format(newRaisedAmount.divide(targetAmount, 4, BigDecimal.ROUND_DOWN));
                    projectEntity.setProgress(process);

                    if (count == 1){
                        Integer peopleNumber = projectEntity.getPeopleNumber() + 1;
                        Integer actualPeopleNumber = projectEntity.getActualPeopleNumber() + 1;
                        projectEntity.setPeopleNumber(peopleNumber);
                        projectEntity.setActualPeopleNumber(actualPeopleNumber);
                    }
                    System.out.println("projectService:");
                    System.out.println(projectEntity.getProductNumber());
                    projectService.updateById(projectEntity);

                    ret = R.ok("SUCCESS", "成功");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //  存储日志
            noticeRecordEntity.setRespBody(ret.toString());
            noticeRecordService.save(noticeRecordEntity);
        }
        return ret;
    }

    /**
     * 小程序信息
     */
    @Login
    @GetMapping("order/info")
    @ApiOperation("订单详情nhj")
    public R appInfo(@RequestAttribute("userId") Integer userId,
                     @RequestParam Map<String, Object> page,
                     @RequestParam(required = false) Integer status) {
        page.put("userId", userId);
        page.put("status", status);
        PageUtils pages = orderService.queryPage(page);
        return R.ok().put("data", pages);
    }


}
