package io.renren.modules.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.project.entity.ReturnProductEntity;

import java.util.Map;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:52:36
 */
public interface ReturnProductService extends IService<ReturnProductEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

