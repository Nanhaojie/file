package io.renren.modules.project.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.project.dao.ProjectDao;
import io.renren.modules.project.entity.ProjectEntity;
import io.renren.modules.project.service.ProjectService;


@Service("projectService")
public class ProjectServiceImpl extends ServiceImpl<ProjectDao, ProjectEntity> implements ProjectService {
    private int crowStatus;

    public static int day(Date start_time, Date endDay) {
        try {
            Date star = start_time;//开始时间
            Date nextDay=star;
            int i=0;
            while(nextDay.before(endDay)){//当明天不在结束时间之前是终止循环
                Calendar cld = Calendar.getInstance();
                cld.setTime(star);
                cld.add(Calendar.DATE, 1);
                star = cld.getTime();
                //获得下一天日期字符串
                nextDay = star;
                i++;
            }
            return +i;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<ProjectEntity> queryWrapper = new QueryWrapper<ProjectEntity>();
        queryWrapper.orderByDesc("create_time");
        IPage<ProjectEntity> page = this.page(
                new Query<ProjectEntity>().getPage(params),
                queryWrapper
        );
        List<ProjectEntity> records = page.getRecords();
        for (ProjectEntity record : records) {
            /*更新众筹流程*/
            String now_time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            Date now_time_date = null;
            try {
                now_time_date = new SimpleDateFormat("yyyy-MM-dd").parse(now_time);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date prepareTime = record.getPrepareTime();
            Date startTime  = record.getStartTime();
            Date endTime = record.getEndTime();
            Date sendGoodsTime = record.getSendGoodsTime();
            int pre_start = day(prepareTime, startTime);
            int pre_end = day(prepareTime, endTime);
            int pre_send = day(prepareTime, sendGoodsTime);
            int pre_now = day(prepareTime, now_time_date);

            if (pre_now<pre_start){
                // 项目筹备
                crowStatus = 1;
            }else if(pre_now<pre_end){
                // 众筹开始
                crowStatus = 2;
            }else if(pre_now<pre_send){
                // 众筹结束
                crowStatus = 3;
            }else{
                // 发货
                crowStatus = 4;
            }
            record.setCrowStatus(crowStatus);
        }
        return new PageUtils(page);
    }

    @Override
    public ProjectEntity getObjectById(Integer id){
        ProjectEntity projectEntity = baseMapper.selectOne(new QueryWrapper<ProjectEntity>().eq("id", id));
        return projectEntity;
    }

}
