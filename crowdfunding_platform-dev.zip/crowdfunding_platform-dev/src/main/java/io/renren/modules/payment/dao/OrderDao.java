package io.renren.modules.payment.dao;

import io.renren.modules.payment.entity.OrderEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单表
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-19 09:42:01
 */
@Mapper
public interface OrderDao extends BaseMapper<OrderEntity> {

}
