package io.renren.modules.project.controller;

import io.renren.common.exception.RRException;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;
import io.renren.modules.oss.cloud.OSSFactory;
import io.renren.modules.project.entity.ProjectImgEntity;
import io.renren.modules.project.service.ProjectImgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.Map;


/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:55:27
 */
@RestController
@RequestMapping("project/projectimg")
@Api(tags = {"图片上传"})
public class ProjectImgController {
    @Autowired
    private ProjectImgService projectImgService;

    /**
     * 列表
     */
    @GetMapping("/list")
    /*@ApiOperation("图片列表")*/
    /*@RequiresPermissions("project:projectimg:list")*/
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = projectImgService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @GetMapping("/info/{id}")
    /*@ApiOperation("图片详情")*/
    /*@RequiresPermissions("project:projectimg:info")*/
    public R info(@PathVariable("id") Integer id){
		ProjectImgEntity projectImg = projectImgService.getById(id);

        return R.ok().put("projectImg", projectImg);
    }

    /**
     * 保存
     */
    @PostMapping("/save")
/*    @ApiOperation("添加图片")*/
    /*@RequiresPermissions("project:projectimg:save")*/
    public R save(@RequestBody ProjectImgEntity projectImg){
		projectImgService.save(projectImg);

        return R.ok();
    }

    //图片上传
    @PostMapping(value = "/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiOperation("上传图片")
    public R upload(@RequestParam("file") MultipartFile file,
                    @RequestParam(required = false,name = "number") String number,
                    @RequestParam(required = false,name ="display_type") String display_type) throws Exception {
        if (file.isEmpty()) {
            throw new RRException("上传文件不能为空");
        }

        //上传文件
        String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        String url = OSSFactory.build().uploadSuffix(file.getBytes(), suffix);
        ProjectImgEntity projectImg = new ProjectImgEntity();
        projectImg.setImgUrl(url);
        if (number != null){
            projectImg.setNumber(Integer.valueOf(number));
        }
        if (display_type!=null){
            projectImg.setDisplayType(Integer.valueOf(display_type));
        }
        return R.ok().put("data", projectImg);
    }


    /**
     * 修改
     */
    @PostMapping("/update")
    /*@ApiOperation("修改图片信息")*/
    /*@RequiresPermissions("project:projectimg:update")*/
    public R update(@RequestBody ProjectImgEntity projectImg){
		projectImgService.updateById(projectImg);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
/*    @ApiOperation("删除图片")*/
    /*@RequiresPermissions("project:projectimg:delete")*/
    public R delete(@RequestBody Integer[] ids){
		projectImgService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
