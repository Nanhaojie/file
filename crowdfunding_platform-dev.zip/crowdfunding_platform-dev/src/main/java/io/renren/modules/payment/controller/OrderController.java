package io.renren.modules.payment.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import io.renren.common.utils.DateUtils;
import io.renren.modules.app.service.UserService;
import io.renren.modules.payment.form.OrderListForm;
import io.renren.modules.project.service.ProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.renren.modules.payment.entity.OrderEntity;
import io.renren.modules.payment.service.OrderService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;

import javax.validation.Valid;


/**
 * 订单表
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-19 09:42:01
 */
@RestController
@RequestMapping("payment/order")
@Api(tags = {"订单管理"})
public class OrderController {
    @Autowired
    private OrderService orderService;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private UserService userService;

    /**
     * 列表
     */
    @GetMapping ("/list")
    @ApiOperation("订单列表nhj")
    public R list(@Valid OrderListForm query){
        PageUtils pages = orderService.queryPage(query);

        return R.ok().put("page", pages);
    }


    /**
     * 信息
     */
    @GetMapping("/info/{id}")
    @ApiOperation("订单详情nhj")
    public R info(@PathVariable("id") Integer id){
		OrderEntity order = orderService.getById(id);
        Integer projectId = order.getProjectId();
        String projectImgUrl = projectService.getById(projectId).getProjectImgUrl();
        order.setProjectImgUrl(projectImgUrl);
        String sponsor = projectService.getById(projectId).getSponsor();
        order.setSponsor(sponsor);
        String sponsorImgUrl = projectService.getById(projectId).getSponsorImgUrl();
        order.setSponsorImgUrl(sponsorImgUrl);
        String projectName = projectService.getById(projectId).getProjectName();
        order.setProjectName(projectName);
        if ("UPQUICKPASS_DEBIT".equals(order.getBankType())){
            order.setBankType("2");
        }else {
            order.setBankType("1");
        }
        long userId = order.getUserId();
        try {
            String phone = userService.getById(userId).getMobile();
            order.setUserPhone(phone);
        }catch (Exception e){
            System.out.println("--------");
            System.out.println(order.getUserId());
        }

        return R.ok().put("order", order);
    }

    /**
     * 保存
     */
    @PostMapping("/save")
    public R save(@RequestBody OrderEntity order){
		orderService.save(order);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @ApiOperation("修改订单收货地址nhj")
    public R update(@RequestBody OrderEntity order){
		orderService.updateById(order);

        return R.ok();
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public R delete(@RequestBody Integer[] ids){
		orderService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
