package io.renren.modules.project.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;
import io.renren.modules.project.dao.ProjectImgDao;
import io.renren.modules.project.entity.ProjectImgEntity;
import io.renren.modules.project.service.ProjectImgService;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service("projectImgService")
public class ProjectImgServiceImpl extends ServiceImpl<ProjectImgDao, ProjectImgEntity> implements ProjectImgService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<ProjectImgEntity> page = this.page(
                new Query<ProjectImgEntity>().getPage(params),
                new QueryWrapper<ProjectImgEntity>()
        );

        return new PageUtils(page);
    }

}
