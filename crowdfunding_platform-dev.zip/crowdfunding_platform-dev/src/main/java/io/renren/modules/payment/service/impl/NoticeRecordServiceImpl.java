package io.renren.modules.payment.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.payment.dao.NoticeRecordDao;
import io.renren.modules.payment.entity.NoticeRecordEntity;
import io.renren.modules.payment.service.NoticeRecordService;


@Service("noticeRecordService")
public class NoticeRecordServiceImpl extends ServiceImpl<NoticeRecordDao, NoticeRecordEntity> implements NoticeRecordService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<NoticeRecordEntity> page = this.page(
                new Query<NoticeRecordEntity>().getPage(params),
                new QueryWrapper<NoticeRecordEntity>()
        );

        return new PageUtils(page);
    }

}