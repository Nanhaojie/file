package io.renren.modules.payment.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 订单表
 *
 * @author zwz
 * @email test@gmail.com
 * @date 2022-05-17 15:52:55
 */
@Data
@TableName("t_order")
public class OrderEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	@TableId
	private Integer id;
	/**
	 *
	 */
	private long userId;
	/**
	 *
	 */
	private Integer projectId;
	/**
	 *
	 */
	private String orderNumber;
	/**
	 *
	 */
	private String wxTransactionId;
	/**
	 *
	 */
	private String prepayId;
	/**
	 *
	 */
	private String productParam;
	/**
	 *
	 */
	private Integer productNumber;
	/**
	 *
	 */
	private Integer paymentAmount;
	/**
	 *
	 */
	private String name;
	/**
	 *
	 */
	private String mobile;
	/**
	 *
	 */
	private String province;
	/**
	 *
	 */
	private String city;
	/**
	 *
	 */
	private String country;
	/**
	 *
	 */
	private String detailedAddress;
	/**
	 *
	 */
	private Integer status;
	/**
	 *
	 */
	private Date payTime;
	/**
	 *
	 */
	private Date createTime;
	/**
	 *
	 */
	private Date updateTime;
	/**
	 *
	 */
	private String notes;

	private Boolean isEarlyBirdPrice;
	private String bankType;

	@TableField(exist=false)
	private String projectImgUrl;

	@TableField(exist=false)
	private String sponsor;

	@TableField(exist=false)
	private String sponsorImgUrl;

	@TableField(exist=false)
	private String projectName;

	@TableField(exist=false)
	private String userPhone;

}
