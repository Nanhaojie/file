package io.renren.modules.app.controller;


import com.alibaba.fastjson.JSON;
//import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import io.renren.common.utils.R;
import io.renren.modules.app.annotation.Login;
import io.renren.modules.app.annotation.LoginUser;
import io.renren.modules.app.entity.UserEntity;
import io.renren.modules.app.form.DecryptDataForm;
import io.renren.modules.app.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.codec.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/applet/user")
@Api(tags = "App用户")
public class AppUserController {

    @Autowired
    private UserService userService;

    @Login
    @PutMapping("/updatePhone")
    @ApiOperation("更新用户手机号")
    public R updatePhone(@LoginUser UserEntity userEntity, @RequestBody DecryptDataForm decryptDataForm) {
        // 解密数据
        String sessionKey = userEntity.getSessionKey();
        byte[] encData = Base64.decode(decryptDataForm.getEncryptedData());
        byte[] iv = Base64.decode(decryptDataForm.getIv());
        byte[] key = Base64.decode(sessionKey);
        try {
            AlgorithmParameterSpec ivSpec = new IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            String decryptData = new String(cipher.doFinal(encData), "UTF-8");
            Map decryptJson = (Map) JSON.parse(decryptData);
            String phoneNumber = String.valueOf(decryptJson.get("phoneNumber"));
            userEntity.setMobile(phoneNumber);
            userService.updateById(userEntity);
            Map<String, Object> map = new HashMap<>();
            map.put("mobile", phoneNumber);
            return R.ok(map);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return R.error("解密失败1");
        } catch (BadPaddingException e) {
            e.printStackTrace();
            return R.error("解密失败2");
        } catch (InvalidKeyException e) {
            e.printStackTrace();
            return R.error("解密失败3");
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
            return R.error("解密失败4");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return R.error("解密失败5");
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
            return R.error("解密失败5");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return R.error("解密失败7");
        }
    }
}
