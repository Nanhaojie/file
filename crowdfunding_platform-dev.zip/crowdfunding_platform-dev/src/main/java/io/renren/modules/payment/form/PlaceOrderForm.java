package io.renren.modules.payment.form;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel(value = "下单表单")
public class PlaceOrderForm {

    @ApiModelProperty(value = "项目ID")
    @NotNull(message = "项目ID不能为空")
    private Integer projectId;

    @ApiModelProperty(value = "项目参数")
    @NotBlank(message = "项目参数不能为空")
    private String productParam;

    @ApiModelProperty(value = "产品数量")
    @NotNull(message = "产品数量不能为空")
    private Integer productNumber;

    @ApiModelProperty(value = "支付金额.单位：分")
    @NotNull(message = "支付金额不能为空")
    private Integer paymentAmount;

    @ApiModelProperty(value = "收货人姓名")
    @NotBlank(message = "收货人姓名不能为空")
    private String name;

    @ApiModelProperty(value = "收货人手机号")
    @NotBlank(message = "收货人手机号不能为空")
    private String mobile;

    @ApiModelProperty(value = "省份")
    @NotBlank(message = "省份不能为空")
    private String province;

    @ApiModelProperty(value = "市")
    @NotBlank(message = "市不能为空")
    private String city;

    @ApiModelProperty(value = "区/县")
    @NotBlank(message = "区/县不能为空")
    private String country;

    @ApiModelProperty(value = "详细地址")
    @NotBlank(message = "详细地址不能为空")
    private String detailedAddress;

    @ApiModelProperty(value = "是否早鸟价")
    @NotNull(message = "是否早鸟价不能为空")
    private boolean isEarlyBirdPrice;

    @ApiModelProperty(value = "备注")
    private String notes;

    @ApiModelProperty(value = "收货地址id")
    @NotNull(message = "收货地址id不能为空")
    private Integer addrId;
}
