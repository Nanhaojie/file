package io.renren.modules.project.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.renren.modules.project.entity.ProjectImgEntity;
import io.renren.modules.project.entity.ReturnProductEntity;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;


/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-12 13:59:39
 */
@Data
@TableName("tb_project")
public class ProjectEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 主键
	 */
	@TableId
	private Integer id;
	/**
	 * 项目名称
	 */
	@NotEmpty(message = "产品名字不能为空!")
	@Length(max = 100, message = "产品名字不能超过100个字符!")
	private String projectName;
	/**
	 * 项目描述
	 */
	@NotEmpty(message = "项目描述不能为空!")
	@Length(max = 100, message = "项目描述不能超过100个字符!")
	private String projectDescribe;
	/**
	 * 众筹价
	 */
	@Range(min=1, max=100000, message="众筹价金额需要在1-100000!")
	@NotNull(message = "众筹价不能为空!")
	@Digits(integer=6, fraction=2, message = "不能超过两位小数!")
	private BigDecimal crowdfundingPrice;
	/**
	 * 早鸟价
	 */
	@Range(min=1, max=100000, message="早鸟价金额需要在1-100000!")
	@Digits(integer=6, fraction=2, message = "不能超过两位小数!")
	@TableField(updateStrategy = FieldStrategy.IGNORED,insertStrategy = FieldStrategy.IGNORED)
	private BigDecimal earlyBirdPrice;
	/**
	 * 早鸟价开始时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	@TableField(updateStrategy = FieldStrategy.IGNORED,insertStrategy = FieldStrategy.IGNORED)
	private Date earlyBirdStartTime;
	/**
	 * 早鸟价结束时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	@TableField(updateStrategy = FieldStrategy.IGNORED,insertStrategy = FieldStrategy.IGNORED)
	private Date earlyBirdEndTime;
	/**
	 * 目标金额
	 */
	@NotNull(message = "目标金额不能为空!")
	@Range(min=1, max=100000000, message="金额需要在1-100000000!")
	@Positive(message = "目标金额必须为正整数!")
	@Digits(integer=9, fraction=0, message = "目标金额必须为正整数!")
	private BigDecimal targetAmount;
	/**
	 * 已筹金额
	 */
	private BigDecimal  raisedAmount;
	/**
	 * 实际支付金额
	 */
	private BigDecimal  actualAmount;
	/**
	 * 支持人数
	 */
	private Integer peopleNumber;
	/**
	 * 实际购买人数
	 */
	private Integer actualPeopleNumber;
	/**
	 * 众筹准备时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	private Date prepareTime;
	/**
	 * 众筹开始时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	private Date startTime;
	/**
	 * 众筹结束时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	private Date endTime;
	/**
	 * 发货时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" , timezone = "GMT+8")
	private Date sendGoodsTime;
	/**
	 * 发起人
	 */
	@NotEmpty(message = "发起人不能为空!")
	@Length(max = 100, message = "发起人不能超过100个字符!")
	private String sponsor;
	/**
	 * 发起人介绍
	 */
	@NotEmpty(message = "发起人简介不能为空!")
	@Length(max = 100, message = "发起人简介不能超过100个字符!")
	private String sponsorIntroduction;
	/**
	 * 发起人图片
	 */
	@NotEmpty(message = "发起人图片不能为空!")
	private String sponsorImgUrl;
	/**
	 * 0：众筹失败
1：众筹成功
2：众筹中
	 */
	private Integer state;
	/**
	 * 众筹进度
	 */
	private String progress;
	/**
	 * 购买产品个数
	 */
	private Integer productNumber;
	/**
	 * 添加时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss" , timezone = "GMT+8")
	private Date createTime;
	/**
	 * 更新时间
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss" , timezone = "GMT+8")
	private Date updateTime;
	/**
	 * 备注
	 */
	//private String notes;
	/**
	 *
	 */
	//private String spareStr1;
	/**
	 *
	 */
	//private String spareStr2;
	/**
	 *
	 */
	//private String spareStr3;
	/**
	 *
	 */
	//private Integer spareInt1;
	/**
	 *
	 */
	//private Integer spareInt2;
	/**
	 *
	 */
	//private Integer spareInt3;
	/**
	 *
	 */
	private Integer leftDay;

	@NotEmpty(message = "项目图片不能为空!")
	private String projectImgUrl;

	private String supporter;

	private String privacy;

	private String risk;

	private String help;

	@TableField(exist = false)
	private List<ProjectImgEntity> imgList;

	@TableField(exist = false)
	private List<ReturnProductEntity> productList;

	@TableField(exist = false)
	private Integer isEarlyBird;

	@TableField(exist=false)
	private Integer crowStatus;


	public Boolean getIsEarlyBird() {
		Date startTime = this.getEarlyBirdStartTime();
		Date endTime = this.getEarlyBirdEndTime();
		Date nowDate = new Date();
		if (startTime != null & endTime != null){
			if (nowDate.getTime() >= startTime.getTime() & nowDate.getTime() <= endTime.getTime()) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
