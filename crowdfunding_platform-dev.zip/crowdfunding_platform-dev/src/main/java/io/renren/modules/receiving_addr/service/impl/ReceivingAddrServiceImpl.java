package io.renren.modules.receiving_addr.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import io.renren.common.exception.RRException;
import io.renren.modules.area.dao.AreaDao;
import io.renren.modules.area.entity.AreaEntity;
import io.renren.modules.area.service.AreaService;
import io.renren.modules.area.service.impl.AreaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.receiving_addr.dao.ReceivingAddrDao;
import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;
import io.renren.modules.receiving_addr.service.ReceivingAddrService;


@Service("receivingAddrService")
public class ReceivingAddrServiceImpl extends ServiceImpl<ReceivingAddrDao, ReceivingAddrEntity> implements ReceivingAddrService {

    @Autowired
    private AreaService AreaService;

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<ReceivingAddrEntity> queryWrapper = new QueryWrapper();
        queryWrapper.eq("user_id", params.get("userId"));

        IPage<ReceivingAddrEntity> page = this.page(
                new Query<ReceivingAddrEntity>().getPage(params, "id", false),
                queryWrapper
        );
        List<ReceivingAddrEntity> records = page.getRecords();
        for (ReceivingAddrEntity record: records){
            String countyName = AreaService.getById(record.getCountyId()).getFullname();
            record.setCountyName(countyName);
            String cityName = AreaService.getById(record.getCityId()).getFullname();
            record.setCityName(cityName);
            String ProvinceName = AreaService.getById(record.getProvinceId()).getFullname();
            record.setProvinceName(ProvinceName);
        }

        return new PageUtils(page);
    }

    @Override
    public void cancelOtherDefault(ReceivingAddrEntity entity) {
        getBaseMapper().update(null,
                new UpdateWrapper<ReceivingAddrEntity>()
                        .set("is_default", 0)
                        .eq("user_id", entity.getUserId()));
    }

    @Override
    public Map<String, String> getDefaultAddr(Long userId) {
        return getBaseMapper().selectDefaultAddr(userId);

    }

    @Override
    public boolean updateById(ReceivingAddrEntity entity) {
        if (entity.getIsDefault() == 1) {
            this.cancelOtherDefault(entity);
        }
        return SqlHelper.retBool(getBaseMapper().updateById(entity));
    }

    @Override
    public boolean save(ReceivingAddrEntity entity) {
        if (entity.getIsDefault() == 1) {
            this.cancelOtherDefault(entity);
        }

        // 查询城市行政编号是否存在
        HashSet<Integer> areaIDSet = new HashSet<>();
        areaIDSet.add(entity.getCityId());
        areaIDSet.add(entity.getCountyId());
        areaIDSet.add(entity.getProvinceId());

        if (AreaService.query().in("id", areaIDSet).count() != areaIDSet.size()){
            throw new RRException("行政编号不存在");
        }

        return SqlHelper.retBool(getBaseMapper().insert(entity));
    }

    @Override
    public void updateLastUseAddr(long addrId, long userId) {
        QueryWrapper<ReceivingAddrEntity> queryWrapper = new QueryWrapper<ReceivingAddrEntity>();
        queryWrapper.eq("user_id", userId).eq("is_last_use", 1);
        List<ReceivingAddrEntity> addrs = baseMapper.selectList(queryWrapper);
        if (addrs != null) {
            for (ReceivingAddrEntity addr: addrs) {
                if (addrId != addr.getId()){
                    addr.setIsLastUse(0);
                    baseMapper.updateById(addr);
                }
            }
        }
        ReceivingAddrEntity lastUseAddr = baseMapper.selectById(addrId);
        lastUseAddr.setIsLastUse(1);
        baseMapper.updateById(lastUseAddr);
    };

}