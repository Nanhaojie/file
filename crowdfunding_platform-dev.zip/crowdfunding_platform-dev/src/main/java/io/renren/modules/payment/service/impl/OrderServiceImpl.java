package io.renren.modules.payment.service.impl;

import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import io.renren.modules.app.entity.UserEntity;
import io.renren.modules.payment.dao.PaymentDao;
import io.renren.modules.payment.form.OrderListForm;
import io.renren.modules.project.entity.ProjectEntity;
import io.renren.modules.project.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.payment.entity.OrderEntity;
import io.renren.modules.payment.service.OrderService;


@Service("orderService")
public class OrderServiceImpl extends ServiceImpl<PaymentDao, OrderEntity> implements OrderService {

    @Autowired
    private ProjectService projectService;

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        QueryWrapper<OrderEntity> queryWrapper = new QueryWrapper<OrderEntity>();
        if (params.get("status") != null) {
            queryWrapper.eq("user_id", params.get("userId")).eq("status", params.get("status"));
        } else {
            queryWrapper.eq("user_id", params.get("userId"));
        }
        queryWrapper.orderByDesc("create_time");
        IPage<OrderEntity> page = this.page(
                new Query<OrderEntity>().getPage(params),
                queryWrapper
        );

        List<OrderEntity> records = page.getRecords();
        for (OrderEntity record : records) {
            Integer projectId = record.getProjectId();
            String projectImgUrl = projectService.getById(projectId).getProjectImgUrl();
            record.setProjectImgUrl(projectImgUrl);
            String sponsor = projectService.getById(projectId).getSponsor();
            record.setSponsor(sponsor);
            String sponsorImgUrl = projectService.getById(projectId).getSponsorImgUrl();
            record.setSponsorImgUrl(sponsorImgUrl);
            String projectName = projectService.getById(projectId).getProjectName();
            record.setProjectName(projectName);

            if ("UPQUICKPASS_DEBIT".equals(record.getBankType())){
                record.setBankType("2");
            }else {
                record.setBankType("1");
            }
        }

        return new PageUtils(page);
    }

    @Override
    public PageUtils queryPage(OrderListForm params) {
        QueryWrapper<OrderEntity> queryWrapper = new QueryWrapper<OrderEntity>();

        queryWrapper.eq(!params.getMobile().equals(""), "mobile", params.getMobile());
        queryWrapper.eq(!params.getOrderNumber().equals(""), "order_number", params.getOrderNumber());

        // 查新产品名称对应id
//        if (!params.getProjectName().equals("")) {
//            List<ProjectEntity> projectList = projectService.query()
//                    .select("id")
//                    .like("project_name", params.getProjectName()).list();
//
//            Set<Integer> projectIdList = projectList.stream().map(ProjectEntity::getId).collect(Collectors.toSet());
//            queryWrapper.in(!projectIdList.isEmpty(), "project_id", projectIdList);
//        }

        // 回报产品
        queryWrapper.like(params.getProjectName() != null, "product_param", params.getProjectName());

//        System.out.println("=+++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//        System.out.println(params.getStatus());
//        System.out.println("=+++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        queryWrapper.eq(params.getStatus() != null, "status", params.getStatus());

        queryWrapper.ge(params.getStartCreateTime() != null, "create_time", params.getStartCreateTime());
        queryWrapper.le(params.getEndCreateTime() !=null, "create_time", params.getEndCreateTime());
        queryWrapper.orderByDesc("create_time");


        HashMap<String, Object> pageMap = new HashMap<>();
        pageMap.put("page", params.getPage());
        pageMap.put("limit", params.getLimit());
        IPage<OrderEntity> page = this.page(
                new Query<OrderEntity>().getPage(pageMap, "id", false),
                queryWrapper
        );

        List<OrderEntity> records = page.getRecords();
        for (OrderEntity record : records) {
            ProjectEntity project = projectService.getById(record.getProjectId());
            record.setProjectName(project == null ? null: project.getProjectName());
        }

        return new PageUtils(page);
    }

    @Override
    public OrderEntity queryByOrderNo(String orderNo) {
        OrderEntity orderEntity = baseMapper.selectOne(new QueryWrapper<OrderEntity>().eq("order_number", orderNo));
        return orderEntity;
    }

    @Override
    public Integer getUserOrderCount(Integer userId) {
        QueryWrapper<OrderEntity> queryWrapper = new QueryWrapper<OrderEntity>();
        queryWrapper.eq("user_id", userId).between("status", 1,4);
        Integer count = baseMapper.selectCount(queryWrapper);
        return count;
    }

}
