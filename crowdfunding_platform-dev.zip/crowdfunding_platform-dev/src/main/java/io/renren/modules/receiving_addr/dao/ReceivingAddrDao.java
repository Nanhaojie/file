package io.renren.modules.receiving_addr.dao;

import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 
 * 
 * @author yyb
 * @email yyb@gmail.com
 * @date 2022-05-17 10:42:40
 */
@Mapper
public interface ReceivingAddrDao extends BaseMapper<ReceivingAddrEntity> {

    @Select("select " +
            "addr.id as id, addr.name as name, mobile, detailed_address as detailedAddress, is_default as isDefault, " +
            "province_id as provinceId, city_id as cityId, county_id as countyId, " +
            "province_area.fullname as provinceName, city_area.fullname as cityName, county_area.fullname as countyName " +
            "from " +
            "tb_receiving_addr addr, tb_area province_area, tb_area city_area, tb_area county_area " +
            "where " +
            "addr.user_id = #{userId} and addr.is_default = 1 and addr.province_id = province_area.id and " +
            "addr.city_id = city_area.id and addr.county_id = county_area.id " +
            "limit 1; ")
    Map<String,String> selectDefaultAddr(@Param("userId")Long userId);

	
}

