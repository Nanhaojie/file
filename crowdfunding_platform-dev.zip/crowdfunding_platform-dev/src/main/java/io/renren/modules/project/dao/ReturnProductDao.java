package io.renren.modules.project.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.project.entity.ReturnProductEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:52:36
 */
@Mapper
public interface ReturnProductDao extends BaseMapper<ReturnProductEntity> {

}
