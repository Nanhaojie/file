package io.renren.modules.payment.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 微信支付通知记录表
 * 
 * @author zwz
 * @email test@gmail.com
 * @date 2022-05-23 15:02:55
 */
@Data
@TableName("t_notice_record")
public class NoticeRecordEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId
	private Long id;
	/**
	 * 
	 */
	private String appid;
	/**
	 * 
	 */
	private String mchid;
	/**
	 * 
	 */
	private String orderNo;
	/**
	 * 
	 */
	private String transactionId;
	/**
	 * 
	 */
	private String eventType;
	/**
	 * 
	 */
	private String openid;
	/**
	 * 
	 */
	private String wechatpayTimestamp;
	/**
	 * 
	 */
	private String wechatpayNonce;
	/**
	 * 
	 */
	private String wechatpaySerial;
	/**
	 * 
	 */
	private String wechatpaySignature;
	/**
	 * 
	 */
	private String reqBody;
	/**
	 * 
	 */
	private String respHeader;
	/**
	 * 
	 */
	private String respBody;
	/**
	 * 
	 */
	private String decryptData;
	/**
	 * 
	 */
	private Date createTime;

}
