package io.renren.modules.receiving_addr.form;

import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

@Data
public class UpdateAddrForm extends AddrForm {

    @NotNull(message = "id不能为空")
    private Long id;

}
