package io.renren.modules.payment.form;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class NoticeBodyForm {

    @ApiModelProperty(value = "通知id")
    private String id;

    @ApiModelProperty(value = "通知时间")
    private String create_time;

    @ApiModelProperty(value = "通知类型")
    private String event_type;

    @ApiModelProperty(value = "通知资源数据类型")
    private String resource_type;

    @ApiModelProperty(value = "通知资源数据")
    private JSONObject resource;

    @ApiModelProperty(value = "回调摘要")
    private String summary;
}
