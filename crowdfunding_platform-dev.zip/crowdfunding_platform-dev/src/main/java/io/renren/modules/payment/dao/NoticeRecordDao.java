package io.renren.modules.payment.dao;

import io.renren.modules.payment.entity.NoticeRecordEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 微信支付通知记录表
 * 
 * @author zwz
 * @email test@gmail.com
 * @date 2022-05-23 15:02:55
 */
@Mapper
public interface NoticeRecordDao extends BaseMapper<NoticeRecordEntity> {
	
}
