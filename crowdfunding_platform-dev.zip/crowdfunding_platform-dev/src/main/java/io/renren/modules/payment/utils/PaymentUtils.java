package io.renren.modules.payment.utils;


import com.alibaba.fastjson.JSON;
import com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder;
import com.wechat.pay.contrib.apache.httpclient.util.PemUtil;
import io.netty.util.internal.StringUtil;
import io.renren.config.WeChatConfig;
import lombok.Data;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;


@Component
public class PaymentUtils {

//    @Autowired
//    private WeChatConfig weChatConfig;

//    private static String certificate =

    public String basePostRequest(String requestUrl, String requestJson, WeChatConfig weChatConfig) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {

//            FileInputStream fileInputStream = null;
//            fileInputStream = new FileInputStream(weChatConfig.getPlatformCretPath());

            String certData = weChatConfig.getCertificate().replace("-----BEGIN CERTIFICATE-----", "")
                    .replace("-----END CERTIFICATE-----", "")
                    .replaceAll("\\s+", "");
            byte[] byteCert = Base64.getDecoder().decode(certData);

            PrivateKey merchantPrivateKey = PemUtil.loadPrivateKey(new ByteArrayInputStream(weChatConfig.getPrivateKey().getBytes("utf-8")));
//            X509Certificate wechatpayCertificate = PemUtil.loadCertificate(new ByteArrayInputStream(weChatConfig.getCertificate().getBytes("utf-8")));
            X509Certificate wechatpayCertificate = PemUtil.loadCertificate(new ByteArrayInputStream(byteCert));
//            X509Certificate wechatpayCertificate = PemUtil.loadCertificate(fileInputStream);
            ArrayList<X509Certificate> listCertificates = new ArrayList<>();
            listCertificates.add(wechatpayCertificate);

            httpClient = WechatPayHttpClientBuilder.create()
                    .withMerchant(weChatConfig.getMchid(), weChatConfig.getSerialNo(), merchantPrivateKey)
                    .withWechatpay(listCertificates)
                    .build();

            HttpPost httpPost = new HttpPost(requestUrl);

            // NOTE: 建议指定charset=utf-8。低于4.4.6版本的HttpCore，不能正确的设置字符集，可能导致签名错误
            StringEntity reqEntity = new StringEntity(requestJson, ContentType.create("application/json", "utf-8"));
            httpPost.setEntity(reqEntity);
            httpPost.addHeader("Accept", "application/json");
            response = httpClient.execute(httpPost);
            entity = response.getEntity();
            return EntityUtils.toString(entity);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭流
        }
        return null;
    }

    /**
     * 微信支付-前端唤起支付参数
     * prepay_id=wx201410272009395522657a690389285100
     * @param packageStr 预下单接口返回数据 预支付交易会话标识	prepay_id
     * @return
     */
    public Map<String,Object> createPayParams(String packageStr, WeChatConfig weChatConfig) {
        Map<String,Object> resultMap = new HashMap<>();
        String nonceStr = getUUID();
        Long timestamp = System.currentTimeMillis() / 1000;
        String message = buildMessage(timestamp, nonceStr, packageStr, weChatConfig);
        String signature = null;
        try {
            signature = sign(message.getBytes("utf-8"), weChatConfig);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
//        Map packageJson = (Map) JSON.parse(packageStr);
        resultMap.put("appId", weChatConfig.getAppid());
        resultMap.put("timeStamp",timestamp.toString());
        resultMap.put("nonceStr",nonceStr);
        resultMap.put("package",packageStr);
        resultMap.put("signType","RSA");
        resultMap.put("paySign",signature);
        return resultMap;
    }

    public static String getUUID(){
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * 微信支付-前端唤起支付参数-签名
     * @param message 签名数据
     * @return
     */
    public String sign(byte[] message, WeChatConfig weChatConfig) {
        try{
            Signature sign = Signature.getInstance("SHA256withRSA");
            sign.initSign(getPrivateKey("weChatConfig.getKeyFilePath()", weChatConfig));
            sign.update(message);
            return Base64.getEncoder().encodeToString(sign.sign());
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 微信支付-前端唤起支付参数-构建签名参数
     * @param nonceStr 签名数据
     * @return
     */
    public String buildMessage(long timestamp, String nonceStr, String packageStr, WeChatConfig weChatConfig) {
        return weChatConfig.getAppid() + "\n"
                + timestamp + "\n"
                + nonceStr + "\n"
                + packageStr + "\n";
    }

    /**
     * 微信支付-前端唤起支付参数-获取商户私钥
     *
     * @param filename 私钥文件路径  (required)
     * @return 私钥对象
     */
    public static PrivateKey getPrivateKey(String filename, WeChatConfig weChatConfig) throws IOException {

//        String content = new String(Files.readAllBytes(Paths.get(filename)), "utf-8");
        try {
//            String privateKey = content.replace("-----BEGIN PRIVATE KEY-----", "")
            String privateKey = weChatConfig.getPrivateKey().replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s+", "");

            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePrivate(
                    new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKey)));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("当前Java环境不支持RSA", e);
        } catch (InvalidKeySpecException e) {
            throw new RuntimeException("无效的密钥格式");
        }
    }


    /**
     * 回调验签
     * https://pay.weixin.qq.com/wiki/doc/apiv3/wechatpay/wechatpay4_1.shtml
     * @param wechatpaySerial 回调head头部
     * @param wechatpaySignature 回调head头部
     * @param wechatpayTimestamp 回调head头部
     * @param wechatpayNonce 回调head头部
     * @param body 请求数据
     * @return
     */
    public boolean  responseSignVerify(String wechatpaySerial, String wechatpaySignature, String wechatpayTimestamp, String wechatpayNonce, String body, WeChatConfig weChatConfig) {
        FileInputStream fileInputStream = null;
        try {
            String signatureStr = buildVerifyMessage(wechatpayTimestamp, wechatpayNonce, body);
            Signature signer = Signature.getInstance("SHA256withRSA");

            String certData = weChatConfig.getCertificate().replace("-----BEGIN CERTIFICATE-----", "")
                    .replace("-----END CERTIFICATE-----", "")
                    .replaceAll("\\s+", "");
            byte[] byteCert = Base64.getDecoder().decode(certData);

//            fileInputStream = new FileInputStream(weChatConfig.getPlatformCretPath());
//            X509Certificate receivedCertificate = loadCertificate(fileInputStream);
            X509Certificate receivedCertificate = PemUtil.loadCertificate(new ByteArrayInputStream(byteCert));
            signer.initVerify(receivedCertificate);
            signer.update(signatureStr.getBytes(StandardCharsets.UTF_8));
            return signer.verify(Base64.getDecoder().decode(wechatpaySignature));
        } catch (Exception e ) {
            e.printStackTrace();
        }
//        finally {
//            if (fileInputStream != null) {
//                try {
//                    fileInputStream.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
        return false;
    }


    /**
     * 回调验签-加载微信平台证书
     * @param inputStream
     * @return
     */
    public static X509Certificate loadCertificate(InputStream inputStream) {
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X509");
            X509Certificate cert = (X509Certificate) cf.generateCertificate(inputStream);
            cert.checkValidity();
            return cert;
        } catch (CertificateExpiredException e) {
            throw new RuntimeException("证书已过期", e);
        } catch (CertificateNotYetValidException e) {
            throw new RuntimeException("证书尚未生效", e);
        } catch (CertificateException e) {
            throw new RuntimeException("无效的证书", e);
        }
    }
    /**
     * 回调验签-构建签名数据
     * @param
     * @return
     */
    public static String buildVerifyMessage(String wechatpayTimestamp, String wechatpayNonce, String body) {
        return wechatpayTimestamp + "\n"
                + wechatpayNonce + "\n"
                + body + "\n";
    }
}
