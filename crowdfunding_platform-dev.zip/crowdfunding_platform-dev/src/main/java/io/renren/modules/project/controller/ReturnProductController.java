package io.renren.modules.project.controller;

import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;
import io.renren.modules.project.entity.ReturnProductEntity;
import io.renren.modules.project.service.ReturnProductService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Map;


/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:52:36
 */
@RestController
@RequestMapping("project")
@Api(tags = {"测试接口"})
public class ReturnProductController {
    @Autowired
    private ReturnProductService returnProductService;

    @GetMapping("/test")
    @ApiOperation("测试接口返回数据")
    /*@RequiresPermissions("project:returnproduct:info")*/
    public R hello(){
        return R.ok().put("data", "hello word!");
    }

    /**
     * 列表
     */
    @GetMapping("/list")
    //@ApiOperation("产品列表")
    /*@RequiresPermissions("project:returnproduct:list")*/
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = returnProductService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @GetMapping("/info/{id}")
    //@ApiOperation("产品详细信息")
    /*@RequiresPermissions("project:returnproduct:info")*/
    public R info(@PathVariable("id") Integer id){
		ReturnProductEntity returnProduct = returnProductService.getById(id);

        return R.ok().put("returnProduct", returnProduct);
    }

    /**
     * 保存
     */
    @PostMapping("/save")
    /*@ApiOperation("添加产品")*/
    /*@RequiresPermissions("project:returnproduct:save")*/
    public R save(@RequestBody ReturnProductEntity returnProduct){
		returnProductService.save(returnProduct);

        return R.ok();
    }

    /**
     * 修改
     */
    @PostMapping("/update")
    //@ApiOperation("删除产品")
    /*@RequiresPermissions("project:returnproduct:update")*/
    public R update(@RequestBody ReturnProductEntity returnProduct){
		returnProductService.updateById(returnProduct);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    /*@ApiOperation("删除产品")*/
    /*@RequiresPermissions("project:returnproduct:delete")*/
    public R delete(@RequestBody Integer[] ids){
		returnProductService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
