package io.renren.modules.receiving_addr.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.modules.app.annotation.Login;
import io.renren.modules.receiving_addr.form.AddrForm;
import io.renren.modules.receiving_addr.form.UpdateAddrForm;
import io.renren.modules.sys.controller.AbstractController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.renren.modules.receiving_addr.entity.ReceivingAddrEntity;
import io.renren.modules.receiving_addr.service.ReceivingAddrService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;

import javax.validation.Valid;


/**
 * @author yyb
 * @email
 * @date 2022-05-17 10:42:40
 */
@RestController
@RequestMapping("applet/addr")
@Api(value = "ReceivingAddrApi", tags = {"收货地址"})
public class ReceivingAddrController extends AbstractController {
    @Autowired
    private ReceivingAddrService receivingAddrService;

    /**
     * 列表
     */
    @Login
    @GetMapping("/list")
//    @RequiresPermissions("receiving_addr:receivingaddr:list")
    @ApiOperation("地址列表 yyb")
    public R list(@RequestAttribute("userId") Integer userId, @RequestParam Map<String, Object> params) {
        params.put("userId", userId);
        PageUtils page = receivingAddrService.queryPage(params);

        return R.ok().put("data", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("receiving_addr:receivingaddr:info")
    public R info(@PathVariable("id") Long id) {
        ReceivingAddrEntity receivingAddr = receivingAddrService.getById(id);

        return R.ok().put("receivingAddr", receivingAddr);
    }

    /**
     * 保存
     */
    @Login
    @PostMapping("/save")
//    @RequiresPermissions("receiving_addr:receivingaddr:save")
    @ApiOperation("新建地址 yyb")
    public R save(@RequestAttribute("userId") Long userId, @Valid @RequestBody AddrForm receivingAddr) {
        receivingAddr.setCreateTime(new Date());
        receivingAddr.setUserId(userId);
        receivingAddrService.save(receivingAddr);

        return R.ok();
    }

    @Login
    @GetMapping("/default")
    @ApiOperation(value = "默认地址 yyb")
    public R getDefault(@RequestAttribute("userId") Long userId) {
        return R.ok().put("data", receivingAddrService.getDefaultAddr(userId));
    }


    /**
     * 修改
     */
    @Login
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @ApiOperation(value = "修改地址")
//    @RequiresPermissions("receiving_addr:receivingaddr:update")
    public R update(@RequestAttribute("userId") Long userId, @Valid @RequestBody UpdateAddrForm receivingAddr) {
        receivingAddr.setUpdateTime(new Date());
        receivingAddr.setUserId(userId);
        receivingAddrService.updateById(receivingAddr);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
//    @RequiresPermissions("receiving_addr:receivingaddr:delete")
    @ApiOperation(value = "删除收货地址")
    public R delete(@RequestBody Long[] ids) {
        receivingAddrService.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
