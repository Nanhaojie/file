package io.renren.modules.project.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.project.entity.ProjectImgEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 *
 *
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-13 16:55:27
 */
@Mapper
public interface ProjectImgDao extends BaseMapper<ProjectImgEntity> {

}
