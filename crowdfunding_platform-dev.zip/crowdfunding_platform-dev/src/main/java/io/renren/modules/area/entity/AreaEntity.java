package io.renren.modules.area.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author nhj
 * @email nhj@gmail.com
 * @date 2022-05-17 10:49:06
 */
@Data
@TableName("tb_area")
public class AreaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId
	private Integer id;
	/**
	 * 
	 */
	private String name;
	/**
	 * 
	 */
	private String fullname;
	/**
	 * 
	 */
	private String location;
	/**
	 * 
	 */
	private Integer pid;
	/**
	 * 
	 */
	private String managename;
	/**
	 * 
	 */
	private Integer level;
	/**
	 * 
	 */
	private Integer sheng;
	/**
	 * 
	 */
	private Integer shi;
	/**
	 * 
	 */
	private Integer xian;

}
