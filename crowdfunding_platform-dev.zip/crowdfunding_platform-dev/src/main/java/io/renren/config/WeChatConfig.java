package io.renren.config;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.security.PrivateKey;

@Component
@Data
@ConfigurationProperties(prefix = "wechat")
public class WeChatConfig {
    public String appid;
    public String appSecret;
    public String mchid;
    public String serialNo;
    public String platSerialNo;
    public String apiV3Key;
    public String privateKey;
    public String publicKey;
    public String certificate;
    public String notifyUrl;
    public String platformCretPath;
}
