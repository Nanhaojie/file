众筹平台
```
Swagger文档路径：http://localhost:8010/renren-fast/swagger/index.html

# 用这一个
Swagger注解路径：http://localhost:8010/renren-fast/swagger-ui.html 
```



```

10服务器
docker run -itd --name crowd_platform -p 8011:8011 --restart always -v /opt/apps/crowdfunding_platform/:/crowdfunding_platform/ java:8 /bin/bash /crowdfunding_platform/entrypoint.sh
```

```
测试线：

docker run -itd --name crowd_platform -p 8011:8011 --restart always -v /data/lib/jenkins/workspace/crowd/:/crowd/ java:8 /bin/bash /crowd/entrypoint_jenkins.sh

```

```
正式线：
docker run -itd --name crowd_platform -p 8011:8011 --restart always -v /opt/release/crowdfunding_platform/:/crowdfunding_platform/ java:8 /bin/bash /crowdfunding_platform/entrypoint.sh
```